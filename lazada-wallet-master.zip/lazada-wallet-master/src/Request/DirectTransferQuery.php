<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet\Request;

class DirectTransferQuery
{
    private string $timestamp;

    public function __construct(
        private string $transferOrderId,
    ) {
        $this->timestamp = \time() . '000';
    }

    public function endpoint(): string
    {
        return '/wallet/transfer/request';
    }

    public function transferOrderId(): string
    {
        return $this->transferOrderId;
    }

    public function timestamp(): string
    {
        return $this->timestamp;
    }

    /**
     * @return array{
     *     transfer_order_id: string,
     *     timestamp: string,
     * }
     */
    public function toArray(): array
    {
        return [
            'transfer_order_id' => $this->transferOrderId(),
            'timestamp' => $this->timestamp(),
        ];
    }
}
