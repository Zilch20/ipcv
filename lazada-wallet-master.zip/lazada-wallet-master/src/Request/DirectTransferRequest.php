<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet\Request;

use IPCV\LazadaWallet\Account;

class DirectTransferRequest
{
    private string $timestamp;

    public function __construct(
        private Account $account,
        private string $transferOrderId,
        private string $transferRequestId,
        private float $amount,
        private float $deposit,
    ) {
        $this->timestamp = \time() . '000';
    }

    public function account(): Account
    {
        return $this->account;
    }

    public function transferOrderId(): string
    {
        return $this->transferOrderId;
    }

    public function transferRequestId(): string
    {
        return $this->transferRequestId;
    }

    public function amount(): float
    {
        return $this->amount;
    }

    public function deposit(): float
    {
        return $this->deposit;
    }

    public function timestamp(): string
    {
        return $this->timestamp;
    }

    /**
     * @return array{
     *     account_number: Account,
     *     transfer_order_id: string,
     *     transfer_request_id: string,
     *     amount: float,
     *     deposit: float,
     *     timestamp: string,
     * }
     */
    public function toArray(): array
    {
        return [
            'account_number' => $this->account(),
            'transfer_order_id' => $this->transferOrderId(),
            'transfer_request_id' => $this->transferRequestId(),
            'amount' => $this->amount(),
            'deposit' => $this->deposit(),
            'timestamp' => $this->timestamp(),
        ];
    }
}
