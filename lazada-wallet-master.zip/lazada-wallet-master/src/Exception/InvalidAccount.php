<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet\Exception;

use Throwable;

class InvalidAccount extends \Exception
{
    public function __construct(string $message = "", int $code = 0, ?Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
