<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet;

use CurlHandle;

interface HttpRequest
{
    public function baseUrl(): string;

    public function setOption(int $option, mixed $value): void;

    public function getInfo(int $option): mixed;

    public function getError(): string;

    public function execute(): string|bool;

    public function close(): void;
}
