<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet;

use CurlHandle;

class CurlRequest implements HttpRequest
{
    public const MY_PROD_URL = 'https://api.lazada.com.my/rest';
    public const TH_PROD_URL = 'https://api.lazada.com.th/rest';
    public const VN_PROD_URL = 'https://api.lazada.com.vn/rest';
    public const ID_PROD_URL = 'https://api.lazada.com.id/rest';
    public const SG_PROD_URL = 'https://api.lazada.com.sg/rest';
    public const PH_PROD_URL = 'https://api.lazada.com.ph/rest';

    private CurlHandle $curlHandle;

    public function __construct(
        private string $baseUrl
    ) {
        $this->curlHandle = \curl_init($this->baseUrl());
    }

    public function baseUrl(): string
    {
        return $this->baseUrl;
    }

    public function setOption(int $option, mixed $value): void
    {
        \curl_setopt($this->curlHandle, $option, $value);
    }

    public function getInfo(int $option): mixed
    {
        return \curl_getinfo($this->curlHandle, $option);
    }

    public function getError(): string
    {
        return  \curl_error($this->curlHandle);
    }

    public function execute(): string|bool
    {
        return \curl_exec($this->curlHandle);
    }

    public function close(): void
    {
        \curl_close($this->curlHandle);
    }
}
