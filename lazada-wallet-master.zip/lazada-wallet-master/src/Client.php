<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet;

use CurlHandle;
use IPCV\LazadaWallet\Request\DirectTransferQuery;
use IPCV\LazadaWallet\Request\DirectTransferRequest;
use IPCV\LazadaWallet\Exception\RequestException;

final class Client
{
    public function __construct(
        private HttpRequest $httpRequest,
        private string $appKey,
        private string $appSecret,
    ) {
        $this->httpRequest->setOption(CURLOPT_HEADER, 0);
        $this->httpRequest->setOption(CURLOPT_RETURNTRANSFER, true);
    }

    public function directTransferQuery(DirectTransferQuery $request): Response
    {
        $endPoint = '/wallet/transfer/query';

        $params = $request->toArray();
        \ksort($params);

        $headers = [];
        $response = $this->prepareAndSendRequest($headers, $params, $endPoint);
        $httpCode = $this->httpRequest->getInfo(CURLINFO_HTTP_CODE);

        return new Response($httpCode, $headers, $response);
    }

    /**
     * @throws RequestException
     */
    public function directTransferRequest(DirectTransferRequest $request): Response
    {
        $endPoint = '/wallet/transfer/request';

        $params = $request->toArray();
        \ksort($params);

        $headers = [];
        $response = $this->prepareAndSendRequest($headers, $params, $endPoint);
        $httpCode = $this->httpRequest->getInfo(CURLINFO_HTTP_CODE);

        return new Response($httpCode, $headers, $response);
    }

    /**
     * @throws RequestException
     */
    private function prepareAndSendRequest(array &$headers, array $params, string $endpoint): string
    {
        $params = $this->addDefaultValuesToParameterArray($params, $endpoint);

        $this->httpRequest->setOption(CURLOPT_HEADERFUNCTION, self::parseHeadersCallable($headers));
        $this->httpRequest->setOption(
            CURLOPT_URL,
            $foo = $this->httpRequest->baseUrl() . $endpoint . '?' . \http_build_query($params)
        );

        $response = $this->httpRequest->execute();

        if (! $response) {
            throw new RequestException($this->httpRequest->getError());
        }

        return $response;
    }

    private static function parseHeadersCallable(array &$headers): callable
    {
        return function (CurlHandle $curlHandle, string $header) use (&$headers) {
            $len = \strlen($header);
            $headerAsArray = \explode(':', $header, 2);

            if (\count($headerAsArray) < 2) {
                return $len;
            }

            $headers[\strtolower(\trim($headerAsArray[0]))][] = \trim($headerAsArray[1]);

            return $len;
        };
    }

    private function generateSign(array $params, string $endPoint, string $signAlgo): string
    {
        $concatenatedParams = \http_build_query($params, arg_separator: '');

        return \hash_hmac(algo: $signAlgo, data: "$endPoint$concatenatedParams", key: $this->appSecret);
    }

    private function addDefaultValuesToParameterArray(array $parameters, string $endpoint): array
    {
        $sign = $this->generateSign($parameters, $endpoint, $signAlgo = 'sha256');

        $parameters['app_key'] = $this->appKey;
        $parameters['sign'] = $sign;
        $parameters['sign_method'] = $signAlgo;

        return $parameters;
    }
}
