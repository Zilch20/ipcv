<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet;

use IPCV\LazadaWallet\Exception\InvalidAccount;

final class Account implements \Stringable
{
    private function __construct(
        private string $account
    ) {
    }

    /**
     * @throws InvalidAccount
     */
    public static function createMobile(string $mobileNumber): Account
    {
        if (!\preg_match('/^09\d{9}$/', $mobileNumber)) {
            throw new InvalidAccount("Invalid mobile number.");
        }

        return new Account($mobileNumber);
    }

    /**
     * @throws InvalidAccount
     */
    public static function createEmail(string $email): Account
    {
        if (!\filter_var(value: $email, filter: FILTER_VALIDATE_EMAIL)) {
            throw new InvalidAccount("Invalid email.");
        }

        return new Account($email);
    }

    public function __toString(): string
    {
        return $this->account;
    }
}
