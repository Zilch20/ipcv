<?php

declare(strict_types=1);

namespace IPCV\LazadaWallet;

use JsonException;

final class Response
{
    public function __construct(
        private int $statusCode,
        private array $headers = [],
        private string $body = '',
    ) {
    }

    public function statusCode(): int
    {
        return $this->statusCode;
    }

    /**
     * @return array<string, array<int, string>>
     */
    public function headers(): array
    {
        return $this->headers;
    }

    public function bodyRaw(): string
    {
        return $this->body;
    }

    /**
     * @throws JsonException
     */
    public function body(): array
    {
        return \json_decode($this->body, true, 512, JSON_THROW_ON_ERROR);
    }
}
