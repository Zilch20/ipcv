<?php

namespace spec\IPCV\LazadaWallet\Exception;

use IPCV\LazadaWallet\Exception\InvalidAccount;
use PhpSpec\ObjectBehavior;

class InvalidAccountSpec extends ObjectBehavior
{
    function it_is_initializable()
    {
        $this->shouldHaveType(InvalidAccount::class);
    }
}
