<?php

namespace spec\IPCV\LazadaWallet\Request;

use IPCV\LazadaWallet\Request\DirectTransferQuery;
use PhpSpec\ObjectBehavior;
use Prophecy\Argument;

/**
 * @mixin DirectTransferQuery
 */
class DirectTransferQuerySpec extends ObjectBehavior
{
    private string $transferOrderId;

    function let()
    {
        $this->beConstructedWith($this->transferOrderId = 'foo-id', 0.0);
    }

    function it_is_initializable()
    {
        $this->shouldHaveType(DirectTransferQuery::class);
    }

    function it_should_return_its_defaults()
    {
        $this->endpoint()->shouldBe('/wallet/transfer/request');
        $this->transferOrderId()->shouldBe($this->transferOrderId);
        $this->timestamp()->shouldBeString();
    }

    function it_should_return_its_array_form()
    {
        $this->toArray()->shouldBe([
            'transfer_order_id' => $this->transferOrderId(),
            'timestamp' => $this->timestamp()
        ]);
    }
}
