<?php

namespace spec\IPCV\LazadaWallet\Request;

use IPCV\LazadaWallet\Account;
use IPCV\LazadaWallet\Request\DirectTransferRequest;
use PhpSpec\ObjectBehavior;

/**
 * @mixin DirectTransferRequest
 */
class DirectTransferRequestSpec extends ObjectBehavior
{
    function let()
    {
        $this->beConstructedWith(
            Account::createEmail('fooAccount@lazada.com'),
            'transfer_order_id_1',
            'transfer_request_id_1',
            500.25,
            1000.50
        );
    }

    function it_is_initializable()
    {
        $this->shouldHaveType(DirectTransferRequest::class);
    }

    function it_should_return_its_defaults()
    {
        $this->account()->shouldBeLike($account = Account::createEmail('fooAccount@lazada.com'));
        $this->transferOrderId()->shouldBe('transfer_order_id_1');
        $this->transferRequestId()->shouldBe('transfer_request_id_1');
        $this->amount()->shouldBe(500.25);
        $this->deposit()->shouldBe(1000.50);
    }

    public function it_should_return_its_array_form()
    {
        $this->toArray()->shouldBe([
            'account_number' => $this->account(),
            'transfer_order_id' => $this->transferOrderId(),
            'transfer_request_id' => $this->transferRequestId(),
            'amount' => $this->amount(),
            'deposit' => $this->deposit(),
            'timestamp' => $this->timestamp(),
        ]);
    }
}
