<?php

namespace spec\IPCV\LazadaWallet;

use IPCV\LazadaWallet\Account;
use IPCV\LazadaWallet\Client;
use IPCV\LazadaWallet\CurlRequest;
use IPCV\LazadaWallet\HttpRequest;
use IPCV\LazadaWallet\Request\DirectTransferQuery;
use IPCV\LazadaWallet\Request\DirectTransferRequest;
use IPCV\LazadaWallet\Response;
use PhpSpec\ObjectBehavior;
use Prophecy\Argument;

/**
 * @mixin Client
 */
class ClientSpec extends ObjectBehavior
{
    function let(HttpRequest $httpRequest)
    {
        $this->beConstructedWith($httpRequest, 'app-key', 'app-secret');
    }

    function it_is_initializable()
    {
        $this->shouldHaveType(Client::class);
    }

    function it_should_do_direct_transfer_request(HttpRequest $httpRequest)
    {
        $fakeResponse = [
            'account_number' => 'lzd_test_001@tom.com',
            'amount' => '0.01',
            'code' => '0',
            'transfer_order_id' => 'test001',
            'transfer_request_id' => 'open_100100_test001_id',
            'deposit' => '99.99',
            'request_id' => '0ba2887315178178017221014',
        ];

        $httpRequest->setOption(CURLOPT_HEADER, 0)->shouldBeCalledOnce();
        $httpRequest->setOption(CURLOPT_RETURNTRANSFER, true)->shouldBeCalledOnce();
        $httpRequest->setOption(CURLOPT_HEADERFUNCTION, Argument::type('callable'));

        $httpRequest->baseUrl()->shouldBeCalledOnce()->willReturn(CurlRequest::PH_PROD_URL);
        $httpRequest->setOption(CURLOPT_URL, Argument::type('string'));

        $httpRequest->execute()->shouldBeCalledOnce()->willReturn($responseAsString = \json_encode($fakeResponse));
        $httpRequest->getInfo(CURLINFO_HTTP_CODE)->shouldBeCalledOnce()->willReturn($responseCode = 200);

        $request = new DirectTransferRequest(
            Account::createEmail('foo@email.com'),
            'test001',
            'open_100100_test001_id',
            0.01,
            99.99
        );

        $response = $this->directTransferRequest($request);

        $response->statusCode()->shouldBe($responseCode);
        $response->bodyRaw()->shouldBe($responseAsString);
        $response->body()->shouldBe($fakeResponse);
    }

    function it_should_do_direct_transfer_query(HttpRequest $httpRequest)
    {
        $fakeResponse = [
            'account_number' => '09160000001',
            'amount' => '0.01',
            'code' => '0',
            'transfer_order_id' => 'test001',
            'transfer_request_id' => 'open_105400_test001_id',
            'deposit' => '99.99',
            'request_id' => '0ba2887315178178017221014',
        ];

        $httpRequest->setOption(CURLOPT_HEADER, 0)->shouldBeCalledOnce();
        $httpRequest->setOption(CURLOPT_RETURNTRANSFER, true)->shouldBeCalledOnce();
        $httpRequest->setOption(CURLOPT_HEADERFUNCTION, Argument::type('callable'));

        $httpRequest->baseUrl()->shouldBeCalledOnce()->willReturn(CurlRequest::PH_PROD_URL);
        $httpRequest->setOption(CURLOPT_URL, Argument::type('string'));

        $httpRequest->execute()->shouldBeCalledOnce()->willReturn($responseAsString = \json_encode($fakeResponse));
        $httpRequest->getInfo(CURLINFO_HTTP_CODE)->shouldBeCalledOnce()->willReturn($responseCode = 200);

        $request = new DirectTransferQuery(Account::createEmail('foo@email.com'));

        $response = $this->directTransferQuery($request);
        $response->statusCode()->shouldBe(200);
        $response->bodyRaw()->shouldBe($responseAsString);
        $response->body()->shouldBe($fakeResponse);
    }
}
