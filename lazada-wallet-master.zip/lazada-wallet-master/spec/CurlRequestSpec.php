<?php

namespace spec\IPCV\LazadaWallet;

use IPCV\LazadaWallet\CurlRequest;
use IPCV\LazadaWallet\HttpRequest;
use PhpSpec\ObjectBehavior;

/**
 * @mixin CurlRequest
 */
class CurlRequestSpec extends ObjectBehavior
{
    function let()
    {
        $this->beConstructedWith(CurlRequest::PH_PROD_URL);
    }

    function it_should_return_base_url()
    {
        $this->baseUrl()->shouldBe(CurlRequest::PH_PROD_URL);
    }
}
