<?php

namespace spec\IPCV\LazadaWallet;

use IPCV\LazadaWallet\Account;
use IPCV\LazadaWallet\Exception\InvalidAccount;
use PhpSpec\ObjectBehavior;

/**
 * @mixin Account
 */
class AccountSpec extends ObjectBehavior
{
    function it_is_initializable()
    {
        $this->shouldHaveType(Account::class);
    }

    function it_should_be_created_as_mobile()
    {
        $this->beConstructedThrough('createMobile', [$mobile = '09123456789']);
        $this->__toString()->shouldBe($mobile);
    }

    function it_should_throw_on_invalid_mobile()
    {
        $this->beConstructedThrough('createMobile', ['69123456789']);
        $this->shouldThrow(InvalidAccount::class)->duringInstantiation();
    }

    function it_should_throw_on_invalid_email()
    {
        $this->beConstructedThrough('createEmail', ['email@ng@ina@mo']);
        $this->shouldThrow(InvalidAccount::class)->duringInstantiation();
    }

    function it_should_be_created_as_email()
    {
        $this->beConstructedThrough('createEmail', [$email = 'foo@email.com']);
        $this->__toString()->shouldBe($email);
    }
}
