<?php

return [
    'secret' => \env('JWT_SECRET', 'tDMSgRH7mtK7ZApSyxdkFnhzYq4oSTbRgmSTZiCDt5Y='),
    'expiry_in_seconds' => \env('JWT_EXPIRY_IN_SECONDS', 3600),
];
