<?php

namespace App\Services;

use Illuminate\Contracts\Auth\Authenticatable;

interface AuthService
{
    public function authenticate(Authenticatable $user): string;
}
