<?php

declare(strict_types=1);

namespace App\Services\Auth;

use App\Services\AuthService;
use Illuminate\Contracts\Auth\Authenticatable;
use Lcobucci\JWT\Builder;
use Lcobucci\JWT\Signer\Hmac\Sha256;
use Lcobucci\JWT\Signer\Key\InMemory;

class JwtAuthService implements AuthService
{
    public function __construct(
        private readonly Builder $builder,
        private readonly string $jwtSecret,
    ) {
    }

    public function authenticate(Authenticatable $user): string
    {
        $token = $this->builder
            ->withClaim('user_uuid', $user->user_uuid)
            ->getToken(new Sha256(), InMemory::plainText($this->jwtSecret))
        ;

        return $token->toString();
    }
}
