<?php

namespace App\Providers;

use App\Services\Auth\JwtAuthService;
use App\Services\AuthService;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Lcobucci\JWT\Encoding\ChainedFormatter;
use Lcobucci\JWT\Encoding\JoseEncoder;
use Lcobucci\JWT\Token\Builder;
use Ramsey\Uuid\Uuid;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * Register any authentication / authorization services.
     */
    public function boot(): void
    {
        $this->registerPolicies();

        $this->app->bind(AuthService::class, fn(Application $app) =>
            new JwtAuthService(self::createJwtTokenBuilder(), config('jwt.secret'))
        );
    }

    /**
     * @throws \Exception
     */
    private static function createJwtTokenBuilder(): Builder
    {
        $builder = new Builder(new JoseEncoder(), ChainedFormatter::default());

        return $builder
            ->issuedBy(\config('app.name') . '_' . \config('app.env'))
            ->identifiedBy(Uuid::uuid4())
            ->issuedAt($now = new \DateTimeImmutable())
            ->canOnlyBeUsedAfter($now)
            ->expiresAt($now->modify(\sprintf('+%s seconds', config('jwt.expiry_in_seconds'))))
        ;
    }
}
