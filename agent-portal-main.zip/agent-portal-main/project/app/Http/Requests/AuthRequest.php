<?php

declare(strict_types=1);

namespace App\Http\Requests;

class AuthRequest extends BaseFormRequest
{
    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'email' => ['required'],
            'password' => ['required'],
            'remember_me' => ['boolean'],
        ];
    }
}
