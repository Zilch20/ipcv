<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\AuthRequest;
use App\Models\User;
use App\Services\AuthService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class AuthController extends Controller
{
    public function __construct(private readonly AuthService $authService)
    {
    }

    public function __invoke(AuthRequest $request): Response
    {
        $user = $this->findUser($request->input('email'));

        if (null === $user) {
            return new Response(null, Response::HTTP_UNAUTHORIZED);
        }

        if (false === $this->checkPassword($user, $request->input('password'))) {
            return new Response(null, Response::HTTP_UNAUTHORIZED);
        }

        $token = $this->authService->authenticate($user);

        return new JsonResponse(['token' => $token]);
    }

    /**
     * @return Model<User>|null
     */
    private function findUser(string $email): ?User
    {
        return User::query()->where(column: 'email', operator: '=', value: $email)->first();
    }

    private function checkPassword(User $user, string $password): bool
    {
        return Hash::check(value: $password, hashedValue: $user->getAuthPassword());
    }
}
