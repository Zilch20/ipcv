CURRENTUSER=`whoami`
if [ "$CURRENTUSER" = "root" ]; then
  PS1='\[\033[01;31m\]\u@$SERVICE_NAME\[\033[01;34m\] \W \$\[\033[00m\] '
else
  PS1='\[\033]0;\u@\h:\w\007\]\[\033[01;32m\]\u@\h\[\033[01;34m\] \w \$\[\033[00m\] '
fi

alias ls='ls --color=auto';
