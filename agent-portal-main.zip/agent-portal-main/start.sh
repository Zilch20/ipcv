#!/bin/bash

## Initialize var (project)
test -v HOST_UID \
    && cd "/var/project/" \
    && { mkdir var/ || true; } \
    && { mkdir vendor/ || true; } \
    && setfacl -dR -m u:www-data:rwX -m u:$HOST_UID:rwX storage/ bootstrap/cache/ \
    && setfacl -R -m u:www-data:rwX -m u:$HOST_UID:rwX storage/ bootstrap/cache/;

## Start supervisord
/usr/bin/supervisord -c /etc/supervisord.conf;
