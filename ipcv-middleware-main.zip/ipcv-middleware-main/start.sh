#!/bin/bash

## Initialize var (project)
test -v HOST_UID \
    && cd "/var/project/" \
    && { mkdir var/ || true; } \
    && { mkdir vendor/ || true; } \
    && setfacl -dR -m u:www-data:rwX -m u:$HOST_UID:rwX var/ vendor/ \
    && setfacl -R -m u:www-data:rwX -m u:$HOST_UID:rwX var/ vendor/ \;

## Initialize environment variables
echo '#!/bin/bash' > /etc/profile.d/zz-00-env.sh \
  && declare -p | grep -Ev 'BASHOPTS|BASH_VERSINFO|EUID|PPID|SHELLOPTS|UID' >> /etc/profile.d/zz-00-env.sh;

/usr/local/sbin/php-fpm
