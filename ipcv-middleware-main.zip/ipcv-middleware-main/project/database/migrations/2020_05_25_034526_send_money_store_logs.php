<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SendMoneyStoreLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('send_money_store_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('mtcn')->nullable();
            $table->string('senderName')->nullable();
            $table->string('address')->nullable();
            $table->string('city')->nullable();
            $table->string('province')->nullable();
            $table->integer('postalCode')->nullable();
            $table->string('idNum')->nullable();
            $table->string('issueDate')->nullable();
            $table->string('expiration')->nullable();
            $table->string('birthDate')->nullable();
            $table->string('occupation')->nullable();
            $table->string('transactionReason')->nullable();
            $table->string('gender')->nullable();
            $table->string('fundSource')->nullable();
            $table->string('relationshiptoReceiver')->nullable();
            $table->string('positionLevel')->nullable();
            $table->string('phoneNum')->nullable();
            $table->string('accountNumber')->nullable();
            $table->string('receiverName')->nullable();
            $table->string('currencyCode')->nullable();
            $table->string('destinationCountry')->nullable();
            $table->string('destinationCurrencyCode')->nullable();
            $table->string('amount')->nullable();
            $table->string('new_mtcn')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('SendMoneyStoreLogs');
    }
}
