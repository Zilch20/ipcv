<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColumnsToSubAgentManagementTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sub_agent_management_table', function (Blueprint $table) {
            $table->string('client_id')->after('branchLocation');
            $table->string('client_secret')->after('branchLocation');
            $table->boolean('is_active')->after('branchLocation');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sub_agent_management_table', function (Blueprint $table) {
            //
        });
    }
}
