<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('country_currencies', static function (Blueprint $table) {
            $table->id();
            $table->string('country_long')->index();
            $table->string('iso_country_num_cd');
            $table->string('iso_country_cd')->index();
            $table->string('iso_currency_num_cd');
            $table->string('currency_cd')->index();
            $table->string('currency_name');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('country_currencies');
    }
};
