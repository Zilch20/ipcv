<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddAgentDetailsToSendLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('send_money_store_logs', function (Blueprint $table) {
            $table->string('agentName')->nullable();
            $table->string('ftid')->nullable();
            $table->string('branchLocation')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('send_money_store_logs', function (Blueprint $table) {
            //
        });
    }
}
