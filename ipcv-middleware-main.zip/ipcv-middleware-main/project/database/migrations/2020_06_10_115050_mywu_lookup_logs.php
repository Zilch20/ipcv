<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class MywuLookupLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mywu_lookup_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('client_id')->nullable();
            $table->string('senderCountryCode')->nullable();
            $table->string('loyaltyCardUpdateIndicator')->nullable();
            $table->string('permanentChange')->nullable();
            $table->string('myWuNumber')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
