<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddtosendMoneyStoreLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('send_money_store_logs', function (Blueprint $table) {
            $table->string('destinationAmount')->nullable();
            $table->string('grossTotalAmount')->nullable();
            $table->string('plusChargesAmount')->nullable();
            $table->string('charges')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('send_money_store_logs', function (Blueprint $table) {
            //
        });
    }
}
