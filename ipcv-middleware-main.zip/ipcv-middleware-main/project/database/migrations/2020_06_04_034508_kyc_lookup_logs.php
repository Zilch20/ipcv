<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class KycLookupLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('kyc_lookup_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('myWuNumber')->nullable();
            $table->string('clientId')->nullable();
            $table->string('transactionType')->nullable();
            $table->string('pfcFilter')->nullable();
            $table->string('searchType')->nullable();
            $table->string('firstName')->nullable();
            $table->string('lastName')->nullable();
            $table->string('idType')->nullable();
            $table->string('idNum')->nullable();
            $table->string('phoneNum')->nullable();

            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
