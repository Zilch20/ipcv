<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class PayStatusInquiryLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pay_status_inquiry_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('mtcn')->nullable();
            $table->string('clientId')->nullable();
            $table->string('recordingCountryCode')->nullable();
            $table->string('recordingCountryCurrencyCode')->nullable();
            $table->string('payWoIdIndicator')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
