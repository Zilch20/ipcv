<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddNewRequesttoFeeInquiryLog extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('fee_inquiry_logs', function (Blueprint $table) {   
            $table->string('destinationAmount')->nullable();
            $table->string('transactionType')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('fee_inquiry_logs', function (Blueprint $table) {
            //
        });
    }
}
