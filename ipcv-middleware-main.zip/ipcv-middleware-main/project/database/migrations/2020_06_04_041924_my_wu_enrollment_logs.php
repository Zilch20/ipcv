<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class MyWuEnrollmentLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('my_wu_enrollment_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('clientId')->nullable();
            $table->string('firstName')->nullable();
            $table->string('lastName')->nullable();
            $table->string('address')->nullable();
            $table->string('city')->nullable();
            $table->string('postalCode')->nullable();
            $table->string('countryCode')->nullable();
            $table->string('currencyCode')->nullable();
            $table->string('phoneNum')->nullable();
            $table->string('gender')->nullable();
            $table->string('senderCurrencyCode')->nullable();
            $table->string('destinationCountryCode')->nullable();
            $table->string('destinationCurrencyCode')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
