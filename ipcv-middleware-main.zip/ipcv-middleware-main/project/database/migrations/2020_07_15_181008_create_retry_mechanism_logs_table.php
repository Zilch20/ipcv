<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRetryMechanismLogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('retry_mechanism_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('client_id')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('error_xml_response')->nullable();
            $table->string('galactic_id')->nullable();
            $table->string('account_nbr')->nullable();
            $table->string('mtcn')->nullable();
            $table->string('mtcn_digest')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('retry_mechanism_logs');
    }
}
