<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddNewRequesttoReceiveMoneyPayLog extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('receive_money_pay_logs', function (Blueprint $table) {
            $table->string('countryName')->nullable();
            $table->string('receiverCountryCode')->nullable();
            $table->string('receiverCountryCurrencyCode')->nullable();
            $table->string('idCountryIssued')->nullable();
            $table->string('countryofBirth')->nullable();
            $table->string('transactionType')->nullable();
            $table->string('mtk')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('receive_money_pay_logs', function (Blueprint $table) {
            //
        });
    }
}
