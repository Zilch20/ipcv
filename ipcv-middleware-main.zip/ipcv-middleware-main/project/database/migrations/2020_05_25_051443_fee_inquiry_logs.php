<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class FeeInquiryLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('fee_inquiry_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('currencyCode')->nullable();
            $table->string('destinationCountry')->nullable();
            $table->string('destinationCurrencyCode')->nullable();
            $table->string('amount')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
