<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DasRequestLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('das_request_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('clientId')->nullable();
            $table->string('dasRequest')->nullable();
            $table->string('queryFilter1')->nullable();
            $table->string('queryFilter2')->nullable();
            $table->string('queryFilter3')->nullable();
            $table->string('queryFilter4')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
