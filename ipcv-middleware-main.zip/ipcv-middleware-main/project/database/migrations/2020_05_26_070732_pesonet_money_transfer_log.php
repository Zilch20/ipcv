<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class PesonetMoneyTransferLog extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pesonet_transfer_money_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('client_id')->nullable();
            $table->string('referenceID')->nullable();
            $table->string('sender_name')->nullable();
            $table->string('sender_addr_line1')->nullable();
            $table->string('sender_addr_line2')->nullable();
            $table->string('sender_city')->nullable();
            $table->string('sender_province')->nullable();
            $table->string('sender_zipCode')->nullable();
            $table->string('sender_country')->nullable();
            $table->string('beneficiary_acct_number')->nullable();
            $table->string('beneficiary_name')->nullable();
            $table->string('beneficiary_addr_line1')->nullable();
            $table->string('beneficiary_addr_line2')->nullable();
            $table->string('beneficiary_city')->nullable();
            $table->string('beneficiary_province')->nullable();
            $table->string('beneficiary_zipCode')->nullable();
            $table->string('beneficiary_country')->nullable();
            $table->string('amount')->nullable();
            $table->string('currency')->nullable();
            $table->string('receivingBank')->nullable();
            $table->string('purpose')->nullable();
            $table->string('instructions')->nullable();
            $table->json('request_data')->nullable();
            $table->longText('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
