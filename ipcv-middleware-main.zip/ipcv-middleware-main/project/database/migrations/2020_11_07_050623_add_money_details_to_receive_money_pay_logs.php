<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddMoneyDetailsToReceiveMoneyPayLogs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('receive_money_pay_logs', function (Blueprint $table) {
            $table->string('grossTotalAmount')->nullable();
            $table->string('principalAmount')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('receive_money_pay_logs', function (Blueprint $table) {
            //
        });
    }
}
