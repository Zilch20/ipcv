<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class InstapayTransferMoneyLog extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('instapay_transfer_money_logs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('client_id')->nullable();

            $table->string('senderReference')->nullable();
            $table->string('amount')->nullable();
            $table->string('purpose')->nullable();
            $table->string('receiverType')->nullable();

            $table->string('senderAccountName')->nullable();
            $table->string('senderAccountNumber')->nullable();
            $table->string('senderMobileNumber')->nullable();
            $table->string('senderEmail')->nullable();
            $table->string('senderAddress')->nullable();
            $table->string('senderBarangay')->nullable();
            $table->string('senderCity')->nullable();
            $table->string('senderZipCode')->nullable();

            $table->string('receiverAccountName')->nullable();
            $table->string('receiverAccountNumber')->nullable();
            $table->string('receiverMobileNumber')->nullable();
            $table->string('receiverEmail')->nullable();
            $table->string('receiverAddress')->nullable();
            $table->string('receiverBarangay')->nullable();
            $table->string('receiverCity')->nullable();
            $table->string('receiverZipCode')->nullable();
            $table->string('receiverBankName')->nullable();
            $table->string('receverBankCode')->nullable();
            $table->string('receiverGender')->nullable();
            $table->string('receiverBirthDate')->nullable();
            
            $table->string('representativeFirstName')->nullable();
            $table->string('representativeMiddleName')->nullable();
            $table->string('representativeLastName')->nullable();
            $table->string('representativeSuffix')->nullable();
            
            $table->json('request_data')->nullable();
            $table->json('reply_data')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
