<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddNewRequesttoSendMoneyStoreLog extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('send_money_store_logs', function (Blueprint $table) {
            $table->string('countryName')->nullable();
            $table->string('senderCountryCode')->nullable();
            $table->string('senderCountryCurrencyCode')->nullable();
            $table->string('idCountryIssued')->nullable();
            $table->string('countryofBirth')->nullable();
            $table->string('transactionType')->nullable();
            $table->string('paymentType')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('send_money_store_logs', function (Blueprint $table) {
            //
        });
    }
}
