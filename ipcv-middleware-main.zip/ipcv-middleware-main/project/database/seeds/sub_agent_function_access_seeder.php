<?php

use Illuminate\Database\Seeder;
use App\SubAgentFuntionAccess;

class sub_agent_function_access_seeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $ipcvAccess = new SubAgentFuntionAccess();
        $ipcvAccess->branchOwner = 'IPCV';
        $ipcvAccess->description = 'Can Use All Functions';
        $ipcvAccess->save();

        $expresspayAccess = new SubAgentFuntionAccess();
        $expresspayAccess->branchOwner = 'EXPRESSPAY';
        $expresspayAccess->description = 'Can Use All Functions';
        $expresspayAccess->save();

        $gprsAccess = new SubAgentFuntionAccess();
        $gprsAccess->branchOwner = 'GPRS';
        $gprsAccess->description = 'Can Use All Functions';
        $gprsAccess->save();

        $pisopayAccess = new SubAgentFuntionAccess();
        $pisopayAccess->branchOwner = 'PISOPAY';
        $pisopayAccess->description = 'Can Use All Functions Except MyWU';
        $pisopayAccess->save();

        $bocAccess = new SubAgentFuntionAccess();
        $bocAccess->branchOwner = 'BOC';
        $bocAccess->description = 'Can Use Receive Functions';
        $bocAccess->save();
    }
}
