<?php

use App\User;

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new User();
        $user->id = 1;
        $user->name = 'Dave';
        $user->email = 'dave@test.com';
        $user->password = app('hash')->make('devTest1234');
        $user->phone_number = '+639171234567';
        $user->save();

        // $user = new User();
        // $user->id = 2;
        // $user->name = 'Dave B. Mercado';
        // $user->email = 'dave.mercado@test.com';
        // $user->password = '$2y$10$CAWWUOPzWjgX0SWGoWMhcOdFL5smvS6Z4MP1Az.bNOm7gC77bqpDS';
        // $user->phone_number = '+639178940784';
        // $user->save();

        // $user = new User();
        // $user->id = 3;
        // $user->name = 'Dave B. Mercado';
        // $user->email = 'dave.mercado@test2.com';
        // $user->password = '$2y$10$iBDt8gk7OC2wa.cERsd9junK8I7VJBh0VNuZp90P59z5Hde1DE2X6';
        // $user->phone_number = '+639177654321';
        // $user->save();

        $user = new User();
        $user->id = 4;
        $user->name = 'SmarTech';
        $user->email = 'SmarTech@test.com';
        $user->password = '$2y$10$O1ulmvyEzz97/IHNc7G2Te3/SHvE.HFePjK/IWHEN1NB2oDv2D3XO';
        $user->phone_number = '+None';
        $user->save();

        $user = new User();
        $user->id = 6;
        $user->name = 'Admin Tool';
        $user->email = 'AdminTool@test.com';
        $user->password = '$2y$10$EE.Mgyj2eZL/.cSUKACwa.LqMOKT4/M3GrQcSdaxdBZfd626IMWD6';
        $user->phone_number = '+empty';
        $user->save();

        $user = new User();
        $user->id = 7;
        $user->name = 'Eplata';
        $user->email = 'eplata@test.com';
        $user->password = '$2y$10$rf4AuCFDxms0tJ.qAHoP0uBDFEeTwPNLW.grNxUX734GReBOyCite';
        $user->phone_number = '+empty2';
        $user->save();

        $user = new User();
        $user->id = 8;
        $user->name = 'AdminTool';
        $user->email = 'Admin_Tool@test.com';
        $user->password = '$2y$10$4UPIWiRNKUAI.gKaNAmfIOSjef9vt0CGBOYt6RNTEaqC66E5.q4z.';
        $user->phone_number = '+zero';
        $user->save();

        $user = new User();
        $user->id = 9;
        $user->name = 'bankcomTest';
        $user->email = 'bankcom@test.com';
        $user->password = '$2y$10$ePXSQYOXkY6yGaJXXi7.9.K4cYrTyaVGJLzhqw1vM3I6EZJFfwC7e';
        $user->phone_number = '+non';
        $user->save();

        $user = new User();
        $user->id = 10;
        $user->name = 'bankcomTest';
        $user->email = 'bankcom1@test.com';
        $user->password = '$2y$10$fbla8XdL3MMpbL11PPHvcuUEX6Xs8gYlFcF6LT4JSmBZUuJAlOoTm';
        $user->phone_number = '+NotNeeded';
        $user->save();

        $user = new User();
        $user->id = 11;
        $user->name = 'adam';
        $user->email = 'adam@sdsolutions.com.ph';
        $user->password = app('hash')->make('HiOV73hvv94V');
        $user->phone_number = '+none_adam';
        $user->save();
    }
}
