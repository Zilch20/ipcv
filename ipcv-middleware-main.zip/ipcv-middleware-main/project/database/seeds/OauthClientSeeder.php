<?php

use App\oauth_clients;

use Illuminate\Database\Seeder;

class OauthClientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $oauth = new oauth_clients();
        $oauth->id = 2;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'KTRHEWoUAfKFqbI9bBbpyzCCeVy28ww2G8ePDUHt';
        $oauth->redirect = 'http://54.169.246.165';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 4;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'xpqNOrWVUo1Q8sU2OQzEPbRTLNdviqP9hDDRXESJ';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 5;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'WOJffX2qhZuQXuSeBfCkYM0VXsA568Xo9tZNjZ4E';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 6;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = '14WfCIBJLEcTLyHe9eA8hQxFs8I2I5h6fBvf423U';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 7;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'e0u6cefNbnmunAbewaMndDHfo8HyUeusJ1Em5m1t';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 10;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'iiarGSPvNCduTcBsmDN1O5mlCrskSClcnyZ7QIPX';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 11;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'vYJ921ZR6ysgpQXEJTblMwOQYuj4mfij1GSZwO1O';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 12;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'ye2iEUOqemK7hPFH6QqcowToqFh6sVlaWI1FK1Dm';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 13;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = '1GKgqyY5tSGWHSIz8XrABXsiSJZipd6L7yImbnR2';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 14;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'KWdrJ0x1wVNIhckRGHhBaAyO37NLTcYydnss1vEI';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = '22';
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'KD0oYPac3VkBef4Px1nfxdWlBdc3MP0FnNsmsCYg';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 15;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'IZYeXPn1XTNIbFc2jbt3Y4oOH8VdA4RA3XWiT9Si';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 17;
        $oauth->name = 'Password Grant Client (Pisopay)';
        $oauth->secret = 'iiarGSPvNCduTcBsmDN1O5mlCrskSClcnyZ7QIPX';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = 18;
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'vYJ921ZR6ysgpQXEJTblMwOQYuj4mfij1GSZwO1O';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();
    }
}
