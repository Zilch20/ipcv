<?php

use App\Repositories\Aws\S3Repository;
use Aws\ResultInterface;
use Aws\S3\S3ClientInterface;

class S3RepositoryTest extends TestCase
{
    public function test_it_should_upload_object(): void
    {
        $s3Client = Mockery::mock(S3ClientInterface::class);
        $expectedResult = Mockery::mock(ResultInterface::class);
        $bucketName = 'bucket-meal';
        $fileName = 'sapnu.jpg';
        $file = new SplFileInfo($fileName);

        $repository = new S3Repository($s3Client, $bucketName);

        $s3Client
            ->shouldReceive('upload')
            ->withArgs([$bucketName, $fileName, $file])
            ->once()
            ->andReturn($expectedResult)
        ;

        $result = $repository->uploadObject($file, $fileName);

        $this->assertEquals($expectedResult, $result);
    }
}
