<?php

class ExampleTest extends TestCase
{
    /**
     * A basic test example.
     */
    public function testExample(): void
    {
        $this->get('/');

        $this->assertEquals(
            \json_encode(['message' => 'IPCV Middleware API'], JSON_THROW_ON_ERROR), $this->response->getContent()
        );
    }
}
