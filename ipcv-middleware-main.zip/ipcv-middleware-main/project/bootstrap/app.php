<?php

declare(strict_types=1);

use App\Providers\FormRequestServiceProvider;
use App\Providers\WesternUnionServiceProvider;
use App\Repositories\Aws\S3Repository;
use Aws\S3\S3Client;
use Aws\S3\S3ClientInterface;
use Laravel\Passport\Http\Middleware\CheckClientCredentials;

require_once __DIR__ . '/../vendor/autoload.php';

(new Laravel\Lumen\Bootstrap\LoadEnvironmentVariables(
    dirname(__DIR__)
))->bootstrap();

/*
|--------------------------------------------------------------------------
| Create The Application
|--------------------------------------------------------------------------
|
| Here we will load the environment and create the application instance
| that serves as the central piece of this framework. We'll use this
| application as an "IoC" container and router for this framework.
|
*/

$app = new Laravel\Lumen\Application(
    dirname(__DIR__)
);

$app->withFacades();
$app->withEloquent();

$app->configure('app');
$app->configure('config/auth');
$app->configure('country');
$app->configure('aws');
$app->configure('api_environment');
$app->configure('IpayConfig/services');
$app->configure('subagentftid');
$app->configure('unionbankbankcode');
$app->configure("data");
$app->configure('western_union');

/*
|--------------------------------------------------------------------------
| Register Container Bindings
|--------------------------------------------------------------------------
|
| Now we will register a few bindings in the service container. We will
| register the exception handler and the console kernel. You may add
| your own bindings here if you like or you can make another file.
|
*/

$app->singleton(
    Illuminate\Contracts\Debug\ExceptionHandler::class,
    App\Exceptions\Handler::class
);

$app->singleton(
    Illuminate\Contracts\Console\Kernel::class,
    App\Console\Kernel::class
);

$app->singleton(
    S3ClientInterface::class,
    fn() => (new S3Client([
        'region' => config('aws.s3.region'),
        'credentials' => array(
            'key' => config('aws.s3.access_key'),
            'secret' => config('aws.s3.secret_key')
        ),
        'version' => '2006-03-01'
    ]))
);

$app->singleton(
    S3Repository::class,
    fn() => new S3Repository(
        $app->get(S3ClientInterface::class),
        bucket: config('aws.s3.bucket'),
        directory: 'id-photos'
    )
);

/*
|--------------------------------------------------------------------------
| Register Middleware
|--------------------------------------------------------------------------
|
| Next, we will register the middleware with the application. These can
| be global middleware that run before and after each request into a
| route or middleware that'll be assigned to some specific routes.
|
*/
$app->routeMiddleware([
    'auth' => App\Http\Middleware\Authenticate::class,
]);

/*
|--------------------------------------------------------------------------
| Register Service Providers
|--------------------------------------------------------------------------
|
| Here we will register all of the application's service providers which
| are used to bind services into the container. Service providers are
| totally optional, so you are not required to uncomment this line.
|
*/
$app->register(FormRequestServiceProvider::class);
$app->register(App\Providers\AuthServiceProvider::class);
$app->register(Laravel\Passport\PassportServiceProvider::class);
$app->register(Dusterio\LumenPassport\PassportServiceProvider::class);
$app->register(WesternUnionServiceProvider::class);

Dusterio\LumenPassport\LumenPassport::routes($app->router, ['app' => 'api/v1/oauth']);

/*
|--------------------------------------------------------------------------
| Load The Application Routes
|--------------------------------------------------------------------------
|
| Next we will include the routes file so that they can all be added to
| the application. This will provide all of the URLs the application
| can respond to, as well as the controllers that may handle them.
|
*/

$app->router->group([
    'namespace' => 'App\Http\Controllers',
], function ($router) {
    require __DIR__ . '/../routes/web.php';
    require __DIR__ . '/../routes/country_information.php';
});

$app->routeMiddleware([
    'auth' => App\Http\Middleware\Authenticate::class,
    'client' => CheckClientCredentials::class,
]);

return $app;
