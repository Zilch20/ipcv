<?php

return [
    'debug' => env('APP_DEBUG', true),
    'url' => env('APP_URL'),
    'key' => env('APP_KEY'),
    'cipher' => env('APP_CIPHER','AES-256-CBC'),
];
