<?php

return [
    'base_uri' => env('WESTERN_UNION_BASE_URI'),
    'certificate' => env('WESTERN_UNION_CERT'),
    'certificate_key' => env('WESTERN_UNION_CERT_KEY'),
    'certificate_key_passphrase' => env('WESTERN_UNION_CERT_KEY_PASSPHRASE'),

    'das_base_uri' => env('WESTERN_UNION_DAS_URI'),
    'das_certificate' => env('WESTERN_UNION_DAS_CERT'),
    'das_certificate_key' => env('WESTERN_UNION_DAS_CERT_KEY'),
    'das_certificate_key_passphrase' => env('WESTERN_UNION_DAS_CERT_KEY_PASSPHRASE'),

    'credential' => env('WESTERN_UNION_CREDENTIAL'),
    'user_id' => env('WESTERN_UNION_USER_ID'),
    'auth_token' => env('WESTERN_UNION_AUTH_TOKEN'),
];
