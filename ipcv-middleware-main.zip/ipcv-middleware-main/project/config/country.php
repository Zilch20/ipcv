<?php

return [
        "AF" => "Afghanistan",

        "XP" => "Afghanistan US Military Base",

        "AL" => "Albania",

        "DZ" => "Algeria",

        "AS" => "American Samoa",

        "AD" => "Andorra",

        "AO" => "Angola",
        
        "AI" => "Anguilla",

        "AG" => "Antigua And Barbuda",

        "AR" => "Argentina",

        "AW" => "Aruba",

        "AU" => "Australia",

        "AT" => "Austria",

        "AZ" => "Azerbaijan",

        "BS" => "Bahamas",

        "BH" => "Bahrain",

        "XB" => "Bahrain US Military Base",

        "BD" => "Bangladesh",

        "BB" => "Barbados",

        "BY" => "Belarus",

        "BE" => "Belgium",

        "QQ" => "Belgium US Military Base",

        "BZ" => "Belize",

        "BJ" => "Benin",

        "BM" => "Bermuda",

        "BT" => "Bhutan",

        "BO" => "Bolivia",

        "B1" => "Bonaire",

        "BA" => "Bosnia and Herzegovina",

        "BW" => "Botswana",

        "BR" => "Brazil",

        "VG" => "British Virgin Islands",

        "BN" => "Brunei Darussalam",

        "BG" => "Bulgaria",

        "BF" => "Burkina Faso",

        "BI" => "Burundi",

        "KH" => "Cambodia",

        "CM" => "Cameroon",

        "CA" => "Canada",

        "CV" => "Cape Verde",

        "KY" => "Cayman Islands",

        "CF" => "Central African Republic",

        "TD" => "Chad",

        "CL" => "Chile",

        "CN" => "China",

        "CO" => "Colombia",

        "KM" => "Comoros",

        "CD" => "Congo, Democratic Republic of",

        "CG" => "Congo-Brazzaville",

        "CK" => "Cook Islands",

        "CR" => "Costa Rica",

        "HR" => "Croatia",

        "CU" => "Cuba",

        "QS" => "Cuba US Military Base",

        "AN" => "Curacao",

        "CY" => "Cyprus",

        "C2" => "Cyprus (Northern)",

        "CZ" => "Czech Republic",

        "DK" => "Denmark",

        "DJ" => "Djibouti",

        "QV" => "Djibouti US Military Base",

        "DM" => "Dominica",

        "DO" => "Dominican Republic",

        "TP" => "East Timor",

        "EC" => "Ecuador",

        "EG" => "Egypt",

        "SV" => "El Salvador",

        "XQ" => "England",

        "GQ" => "Equatorial Guinea",

        "ER" => "Eritrea",

        "EE" => "Estonia",

        "ET" => "Ethiopia",

        "FK" => "Falkland Islands (Malvinas)",

        "FJ" => "Fiji",

        "FI" => "Finland",

        "FR" => "France",

        "GF" => "French Guiana",

        "PF" => "French Polynesia",

        "GA" => "Gabon",

        "GM" => "Gambia",

        "GE" => "Georgia",

        "DE" => "Germany",

        "QO" => "Germany US Military Base",

        "GH" => "Ghana",

        "GI" => "Gibraltar",

        "GR" => "Greece",

        "QZ" => "Greece US Military Base",

        "GD" => "Grenada",

        "GP" => "Guadeloupe",

        "GU" => "Guam",

        "XY" => "Guam US Military Base",

        "GT" => "Guatemala",

        "GN" => "Guinea",

        "GW" => "Guinea=>Bissau",

        "GY" => "Guyana",

        "HT" => "Haiti",

        "HN" => "Honduras",

        "QR" => "Honduras US Military Base",

        "HK" => "Hong Kong",

        "HU" => "Hungary",

        "IS" => "Iceland",

        "XM" => "Iceland US Military Base",

        "IN" => "India",

        "ID" => "Indonesia",

        "X0" => "International Test Country",

        "IQ" => "Iraq",

        "QX" => "Iraq US Military Base",

        "IE" => "Ireland",

        "IL" => "Israel",

        "IT" => "Italy",

        "QP" => "Italy US Military Base",

        "CI" => "Ivory Coast",

        "JM" => "Jamaica",

        "JP" => "Japan",

        "QM" => "Japan US Military Base",

        "JO" => "Jordan",

        "KZ" => "Kazakhstan",

        "KE" => "Kenya",

        "KI" => "Kiribati",

        "KR" => "Korea",

        "QN" => "Korea US Military Base",

        "K1" => "Kosovo",

        "XF" => "Kosovo US Military Base",

        "KW" => "Kuwait",

        "QU" => "Kuwait US Military Base",

        "KG" => "Kyrghyz Republic",

        "AA" => "Kyrghyz Republic US Military Base",

        "LA" => "Laos",

        "LV" => "Latvia",

        "LB" => "Lebanon",

        "LS" => "Lesotho",

        "LR" => "Liberia",

        "LY" => "Libya",

        "LI" => "Liechtenstein",

        "LT" => "Lithuania",

        "LU" => "Luxembourg",

        "MO" => "Macau",

        "MK" => "Macedonia",

        "MG" => "Madagascar",

        "MW" => "Malawi",

        "MY" => "Malaysia",

        "MV" => "Maldives",

        "ML" => "Mali",

        "MT" => "Malta",

        "MH" => "Marshall Islands",

        "MQ" => "Martinique",

        "MR" => "Mauritania",

        "MU" => "Mauritius",

        "YT" => "Mayotte",

        "MX" => "Mexico",

        "FM" => "Micronesia",

        "MD" => "Moldova",

        "MC" => "Monaco",

        "MN" => "Mongolia",

        "ME" => "Montenegro",

        "MS" => "Montserrat",

        "MA" => "Morocco",

        "MZ" => "Mozambique",

        "MM" => "Myanmar",

        "NA" => "Namibia",

        "NR" => "Nauru",

        "NP" => "Nepal",

        "NL" => "Netherland",    
         "QT" => "Netherlands US Military Base",
      "NC" => "New Caledonia",
      "NZ" => "New Zealand",
      "NI" => "Nicaragua",
      "NE" => "Niger",
      "NG" => "Nigeria",
      "NU" => "Niue",
      "XZ" => "North Ireland",
      "MP" => "Northern Mariana Islands",
      "NO" => "Norway",
      "OM" => "Oman",
      "PK" => "Pakistan",
      "PW" => "Palau",
      "PS" => "Palestinian Authority",
      "PA" => "Panama",
      "PG" => "Papua New Guinea",
      "PY" => "Paraguay",
      "PE" => "Peru",
      "PH" => "Philippines",
      "PL" => "Poland",
      "PT" => "Portugal",
      "XT" => "Portugal US Military Base",
      "PR" => "Puerto Rico",
      "QA" => "Qatar",
      "QY" => "Qatar US Military Base",
      "RE" => "Reunion Island",
      "RO" => "Romania",
      "XW" => "Rota, CNMI",
      "RU" => "Russia",
      "RW" => "Rwanda",
      "BL" => "Saint Barthelemy",
      "KN" => "Saint Kitts And Nevis",
      "LC" => "Saint Lucia",
      "VC" => "Saint Vincent And The Grenadines",
      "XU" => "Saipan, CNMI",
      "WS" => "Samoa",
      "ST" => "Sao Tome And Principe",
      "SA" => "Saudi Arabia",
      "XS" => "Scotland",
      "SN" => "Senegal",
      "YU" => "Serbia",
      "SC" => "Seychelles",
      "SL" => "Sierra Leone",
      "SG" => "Singapore",
      "SK" => "Slovakia",
      "SI" => "Slovenia",
      "SB" => "Solomon Islands",
      "SO" => "Somalia",
      "XA" => "Somaliland",
      "ZA" => "South Africa",
      "SS" => "South Sudan",
      "ES" => "Spain",
      "AB" => "Spain US Military Base",
      "LK" => "Sri Lanka",
      "S1" => "St. Maarten",
      "MF" => "St. Martin",
      "XD" => "St. Thomas",
      "SD" => "Sudan",
      "SR" => "Suriname",
      "SZ" => "Swaziland",
      "SE" => "Sweden",
      "CH" => "Switzerland",
      "SY" => "Syria",
      "TW" => "Taiwan",
      "TJ" => "Tajikistan",
      "TZ" => "Tanzania",
      "TH" => "Thailand",
      "XV" => "Tinian, CNMI",
      "TG" => "Togo",
      "TO" => "Tonga",
      "TT" => "Trinidad and Tobago",
      "TN" => "Tunisia",
      "TR" => "Turkey",
      "XN" => "Turkey US Military Base",
      "TM" => "Turkmenistan",
      "TC" => "Turks and Caicos Islands",
      "TV" => "Tuvalu",
      "XE" => "UAE US Military Base",
      "UG" => "Uganda",
      "UA" => "Ukraine",
      "AE" => "United Arab Emirates",
      "GB" => "United Kingdom",
      "QW" => "United Kingdom US Military Base",
      "US" => "United States",
      "UY" => "Uruguay",
      "UZ" => "Uzbekistan",
      "VU" => "Vanuatu",
      "VE" => "Venezuela",
      "VN" => "Vietnam",
      "VI" => "Virgin Islands (US)",
      "XR" => "Wales",
      "YE" => "Yemen",
      "ZM" => "Zambia",

        "ZW" => "Zimbabwe",
];