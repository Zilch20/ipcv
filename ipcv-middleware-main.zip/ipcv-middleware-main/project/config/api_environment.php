<?php

return [
    'dev'        => [
        'api_url'     => 'http://3.1.170.158/mw-development/public',
        'instance_folder' => 'mw-development'
    ],
    'staging'    => [
        'api_url'     => 'http://3.1.170.158/mw-staging/public',
        'instance_folder' => 'mw-staging'
    ],
    'production' => [
        'api_url'     => 'http://3.1.170.158/mw/public',
        'instance_folder' => 'mw'
    ]
];
