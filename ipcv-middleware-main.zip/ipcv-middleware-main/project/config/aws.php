<?php

return [
    's3' => [
        'access_key' => env('AWS_ACCESS_KEY_ID', 'AKIARKNTKKNG2YRYPGWO'),
        'secret_key' => env('AWS_SECRET_ACCESS_KEY', '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'),
        'region' => env('AWS_DEFAULT_REGION', 'ap-southeast-1'),
        'bucket' => env('AWS_BUCKET', 'ipcv-middleware'),
        'endpoint' => env('AWS_ENDPOINT', 'https://s3-ap-southeast-1.amazonaws.com'),
        'url' => env('AWS_URL', 'https://ipay-test-bucket.s3-ap-southeast-1.amazonaws.com')
    ],
];
