<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class AgentPortalTransactionLog extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;

    /**
     * The connection name for the model.
     *
     * @var string
     */
    protected $connection = 'agent_portal';

    protected $table = 'transactions';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        "transaction_id",
        "admin_user_id",
        "type",
        "amount",
        "currencyCode",
        "destinationCountry",
        "destinationCurrencyCode",
        "firstName",
        "middleName",
        "lastName",
        "address1",
        "city",
        "province",
        "postalCode",
        "idNum",
        "issueDate",
        "expiration",
        "birthDate",
        "gender",
        "occupation",
        "positionLevel",
        "fundSource",
        "transactionReason",
        "relationshiptoReceiver",
        "accountNumber",
        "phoneNum",
        "receiverFirstName",
        "receiverMiddleName",
        "receiverLastName",
        "mtcn",
        "new_mtcn",
        "source_amount",
        "destination_amount",
        "charges",
        "plus_charges_amount",
        "exchange_rate",
        "status",
        "created_at",
        "modified_at",
        "transactionType",
        "senderCountryCode",
        "senderCountryCurrencyCode",
        "idCountryIssued",
        "countryofBirth",
        "paymentType",
        "idType",
        "phoneCountryCode",
        "payWoIdIndicator",
        "deliveryCode",
        "stateCode",
        "receiverCity",
        "payOrDoNot",
        "gross_total_amount",
        "myWuNumber",
        "permanentChange",
        "nationality",
        "message1",
        "message2",
        "message3",
        "message4",
        "fixOnSend",
        "message_charges",
        "bankName",
        "bic",
        "branchNumber",
        "accountPrefix",
        "accountSuffix",
        "message",
        "new_points_earned",
        "receiverAddress1",
        "receiverAddress2",
        "receiverHomeCity",
        "receiverState",
        "receiverPostalCode",
        "receiverPhoneCountryCode",
        "receiverPhoneNum",
        "couponCode",
        "complianceDataBuffer"
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
