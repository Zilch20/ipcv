<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class PesonetTransferMoneyLog extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;
    protected $table = 'pesonet_transfer_money_logs';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'client_id','referenceID','sender_name','sender_addr_line1','sender_addr_line2','sender_city','sender_province','sender_zipCode','sender_country','beneficiary_acct_number','beneficiary_name','beneficiary_addr_line1','beneficiary_addr_line2','beneficiary_city','beneficiary_province','beneficiary_zipCode','beneficiary_country','amount','currency','receivingBank','purpose','instructions','request_data'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
