<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class ReceiveMoneySearchLog extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;
    protected $table = 'receive_money_search_logs';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'xml_request',
        'client_id',
        'mtcn',
        'destinationCountry',
        'destinationCurrencyCode',
        'request_data',
        'reply_data'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    public function ScopeFindRequestDataJSONByMtcn($query, $mtcn)
    {
        return $query->whereJsonContains('request_data->mtcn', $mtcn);
    }

    public function ScopeFindRequestDataJSONByDestinationCountry($query, $destinationCountry)
    {
        return $query->whereJsonContains('request_data->destinationCountry', $destinationCountry);
    }

    public function ScopeFindRequestDataJSONByDestinationCurrencyCode($query, $destinationCurrencyCode)
    {
        return $query->whereJsonContains('request_data->destinationCurrencyCode', $destinationCurrencyCode);
    }
}
