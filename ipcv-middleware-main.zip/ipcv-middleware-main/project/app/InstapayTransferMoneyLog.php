<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class InstapayTransferMoneyLog extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;
    protected $table = 'instapay_transfer_money_logs';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'client_id',
        "senderReference",
        "amount",
        "purpose",
        "receiverType",
        "senderAccountName",
        "senderAccountNumber",
        "senderMobileNumber",
        "senderEmail",
        "senderAddress",
        "senderBarangay",
        "senderCity",
        "senderZipCode",
        "receiverAccountName",
        "receiverAccountNumber",
        "receiverMobileNumber",
        "receiverEmail",
        "receiverAddress",
        "receiverBarangay",
        "receiverCity",
        "receiverZipCode",
        "receiverBankName",
        "receverBankCode",
        "receiverGender",
        "receiverBirthDate",
        "representativeFirstName",
        "representativeMiddleName",
        "representativeLastName",
        "representativeSuffix",
        "request_data",
        "reply_data",
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
