<?php

namespace App\Helpers;

class IonAuthPasswordHelper
{

    const MAX_PASSWORD_SIZE_BYTES = 4096;
    const HASH_METHOD = 'bcrypt';
    const BCRYPT_DEFAULT_COST = 10;
    const ARGON2_DEFAULT_PARAMS = [
        'memory_cost' => 1 << 12,    // 4MB
        'time_cost'   => 2,
        'threads'     => 2
    ];

    /**
     * Hashes the password to be stored in the database.
     *
     * @param string $password
     * @param string $identity
     *
     * @return false|string
     * @author Mathew
     */
    public static function hash_password($password)
    {
        // Check for empty password, or password containing null char, or password above limit
        // Null char may pose issue: http://php.net/manual/en/function.password-hash.php#118603
        // Long password may pose DOS issue (note: strlen gives size in bytes and not in multibyte symbol)
        if (empty($password) || strpos($password, "\0") !== FALSE || strlen($password) > self::MAX_PASSWORD_SIZE_BYTES) {
            return FALSE;
        }

        $algo = self::_get_hash_algo();
        $params = self::_get_hash_parameters();

        if ($algo !== FALSE && $params !== FALSE) {
            return password_hash($password, $algo, $params);
        }

        return FALSE;
    }

    /** Retrieve hash algorithm according to options
     *
     * @return string|bool
     */
    protected static function _get_hash_algo()
    {
        $algo = FALSE;
        switch (self::HASH_METHOD) {
            case 'bcrypt':
                $algo = PASSWORD_BCRYPT;
                break;

            case 'argon2':
                $algo = PASSWORD_ARGON2I;
                break;

            default:
                // Do nothing
        }

        return $algo;
    }

    /** Retrieve hash parameter according to options
     *
     * @return array|bool
     */
    protected static function _get_hash_parameters()
    {
        $params = FALSE;
        switch (self::HASH_METHOD) {
            case 'bcrypt':
                $params = [
                    'cost' => self::BCRYPT_DEFAULT_COST
                ];
                break;

            case 'argon2':
                $params = self::ARGON2_DEFAULT_PARAMS;
                break;

            default:
                // Do nothing
        }

        return $params;
    }
}
