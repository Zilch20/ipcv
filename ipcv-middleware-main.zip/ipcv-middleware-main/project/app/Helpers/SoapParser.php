<?php

namespace App\Helpers;

class SoapParser
{

    public static function parseSOAP($soap)
    {
        $xml = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $soap);
        $xml = simplexml_load_string($xml);
        $json = json_encode($xml);
        return json_decode($json, true);
    }
}
