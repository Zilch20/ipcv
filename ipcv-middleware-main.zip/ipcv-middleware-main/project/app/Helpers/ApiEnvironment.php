<?php

namespace App\Helpers;

class ApiEnvironment
{
    public static function get()
    {
        $envDatabase = env('DB_DATABASE');

        if ($envDatabase === 'ipay_api') {
            $apiEnv = config('api_environment.production');
        } else if ($envDatabase === 'ipay_api_staging') {
            $apiEnv = config('api_environment.staging');
        } else {
            $apiEnv = config('api_environment.dev');
        }

        return $apiEnv;
    }
}
