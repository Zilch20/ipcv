<?php

namespace App\Helpers;

class Debugger
{
    public static function dd($output, $isDie = true)
    {
        echo '<pre>';
        print_r($output);

        if ($isDie) {
            die;
        }
    }

}
