<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class BranchManagementTable extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;

    protected $table = 'branch_management_table';

    protected $fillable = [
        "branchName",
        "branchOwner",
        "branchEmail",
        "branchAddress",
        "branchContact",
        "branchTerminalId",
        "ftid",
        "naid"
    ];
}
