<?php

namespace App\Traits;

use App\Helpers\JSONSOAPConvert;
use App\WesternUnionConnectionErrorLog;

trait GetStatusTraits{

    /*
        getTransactionStatus = Checks if Response From WU is Successful or an Error
        responseStatus = Test Function
    */

    public function getTransactionStatus($output){
        
        // dd('Hello');
        $xml = preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($output));
            // dd($xml);

        $myArray = str_split($xml);
        // dd($myArray);
        $size = count($myArray);

        $request['status'] = "Success";

        for ($counter = 0; $counter < $size-4; $counter++){
            $word = (string)$myArray[$counter].$myArray[$counter+1].$myArray[$counter+2].$myArray[$counter+3].$myArray[$counter+4];
            if($word == "error"|| $word == "Error"){
                // dd("error");
                $request['status'] = "Failed";
            break;
            }
            // echo $word. "\n";
        }

        return $request['status'];
    }

    //Response Status Test Function
    public function responseStatus($code){

        if($code == 400){
            $message = [
                "code" => 400,
                "message" => "Bad Request"
            ];

            return $message;
        }
        if($code == 401){
            $message = [
                "code" => 401,
                "message" => "Unauthorized"
            ];

            return $message;
        }
        if($code == 403){
            $message = [
                "code" => 403,
                "message" => "Forbidden"
            ];

            return $message;
        }
        if($code == 404){
            $message = [
                "code" => 404,
                "message" => "Not Found"
            ];

            return $message;
        }

        if($code == 500){
            $message = [
                "code" => 500,
                "message" => "Internal Server Error"
            ];
            return $message;
        }

        if($code == 502){
            $message = [
                "code" => 502,
                "message" => "Bad Gateway"
            ];

            return $message;
        }

        if($code == 503){
            $message = [
                "code" => 503,
                "message" => "Service Unavailable"
            ];

            return $message;
        }

        if($code == 504){
            $message = [
                "code" => 504,
                "message" => "Gateway Timeout"
            ];

            return $message;
        }
        return true;

    }

}