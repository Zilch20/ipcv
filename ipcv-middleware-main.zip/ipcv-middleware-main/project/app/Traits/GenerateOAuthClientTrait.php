<?php

namespace App\Traits;

use App\Helpers\Debugger;
use App\oauth_clients;
use Illuminate\Support\Str;

trait GenerateOAuthClientTrait
{
    public function generateOAuthClient()
    {
//        $certFolder = '';
//        $dirCertFolder = base_path($certFolder);
//        chdir($dirCertFolder);
//
//        $output = shell_exec('php artisan passport:client --password');
//
//        $output = explode("\n",$output);
//
//        if (!empty($output[1]) && strpos($output[1], 'Client ID')) {
//         return [
//             'client_id' => str_replace('Client ID: ', '', $output[1]),
//             'client_secret' => str_replace('Client secret: ', '', $output[2])
//         ];
//        }

        $oAuthClient = new oauth_clients();
        $oAuthClient->name = 'Password Grant Client';
        $oAuthClient->secret = Str::random(40);
        $oAuthClient->redirect = 'http://3.1.170.158/ipay-api';
        $oAuthClient->personal_access_client = '0';
        $oAuthClient->password_client = '1';
        $oAuthClient->revoked = '0';
        $oAuthClient->save();

        return [
            'client_id'     => $oAuthClient->id,
            'client_secret' => $oAuthClient->secret
        ];
    }


}
