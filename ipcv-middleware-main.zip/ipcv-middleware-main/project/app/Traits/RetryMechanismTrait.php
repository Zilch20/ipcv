<?php

namespace App\Traits;

use App\Helpers\Debugger;
use App\Helpers\SoapParser;
use App\RetryMechanismLog;

trait RetryMechanismTrait
{
    public function retryMechanism($output, $request_name, $request_data, $client_id)
    {
        $soap = SoapParser::parseSOAP($output);

        if (!empty($soap['soapenvBody']['soapenvFault']['detail']['xrsierror-reply'])) {
            $soapError = $soap['soapenvBody']['soapenvFault']['detail']['xrsierror-reply'];

            $accountNbr = null;

            if (!empty($soapError['account_nbr'])) {
                $accountNbr = $soapError['account_nbr'];
            }

            if (!empty($soapError['mywu_number'])) {
                $accountNbr = $soapError['mywu_number'];
            }

            $data = [
                'request_name'      => !empty($request_name) ? $request_name : null,
                'client_id'         => !empty($client_id) ? $client_id : null,
                'request_data'      => !empty($request_data) ? json_encode($request_data) : null,
                'error_xml_response' => !empty($output) ? $output : null,
                'galactic_id'       => !empty($soapError['galactic_id']) ? $soapError['galactic_id'] : null,
                'account_nbr'       => $accountNbr,
                'mtcn'              => !empty($soapError['mtcn']) ? $soapError['mtcn'] : null,
                'mtcn_digest'       => !empty($soapError['mtcn_digest']) ? $soapError['mtcn_digest'] : null
            ];
            RetryMechanismLog::create($data);
        }
    }


}
