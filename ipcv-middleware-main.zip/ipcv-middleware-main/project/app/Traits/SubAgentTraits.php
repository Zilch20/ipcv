<?php

namespace App\Traits;

use App\AgentPortalUser;
use App\BranchManagementTable;
use App\Helpers\JSONSOAPConvert;
use App\HelpersDebugger;
use App\HelpersSoapParser;
use App\SubAgentManagementTable;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;

trait SubAgentTraits
{
    /*
        getAgentName = Get Agent name from database
        getBranchLocation = Gets Branch location from MW DB if no branch Location is defined in the request
        getFtid = Get FTID of specific branch from DB
        getNaid = Get NAID from DB based on defined branchLocation
        getBranchOwner = Check if Branch Owner is Independent, GPRS, BOC, PisoPay, or EPI
        checkSuspended = Check if Branch FTID is Suspended
    */
    public function getAgentName($request)
    {
        $email = $request['agentEmail'];
        $agentFirstName = SubAgentManagementTable::where('agentEmail', '=', $email)
            ->pluck('firstName');
        $agentFirstName = $agentFirstName[0];
        $agentLastName = SubAgentManagementTable::where('agentEmail', '=', $email)
            ->pluck('lastName');
        $agentLastName = $agentLastName[0];

        $agentName = $agentFirstName . " " . $agentLastName;

        return $agentName;
    }

    public function getBranchLocation($request): string
    {
        $email = $request['agentEmail'];

        $checkExists = SubAgentManagementTable::where('agentEmail', '=', $email)
            ->count();

        $checkExistsFE = AgentPortalUser::where('username', '=', $email)
            ->count();

        if (!$checkExists && !$checkExistsFE) {
            return JSONSOAPConvert::toSoap('No User Found');
        }

        if (!$checkExists && $checkExistsFE) {
            return AgentPortalUser::query()->join('ipay_fe_agent_portal.admin_users_groups', 'admin_users_groups.user_id', '=', 'admin_users.id')
                ->join('ipay_fe_agent_portal.admin_branches', 'admin_branches.id', '=', 'admin_users_groups.branch_id')
                ->where('username', '=', $email)
                ->firstOrFail()
                ->name;
        }

        return SubAgentManagementTable::query()
            ->where('agentEmail', '=', $email)
            ->firstOrFail()
            ->branchLocation;
    }

    public function getFtid($request)
    {
        $checkBranch = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
            ->get()
            ->count();

        if ($checkBranch == 0) {
            return JSONSOAPConvert::toSoap('BRANCH IS NOT REGISTERED');
        }

        $ftid = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
            ->pluck('ftid');
        $ftid = $ftid[0];

        return $ftid;
    }

    public function getNaid($request)
    {
        $checkBranch = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
            ->get()
            ->count();

        if ($checkBranch == 0) {
            return JSONSOAPConvert::toSoap('BRANCH IS NOT REGISTERED');
        }

        $ftid = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
            ->pluck('naid');
        $ftid = $ftid[0];

        return $ftid;
    }

    public function getBranchOwner($request)
    {
        $branchOwner = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
            ->pluck('branchOwner');
        $branchOwner = $branchOwner[0];

        return $branchOwner;
    }

    /**
     * @throws ModelNotFoundException
     */
    public function checkSuspended(Request $request): bool
    {
        $branch = BranchManagementTable::query()
            ->where('branchName', '=', $request['branchLocation'])
            ->firstOrFail();

        $ftid = \strtolower($branch->ftid);

        return $ftid === 'suspended' || $ftid === 'suspend';
    }

}
