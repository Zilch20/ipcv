<?php

namespace App\Traits\D2B;

use App\repositories\WesternUnionRepositories\SendMoneyProcessRepository;

trait ReasonForSendingTrait
{

    /**
     * Get Reason for Sending Code using the Transaction Reason Request Value
     * @param $request
     * @return string
     */
    public function getReasonForSendingCode($request)
    {
        if(empty($request['transactionReason']))
        {
            $request['transactionReason'] = '';
        }

        if(empty($request['destinationCountry']))
        {
            $request['destinationCountry'] = '';
        }

        if(empty($request['deliveryCode']))
        {
            $request['deliveryCode'] = '';
        }
        
        $destinationReasonArray =[
            "transactionReason" => $request['transactionReason'], 
            "destinationCountry" => $request['destinationCountry'],
            "deliveryCode" => $request['deliveryCode']
        ];
        // dd($destinationReasonArray);
        $reason = $request['transactionReason'];
        $reasonCode = '';
        if ($destinationReasonArray['deliveryCode'] == "500")
        {
            if($destinationReasonArray["destinationCountry"] == "TH")
            {
                $reasonCode = $this->getReasonCode($reason);
                return $reasonCode;
            }
            if($destinationReasonArray["destinationCountry"] == "EG")
            {
                $reasonCode = $this->getReasonCode($reason);
                return $reasonCode;
            }
            if($destinationReasonArray["destinationCountry"] == "AE")
            {
                $reasonCode = $this->getReasonCode($reason);
                return $reasonCode;
            }
            if($destinationReasonArray["destinationCountry"] == "IN")
            {
                $reasonCode = $this->getIndiaReasonCode($reason);
                return $reasonCode;
            }
            if($destinationReasonArray["destinationCountry"] == "PL")
            {
                $reasonCode = $this->getReasonCode($reason);
                return $reasonCode;
            }
            if($destinationReasonArray["destinationCountry"] == "CN")
            {
                $reasonCode = $this->getReasonCode($reason);
                return $reasonCode;
            }
            return $reasonCode;
        }
       return $reasonCode;
    }

    private function getReasonCode($reason)
    {
        if ($reason == "Family Support/Living Expenses")
        {
            $reasonCode = "P001";
            return $reasonCode;
        }
        if ($reason == "Saving/Investments")
        {
            $reasonCode = "P002";
            return $reasonCode;
        }
        if ($reason == "Gift")
        {
            $reasonCode = "P003";
            return $reasonCode;
        }
        if ($reason == "Education/School Fee")
        {
            $reasonCode = "P004";
            return $reasonCode;
        }
        if ($reason == "Rent/Mortgage")
        {
            $reasonCode = "P005";
            return $reasonCode;
        }
        if ($reason == "Emergency/Medical Aid")
        {
            $reasonCode = "P006";
            return $reasonCode;
        }
        if ($reason == "Travel Expenses")
        {
            $reasonCode = "P008";
            return $reasonCode;
        }
        if ($reason == "Employee Payroll/Employee Expense")
        {
            $reasonCode = "P009";
            return $reasonCode;
        }
        if ($reason == "Goods & Service payment")
        {
            $reasonCode = "P010";
            return $reasonCode;
        }
        if ($reason == "Charity/Aid Payment")
        {
            $reasonCode = "P011";
            return $reasonCode;
        }
        if ($reason == "Prize or Lottery Fees/Taxes")
        {
            $reasonCode = "P012";
            return $reasonCode;
        }
    }

    private function getIndiaReasonCode($reason)
    {
        if ($reason == "Family Support/Living Expenses")
        {
            $reasonCode = "P102";
            return $reasonCode;
        }
        if ($reason == "Credit to NRE Account")
        {
            $reasonCode = "P101";
            return $reasonCode;
        }
    }
}


