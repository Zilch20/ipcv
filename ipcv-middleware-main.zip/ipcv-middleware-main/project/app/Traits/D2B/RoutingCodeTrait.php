<?php

namespace App\Traits\D2B;

use App\repositories\WesternUnionRepositories\SendMoneyProcessRepository;

trait RoutingCodeTrait
{

    /**
     * Parsing the output of DAS GetDeliveryServices request getting the record set and making it as an array
     * @param $response
     * @return mixed
     */
    private function parseDeliveryServices($response)
    {
        $deliveryServices = preg_replace('/(<\/?)(\w+):([^>]*>)/', '$1$2$3', $response);
        $xml = simplexml_load_string($deliveryServices);
//        For catching simplexml error
//        if (!$xml) {
//            $errors = libxml_get_errors();
//            print_r($errors);
//            die;
//        }
        $toJson = json_encode($xml);
        $xmlResponse = json_decode($toJson, true);

        if (isset($xmlResponse['soapenvBody']['xrsih2h-das-reply']['MTML']['REPLY']['DATA_CONTEXT']['RECORDSET']['GETDELIVERYSERVICES'])) {
            return $xmlResponse['soapenvBody']['xrsih2h-das-reply']['MTML']['REPLY']['DATA_CONTEXT']['RECORDSET']['GETDELIVERYSERVICES'];
        }
        return [];
    }

    /**
     * Making DAS GetDeliveryServices request
     *
     * @param $request
     * @return array|mixed
     */
    private function getDasDeliveryServices($request)
    {
        $sendMoneyRepo = new SendMoneyProcessRepository();
        $clientIdFE = 4;

        $originCountryCurrencyCodes = !empty($request['senderCountryCode']) ? $request['senderCountryCode'] : ' ';
        $originCountryCurrencyCodes .= ' ';
        $originCountryCurrencyCodes .= !empty($request['senderCountryCurrencyCode']) ? $request['senderCountryCurrencyCode'] : ' ';

        $destCountryCurrencyCodes = !empty($request['destinationCountry']) ? $request['destinationCountry'] : ' ';
        $destCountryCurrencyCodes .= ' ';
        $destCountryCurrencyCodes .= !empty($request['destinationCurrencyCode']) ? $request['destinationCurrencyCode'] : ' ';

        $data = [
            "channelType" => "H2H",
            "channelVersion" => "9500",
            "Category" => "Das",
            "dasRequest" => "GetDeliveryServices",
            "queryFilter1" => strtoupper($originCountryCurrencyCodes),
            "queryFilter2" => strtoupper($destCountryCurrencyCodes),
            "queryFilter3" => "ALL"
        ];

        $response = $sendMoneyRepo->dasRequest($data, $clientIdFE);
        return $this->parseDeliveryServices($response);
    }

    /**
     * Get the D2B routing code
     *
     * @param $request
     * @return mixed|string
     */
    private function getD2BRoutingCode($request)
    {
        $result = [];
        $d2bDeliveryService = "500";

        if (!empty($request['deliveryCode']) && $request['deliveryCode'] === $d2bDeliveryService) {
            $deliveryServices = $this->getDasDeliveryServices($request);

            foreach ($deliveryServices as $deliveryService) {
                if ($deliveryService['SVC_CODE'] === $d2bDeliveryService) {
                    $result['routingCode'] = $deliveryService['ROUTE'];
                    $result['templateId'] = $deliveryService['TEMPLT'];
                }
            }
        }

        return $result;
    }

    /**
     * Get the routing code
     *
     * @param $request
     *
     * @return array
     */
    public function getRoutingCode($request)
    {
        $d2bRoutingCode = $this->getD2BRoutingCode($request);
        $result = [];

        if (!empty($d2bRoutingCode['routingCode'])) {
            $result['routingCode'] = '<routing_code>' . $d2bRoutingCode['routingCode'] . '</routing_code>';
        } else {
            $result['routingCode'] = !empty($request['routingCode']) ? '<routing_code>' . $request['routingCode'] . '</routing_code>' : '';
        }

        if (!empty($d2bRoutingCode['templateId'])) {
            $result['templateId'] = '<template_id>' . $d2bRoutingCode['templateId'] . '</template_id>';
        } else {
            $result['templateId'] = !empty($request['templateId']) ? '<template_id>' . $request['templateId'] . '</template_id>' : '';
        }

        return $result;
    }
}
