<?php

declare(strict_types=1);

namespace App\Traits;

use App\Helpers\JSONSOAPConvert;
use App\WesternUnionConnectionErrorLog;
use CurlHandle;
use JsonException;
use RuntimeException;
use function curl_close;
use function curl_error;
use function curl_exec;
use function curl_init;
use function curl_setopt;
use function is_readable;
use function strlen;

trait WesternUnionCurlRequestTrait
{
    /**
     * @throws JsonException
     */
    public function requestWUAPI(string $params, int $client_id, array $request_data = []): false|string
    {
        $ch = curl_init(config('western_union.base_uri'));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/xml',
            'Content-Length: ' . strlen($params)
        ]);

        $this->setCurlOptions($ch, $params);
        $output = curl_exec($ch);
        curl_close($ch);

        if (false === $output) {
            $errorMessage = 'Internal error - ' . curl_error($ch);
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $this->saveErrorToDB($params, $client_id, $request_data, $soapResponse);

            return $soapResponse;
        }

        return $output;
    }

    /**
     * @throws JsonException
     */
    public function requestWUAPIMobile(string $params, int $client_id, array $request_data = []): false|string
    {
        $ch = curl_init(config('western_union.base_uri'));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/xml',
            'Content-Length: ' . strlen($params),
            'Credential: ' . config('western_union.credential'),
            'User_id: ' . config('western_union.user_id'),
            'Auth_token: ' . config('western_union.auth_token'),
        ]);

        $this->setCurlOptions($ch, $params);
        $output = curl_exec($ch);

        if (false === $output) {
            $errorMessage = 'Internal error (Mobile) - ' . curl_error($ch);
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $this->saveErrorToDB($params, $client_id, $request_data, $soapResponse);

            return $soapResponse;
        }

        curl_close($ch);

        return $output;
    }

    private function setCurlOptions(CurlHandle $ch, string $params): void
    {
        $cert = config('western_union.certificate');
        $key = config('western_union.certificate_key');
        $pass = config('western_union.certificate_key_passphrase');

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_POST, 1);

        if (false === is_readable($cert)) {
            throw new RuntimeException('western_union.certificate is not readable.');
        }

        curl_setopt($ch, CURLOPT_SSLCERT, $cert);
        curl_setopt($ch, CURLOPT_SSLCERTTYPE, "PEM");
        curl_setopt($ch, CURLOPT_SSLKEY, $key);
        curl_setopt($ch, CURLOPT_SSLKEYTYPE, "PEM");
        curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $pass);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    }

    /**
     * @throws JsonException
     */
    private function saveErrorToDB(string $params, int $clientId, array $requestData, string $response): void
    {
        $logs = [];
        $logs['client_id'] = $clientId;
        $logs['request_data'] = json_encode($requestData, JSON_THROW_ON_ERROR);
        $logs['xml_request'] = $params;
        $logs['reply_data'] = $response;

        WesternUnionConnectionErrorLog::create($logs);
    }
}
