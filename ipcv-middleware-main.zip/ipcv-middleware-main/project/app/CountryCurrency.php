<?php

declare(strict_types=1);

namespace App;

use Illuminate\Database\Eloquent\Model;

class CountryCurrency extends Model
{
    protected $table = 'country_currencies';

    public $timestamps = false;

    public const FILLABLES = [
        'country_long',
        'iso_country_num_cd',
        'iso_country_cd',
        'iso_currency_num_cd',
        'currency_cd',
        'currency_name',
    ];

    protected $fillable = self::FILLABLES;
}
