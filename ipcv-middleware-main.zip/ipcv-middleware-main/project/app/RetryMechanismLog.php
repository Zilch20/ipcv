<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class RetryMechanismLog extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;
    protected $table = 'retry_mechanism_logs';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'request_name',
        'client_id',
        'request_data',
        'error_xml_response',
        'galactic_id',
        'account_nbr',
        'mtcn',
        'mtcn_digest'
    ];

    public function scopeFindLog($query, $request_name, $request_data, $request_type)
    {
        $query = $query->where('request_name', $request_name)
                       ->where('request_data->firstName', $request_data['firstName'])
                       ->where('request_data->lastName', $request_data['lastName']);

        if ($request_type !== 'mobile_send' && $request_type !== 'mobile_receive') {
            $query->where('request_data->deliveryCode', $request_data['deliveryCode']);
        }

        if ($request_type === 'send' || $request_type === 'mobile_send') {
            $query->where('request_data->amount', $request_data['amount'])
                  ->where('request_data->receiverFirstName', $request_data['receiverFirstName'])
                  ->where('request_data->receiverLastName', $request_data['receiverLastName']);
        } elseif ($request_type === 'receive' || $request_type === 'mobile_receive') {
            $query->where('request_data->mtk', $request_data['mtk'])
                  ->where('request_data->grossTotalAmount', $request_data['grossTotalAmount']);
        }

        return $query->orderBy('created_at', 'desc');
    }
}
