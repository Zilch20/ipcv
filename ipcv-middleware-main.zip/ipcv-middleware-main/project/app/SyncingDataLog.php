<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class SyncingDataLog extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $guarded = [];
    
    public static function saveLogs($date,$table_logs,$count_data){
        self::create([
            'date_grab_input'=>$date,
            'data_log_name'=>$table_logs,
            'data_count'=>$count_data,
        ]);
    }
}
