<?php

namespace App\Repositories\BayadCenterRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class TransactRepository extends Controller
{
    public function test(){
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }
//Payment Functions
    public function telecommunicationsTransact($request, $partnerID)
    {
        if($partnerID == '1'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'X-MECOM-PARTNER-SECRET' => '',
                    'X-MECOM-PARTNER-REFNO' => ''
                ]
            ]);

            $params=[
                'biller' => $request['ParameterOne'],
                'amount' => $request['Amount'],
                'channel' => $request['channel']
            ];

            $res = $guzzle->post(env('BAYAD_CENTER_BILLS_TRANSACT_URL'), [
                'json' => $params
            ]);

            return json_decode($res->getBody(), true);
        }

        if($partnerID == '2'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'X-MECOM-PARTNER-SECRET' => '',
                    'X-MECOM-PARTNER-REFNO' => ''
                ]
            ]);

            $params=[
                'biller' => $request['ParameterOne'],
                'amount' => $request['Amount'],
                'channel' => $request['channel']
            ];

            $res = $guzzle->post(env('BAYAD_CENTER_BILLS_TRANSACT_URL'), [
                'json' => $params
            ]);

            return json_decode($res->getBody(), true);
        }

        if($partnerID == '3'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'X-MECOM-PARTNER-SECRET' => '',
                    'X-MECOM-PARTNER-REFNO' => ''
                ]
            ]);

            $params=[
                'biller' => $request['ParameterOne'],
                'amount' => $request['Amount'],
                'channel' => $request['channel']
            ];

            $res = $guzzle->post(env('BAYAD_CENTER_BILLS_TRANSACT_URL'), [
                'json' => $params
            ]);

            return json_decode($res->getBody(), true);
        }
    }






//Extra Functions

    public function billerList()
    {
        $guzzle = new Client([
            'headers' => [
                'Host' => env('ECPAY_HOST'),
                'Content-Type' => 'text/xml; charset=utf-8',
                'Content-Length' => 1,
            ]
        ]);

        $params=
        '<?xml version="1.0" encoding="utf-8"?>
            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <GetBillerList xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password>
                    </GetBillerList> 
                </soap:Body>
            </soap:Envelope>
        ';
 
        $res = $guzzle->post(env('ECPAY_BILLS_LIST_URL'), [
            'body' => $params
        ]);
        
        $xml = $res->getBody()->getContents();

        return json_decode(json_encode($xml), true);
    }
    public function checkBalance()
    {
        $guzzle = new Client([
            'headers' => [
                'Host' => env('ECPAY_HOST'),
                'Content-Type' => 'text/xml; charset=utf-8',
                'Content-Length' => 1,
            ]
        ]);

        $params= 
        '<?xml version="1.0" encoding="utf-8"?>
            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <CheckBalance xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                    <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                    <Username>'.env('ECPAY_USERNAME').'</Username>
                    <Password>'.env('ECPAY_PASSWORD').'</Password>
                    </CheckBalance> 
                </soap:Body>
            </soap:Envelope>
        ';

        $res = $guzzle->post(env('ECPAY_BILLS_BALANCE_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();

        return json_decode(json_encode($xml), true);
    }

}