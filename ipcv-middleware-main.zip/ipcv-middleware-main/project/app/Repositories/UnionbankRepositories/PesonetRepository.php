<?php

namespace App\Repositories\UnionbankRepositories;

use App\Http\Controllers\Controller;
use App\PesonetTransferMoneyLog;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Cache;

date_default_timezone_set("Asia/Manila");

class PesonetRepository extends Controller
{
    public function partnerTransfer($request, $client_id)
    {
        $token = Cache::get('UnionBankToken');

        $date = substr(date("Y-m-d\TH:i:s.u"), 0, -3);

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => env("UNIONBANK_CLIENT_ID"),
                "x-ibm-client-secret" => env("UNIONBANK_CLIENT_SECRET"),
                "authorization" => "Bearer ". $token,
                "x-partner-id" => env("UNIONBANK_PARTNER_ID")
            ]
        ]);

        $params = [
            "senderRefId"=> $request['referenceID'],
            "tranRequestDate"=> $date,
            "sender" => [
                "name"=> $request['sender_name'],
                "address"=> [
                    "line1"=> $request['sender_addr_line1'],
                    "line2"=> $request['sender_addr_line2'],
                    "city"=> $request['sender_city'],
                    "province"=> $request['sender_province'],
                    "zipCode"=> $request['sender_zipCode'],
                    "country"=> $request['sender_country']
                ]
            ],
            "beneficiary"=> [
                "accountNumber"=> $request['beneficiary_acct_number'],
                "name"=> $request['beneficiary_name'],
                "address"=> [
                    "line1"=> $request['beneficiary_addr_line1'],
                    "line2"=> $request['beneficiary_addr_line2'],
                    "city"=> $request['beneficiary_city'],
                    "province"=> $request['beneficiary_province'],
                    "zipCode"=> $request['beneficiary_zipCode'],
                    "country"=> $request['beneficiary_country']
                ]
            ],
            "remittance" => [
                "amount"=> $request['amount'],
                "currency"=> $request['currency'],
                "receivingBank"=> $request['receivingBank'],
                "purpose"=> $request['purpose'],
                "instructions"=> $request['instructions']
            ]
        ];

        $res = $guzzle -> post(env("UNIONBANK_PESONET_TRANSFER_SINGLE_URL"), [
            "json" => $params
        ]);

        $logs['client_id'] = $client_id;
        $logs['referenceID'] = $request['referenceID'];

        $logs['sender_name'] = $request['sender_name'];
        $logs['sender_addr_line1'] = $request['sender_addr_line1'];
        $logs['sender_addr_line2'] = $request['sender_addr_line2'];
        $logs['sender_city'] = $request['sender_city'];
        $logs['sender_province'] = $request['sender_province'];
        $logs['sender_zipCode'] = $request['sender_zipCode'];
        $logs['sender_country'] = $request['sender_country'];

        $logs['beneficiary_acct_number'] = $request['beneficiary_acct_number'];
        $logs['beneficiary_name'] = $request['beneficiary_name'];
        $logs['beneficiary_addr_line1'] = $request['beneficiary_addr_line1'];
        $logs['beneficiary_addr_line2'] = $request['beneficiary_addr_line2'];
        $logs['beneficiary_city'] = $request['beneficiary_city'];
        $logs['beneficiary_province'] = $request['beneficiary_province'];
        $logs['beneficiary_zipCode'] = $request['beneficiary_zipCode'];
        $logs['beneficiary_country'] = $request['beneficiary_country'];

        $logs['amount'] = $request['amount'];
        $logs['currency'] = $request['currency'];
        $logs['receivingBank'] = $request['receivingBank'];
        $logs['purpose'] = $request['purpose'];
        $logs['instructions'] = $request['instructions'];

        $logs['request_data'] = json_encode($request);
        $data_inserted = PesonetTransferMoneyLog::create($logs);

        return json_decode($res->getBody(), true);
    }

    public function TransferVerification($request){
        $token = Cache::get('UnionBankToken');

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => env("UNIONBANK_CLIENT_ID"),
                "x-ibm-client-secret" => env("UNIONBANK_CLIENT_SECRET"),
                "authorization" => "Bearer ". $token,
                "x-partner-id" => env("UNIONBANK_PARTNER_ID")
            ]
        ]);

        $url = PesonetRepository . phpenv("UNIONBANK_PESONET_TRANSFER_VERIFICATION_URL");

        $res = $guzzle -> get($url);

        return json_decode($res->getBody(), true);
    }
    public function BankList(){

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => env("UNIONBANK_CLIENT_ID"),
                "x-ibm-client-secret" => env("UNIONBANK_CLIENT_SECRET"),
                "x-partner-id" => env("UNIONBANK_PARTNER_ID")
            ]
        ]);

        $res = $guzzle -> get(env("UNIONBANK_PESONET_BANK_PARTNER_URL"));

        return json_decode($res->getBody(), true);
    }

    public function TransferStatusUpdate($request)
    {
        $token = Cache::get('UnionBankToken');

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => env("UNIONBANK_CLIENT_ID"),
                "x-ibm-client-secret" => env("UNIONBANK_CLIENT_SECRET"),
                "authorization" => "Bearer ". $token,
                "x-partner-id" => env("UNIONBANK_PARTNER_ID")
            ]
        ]);

        $params = [
                'status' => $request['status'],
                'remittanceId' => $request['remittanceNo']
        ];

        $res = $guzzle -> post(env("UNIONBANK_PESONET_UPDATE_TRANSFER_STATUS_URL"), [
            "json" => $params
        ]);

        return json_decode($res->getBody(), true);
    }



}
