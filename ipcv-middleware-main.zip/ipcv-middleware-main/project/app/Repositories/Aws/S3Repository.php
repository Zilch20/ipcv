<?php

declare(strict_types=1);

namespace App\Repositories\Aws;

use Aws\Result;
use Aws\ResultInterface;
use Aws\S3\Exception\S3Exception;
use Aws\S3\S3ClientInterface;
use GuzzleHttp\Psr7\Stream;
use Illuminate\Http\UploadedFile;

class S3Repository
{
    public function __construct(
        private readonly S3ClientInterface $client,
        private readonly string $bucket,
        private readonly string $directory,
    ) {
    }

    public function uploadObject(UploadedFile $file, string $fileName): ResultInterface
    {
        return $this->client->upload(
            $this->bucket,
            "$this->directory/$fileName",
            $file->openFile('rb'),
            '',
        );
    }

    public function getObject(string $fileName): ?Stream
    {
        try {
            /** @var Result $object */
            $object = $this->client->getObject([
                'Bucket' => $this->bucket,
                'Key' => "$this->directory/$fileName",
            ]);

            return $object->get('Body');
        } catch (S3Exception $e) {
            return null;
        }
    }
}
