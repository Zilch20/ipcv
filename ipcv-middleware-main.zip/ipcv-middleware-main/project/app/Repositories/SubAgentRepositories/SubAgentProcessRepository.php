<?php

namespace App\Repositories\SubAgentRepositories;

use App\AgentPortalBranch;
use App\AgentPortalGroup;
use App\AgentPortalUser;
use App\AgentPortalUsersGroups;
use App\Helpers\IonAuthPasswordHelper;
use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use App\SubAgentManagementTable;
use App\Traits\GenerateOAuthClientTrait;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class SubAgentProcessRepository extends Controller
{
    use GenerateOAuthClientTrait;

    /*
        This Class contains the CRUD Functions for the Sub Agent Management Database
    */
    public function RegisterSubAgent($request, $client_id): string
    {
        //Checks if Agent Email has been used
        $emailExists = SubAgentManagementTable::where('agentEmail', $request['agentEmail'])->count();
        if ($emailExists) {
            return JSONSOAPConvert::toSoap('Email already exists');
        }

        //Inserts into Sub-Agent DB
        $data['firstName'] = $request['firstName'];
        $data['lastName'] = $request['lastName'];
        $data['agentEmail'] = $request['agentEmail'];
        $data['branchLocation'] = $request['branchLocation'];
        $data['is_active'] = $request['isActive'];
        $data['password'] = $request['password'];

        $oauthClient = $this->generateOAuthClient();
        if ($oauthClient) {
            $data['client_id'] = $oauthClient['client_id'];
            $data['client_secret'] = $oauthClient['client_secret'];
        }

//        $data['client_id'] = 22;
//        $data['client_secret'] = 'aLtkapgGMvj2dTIM1cmABPgnTjMDopRzKNxjN9RW';

        $subAgentCreation = SubAgentManagementTable::create($data);
        $middlewareUserCreation = $this->createMiddlewareUser($data);

        if ($subAgentCreation && $middlewareUserCreation) {
            $soapMessage = '<first_name>' . $data['firstName'] . '</first_name>';
            $soapMessage .= '<last_name>' . $data['lastName'] . '</last_name>';
            $soapMessage .= '<agent_email>' . $data['agentEmail'] . '</agent_email>';
            $soapMessage .= '<branch_location>' . $data['branchLocation'] . '</branch_location>';
            $soapMessage .= '<client_id>' . (!empty($data['client_id']) ? $data['client_id'] : '') . '</client_id>';
            $soapMessage .= '<client_secret>' . (!empty($data['client_secret']) ? $data['client_secret'] : '') . '</client_secret>';
            $soapMessage .= '<is_active>' . $data['is_active'] . '</is_active>';
            $soapResponse = JSONSOAPConvert::toOutput($soapMessage);
        } else {
            $soapMessage = '<message>Sub-agent enrollment has failed to create an account.</message>';
            $soapResponse = JSONSOAPConvert::toOutput($soapMessage, 'error');
        }

        return $soapResponse;
    }

    public function RegisterFE($request, $client_id): string
    {
        //Checks if Email has been used
        $emailExists = AgentPortalUser::where('email', $request['agentEmail'])->count();
        if ($emailExists) {
            return JSONSOAPConvert::toSoap('Email already exists');
        }

        $data = [
            'ip_address' => $request['ip_address'],
            'username'   => $request['agentEmail'],
            'password'   => IonAuthPasswordHelper::hash_password($request['password']),
            'email'      => $request['agentEmail'],
            'active'     => $request['isActive'],
            'first_name' => $request['firstName'],
            'last_name'  => $request['lastName'],
            'created_on' => time()
        ];

        $agentPortalUser = AgentPortalUser::create($data);

        if ($agentPortalUser) {
            $getGroupId = AgentPortalGroup::where('name', $request['groupName'])->select('id')->first();
            $getBranchId = AgentPortalBranch::where('name', $request['branchLocation'])->select('id')->first();

            AgentPortalUsersGroups::create([
                'user_id'   => $agentPortalUser->id,
                'group_id'  => $getGroupId->id,
                'branch_id' => $getBranchId->id
            ]);

            $soapMessage = '<first_name>' . $data['first_name'] . '</first_name>';
            $soapMessage .= '<last_name>' . $data['last_name'] . '</last_name>';
            $soapMessage .= '<agent_email>' . $data['email'] . '</agent_email>';
            $soapMessage .= '<username>' . $data['username'] . '</username>';
            $soapMessage .= '<branch_location>' . $request['branchLocation'] . '</branch_location>';
            $soapMessage .= '<group_name>' . $request['groupName'] . '</group_name>';
            $soapMessage .= '<is_active>' . $data['active'] . '</is_active>';
            $soapResponse = JSONSOAPConvert::toOutput($soapMessage);
        } else {
            $soapMessage = '<message>Sub-agent enrollment agent portal access has failed to create an account.</message>';
            $soapResponse = JSONSOAPConvert::toOutput($soapMessage, 'error');
        }
        return $soapResponse;

    }

    public function UpdateSubAgent($request, $client_id): string
    {
        $emailExists = SubAgentManagementTable::where('agentEmail', $request['agentEmail'])->count();
        if (!$emailExists) {
            return JSONSOAPConvert::toSoap('Sub-agent account does not exist');
        }

        $data['is_active'] = $request['isActive'];

        if (!empty($request['firstName'])) {
            $data['firstName'] = $request['firstName'];
        }

        if (!empty($request['lastName'])) {
            $data['lastName'] = $request['lastName'];
        }

        if (!empty($request['agentEmail'])) {
            $data['agentEmail'] = $request['agentEmail'];
        }

        if (!empty($request['branchLocation'])) {
            $data['branchLocation'] = $request['branchLocation'];
        }

        $subAgentUpdate = SubAgentManagementTable::where('agentEmail', $request['agentEmail'])->update($data);

        if (!empty($request['password'])) {
            $data['password'] = $request['password'];
        }

        $middlewareUserUpdate = $this->updateMiddlewareUser($data);

        if ($subAgentUpdate && $middlewareUserUpdate) {
            return JSONSOAPConvert::toOutput('<message>Sub-agent account has been updated</message>');
        }

        return JSONSOAPConvert::toOutput('<message>Sub-agent account has failed to update</message>', 'error');
    }

    public function UpdateFE($request, $client_id): string
    {
        $emailExists = AgentPortalUser::where('email', $request['agentEmail'])->count();
        if (!$emailExists) {
            return JSONSOAPConvert::toSoap('Sub-agent account agent portal does not exist');
        }

        $data['ip_address'] = $request['ip_address'];
        $data['active'] = $request['isActive'];

        if (!empty($request['firstName'])) {
            $data['first_name'] = $request['firstName'];
        }

        if (!empty($request['lastName'])) {
            $data['last_name'] = $request['lastName'];
        }

        if (!empty($request['agentEmail'])) {
            $data['email'] = $request['agentEmail'];
            $data['username'] = $request['agentEmail'];
        }

        if (!empty($request['password'])) {
            $data['password'] = IonAuthPasswordHelper::hash_password($request['password']);
        }

        AgentPortalUser::query()->where('email', $request['agentEmail'])->update($data);

        $getGroupId = AgentPortalGroup::query()->where('name', $request['groupName'])->select('id')->first();
        $getBranchId = AgentPortalBranch::query()->where('name', $request['branchLocation'])->select('id')->first();

        $agentPortalUserId = AgentPortalUser::query()->where('email', $request['agentEmail'])->select('id')->first();
        AgentPortalUsersGroups::where('user_id', $agentPortalUserId->id)->update([
            'group_id'  => $getGroupId->id,
            'branch_id' => $getBranchId->id
        ]);

        return JSONSOAPConvert::toOutput('<message>Sub-agent account agent portal has been updated</message>');
    }

    public function DeleteSubAgent($request, $client_id): string
    {
        $emailExists = SubAgentManagementTable::where('agentEmail', $request['agentEmail'])->count();
        if (!$emailExists) {
            return JSONSOAPConvert::toSoap('Sub-agent account does not exist');
        }

        $getClientIdSubAgent = SubAgentManagementTable::where('agentEmail', $request['agentEmail'])
                                                      ->select('client_id')
                                                      ->first();

        \DB::table('oauth_clients')->where('id', $getClientIdSubAgent->client_id)->delete();
        \DB::table('oauth_access_tokens')->where('client_id', $getClientIdSubAgent->client_id)->delete();
        \DB::table('oauth_auth_codes')->where('client_id', $getClientIdSubAgent->client_id)->delete();
        \DB::table('oauth_personal_access_clients')->where('client_id', $getClientIdSubAgent->client_id)->delete();

        SubAgentManagementTable::where('agentEmail', $request['agentEmail'])->delete();
        User::where('email', $request['agentEmail'])->delete();

        return JSONSOAPConvert::toOutput('Sub-agent account has been deleted');
    }

    public function DeleteFE($request, $client_id): string
    {
        $emailExists = AgentPortalUser::where('email', $request['agentEmail'])->count();
        if (!$emailExists) {
            return JSONSOAPConvert::toSoap('Sub-agent account agent portal does not exist');
        }

        AgentPortalUser::where('email', $request['agentEmail'])->delete();
        return JSONSOAPConvert::toOutput('Sub-agent account agent portal has been deleted');
    }

    public function checkAccount($request, $client_id): string
    {
        $checkMiddleware = SubAgentManagementTable::where('agentEmail', $request['agentEmail'])->count();
        $checkAgentPortal = AgentPortalUser::where('email', $request['agentEmail'])->count();
        $statuses = '<ipay_api_account_status>' . ($checkMiddleware ? 'true' : 'false') . '</ipay_api_account_status>';
        $statuses .= '<agent_portal_account_status>' . ($checkAgentPortal ? 'true' : 'false') . '</agent_portal_account_status>';
        return JSONSOAPConvert::toOutput($statuses);
    }

    // Privates
    private function createMiddlewareUser($data)
    {
        $input = [
            'name'         => $data['firstName'] . ' ' . $data['lastName'],
            'email'        => $data['agentEmail'],
            'phone_number' => '+_' . time(),
        ];
        $input['password'] = Hash::make($data['password']);
        $input['api_token'] = Str::random(60);
        return User::create($input);
    }


    private function updateMiddlewareUser($data)
    {
        $name = !empty($data['firstName']) ? $data['firstName'] : '';
        $name .= !empty($data['lastName']) ? $data['lastName'] : '';

        $input = [
            'name'  => $name,
            'email' => !empty($data['agentEmail']) ? $data['agentEmail'] : '',
        ];

        if (!empty($data['password'])) {
            $input['password'] = Hash::make($data['password']);
        }

        return User::where('email', $data['agentEmail'])->update($input);
    }
}
