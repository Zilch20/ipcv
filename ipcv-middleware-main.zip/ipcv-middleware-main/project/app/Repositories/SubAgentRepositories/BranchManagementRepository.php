<?php

namespace App\Repositories\SubAgentRepositories;

use App\AgentPortalBranch;
use App\BranchManagementTable;
use App\Http\Controllers\Controller;

class BranchManagementRepository extends Controller
{
    public function GetBranch()
    {
        $GetBranches = BranchManagementTable::orderBy('branchName', 'ASC')->get();
        return $GetBranches->toJson();
    }

    public function RegisterBranch($request)
    {
        $branchName = $request['branchName'];
        $branchExists = BranchManagementTable::where('branchName', '=', $branchName)
                        ->get()
                        ->count();
        if($branchExists > 0)
        {
            return response()->json(['Branch Already Exists'],200);
        }
        //Inserts into Sub-Agent DB
        $data['branchName'] = $request['branchName'];
        $data['branchOwner'] = $request['branchOwner'];
        $data['branchEmail'] = $request['branchEmail'];
        $data['branchAddress'] = $request['branchAddress'];
        $data['branchContact'] = $request['branchContact'];
        $data['branchTerminalId'] = $request['branchTerminalId'];
        $data['ftid'] = $request['ftid'];
        $data_inserted = BranchManagementTable::create($data);

        $this->RegisterBranchFE($request);

        //Convert Response to SOAP
        return response()->json(['Branch Registered'],200);

    }

    private function RegisterBranchFE($request)
    {
        //Inserts into Agent Portal DB
        $data['name'] = $request['branchName'];
        $data['description'] = $request['branchOwner'];
        $data['active'] = 1;
        $data_inserted = AgentPortalBranch::create($data);
    }

    public function UpdateBranch($request)
    {

        $branchId = $request['branchId'];

        $branchName = !empty($request['branchName']) ? $request['branchName'] : '';
        $branchOwner = !empty($request['branchOwner']) ? $request['branchOwner'] : '';
        $branchEmail = !empty($request['branchEmail']) ? $request['branchEmail'] : '';
        $branchAddress = !empty($request['branchAddress']) ? $request['branchAddress'] : '';
        $branchContact = !empty($request['branchContact']) ? $request['branchContact'] : '';
        $branchTerminalId = !empty($request['branchTerminalId']) ? $request['branchTerminalId'] : '';
        $ftid = !empty($request['ftid']) ? $request['ftid'] : '';

        //Checks if Branch Exists
        $emailExists = BranchManagementTable::where('id', '=', $branchId)
                        ->get()
                        ->count();
        // dd($emailExists);
        if($emailExists == 0)
        {
            return response()->json(['Branch is not Registered'],400);
        }

        // Code to Update FE Database Start
        $updateFE = BranchManagementTable::where('id', '=', $branchId)
                        ->get()
                        ->pluck("branchName");
        $this->UpdateBranchFE($request, $updateFE);

        //Updates Sub-agent Status
        if(!empty($request['branchName']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchName' => $branchName]);
        }
        if(!empty($request['branchOwner']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchOwner' => $branchOwner]);
        }
        if(!empty($request['branchEmail']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchEmail' => $branchEmail]);
        }
        if(!empty($request['branchAddress']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchAddress' => $branchAddress]);
        }
        if(!empty($request['branchContact']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchContact' => $branchContact]);
        }
        if(!empty($request['branchTerminalId']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchTerminalId' => $branchTerminalId]);
        }
        if(!empty($request['ftid']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['ftid' => $ftid]);
        }

        return response()->json(['Branch Information has Updated'],200);

    }

    private function UpdateBranchFE($request, $previousName)
    {
        $branchName = !empty($request['branchName']) ? $request['branchName'] : '';
        $branchOwner = !empty($request['branchOwner']) ? $request['branchOwner'] : '';

        //Updates Sub-agent Status
        if(!empty($request['branchName']))
        {
            $data_updated = AgentPortalBranch::where('name', '=', $previousName)
            ->update(['name' => $branchName]);
        }
        if(!empty($request['branchOwner']))
        {
            $data_updated = AgentPortalBranch::where('name', '=', $previousName)
            ->update(['description' => $branchOwner]);
        }
    }

    public function DeleteBranch($request)
    {
        $branchName = $request['branchName'];

        //Checks if Branch Exists
        $emailExists = BranchManagementTable::where('branchName', '=', $branchName)
                        ->get()
                        ->count();
        // dd($emailExists);
        if($emailExists == 0)
        {
            return response()->json(['Branch is not Registered'],400);
        }

        //Deletes Record From Sub-Agent DB
        $data_inserted = BranchManagementTable::where('branchName', '=', $branchName)->delete();

        $this->DeleteBranchFE($request);

        //Convert Response to SOAP
        return response()->json(['Branch '. $branchName .' Has Been Deleted'],200);

    }

    private function DeleteBranchFE($request)
    {
        $branchName = $request['branchName'];
        //Deletes Record From Sub-Agent DB
        $data_inserted = AgentPortalBranch::where('name', '=', $branchName)->delete();
    }

    public function searchBranch($request)
    {
        $branchName = !empty($request['branchName']) ? $request['branchName'] : '';
        $branchOwner = !empty($request['branchOwner']) ? $request['branchOwner'] : '';


        if(!empty($request['branchName']))
        {
            $branchDetails = BranchManagementTable::where('branchName', 'like', '%'.$branchName.'%')
                            ->get();
        }
        if(!empty($request['branchOwner']))
        {
            $branchDetails = BranchManagementTable::where('branchOwner', 'like', '%'.$branchName.'%')
                            ->get();
        }

        return $branchDetails->toJson();
    }

    public function GetBranchByOwner($request)
    {
        $branchOwner = $request['branchOwner'];
        $branchOwner = strtoupper($branchOwner);

        $branchOwnerExists = BranchManagementTable::where('branchOwner', '=', $branchOwner)
                        ->get()
                        ->count();
        if($branchOwnerExists == 0)
        {
            return response()->json(['No Branches'],400);
        }

        $GetBranches = BranchManagementTable::select('id','branchName', 'branchOwner')
                        ->where('branchOwner', '=', $branchOwner)
                        ->get();
        return $GetBranches->toJson();
    }
}
