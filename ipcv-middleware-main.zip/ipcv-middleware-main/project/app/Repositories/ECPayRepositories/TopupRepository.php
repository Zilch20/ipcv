<?php

namespace App\Repositories\ECPayRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class TopupRepository extends Controller
{
    public function test(){
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }
    //Payment Functions
    public function topupTransact($request, $partnerID)
    {
        $token = env('ECPAY_BRANCH_ID') + $request['phoneNum'] + $request['Amount'] + date("mdy");
        if($partnerID == '1'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'application/soap+xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params=
            '<?xml version="1.0" encoding="utf-8"?>
                <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
                <soap12:Body>
                    <Transact xmlns="http://ECPay/WSTopUp">
                        <LoginInfo>
                            <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                            <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                            <Username>'.env('ECPAY_USERNAME').'</Username>
                            <Password>'.env('ECPAY_PASSWORD').'</Password>
                        </LoginInfo>
                                                                                        
                        <Telco>SMART</Telco>
                        <CellphoneNo>'.$request['phoneNum'].'</CellphoneNo>
                        <ExtTag>'.$request['planCode'].'</ExtTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <Token>'.$request['token'].'</Token>
                    </Transact>
                </soap12:Body>
                </soap12:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }

        if($partnerID == '2'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'application/soap+xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params=
            '<?xml version="1.0" encoding="utf-8"?>
                <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
                <soap12:Body>
                    <Transact xmlns="http://ECPay/WSTopUp">
                        <LoginInfo>
                            <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                            <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                            <Username>'.env('ECPAY_USERNAME').'</Username>
                            <Password>'.env('ECPAY_PASSWORD').'</Password>
                        </LoginInfo>

                        <Telco>GLOBE</Telco>
                        <CellphoneNo>'.$request['phoneNum'].'</CellphoneNo>
                        <ExtTag>'.$request['planCode'].'</ExtTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <Token>'.$request['token'].'</Token>
                    </Transact>
                </soap12:Body>
                </soap12:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }

        if($partnerID == '3'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'application/soap+xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params=
            '<?xml version="1.0" encoding="utf-8"?>
                <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
                <soap12:Body>
                    <Transact xmlns="http://ECPay/WSTopUp">
                        <LoginInfo>
                            <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                            <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                            <Username>'.env('ECPAY_USERNAME').'</Username>
                            <Password>'.env('ECPAY_PASSWORD').'</Password>
                        </LoginInfo>

                        <Telco>SUN</Telco>
                        <CellphoneNo>'.$request['phoneNum'].'</CellphoneNo>
                        <ExtTag>'.$request['planCode'].'</ExtTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <Token>'.$request['token'].'</Token>
                    </Transact>
                </soap12:Body>
                </soap12:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }
    }
    public function telcoList(){
        $guzzle = new Client([
            'headers' => [
                'Host' => env('ECPAY_HOST'),
                'Content-Type' => 'application/soap+xml; charset=utf-8',
                'Content-Length' => 1,
            ]
        ]);

        $params=
        '<?xml version="1.0" encoding="utf-8"?>
            <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
             <soap12:Body>
                <GetTelcoList xmlns="http://ECPay/WSTopUp">
                <LoginInfo>
                    <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                    <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                    <Username>'.env('ECPAY_USERNAME').'</Username>
                    <Password>'.env('ECPAY_PASSWORD').'</Password>
                </LoginInfo>
                </GetTelcoList>
            </soap12:Body>
            </soap12:Envelope>
        ';

        $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $xml);
        $xml = simplexml_load_string($clean_xml);

        $status = (string)$xml->Body->TransactResponse->TransactResult->Status;
        $message = (string)$xml->Body->TransactResponse->TransactResult->Message;
        if($status == '0'){
            $traceNo = (string)$xml->Body->TransactResponse->TransactResult->TraceNo;
            $remainingBal = (string) $xml->Body->TransactResponse->TransactResult->RemainingBalance;
            $result = [
                'Status' => $status,
                'Message' => $message,
                'Trace No' => $traceNo,
                'Remaining Balance' => $remainingBal
            ];
        }

        if($status > '0'){
            $result = [
                'Status' => $status,
                'Message' => $message,
            ];
        }

        return json_decode(json_encode(["Result" => $result]), true);
    }

    private function cleanXML($res){
        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $xml);
        $xml = simplexml_load_string($clean_xml);

        $status = (string)$xml->Body->TransactResponse->TransactResult->Status;
        $message = (string)$xml->Body->TransactResponse->TransactResult->Message;
        if($status == '0'){
            $traceNo = (string)$xml->Body->TransactResponse->TransactResult->TraceNo;
            $remainingBal = (string) $xml->Body->TransactResponse->TransactResult->RemainingBalance;
            $result = [
                'Status' => $status,
                'Message' => $message,
                'Trace No' => $traceNo,
                'Remaining Balance' => $remainingBal
            ];
        }

        if($status > '0'){
            $result = [
                'Status' => $status,
                'Message' => $message,
            ];
        }

        return json_decode(json_encode(["Result" => $result]), true);
    }

}