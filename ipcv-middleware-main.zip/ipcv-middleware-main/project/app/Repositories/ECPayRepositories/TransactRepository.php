<?php

namespace App\Repositories\ECPayRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class TransactRepository extends Controller
{
    //Payment Functions
    public function telecommunicationsTransact($request, $partnerID)
    {

        if($partnerID == '1'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params=
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password>
                        <AccountNo>'.$request['accountNum'].'</AccountNo>
                        <Identifier>'.$request['parameterOne'].'</Identifier>
                        <BillerTag>SMART</BillerTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
            
        }

        if($partnerID == '2'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password>
                        <AccountNo>'.$request['accountNum'].'</AccountNo>
                        <Identifier>'.$request['parameterOne'].'</Identifier>
                        <BillerTag>GLOBELINES</BillerTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [ 
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }

        if($partnerID == '3'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params=
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo>
                        <Identifier>'.$request['parameterOne'].'</Identifier>
                        <BillerTag>SUNCELLULAR</BillerTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }
    }

    public function waterUtilitiesTransact($request, $partnerID)
    {
        if($partnerID == '1'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID>
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password>
                        <AccountNo>'.$request['accountNum'].'</AccountNo>
                        <Identifier>'.$request['parameterOne'].'</Identifier>
                        <BillerTag>MAYNILAD</BillerTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }

        if($partnerID == '2'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo>
                        <Identifier>'.$request['parameterOne'].'</Identifier>
                        <BillerTag>MANILAWATER</BillerTag>
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }
    }

    public function cableTransact($request, $partnerID)
    {
        if($partnerID == '1'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo>
                        <Identifier>'.$request['parameterOne'].'</Identifier>
                        <BillerTag>CIGNAL</BillerTag> 
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }

        if($partnerID == '2'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID> 
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo>
                        <Identifier>'.$request['parameterOne'].'</Identifier>
                        <BillerTag>SKYCABLE</BillerTag> 
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }
        if($partnerID == '3'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID> 
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo> 
                        <Identifier>'.$request['parameterOne'].'</Identifier> 
                        <BillerTag>CABLELINK</BillerTag> 
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }
    }

    public function creditCardTransact($request, $partnerID)
    {
        if($partnerID == '1'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID> 
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo> 
                        <Identifier>'.$request['parameterOne'].'</Identifier> 
                        <BillerTag>AUB_CREDITCARDS</BillerTag> 
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }

        if($partnerID == '2'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID> 
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo> 
                        <Identifier>'.$request['parameterOne'].'</Identifier> 
                        <BillerTag>BPI_CREDITCARD</BillerTag> 
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }
    }
    public function insuranceTransact($request, $partnerID)
    {
        if($partnerID == '1'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params=
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID> 
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo> 
                        <Identifier>'.$request['parameterOne'].'</Identifier> 
                        <BillerTag>AXA_PHIL</BillerTag> 
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }

        if($partnerID == '2'){
            //Send Validate Request
            $guzzle = new Client([
                'headers' => [
                    'Host' => env('ECPAY_HOST'),
                    'Content-Type' => 'text/xml; charset=utf-8',
                    'Content-Length' => 1,
                ]
            ]);

            $params= 
            '<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <Transact xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID> 
                        <BranchID>'.env('ECPAY_BRANCH_ID').'</BranchID> 
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password> 
                        <AccountNo>'.$request['accountNum'].'</AccountNo> 
                        <Identifier>'.$request['parameterOne'].'</Identifier> 
                        <BillerTag>COCOLIFE</BillerTag> 
                        <Amount>'.$request['Amount'].'</Amount>
                        <ClientReference>'.$request['ReferenceNo'].'</ClientReference>
                    </Transact>
                </soap:Body>
                </soap:Envelope>
            ';

            $res = $guzzle->post(env('ECPAY_BILLS_TRANSACT_URL'), [
                'body' => $params
            ]);

            return $this->cleanXML($res);
        }
    }



//Extra Functions

    public function billerList()
    {
        $guzzle = new Client([
            'headers' => [
                'Host' => env('ECPAY_HOST'),
                'Content-Type' => 'text/xml; charset=utf-8',
                'Content-Length' => 1,
            ]
        ]);

        $params=
        '<?xml version="1.0" encoding="utf-8"?>
            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <GetBillerList xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                        <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                        <Username>'.env('ECPAY_USERNAME').'</Username>
                        <Password>'.env('ECPAY_PASSWORD').'</Password>
                    </GetBillerList> 
                </soap:Body>
            </soap:Envelope>
        ';
 
        $res = $guzzle->post(env('ECPAY_BILLS_LIST_URL'), [
            'body' => $params
        ]);
    
        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $xml);
        $xml = simplexml_load_string($clean_xml);

        foreach($xml->Body->GetBillerListResponse->GetBillerListResult as $partner){
            $list = [$partner];
        }
        return json_decode(json_encode(["Partners" => $list]), true);
    }
    public function checkBalance()
    {
        $guzzle = new Client([
            'headers' => [
                'Host' => env('ECPAY_HOST'),
                'Content-Type' => 'text/xml; charset=utf-8',
                'Content-Length' => 1,
            ]
        ]);

        $params= 
        '<?xml version="1.0" encoding="utf-8"?>
            <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Body>
                    <CheckBalance xmlns="http://tempuri.org/ECPNBillsPayment/Service1">
                    <AccountID>'.env('ECPAY_ACCOUNT_ID').'</AccountID>
                    <Username>'.env('ECPAY_USERNAME').'</Username>
                    <Password>'.env('ECPAY_PASSWORD').'</Password>
                    </CheckBalance> 
                </soap:Body>
            </soap:Envelope>
        ';

        $res = $guzzle->post(env('ECPAY_BILLS_BALANCE_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $xml);
        $xml = simplexml_load_string($clean_xml);

        $balance = (string)$xml->Body->CheckBalanceResponse->CheckBalanceResult->RemBal;

        return json_decode(json_encode(["Balance" => $balance]), true);
    }

    private function cleanXML($res){
        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace(['SOAP-ENV:', 'SOAP:'], '', $xml);
        $xml = simplexml_load_string($clean_xml);

        $status = (string)$xml->Body->TransactResponse->TransactResult->Status;
        $message = (string)$xml->Body->TransactResponse->TransactResult->Message;
        if($status == '0'){
            $serviceCharge = (string)$xml->Body->TransactResponse->TransactResult->ServiceCharge;
            $result = [
                'Status' => $status,
                'Message' => $message,
                'Service Charge' => $serviceCharge
            ];
        }

        if($status > '0'){
            $result = [
                'Status' => $status,
                'Message' => $message,
            ];
        }

        return json_decode(json_encode(["Result" => $result]), true);
    }

}