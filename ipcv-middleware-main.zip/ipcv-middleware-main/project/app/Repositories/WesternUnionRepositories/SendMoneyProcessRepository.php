<?php

namespace App\Repositories\WesternUnionRepositories;

use App\DasRequestLog;
use App\FeeInquiryLogs;
use App\Helpers\SpecialCharacters;
use App\Http\Controllers\Controller;
use App\RetryMechanismLog;
use App\SendMoneyStoreLogs;
use App\SendMoneyValidateLogs;
use App\Traits\D2B\ReasonForSendingTrait;
use App\Traits\D2B\RoutingCodeTrait;
use App\Traits\GetStatusTraits;
use App\Traits\RetryMechanismTrait;
use App\Traits\SubAgentTraits;
use App\Traits\WesternUnionCurlRequestTrait;

class SendMoneyProcessRepository extends Controller
{
    use RoutingCodeTrait;
    use ReasonForSendingTrait;
    use WesternUnionCurlRequestTrait;
    use RetryMechanismTrait;
    use SubAgentTraits;
    use GetStatusTraits;

    /*
        dasRequest = Get Additional Data from WU such as US States and State Codes for transactions
        feeInquiryRequest = Computes for the Fees and conversion of money
        sendMoneyValidationRequest = Validates customer data
        sendMoneyStoreRequest = Stores Transaction data ready to be received.
    */

    public function dasRequest($request, $client_id)
    {

        // $ftid = "PH994ARP001B"; //Staging Credentials
        // $fsid = "WGHHPH9940P"; //Staging Credentials
        $fsid = "WGHHPH5130P"; //Prod Credentials
        $ftid = "PH513ARP001A"; //Prod Credentials

        //Get FTID & NAID using branchLocation
        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }

        if(empty($request['mobileFlag']))
        {
            $naid = $this->getNaid($request);
        }

        // Check NAID Start
        $checkNAID = SpecialCharacters::checkNAID($naid);
        if($checkNAID == "PH994")
        {
            $fsid = "WGHHPH9940P";
        }
        // Check NAID End
        //Get FTID & NAID using branchLocation

        //Mobile Conditions
        $device = '';
        $foreignRemoteSystem =
            '<foreign_remote_system>
            <identifier>' . $fsid . '</identifier>
            <reference_no>115210-000000003</reference_no>
            <counter_id>' . $ftid . '</counter_id>
        </foreign_remote_system>';
        if(!empty($request['mobileFlag']))
        {
            if($request['mobileFlag'] === true || $request['mobileFlag'] == 'true')
            {
                $device =
                    '<device>
                    <id>WALLET</id>
                    <type>WALLET</type>
                </device>';

                $foreignRemoteSystem =
                    '<foreign_remote_system>
                    <identifier>WGHHPH5130P</identifier>
                    <reference_no>115210-000000003</reference_no>
                    <counter_id>PH513ARP001A</counter_id>
                </foreign_remote_system>';
            }
        }
        //End Mobile Conditions

        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
            <xrsi:h2h-das-request>
                ' . $device . '
                <channel>
                    <type>' . $request['channelType'] . '</type>
                    <name>IPCV</name>
                    <version>' . $request['channelVersion'] . '</version>
                </channel>

                ' . $foreignRemoteSystem . '

                <client_id>H2H</client_id>
                ' . (!empty($request['dasRequest']) ? '<name>' . $request['dasRequest'] . '</name>' : '') . '

                <filters>
                    <queryfilter1>en</queryfilter1>
                    ' . (!empty($request['queryFilter1']) ? '<queryfilter2>' . $request['queryFilter1'] . '</queryfilter2>' : '') . '
                    ' . (!empty($request['queryFilter2']) ? '<queryfilter3>' . $request['queryFilter2'] . '</queryfilter3>' : '') . '
                    ' . (!empty($request['queryFilter3']) ? '<queryfilter4>' . $request['queryFilter3'] . '</queryfilter4>' : '') . '
                    ' . (!empty($request['queryFilter4']) ? '<queryfilter5>' . $request['queryFilter4'] . '</queryfilter5>' : '') . '
                </filters>

            </xrsi:h2h-das-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }
        // exit(var_dump($params));

        $output = $this->requestWUAPI($params, $client_id, $request);
        // exit(var_dump($output));


    //     $xml = simplexml_load_string($output);
    //     // $points = $xml->addChild("points");
    //     // exit(var_dump($xml));
    //         $namespaces = $xml->getNamespaces(true);
    //         $body = $xml->children($namespaces['soapenv'])
    //             ->Body
    //             ->children($namespaces['xrsi'])
    //             ->children();
    //     //         ->MTML
    //     //         ->REPLY
    //     //         ->DATA_CONTEXT
    //     //         ->RECORDSET;

    //    $body->addChild("total_points_earned", "80");

    //     echo $xml->asXML();

    //     exit();

        // $request['status'] = $this->getTransactionStatus($output);
        // dd($request);

        $logs['clientId'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = DasRequestLog::create($logs);

        return $output;
        // }

    }

    //Returns Fee computation from WU
    public function feeInquiryRequest($request, $client_id)
    {

        // $ftid = "PH994ARP001B"; //Staging Credentials
        // $fsid = "WGHHPH9940P"; //Staging Credentials
        $fsid = "WGHHPH5130P"; //Prod Credentials
        $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }

        if(empty($request['mobileFlag']))
        {
            $naid = $this->getNaid($request);

            // Check NAID Start
            $checkNAID = SpecialCharacters::checkNAID($naid);
            if($checkNAID == "PH994")
            {
                $fsid = "WGHHPH9940P";
            }
            // Check NAID End
        }

        //Mobile Conditions
        $device =
        '<device>
            <type>AGENT</type>
        </device>';
        $foreignRemoteSystem =
        '<foreign_remote_system>
            <identifier>' . $fsid . '</identifier>
            <reference_no>115210-000000003</reference_no>
            <counter_id>' . $ftid . '</counter_id>
        </foreign_remote_system>';
        if(!empty($request['mobileFlag']))
        {
            if($request['mobileFlag'] === true || $request['mobileFlag'] == 'true')
            {
                $device =
                '<device>
                    <id>WALLET</id>
                    <type>WALLET</type>
                </device>';

                $foreignRemoteSystem =
                '<foreign_remote_system>
                    <identifier>WGHHPH5131P</identifier>
                    <reference_no>115210-000000003</reference_no>
                    <counter_id>PH513AMP001E</counter_id>
                </foreign_remote_system>';
            }
        }
        //End Mobile Conditions


        if ($request['transactionType'] == "WMN") {
            $originPrincipalAmount = $request['amount'];
            $destinationPrincipalAmount = 0;
        }
        if ($request['transactionType'] == "WMF") {
            $originPrincipalAmount = 0;
            $destinationPrincipalAmount = $request['destinationAmount'];
        }
        // dd($originPrincipalAmount." ".$destinationPrincipalAmount);
        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:fee-inquiry-request>
                    ' . $device . '
                    <channel>
                        <type>' . $request['channelType'] . '</type>
                        <name>IPCV</name>
                        <version>' . $request['channelVersion'] . '</version>
                    </channel>

                    <financials>
                        ' . (!empty($request['amount']) ? '<originators_principal_amount>' . $request['amount'] . '</originators_principal_amount>' : '') . '
                        ' . (!empty($request['destinationAmount']) ? '<destination_principal_amount>' . $request['destinationAmount'] . '</destination_principal_amount>' : '') . '
                    </financials>

                    <payment_details>
                        <recording_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </recording_country_currency>

                        <destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </destination_country_currency>

                        <originating_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </originating_country_currency>

                        ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                    </payment_details>
                    <promotions>
                        ' . (!empty($request['couponCode']) ? '<coupons_promotions>' . $request['couponCode'] . '</coupons_promotions>' : '') . '
                        ' . (!empty($request['senderPromoCode']) ? '<coupons_promotions>' . $request['senderPromoCode'] . '</coupons_promotions>' : '') . '
                    </promotions>
                    <delivery_services>
                        ' . (!empty($request['deliveryCode']) ? '<code>' . $request['deliveryCode'] . '</code>' : '') . '
                       <message>
                            <message_details context="4">
                                ' . (!empty($request['message1']) ? '<text>' . $request['message1'] . '</text>' : '') . '
                                ' . (!empty($request['message2']) ? '<text>' . $request['message2'] . '</text>' : '') . '
                                ' . (!empty($request['message3']) ? '<text>' . $request['message3'] . '</text>' : '') . '
                                ' . (!empty($request['message4']) ? '<text>' . $request['message4'] . '</text>' : '') . '
                            </message_details>
                       </message>
                    </delivery_services>

                    ' . $foreignRemoteSystem . '

                </xrsi:fee-inquiry-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id, $request);

        // exit(var_dump($output));

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = FeeInquiryLogs::create($logs);

        return $output;

    }

    //Validates Customer Data to make sure no Compliance error can be found
    public function sendMoneyValidationRequest($request, $client_id)
    {

        $request = SpecialCharacters::encodeAmpersand($request);

        $countryCode = $request['senderCountryCode'];
        $countryName = config('country.' . $countryCode);

        $destcountryCode = $request['destinationCountry'];
        $destcountryName = config('country.' . $destcountryCode);

        // $ftid = "PH994ARP001B"; //Staging Credentials
        // $fsid = "WGHHPH9940P"; //Staging Credentials
        $fsid = "WGHHPH5130P"; //Prod Credentials
        $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }

        if(empty($request['mobileFlag']))
        {
            $naid = $this->getNaid($request);

            // Check NAID Start
            $checkNAID = SpecialCharacters::checkNAID($naid);
            if($checkNAID == "PH994")
            {
                $fsid = "WGHHPH9940P";
            }
            // Check NAID End
        }

        //Mobile Conditions
        $currentAddress =
        '<Current_address>
            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
            ' . (!empty($request['province']) ? '<state_name>' . $request['province'] . '</state_name>' : '') . '
            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
            <country>' . $countryName . '</country>
        </Current_address>';
        $device = '';
        $senderBankDetails = '';
        $foreignRemoteSystem =
        '<foreign_remote_system>
            <identifier>' . $fsid . '</identifier>
            <reference_no>115210-000000003</reference_no>
            <counter_id>' . $ftid . '</counter_id>
        </foreign_remote_system>';
        if(!empty($request['mobileFlag']))
        {
            if($request['mobileFlag'] === true || $request['mobileFlag'] == 'true')
            {
            $device =
            '<device>
                <id>WALLET</id>
                <type>WALLET</type>
            </device>';

            $currentAddress = '
            <Current_address>
                ' . (!empty($request['currentAddress1']) ? '<addr_line1>' . $request['currentAddress1'] . '</addr_line1>' : '') . '
                ' . (!empty($request['currentAddress2']) ? '<addr_line2>' . $request['currentAddress2'] . '</addr_line2>' : '') . '
                ' . (!empty($request['currentCity']) ? '<city>' . $request['currentCity'] . '</city>' : '') . '
                ' . (!empty($request['currentProvince']) ? '<state_name>' . $request['currentProvince'] . '</state_name>' : '') . '
                ' . (!empty($request['currentPostalCode']) ? '<postal_code>' . $request['currentPostalCode'] . '</postal_code>' : '') . '
                ' . (!empty($request['currentCountry']) ? '<country>' . $request['currentCountry'] . '</country>' : '') . '
                ' . (empty($request['currentCountry']) ? '<country>' . $countryName . '</country>' : '') . '
            </Current_address>
            ';

            if (!empty($request['senderAccountNumber'])) {
                $senderBankDetails = '<bank_details>';
                $senderBankDetails .= !empty($request['senderBankName']) ? '<name>' . $request['senderBankName'] . '</name>' : '';
                $senderBankDetails .= !empty($request['senderAccountNumber']) ? '<account_number>' . $request['senderAccountNumber'] . '</account_number>' : '';
                $senderBankDetails .= !empty($request['senderAccountType']) ? '<account_type>' . $request['senderAccountType'] . '</account_type>' : '';
                $senderBankDetails .= '</bank_details>';
            }

            $foreignRemoteSystem =
            '<foreign_remote_system>
                <identifier>WGHHPH5131P</identifier>
                <reference_no>115210-000000003</reference_no>
                <counter_id>PH513AMP001E</counter_id>
            </foreign_remote_system>';
            }
        }
        //End Mobile Conditions

        //Bank Details
        $bank_details = '';
        if (!empty($request['accountNumber'])) {
            $bank_details = '<bank_details>';
            $bank_details .= !empty($request['bankName']) ? '<name>' . $request['bankName'] . '</name>' : '';
            $bank_details .= !empty($request['accountNumber']) ? '<account_number>' . $request['accountNumber'] . '</account_number>' : '';
            $bank_details .= !empty($request['routingNumber']) ? '<routing_number>' . $request['routingNumber'] . '</routing_number>' : '';
            $bank_details .= !empty($request['branchNumber']) ? '<branch_number>' . $request['branchNumber'] . '</branch_number>' : '';
            $bank_details .= !empty($request['bankLocation']) ? '<bank_location>' . $request['bankLocation'] . '</bank_location>' : '';
            $bank_details .= !empty($request['bic']) ? '<bic>' . $request['bic'] . '</bic>' : '';
            $bank_details .= !empty($request['bankCode']) ? '<bank_code>' . $request['bankCode'] . '</bank_code>' : '';
            $bank_details .= !empty($request['sortCode']) ? '<sort_code>' . $request['sortCode'] . '</sort_code>' : '';
            $bank_details .= !empty($request['accountPrefix']) ? '<account_prefix>' . $request['accountPrefix'] . '</account_prefix>' : '';
            $bank_details .= !empty($request['accountSuffix']) ? '<account_suffix>' . $request['accountSuffix'] . '</account_suffix>' : '';
            $bank_details .= !empty($request['accountName']) ? '<bank_account_holder>' . $request['accountName'] . '</bank_account_holder>' : '';
            $bank_details .= '</bank_details>';
        }

        $request['issueDate'] = !empty($request['issueDate']) ? str_replace('/', '', $request['issueDate']) : '';
        $request['expiration'] = !empty($request['expiration']) ? str_replace('/', '', $request['expiration']) : '';
        $request['birthDate'] = str_replace('/', '', $request['birthDate']);

        $id_details = '';
        if (!empty($request['idType']) || !empty($request['idCountryIssued']) || !empty($request['idNum'])) {
            $id_details = '<id_details>';
            $id_details .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
            $id_details .= !empty($request['idCountryIssued']) ? '<id_country_of_issue>' . $request['idCountryIssued'] . '</id_country_of_issue>' : '';
            $id_details .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
            $id_details .= '</id_details>';
        }

        $request['reasonForSending'] = $this->getReasonForSendingCode($request);
        // dd($request['reasonForSending']);


        $retryMechanism = RetryMechanismLog::findLog('send_money_validation', $request, 'send')->get();
        if (!empty($retryMechanism[0])) {
            $retryMechanismData = $retryMechanism[0];
            $request['myWuNumber'] = !empty($retryMechanismData['account_nbr']) ? $retryMechanismData['account_nbr'] : $request['myWuNumber'];
            $request['mtcn'] = !empty($retryMechanismData['mtcn']) ? $retryMechanismData['mtcn'] : "";
            $request['galactic_id'] = !empty($retryMechanismData['galactic_id']) ? $retryMechanismData['galactic_id'] : "";
            $request['mtcn_digest'] = !empty($retryMechanismData['mtcn_digest']) ? $retryMechanismData['mtcn_digest'] : "";
        }
//        Debugger::dd($request);

        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
        <soapenv:Header/>
        <soapenv:Body>
           <xrsi:send-money-validation-request>
                ' . $device . '
              <channel>
                 <type>' . $request['channelType'] . '</type>
                 <name>IPCV</name>
                 <version>' . $request['channelVersion'] . '</version>
              </channel>
              <sender>
                 <name name_type="D">
                   ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                   ' . (!empty($request['middleName']) ? '<middle_name>' . $request['middleName'] . '</middle_name>' : '') . '
                   ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                 </name>
                 <address>
                   ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                   ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                   ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                   ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                   ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                    <country_code>
                       <iso_code>
                            ' . (!empty($request['senderCountryCode']) ? '<country_code>' . $request['senderCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['senderCountryCurrencyCode']) ? '<currency_code>' . $request['senderCountryCurrencyCode'] . '</currency_code>' : '') . '
                       </iso_code>
                       <country_name>' . $countryName . '</country_name>
                    </country_code>
                 </address>
                 <preferred_customer>
                    ' . (!empty($request['permanentChange']) ? '<permanent_change>' . $request['permanentChange'] . '</permanent_change>' : '') . '
                    ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                 </preferred_customer>
                 <compliance_details>
                   ' . $this->getRoutingCode($request)['templateId'] . '
                   ' . (!empty($request['version']) ? '<version>' . $request['version'] . '</version>' : '') . '

                   ' . $id_details . '

                   ' . (!empty($request['flagPay']) ? '<third_party_details><flag_pay>' . $request['flagPay'] . '</flag_pay></third_party_details>' : '') . '
                   ' . (!empty($request['issueDate']) ? '<id_issue_date>' . $request['issueDate'] . '</id_issue_date>' : '') . '
                   ' . (!empty($request['expiration']) ? '<id_expiration_date>' . $request['expiration'] . '</id_expiration_date>' : '') . '
                   ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                   ' . (!empty($request['occupation']) ? '<occupation>' . $request['occupation'] . '</occupation>' : '') . '
                   ' . (!empty($request['transactionReason']) ? '<transaction_reason>' . $request['transactionReason'] . '</transaction_reason>' : '') . '

                   ' . $currentAddress . '

                   ' . (!empty($request['countryofBirth']) ? '<Country_of_Birth>' . $request['countryofBirth'] . '</Country_of_Birth>' : '') . '

                   ' . (!empty($request['nationality']) ? '<nationality>' . $request['nationality'] . '</nationality>' : '') . '
                   ' . (!empty($request['gender']) ? '<Gender>' . $request['gender'] . '</Gender>' : '') . '
                   ' . (!empty($request['fundSource']) ? '<Source_of_Funds>' . $request['fundSource'] . '</Source_of_Funds>' : '') . '
                   ' . (!empty($request['relationshiptoReceiver']) ? '<Relationship_to_Receiver_Sender>' . $request['relationshiptoReceiver'] . '</Relationship_to_Receiver_Sender>' : '') . '
                   ' . (!empty($request['idHasExpiration']) ? '<Does_the_ID_have_an_expiration_date>' . $request['idHasExpiration'] . '</Does_the_ID_have_an_expiration_date>' : '') . '
                   ' . (!empty($request['ackFlag']) ? '<ack_flag>' . strtoupper($request['ackFlag']) . '</ack_flag>' : '') . '
                   ' . (!empty($request['galactic_id']) ? '<galactic_id>' . $request['galactic_id'] . '</galactic_id>' : '') . '
                   ' . (!empty($request['multiErrorSupported']) ? '<multi_error_supported>' . $request['multiErrorSupported'] . '</multi_error_supported>' : '') . '
                   ' . (!empty($request['positionLevel']) ? '<employment_position_level>' . $request['positionLevel'] . '</employment_position_level>' : '') . '
                 </compliance_details>
                 ' . (!empty($request['email']) ? '<email>' . $request['email'] . '</email>' : '') . '
                 ' . (!empty($request['phoneCountryCode']) ? '<phone_country_code>' . $request['phoneCountryCode'] . '</phone_country_code>' : '') . '
                 ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                 <mobile_phone>
                    <phone_number>
                        ' . (!empty($request['phoneCountryCode']) ? '<country_code>' . $request['phoneCountryCode'] . '</country_code>' : '') . '
                        ' . (!empty($request['phoneNum']) ? '<national_number>' . $request['phoneNum'] . '</national_number>' : '') . '
                    </phone_number>
                 </mobile_phone>
                 ' . $senderBankDetails . '
              </sender>
              <receiver>
                 <name name_type="D">
                    ' . (!empty($request['receiverFirstName']) ? '<first_name>' . $request['receiverFirstName'] . '</first_name>' : '') . '
                    ' . (!empty($request['receiverMiddleName']) ? '<middle_name>' . $request['receiverMiddleName'] . '</middle_name>' : '') . '
                    ' . (!empty($request['receiverLastName']) ? '<last_name>' . $request['receiverLastName'] . '</last_name>' : '') . '
                 </name>
                 <address>
                 ' . (!empty($request['receiverAddress1']) ? '<addr_line1>' . $request['receiverAddress1'] . '</addr_line1>' : '') . '
                 ' . (!empty($request['receiverAddress2']) ? '<addr_line2>' . $request['receiverAddress2'] . '</addr_line2>' : '') . '
                 ' . (!empty($request['receiverHomeCity']) ? '<city>' . $request['receiverHomeCity'] . '</city>' : '') . '
                 ' . (!empty($request['receiverState']) ? '<state>' . $request['receiverState'] . '</state>' : '') . '
                 ' . (!empty($request['receiverPostalCode']) ? '<postal_code>' . $request['receiverPostalCode'] . '</postal_code>' : '') . '
                  <country_code>
                     <iso_code>
                        ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                        ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                     </iso_code>
                     <country_name>' . $destcountryName . '</country_name>
                    </country_code>
                </address>
                ' . (!empty($request['receiverPhoneCountryCode']) ? '<phone_country_code>' . $request['receiverPhoneCountryCode'] . '</phone_country_code>' : '') . '
                ' . (!empty($request['receiverPhoneNum']) ? '<contact_phone>' . $request['receiverPhoneNum'] . '</contact_phone>' : '') . '
                <mobile_phone>
                    <phone_number>
                        ' . (!empty($request['receiverPhoneCountryCode']) ? '<country_code>' . $request['receiverPhoneCountryCode'] . '</country_code>' : '') . '
                        ' . (!empty($request['receiverPhoneNum']) ? '<national_number>' . $request['receiverPhoneNum'] . '</national_number>' : '') . '
                    </phone_number>
                </mobile_phone>
                ' . (!empty($request['reasonForSending']) ? '<reason_for_sending>' . $request['reasonForSending'] . '</reason_for_sending>' : '') . '
              </receiver>
              <payment_details>
                 <expected_payout_location>
                    ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                    ' . (!empty($request['receiverCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                 </expected_payout_location>
                 <recording_country_currency>
                    <iso_code>
                        ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                        ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                    </iso_code>
                 </recording_country_currency>
                 <destination_country_currency>
                    <iso_code>
                        ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                        ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                    </iso_code>
                 </destination_country_currency>
                 <originating_country_currency>
                    <iso_code>
                        ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                        ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                    </iso_code>
                 </originating_country_currency>
                 ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                 ' . (!empty($request['paymentType']) ? '<payment_type>' . $request['paymentType'] . '</payment_type>' : '') . '
                 ' . (!empty($request['exchangeRate']) ? '<exchange_rate>' . $request['exchangeRate'] . '</exchange_rate>' : '') . '
                 ' . (!empty($request['payWoIdIndicator']) ? '<pay_wo_id_indicator>' . $request['payWoIdIndicator'] . '</pay_wo_id_indicator>' : '') . '
                 ' . (!empty($request['duplicateDetectionFlag']) ? '<duplicate_detection_flag>' . $request['duplicateDetectionFlag'] . '</duplicate_detection_flag>' : '') . '
              </payment_details>
              <financials>
                ' . (!empty($request['amount']) ? '<originators_principal_amount>' . $request['amount'] . '</originators_principal_amount>' : '') . '
                ' . (!empty($request['destinationAmount']) ? '<destination_principal_amount>' . $request['destinationAmount'] . '</destination_principal_amount>' : '') . '
              </financials>
              <delivery_services>
                 ' . (!empty($request['deliveryCode']) ? '<code>' . $request['deliveryCode'] . '</code>' : '') . '
                 ' . $this->getRoutingCode($request)['routingCode'] . '
                 <message>
                    <message_details context="4">
                        ' . (!empty($request['message1']) ? '<text>' . $request['message1'] . '</text>' : '') . '
                        ' . (!empty($request['message2']) ? '<text>' . $request['message2'] . '</text>' : '') . '
                        ' . (!empty($request['message3']) ? '<text>' . $request['message3'] . '</text>' : '') . '
                        ' . (!empty($request['message4']) ? '<text>' . $request['message4'] . '</text>' : '') . '
                    </message_details>
                </message>
              </delivery_services>
              <promotions>
                    ' . (!empty($request['couponCode']) ? '<coupons_promotions>' . $request['couponCode'] . '</coupons_promotions>' : '') . '
                    ' . (!empty($request['senderPromoCode']) ? '<coupons_promotions>' . $request['senderPromoCode'] . '</coupons_promotions>' : '') . '
                </promotions>
             ' . $bank_details . '
            ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
              ' . $foreignRemoteSystem . '
            ' . (!empty($request['mtcn_digest']) ? '<mtcn_digest>' . $request['mtcn_digest'] . '</mtcn_digest>' : '') . '
           </xrsi:send-money-validation-request>
        </soapenv:Body>
     </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }
        //  exit(var_dump($params));

        $output = $this->requestWUAPI($params, $client_id, $request);

        $this->retryMechanism($output, 'send_money_validation', $request, $client_id);

        // exit(var_dump($output));

        $senderFirstName = !empty($request['firstName']) ? $request['firstName'] : '';
        $senderLastName = !empty($request['lastName']) ? $request['lastName'] : '';
        $senderName = $senderFirstName . " " . $senderLastName;

        $receiverFirstName = !empty($request['receiverFirstName']) ? $request['receiverFirstName'] : '';
        $receiverLastName = !empty($request['receiverLastName']) ? $request['receiverLastName'] : '';
        $receiverName = $senderFirstName . " " . $senderLastName;

        // $logs['agentEmail'] = !empty($request['agentEmail']) ? $request['agentEmail'] : '';
        $logs['client_id'] = $client_id;
        $logs['senderName'] = $senderName;
        $logs['transactionReason'] = !empty($request['transactionReason']) ? $request['transactionReason'] : '';
        $logs['amount'] = !empty($request['amount']) ? $request['amount'] : '';
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = SendMoneyValidateLogs::create($logs);

        return $output;

    }

    //Finalizes the transaction allowing the receiving end to be able to get the transaction
    public function sendMoneyStoreRequest($request, $client_id)
    {

        $request = SpecialCharacters::encodeAmpersand($request);

        $destcountryCode = $request['destinationCountry'];
        $destcountryName = config('country.' . $destcountryCode);

        $countryCode = $request['senderCountryCode'];
        $countryName = config('country.' . $countryCode);

        // $ftid = "PH994ARP001B"; //Staging Credentials
        // $fsid = "WGHHPH9940P"; //Staging Credentials
        $fsid = "WGHHPH5130P"; //Prod Credentials
        $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }

        if(empty($request['mobileFlag']))
        {
            $naid = $this->getNaid($request);

            // Check NAID Start
            $checkNAID = SpecialCharacters::checkNAID($naid);
            if($checkNAID == "PH994")
            {
                $fsid = "WGHHPH9940P";
            }
            // Check NAID End
        }

        //Mobile Conditions
        $device = '';
        $senderBankDetails = '';
        $foreignRemoteSystem =
        '<foreign_remote_system>
            <identifier>' . $fsid . '</identifier>
            <reference_no>115210-000000003</reference_no>
            <counter_id>' . $ftid . '</counter_id>
        </foreign_remote_system>';
        if(!empty($request['mobileFlag']))
        {
            if($request['mobileFlag'] === true || $request['mobileFlag'] == 'true')
            {
            $device =
            '<device>
                <id>WALLET</id>
                <type>WALLET</type>
            </device>';

            if (!empty($request['senderAccountNumber'])) {
                $senderBankDetails = '<bank_details>';
                $senderBankDetails .= !empty($request['senderBankName']) ? '<name>' . $request['senderBankName'] . '</name>' : '';
                $senderBankDetails .= !empty($request['senderAccountNumber']) ? '<account_number>' . $request['senderAccountNumber'] . '</account_number>' : '';
                $senderBankDetails .= !empty($request['senderAccountType']) ? '<account_type>' . $request['senderAccountType'] . '</account_type>' : '';
                $senderBankDetails .= '</bank_details>';
            }

            $foreignRemoteSystem =
            '<foreign_remote_system>
                <identifier>WGHHPH5131P</identifier>
                <reference_no>115210-000000003</reference_no>
                <counter_id>PH513AMP001E</counter_id>
            </foreign_remote_system>';
            }
        }
        //End Mobile Conditions



        //Bank Details
        $bank_details = '';
        if (!empty($request['accountNumber'])) {
            $bank_details = '<bank_details>';
            $bank_details .= !empty($request['bankName']) ? '<name>' . $request['bankName'] . '</name>' : '';
            $bank_details .= !empty($request['accountNumber']) ? '<account_number>' . $request['accountNumber'] . '</account_number>' : '';
            $bank_details .= !empty($request['routingNumber']) ? '<routing_number>' . $request['routingNumber'] . '</routing_number>' : '';
            $bank_details .= !empty($request['branchNumber']) ? '<branch_number>' . $request['branchNumber'] . '</branch_number>' : '';
            $bank_details .= !empty($request['bankLocation']) ? '<bank_location>' . $request['bankLocation'] . '</bank_location>' : '';
            $bank_details .= !empty($request['bic']) ? '<bic>' . $request['bic'] . '</bic>' : '';
            $bank_details .= !empty($request['bankCode']) ? '<bank_code>' . $request['bankCode'] . '</bank_code>' : '';
            $bank_details .= !empty($request['sortCode']) ? '<sort_code>' . $request['sortCode'] . '</sort_code>' : '';
            $bank_details .= !empty($request['accountPrefix']) ? '<account_prefix>' . $request['accountPrefix'] . '</account_prefix>' : '';
            $bank_details .= !empty($request['accountSuffix']) ? '<account_suffix>' . $request['accountSuffix'] . '</account_suffix>' : '';
            $bank_details .= !empty($request['accountName']) ? '<bank_account_holder>' . $request['accountName'] . '</bank_account_holder>' : '';
            $bank_details .= '</bank_details>';
        }

        $request['issueDate'] = !empty($request['issueDate']) ? str_replace('/', '', $request['issueDate']) : '';
        $request['expiration'] = !empty($request['expiration']) ? str_replace('/', '', $request['expiration']) : '';
        $request['birthDate'] = !empty($request['expiration']) ? str_replace('/', '', $request['birthDate']) : '';

        $id_details = '';
        if (!empty($request['idType']) || !empty($request['idCountryIssued']) || !empty($request['idNum'])) {
            $id_details = '<id_details>';
            $id_details .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
            $id_details .= !empty($request['idCountryIssued']) ? '<id_country_of_issue>' . $request['idCountryIssued'] . '</id_country_of_issue>' : '';
            $id_details .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
            $id_details .= '</id_details>';
        }

        $firstName = $request['firstName'];
        $lastName = $request['lastName'];
        $name = $firstName . " " . $lastName;

        // Get the transactionReason value from send money validate logs when the value is not in the request data
        if (empty($request['transactionReason'])) {
            $results = SendMoneyValidateLogs::select('senderName', 'transactionReason', 'amount', 'created_at')
//                                            ->where('senderName', '=', $name)
//                                            ->where('amount', '=', $request['amount'])
                                            ->where('request_data->firstName', $request['firstName'])
                                            ->where('request_data->lastName', $request['lastName'])
                                            ->where('request_data->amount', $request['amount'])
                                            ->where('request_data->deliveryCode', $request['deliveryCode'])
                                            ->where('request_data->receiverFirstName', $request['receiverFirstName'])
                                            ->where('request_data->receiverLastName', $request['receiverLastName'])
                                            ->orderBy('created_at', 'desc')
                                            ->take(5)
                                            ->get();
            // dd($results);
            $request['transactionReason'] = $results[0]['transactionReason'];
        }
        // dd($request);

        $request['reasonForSending'] = $this->getReasonForSendingCode($request);
        // dd($request);

        $retryMechanism = RetryMechanismLog::findLog('send_money_validation', $request, 'send')->get();
        if (!empty($retryMechanism[0])) {
            $retryMechanismData = $retryMechanism[0];
            $request['myWuNumber'] = !empty($retryMechanismData['account_nbr']) ? $retryMechanismData['account_nbr'] : $request['myWuNumber'];
//            $request['mtcn'] = !empty($retryMechanismData['mtcn']) ? $retryMechanismData['mtcn'] : $request['mtcn'];
//            $request['galactic_id'] = !empty($retryMechanismData['galactic_id']) ? $retryMechanismData['galactic_id'] : null;
//            $request['mtcn_digest'] = !empty($retryMechanismData['mtcn_digest']) ? $retryMechanismData['mtcn_digest'] : null;
        }
//        Debugger::dd($request);

        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
            <xrsi:send-money-store-request>
                ' . $device . '
                <channel>
                    <type>' . $request['channelType'] . '</type>
                    <name>IPCV</name>
                    <version>' . $request['channelVersion'] . '</version>
                </channel>
                <sender>
                        <name name_type="D">
                        ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                        ' . (!empty($request['middleName']) ? '<middle_name>' . $request['middleName'] . '</middle_name>' : '') . '
                        ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                    </name>
                        <address>
                            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                            ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                            ' . (!empty($request['senderCountryCode']) ? '<country_code>' . $request['senderCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['senderCountryCurrencyCode']) ? '<currency_code>' . $request['senderCountryCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $countryName . '</country_name>
                            </country_code>
                        </address>
                    <preferred_customer>
                        ' . (!empty($request['permanentChange']) ? '<permanent_change>' . $request['permanentChange'] . '</permanent_change>' : '') . '
                        ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                    </preferred_customer>
                    <compliance_details>
                        ' . (!empty($request['complianceDataBuffer']) ? '<compliance_data_buffer>' . $request['complianceDataBuffer'] . '</compliance_data_buffer>' : '') . '
                    </compliance_details>
                    ' . (!empty($request['email']) ? '<Email>' . $request['email'] . '</Email>' : '') . '
                    ' . (!empty($request['phoneCountryCode']) ? '<phone_country_code>' . $request['phoneCountryCode'] . '</phone_country_code>' : '') . '
                    ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                    <mobile_phone>
                       <phone_number>
                           ' . (!empty($request['phoneCountryCode']) ? '<country_code>' . $request['phoneCountryCode'] . '</country_code>' : '') . '
                           ' . (!empty($request['phoneNum']) ? '<national_number>' . $request['phoneNum'] . '</national_number>' : '') . '
                       </phone_number>
                    </mobile_phone>

                    ' . $senderBankDetails . '
                </sender>
                <receiver>
                    <name name_type="D">
                        ' . (!empty($request['receiverFirstName']) ? '<first_name>' . $request['receiverFirstName'] . '</first_name>' : '') . '
                        ' . (!empty($request['receiverMiddleName']) ? '<middle_name>' . $request['receiverMiddleName'] . '</middle_name>' : '') . '
                        ' . (!empty($request['receiverLastName']) ? '<last_name>' . $request['receiverLastName'] . '</last_name>' : '') . '
                    </name>
                    <address>
                    ' . (!empty($request['receiverAddress1']) ? '<addr_line1>' . $request['receiverAddress1'] . '</addr_line1>' : '') . '
                    ' . (!empty($request['receiverAddress2']) ? '<addr_line2>' . $request['receiverAddress2'] . '</addr_line2>' : '') . '
                    ' . (!empty($request['receiverHomeCity']) ? '<city>' . $request['receiverHomeCity'] . '</city>' : '') . '
                    ' . (!empty($request['receiverState']) ? '<state>' . $request['receiverState'] . '</state>' : '') . '
                    ' . (!empty($request['receiverPostalCode']) ? '<postal_code>' . $request['receiverPostalCode'] . '</postal_code>' : '') . '
                    <country_code>
                        <iso_code>
                            ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                            ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                        <country_name>' . $destcountryName . '</country_name>
                        </country_code>
                    </address>
                    ' . (!empty($request['receiverPhoneCountryCode']) ? '<phone_country_code>' . $request['receiverPhoneCountryCode'] . '</phone_country_code>' : '') . '
                    ' . (!empty($request['receiverPhoneNum']) ? '<contact_phone>' . $request['receiverPhoneNum'] . '</contact_phone>' : '') . '
                    <mobile_phone>
                        <phone_number>
                            ' . (!empty($request['receiverPhoneCountryCode']) ? '<country_code>' . $request['receiverPhoneCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['receiverPhoneNum']) ? '<national_number>' . $request['receiverPhoneNum'] . '</national_number>' : '') . '
                        </phone_number>
                    </mobile_phone>
                    ' . (!empty($request['reasonForSending']) ? '<reason_for_sending>' . $request['reasonForSending'] . '</reason_for_sending>' : '') . '
                </receiver>
                ' . $bank_details . '
                <promotions>
                    ' . (!empty($request['couponCode']) ? '<coupons_promotions>' . $request['couponCode'] . '</coupons_promotions>' : '') . '
                </promotions>
                <payment_details>
                    <expected_payout_location>
                        ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                        ' . (!empty($request['receiverCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                    </expected_payout_location>
                    <recording_country_currency>
                        <iso_code>
                            ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </recording_country_currency>
                    <destination_country_currency>
                        <iso_code>
                            ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                            ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </destination_country_currency>
                    <originating_country_currency>
                        <iso_code>
                            ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </originating_country_currency>
                    ' . (!empty($request['originatingCity']) ? '<originating_city>' . $request['originatingCity'] . '</originating_city>' : '') . '
                    ' . (!empty($request['originatingState']) ? '<originating_state>' . $request['originatingState'] . '</originating_state>' : '') . '
                    ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                    ' . (!empty($request['paymentType']) ? '<payment_type>' . $request['paymentType'] . '</payment_type>' : '') . '
                    ' . (!empty($request['exchangeRate']) ? '<exchange_rate>' . $request['exchangeRate'] . '</exchange_rate>' : '') . '
                    ' . (!empty($request['fixOnSend']) ? '<fix_on_send>' . $request['fixOnSend'] . '</fix_on_send>' : '') . '
                    ' . (!empty($request['payWoIdIndicator']) ? '<pay_wo_id_indicator>' . $request['payWoIdIndicator'] . '</pay_wo_id_indicator>' : '') . '
                    ' . (!empty($request['duplicateDetectionFlag']) ? '<duplicate_detection_flag>' . $request['duplicateDetectionFlag'] . '</duplicate_detection_flag>' : '') . '

                </payment_details>
                <financials>
                    ' . (!empty($request['amount']) ? '<originators_principal_amount>' . $request['amount'] . '</originators_principal_amount>' : '') . '
                    ' . (!empty($request['destinationAmount']) ? '<destination_principal_amount>' . $request['destinationAmount'] . '</destination_principal_amount>' : '') . '

                    ' . (!empty($request['grossTotalAmount']) ? '<gross_total_amount>' . $request['grossTotalAmount'] . '</gross_total_amount>' : '') . '
                    ' . (!empty($request['plusChargesAmount']) ? '<plus_charges_amount>' . $request['plusChargesAmount'] . '</plus_charges_amount>' : '') . '

                    ' . (!empty($request['charges']) ? '<charges>' . $request['charges'] . '</charges>' : '') . '
                    ' . (!empty($request['messageCharge']) ? '<message_charge>' . $request['messageCharge'] . '</message_charge>' : '') . '
                </financials>
                <delivery_services>
                    ' . (!empty($request['deliveryCode']) ? '<code>' . $request['deliveryCode'] . '</code>' : '') . '
                    ' . $this->getRoutingCode($request)['routingCode'] . '
                    <message>
                        <message_details context="4">
                            ' . (!empty($request['message1']) ? '<text>' . $request['message1'] . '</text>' : '') . '
                            ' . (!empty($request['message2']) ? '<text>' . $request['message2'] . '</text>' : '') . '
                            ' . (!empty($request['message3']) ? '<text>' . $request['message3'] . '</text>' : '') . '
                            ' . (!empty($request['message4']) ? '<text>' . $request['message4'] . '</text>' : '') . '
                        </message_details>
                    </message>
                </delivery_services>
                ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                ' . (!empty($request['new_mtcn']) ? '<new_mtcn>' . $request['new_mtcn'] . '</new_mtcn>' : '') . '

                ' . $foreignRemoteSystem . '
            </xrsi:send-money-store-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        // exit(var_dump($params));
        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id, $request);

        //Start Get Agent Name
        if(empty($request['mobileFlag'])){
            $branchOwner = $this->getBranchOwner($request);
            $logs['branchOwner'] = $branchOwner;
        }
        //End Get Agent Name

        //Start Get TXN Status
        $request['transactionStatus'] = $this->getTransactionStatus($output);
        //End Get TXN Status

        if(!empty($request['mobileFlag']))
        {
            $request['branchLocation'] = "Mobile";
            $logs['branchOwner'] = "Mobile";
        }

        $senderFirstName = !empty($request['firstName']) ? $request['firstName'] : '';
        $senderLastName = !empty($request['lastName']) ? $request['lastName'] : '';
        $senderName = $senderFirstName . " " . $senderLastName;

        $receiverFirstName = !empty($request['receiverFirstName']) ? $request['receiverFirstName'] : '';
        $receiverLastName = !empty($request['receiverLastName']) ? $request['receiverLastName'] : '';
        $receiverName = $receiverFirstName . " " . $receiverLastName;

        $logs['transactionStatus'] = !empty($request['transactionStatus']) ? $request['transactionStatus'] : '';
        $logs['branchLocation'] = !empty($request['branchLocation']) ? $request['branchLocation'] : '';
        $logs['ftid'] = $ftid;


        // $logs['transactionStatus'] = !empty($request['transactionStatus']) ? $request['transactionStatus'] : '';
        $logs['branchLocation'] = !empty($request['branchLocation']) ? $request['branchLocation'] : '';
        $logs['ftid'] = $ftid;

        $logs['new_mtcn'] = !empty($request['new_mtcn']) ? $request['new_mtcn'] : '';
        $logs['mtcn'] = !empty($request['mtcn']) ? $request['mtcn'] : '';
        // $logs['agentEmail'] = !empty($request['agentEmail']) ? $request['agentEmail'] : '';
        $logs['client_id'] = $client_id;
        $logs['senderName'] = $senderName;
        $logs['receiverName'] = $receiverName;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;

        $grossTotalAmount = !empty($request['grossTotalAmount']) ? (string) $request['grossTotalAmount'] : '';
        $grossTotalAmount = !empty($request['grossTotalAmount']) ? substr_replace($grossTotalAmount,'.',-2,0): '';

        $amount = !empty($request['amount']) ? (string) $request['amount'] : '';
        $amount = !empty($request['amount']) ? substr_replace($amount,'.',-2,0): '';

        $charges = !empty($request['charges']) ? (string) $request['charges'] : '';
        $charges = !empty($request['charges']) ? substr_replace($charges,'.',-2,0): '';

        $logs['amount'] = !empty($request['amount']) ? $amount : '';
        $logs['address1'] = !empty($request['address1']) ? $request['address1'] : '';
        $logs['city'] = !empty($request['city']) ? $request['city'] : '';
        $logs['province'] = !empty($request['province']) ? $request['province'] : '';
        $logs['postalCode'] = !empty($request['postalCode']) ? $request['postalCode'] : '';
        $logs['senderCountryCode'] = !empty($request['senderCountryCode']) ? $request['senderCountryCode'] : '';
        $logs['senderCountryCurrencyCode'] = !empty($request['senderCountryCurrencyCode']) ? $request['senderCountryCurrencyCode'] : '';
        $logs['myWuNumber'] = !empty($request['myWuNumber']) ? $request['myWuNumber'] : '';
        $logs['destinationCountry'] = !empty($request['destinationCountry']) ? $request['destinationCountry'] : '';
        $logs['destinationCurrencyCode'] = !empty($request['destinationCurrencyCode']) ? $request['destinationCurrencyCode'] : '';
        $logs['currencyCode'] = !empty($request['currencyCode']) ? $request['currencyCode'] : '';
        $logs['transactionType'] = !empty($request['transactionType']) ? $request['transactionType'] : '';
        $logs['paymentType'] = !empty($request['paymentType']) ? $request['paymentType'] : '';
        $logs['destinationAmount'] = !empty($request['destinationAmount']) ? $request['destinationAmount'] : '';
        $logs['grossTotalAmount'] = !empty($request['grossTotalAmount']) ? $grossTotalAmount : '';
        $logs['plusChargesAmount'] = !empty($request['plusChargesAmount']) ? $request['plusChargesAmount'] : '';
        $logs['charges'] = !empty($request['charges']) ? $charges : '';
        $logs['phoneNum'] = !empty($request['phoneNum']) ? $request['phoneNum'] : '';

        $data_inserted = SendMoneyStoreLogs::create($logs);

        // exit(var_dump($output));

        return $output;
    }
}
