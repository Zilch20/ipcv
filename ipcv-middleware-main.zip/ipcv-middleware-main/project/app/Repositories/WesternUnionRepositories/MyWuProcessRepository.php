<?php

namespace App\Repositories\WesternUnionRepositories;

use App\Helpers\SpecialCharacters;
use App\Http\Controllers\Controller;
use App\MyWuEnrollmentLog;
use App\MyWuLookupLog;
use App\Traits\SubAgentTraits;
use App\Traits\WesternUnionCurlRequestTrait;

class MyWuProcessRepository extends Controller
{
    use WesternUnionCurlRequestTrait;
    use SubAgentTraits;

    public function test()
    {
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }

    /*
        myWuLookupRequest = Find Customer Records Using MyWU Number
        myWuEnrollmentRequest = Enroll Customer to MyWU Service
    */


    public function myWuLookupRequest($request, $client_id)
    {
        // $ftid = "PH994AMP001A"; //Staging Credentials
        // $fsid = "WGHHPH9940T"; //Staging Credentials
        $fsid = "WGHHPH5130P"; //Prod Credentials
        $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }

        // Check FTID Start
        $checkFTID = SpecialCharacters::checkFTID($ftid);
        if($checkFTID == "PH994")
        {
            $fsid = "WGHHPH9940P";
        }
        // Check FTID End

        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
        <soapenv:Header/>
        <soapenv:Body>
           <xrsi:wu-card-lookup-request>
            <channel>
                <type>' . $request['channelType'] . '</type>
                <name>IPCV</name>
                <version>' . $request['channelVersion'] . '</version>
            </channel>
              <operator>
                 <id/>
                 <password/>
                 <alias/>
                 <network_id/>
              </operator>
              <terminal>
                 <id/>
                 <alias/>
                 <model_id/>
              </terminal>
              <sender>
                 <name/>
                 <address>
                    <country_code>
                        <iso_code>
                        ' . (!empty($request['senderCountryCode']) ? '<country_code>' . $request['senderCountryCode'] . '</country_code>' : '') . '
                        </iso_code>
                    </country_code>
                </address>
                 <preferred_customer>
                    ' . (!empty($request['loyaltyCardUpdateIndicator']) ? '<loyalty_card_update_indicator>' . $request['loyaltyCardUpdateIndicator'] . '</loyalty_card_update_indicator>' : '') . '
                    ' . (!empty($request['permanentChange']) ? '<permanent_change>' . $request['permanentChange'] . '</permanent_change>' : '') . '
                    ' . (!empty($request['myWuNumber']) ? '<account_nbr>' . $request['myWuNumber'] . '</account_nbr>' : '') . '
                    ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                 </preferred_customer>
              </sender>
              <foreign_remote_system>
                 <identifier>' . $fsid . '</identifier>
                 <reference_no>115210-000000003</reference_no>
                 <counter_id>' . $ftid . '</counter_id>
              </foreign_remote_system>
              <card_lookup_search_type>S</card_lookup_search_type>
           </xrsi:wu-card-lookup-request>
        </soapenv:Body>
     </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }
        // exit(var_dump($params));

        $output = $this->requestWUAPI($params, $client_id, $request);

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = MyWuLookupLog::create($logs);
        // exit(var_dump($output));

        return $output;


    }

    public function myWuEnrollmentRequest($request, $client_id)
    {

        // $ftid = "PH994ARP001B"; //Staging Credentials
        // $fsid = "WGHHPH9940P"; //Staging Credentials
        $fsid = "WGHHPH5130P"; //Prod Credentials
        $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }

        // Check FTID Start
        $checkFTID = SpecialCharacters::checkFTID($ftid);
        if($checkFTID == "PH994")
        {
            $fsid = "WGHHPH9940P";
        }
        // Check FTID End

        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
            <xrsi:wu-card-enrollment-request>
                    <channel>
                        <type>' . $request['channelType'] . '</type>
                        <name>IPCV</name>
                        <version>' . $request['channelVersion'] . '</version>
                    </channel>
                    <foreign_remote_system>
                    <identifier>' . $fsid . '</identifier>
                    <reference_no>115210-000000003</reference_no>
                    <counter_id>' . $ftid . ' </counter_id>
                </foreign_remote_system>

                <sender>
                    <name name_type="D">
                        ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                        ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                    </name>
                    <address>
                        ' . (!empty($request['address']) ? '<addr_line1>' . $request['address'] . '</addr_line1>' : '') . '
                        ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                        ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                        ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                        <country_code>
                            <iso_code>
                                ' . (!empty($request['countryCode']) ? '<country_code>' . $request['countryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </country_code>
                    </address>
                    ' . (!empty($request['email']) ? '<email>' . $request['email'] . '</email>' : '') . '
                    ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                </sender>

                <emea_ii>
                    ' . (!empty($request['gender']) ? '<sender_gender>' . $request['gender'] . '</sender_gender>' : '') . '
                    ' . (!empty($request['phoneNum']) ? '<mobile_phone_number>' . $request['phoneNum'] . '</mobile_phone_number>' : '') . '
                </emea_ii>

                <payment_details>
                    <expected_payout_location>
                        ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                        ' . (!empty($request['expectedCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                    </expected_payout_location>
                    <recording_country_currency>
                        <iso_code>
                            ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['senderCurrencyCode']) ? '<currency_code>' . $request['senderCurrencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </recording_country_currency>
                    <destination_country_currency>
                        <iso_code>
                            ' . (!empty($request['destinationCountryCode']) ? '<country_code>' . $request['destinationCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </destination_country_currency>
                    <originating_country_currency>
                        <iso_code>
                            ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['senderCurrencyCode']) ? '<currency_code>' . $request['senderCurrencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </originating_country_currency>
                </payment_details>
            </xrsi:wu-card-enrollment-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        // exit(var_dump($params));

        $output = $this->requestWUAPI($params, $client_id, $request);

        $logs['clientId'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = MyWuEnrollmentLog::create($logs);


        return $output;


    }

}
