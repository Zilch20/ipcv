<?php

namespace App\Repositories\WesternUnionRepositories;

use App\Http\Controllers\Controller;

class DasProcessRepository extends Controller
{
    public function dasRequest($request)
    {
            $params =
            '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
                <soapenv:Header/>
                <soapenv:Body>
                <xrsi:h2h-das-request>

                    <channel>
                        <type>H2H</type>
                        <name>IPAYCHANNELTEST</name>
                        <version>9500</version>
                    </channel>

                    <foreign_remote_system>
                        <identifier>WGHHPH9940T</identifier>
                        <reference_no>115210-000000003</reference_no>
                        <counter_id>PH994AMP001A</counter_id>
                    </foreign_remote_system>

                    <client_id>H2H</client_id>
                    <name>'.$request['dasRequest'].'</name>

                    <filters>
                        <queryfilter1>en</queryfilter1>
                        <queryfilter2>'.$request['queryFilter1'].'</queryfilter2>
                        <queryfilter3>'.$request['queryFilter2'].'</queryfilter3>
                        <queryfilter4>'.$request['queryFilter3'].'</queryfilter4>
                        <queryfilter5>'.$request['queryFilter4'].'</queryfilter5>
                    </filters>

                </xrsi:h2h-das-request>
                </soapenv:Body>
            </soapenv:Envelope>';

            // exit(var_dump($params));

            $ch = curl_init('https://66.218.162.7');
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/xml',
                'Content-Length: ' . strlen($params)
            ]);

            $certFolder = '/var/www/html/mw/pi-cert-key-in-pem-format';
            $path = dirname($certFolder);
            $cert = $path.'/pi-cert-key-in-pem-format/WesternUnionPartnerIntegration-Client.crt.pem';
            $key = $path.'/pi-cert-key-in-pem-format/WesternUnionPartnerIntegration-Client.key.pem';
            $pass = 'BAS$!@S87';

            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
            curl_setopt($ch, CURLOPT_POST, 1);

            $pem=realpath($cert);
            if(!$pem || !is_readable($pem)){
                die("error: .pem is not readable! realpath: \"{$pem}\" - working dir: \"".getcwd()."\" effective user: ".print_r(posix_getpwuid(posix_geteuid()),true));
            }

            curl_setopt($ch, CURLOPT_SSLCERT, $cert);
            curl_setopt($ch, CURLOPT_SSLCERTTYPE, "PEM");
            curl_setopt($ch, CURLOPT_SSLKEY, $key);
            curl_setopt($ch, CURLOPT_SSLKEYTYPE, "PEM");
            curl_setopt($ch, CURLOPT_SSLCERTPASSWD , $pass);

            curl_setopt($ch, CURLOPT_POSTFIELDS, "$params");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $output = curl_exec($ch);
            if(curl_error($ch))
            {
                exit('curl error is -' . curl_error($ch));
            }

            curl_close($ch);

            $xml = simplexml_load_string($output);
            $namespaces = $xml->getNamespaces(true);
            $xml = (string)$xml->children($namespaces['soapenv'])
                ->Body
                ->children($namespaces['xrsi'])
                ->children()
                ->MTML
                ->REPLY
                ->DATA_CONTEXT
                ->RECORDSET;

            // Cache::put('dasRequest',$xml);
            // Cache::put($request['dasRequest'],$xml);

            // if($request['dasRequest'] == 'GetDeliveryOptionTemplate' || $request['dasRequest'] == 'GetDeliveryServices'){
            //     Cache::put($request['queryFilter2'],$xml);
            // }
            // if($request['dasRequest'] == 'GetStateList' || $request['dasRequest'] == 'GetCascadeList'){
            //     Cache::put($request['queryFilter1'],$xml);
            // }

            // dd(Cache::get($request['dasRequest']));
            return $output;
        // }



    }

}
