<?php

namespace App\Repositories\WesternUnionRepositories;

use App\Http\Controllers\Controller;
use App\Traits\WesternUnionCurlRequestTrait;

class HeartbeatRepository extends Controller
{
    use WesternUnionCurlRequestTrait;

    public function test()
    {
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }

    //Check Connection to WU
    public function heartbeatRequest($client_id)
    {

        $params = '
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
            <xrsi:esp-heartbeat-request>
                <partner>
                    <id>WGDSPH51301T</id>
                    <system>
                        <id>WGDSPH51301T</id>
                        <name>IPCV</name>
                        <version>9101</version>
                        <ip_address>192.168.49.20</ip_address>
                        <connector>
                        <id>PH513DSAP01B</id>
                        </connector>
                    </system>
                    <preferences>
                        <language>en</language>
                    </preferences>
                </partner>
                <device>
                    <id>RETAIL</id>
                    <type>RETAIL</type>
                </device>
                <external_reference_no>1</external_reference_no>
                </xrsi:esp-heartbeat-request>
            </soapenv:Body>
        </soapenv:Envelope>';
        // exit(var_dump($params));

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id);

        // $logs['clientId'] = $client_id;
        // $logs['xml_request'] = $params;
        // $logs['request_data'] = json_encode($request);
        // $logs['reply_data'] = $output;
        // $data_inserted = PayStatusInquiryLog::create($logs);


        return $output;


    }

}
