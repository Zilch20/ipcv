<?php

namespace App\Repositories\WesternUnionRepositories;

use App\HoldTxnLog;
use App\Http\Controllers\Controller;
use App\ReceiveMoneyPayLog;
use App\ReceiveMoneySearchLog;
use App\RetryMechanismLog;
use App\Traits\RetryMechanismTrait;
use App\Traits\WesternUnionCurlRequestTrait;

class MobileRecieveMoneyProcessRepository extends Controller
{
    use WesternUnionCurlRequestTrait;
    use RetryMechanismTrait;

    public function test()
    {
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }

    //Payment Functions

    public function recieveMoneySearchRequest($request, $client_id)
    {
        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:receive-money-search-request>
                    <device>
                        <id/>
                        <type>MOBILE</type>
                    </device>
                    <channel>
                        <type>SFSS</type>
                        <name>PES</name>
                        <version>9525</version>
                    </channel>
                        <foreign_remote_system>
                        <identifier>WGSSPH5131T</identifier>
                        <reference_no>0000000015782274</reference_no>
                        <counter_id>PH513DSAP01B</counter_id>
                    </foreign_remote_system>
                    <payment_transaction>
                        <payment_details>
                            <destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '<country_code></country_code>') . '
                                ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '<currency_code></currency_code>') . '
                            </iso_code>
                            </destination_country_currency>
                            <stage_pay_fields>
                                ' . (!empty($request['snpIndicator']) ? '<snp_indicator>' . $request['snpIndicator'] . '</snp_indicator>' : '') . '
                            </stage_pay_fields>
                        </payment_details>
                        ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                    </payment_transaction>
                </xrsi:receive-money-search-request>
            </soapenv:Body>
        </soapenv:Envelope>';
        // exit(var_dump($params));

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPIMobile($params, $client_id, $request);

        // exit(var_dump($output));

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = ReceiveMoneySearchLog::create($logs);

        return $output;


    }

    public function recieveMoneyPayRequest($request, $client_id)
    {

        $countryCode = $request['receiverCountryCode'];
        $countryName = config('country.' . $countryCode);

        if (!array_key_exists("stateCode", $request) || $request['stateCode'] == '') {
            $stateCode = "";
        } else {
            $stateCode = $request['stateCode'];
        }
        if (!array_key_exists("senderCity", $request) || $request['senderCity'] == '') {
            $city = "";
        } else {
            $city = $request['senderCity'];
        }

        if (!array_key_exists("accountNumber", $request)) {
            $accountNumber = "";
        } else {
            $accountNumber = $request['accountNumber'];
        }
        if (!array_key_exists("bankName", $request)) {
            $bankName = "";
        } else {
            $bankName = $request['bankName'];
        }

        if (!array_key_exists("myWuNumber", $request)) {
            $myWuNumber = "";
        } else {
            $myWuNumber = $request['myWuNumber'];
        }

        $bank_details = '';
//        if (!empty($request['accountNumber'])) {
//            $bank_details = '<bank_details>';
//            $bank_details .= !empty($request['bankName']) ? '<name>' . $request['bankName'] . '</name>' : '';
//            $bank_details .= !empty($request['accountNumber']) ? '<account_number>' . $request['accountNumber'] . '</account_number>' : '';
//            $bank_details .= '</bank_details>';
//        }

        $request['issueDate'] = str_replace('/', '', $request['issueDate']);
        $request['expiration'] = str_replace('/', '', $request['expiration']);
        $request['birthDate'] = str_replace('/', '', $request['birthDate']);

        if (!empty($request['templateId'])) {
            $request['templateId'] = 'UNI_01_P';
        }

        $id_details = '';
        if (!empty($request['idType']) || !empty($request['idCountryIssued']) || !empty($request['idNum'])) {
            $id_details = '<id_details>';
            $id_details .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
            $id_details .= !empty($request['idCountryIssued']) ? '<id_country_of_issue>' . $request['idCountryIssued'] . '</id_country_of_issue>' : '';
            $id_details .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
            $id_details .= '</id_details>';
        }

        $request['myWuNumber'] = '';
        $retryMechanism = RetryMechanismLog::findLog('mobile_recieve_money_pay', $request, 'mobile_receive')->get();
        if (!empty($retryMechanism[0])) {
            $retryMechanismData = $retryMechanism[0];
            $request['myWuNumber'] = !empty($retryMechanismData['account_nbr']) ? $retryMechanismData['account_nbr'] : $request['myWuNumber'];
            $request['galactic_id'] = !empty($retryMechanismData['galactic_id']) ? $retryMechanismData['galactic_id'] : null;
        }
//        Debugger::dd($request);

        $accountNbr = '';
        if (!empty($request['myWuNumber'])) {
            $accountNbr = '<preferred_customer>
                            <account_nbr>' . $request['myWuNumber'] . '</account_nbr>
                        </preferred_customer>';
        }

        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:receive-money-pay-request>
                    <device>
                        <type>MOBILE</type>
                    </device>
                    <channel>
                        <type>SFSS</type>
                        <name>IPCV</name>
                        <version>9525</version>
                    </channel>
                    <terminal>
                        <id>*So3</id>
                    </terminal>
                    <receiver>
                        <name name_type="D">
                            ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['middleName']) ? '<middle_name>' . $request['middleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                        </name>
                        <address>
                            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                            ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . ($request['receiverCountryCode'] ? '<country_code>' . $request['receiverCountryCode'] . '</country_code>' : '') . '
                                    ' . ($request['receiverCountryCurrencyCode'] ? '<currency_code>' . $request['receiverCountryCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $countryName . '</country_name>
                            </country_code>
                        </address>

                        ' . $accountNbr . '

                        <compliance_details>
                            ' . (!empty($request['templateId']) ? '<template_id>' . $request['templateId'] . '</template_id>' : '') . '
                            ' . (!empty($request['version']) ? '<version>' . $request['version'] . '</version>' : '') . '

                            ' . $id_details . '

                            ' . (!empty($request['flagPay']) ? '<third_party_details><flag_pay>' . $request['flagPay'] . '</flag_pay></third_party_details>' : '') . '

                            ' . (!empty($request['issueDate']) ? '<id_issue_date>' . $request['issueDate'] . '</id_issue_date>' : '') . '
                            ' . (!empty($request['expiration']) ? '<id_expiration_date>' . $request['expiration'] . '</id_expiration_date>' : '') . '
                            ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                            ' . (!empty($request['occupation']) ? '<occupation>' . $request['occupation'] . '</occupation>' : '') . '
                            ' . (!empty($request['transactionReason']) ? '<transaction_reason>' . $request['transactionReason'] . '</transaction_reason>' : '') . '

                            <Current_address>
                                ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                                ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address'] . '</addr_line2>' : '') . '
                                ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                                ' . (!empty($request['province']) ? '<state_name>' . $request['province'] . '</state_name>' : '') . '
                                ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                                <country>' . $countryName . '</country>
                            </Current_address>

                            ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '

                            ' . (!empty($request['countryofBirth']) ? '<Country_of_Birth>' . $request['countryofBirth'] . '</Country_of_Birth>' : '') . '
                            ' . (!empty($request['nationality']) ? '<nationality>' . $request['nationality'] . '</nationality>' : '') . '
                            ' . (!empty($request['gender']) ? '<Gender>' . $request['gender'] . '</Gender>' : '') . '
                            ' . (!empty($request['fundSource']) ? '<Source_of_Funds>' . $request['fundSource'] . '</Source_of_Funds>' : '') . '
                            ' . (!empty($request['nameOfEmployer']) ? '<Name_of_Employer_Business>' . $request['nameOfEmployer'] . '</Name_of_Employer_Business>' : '') . '
                            ' . (!empty($request['relationshiptoSender']) ? '<Relationship_to_Receiver_Sender>' . $request['relationshiptoSender'] . '</Relationship_to_Receiver_Sender>' : '') . '
                            ' . (!empty($request['ackFlag']) ? '<ack_flag>' . strtoupper($request['ackFlag']) . '</ack_flag>' : '') . '
                            ' . (!empty($request['phoneCountryCode']) ? '<Country_Code>' . $request['phoneCountryCode'] . '</Country_Code>' : '') . '

                            ' . (!empty($request['galactic_id']) ? '<galactic_id>' . $request['galactic_id'] . '</galactic_id>' : '') . '
                            ' . (!empty($request['multiErrorSupported']) ? '<multi_error_supported>' . $request['multiErrorSupported'] . '</multi_error_supported>' : '') . '
                            ' . (!empty($request['positionLevel']) ? '<employment_position_level>' . $request['positionLevel'] . '</employment_position_level>' : '') . '
                        </compliance_details>
                        ' . (!empty($request['phoneCountryCode']) ? '<phone_country_code>' . $request['phoneCountryCode'] . '</phone_country_code>' : '') . '
                        ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                        <mobile_phone>
                            <phone_number>
                                ' . (!empty($request['phoneCountryCode']) ? '<country_code>' . $request['phoneCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['phoneNum']) ? '<national_number>' . $request['phoneNum'] . '</national_number>' : '') . '
                            </phone_number>
                        </mobile_phone>
                    </receiver>
                    <payment_details>
                        <expected_payout_location>
                            ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                            ' . (!empty($request['receiverCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                        </expected_payout_location>

                        <destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </destination_country_currency>

                        <originating_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['originatingCurrencyCode']) ? '<currency_code>' . $request['originatingCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </originating_country_currency>

                        ' . (!empty($request['originatingCity']) ? '<originating_city>' . $request['originatingCity'] . '</originating_city>' : '') . '
                        ' . (!empty($request['originatingState']) ? '<originating_state>' . $request['originatingState'] . '</originating_state>' : '') . '
                        ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                        ' . (!empty($request['exchangeRate']) ? '<exchange_rate>' . $request['exchangeRate'] . '</exchange_rate>' : '') . '

                        <original_destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['ogdestinationCountry']) ? '<country_code>' . $request['ogdestinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['ogdestinationCurrencyCode']) ? '<currency_code>' . $request['ogdestinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </original_destination_country_currency>

                        ' . (!empty($request['mtRequestedStatus']) ? '<mt_requested_status>' . $request['mtRequestedStatus'] . '</mt_requested_status>' : '') . '
                        <stage_pay_fields>
                            ' . (!empty($request['snpIndicator']) ? '<snp_indicator>' . $request['snpIndicator'] . '</snp_indicator>' : '') . '
                        </stage_pay_fields>
                    </payment_details>
                    <financials>
                        <taxes>
                            <tax_worksheet/>
                        </taxes>
                        ' . (!empty($request['grossTotalAmount']) ? '<gross_total_amount>' . $request['grossTotalAmount'] . '</gross_total_amount>' : '') . '
                        ' . (!empty($request['payAmount']) ? '<pay_amount>' . $request['payAmount'] . '</pay_amount>' : '') . '
                        ' . (!empty($request['principalAmount']) ? '<principal_amount>' . $request['principalAmount'] . '</principal_amount>' : '') . '
                        ' . (!empty($request['charges']) ? '<charges>' . $request['charges'] . '</charges>' : '') . '
                        ' . (!empty($request['tolls']) ? '<tolls>' . $request['tolls'] . '</tolls>' : '') . '
                    </financials>
                    ' . (!empty($request['mtk']) ? '<money_transfer_key>' . $request['mtk'] . '</money_transfer_key>' : '') . '
                    ' . (!empty($request['new_mtcn']) ? '<new_mtcn>' . $request['new_mtcn'] . '</new_mtcn>' : '') . '
                    ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                    ' . (!empty($request['payOrDoNot']) ? '<pay_or_do_not_pay_indicator>' . $request['payOrDoNot'] . '</pay_or_do_not_pay_indicator>' : '') . '
                    <foreign_remote_system>
                        <identifier>WGSSPH5131T</identifier>
                        <reference_no>0000000015782274</reference_no>
                        <counter_id>PH513DSAP01B</counter_id>
                    </foreign_remote_system>
                </xrsi:receive-money-pay-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPIMobile($params, $client_id, $request);

        $this->retryMechanism($output, 'mobile_recieve_money_pay', $request, $client_id);

        // exit(var_dump($output));

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;

        $data_inserted = ReceiveMoneyPayLog::create($logs);

        return $output;

    }

    public function holdTxnReleaseRequest($request, $client_id)
    {
        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
            <xrsi:hold-txn-search-request>
                <channel>
                    <type>SFPS</type>
                    <name>IPCV</name>
                    <version>9520</version>
                </channel>

                ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                <search_type>RELEASE</search_type>
                <foreign_remote_system>
                    <identifier>WGPSPH5130T</identifier>
                    <reference_no>115210-000000003</reference_no>
                    <counter_id>PH513PST001D</counter_id>
                </foreign_remote_system>
            </xrsi:hold-txn-search-request>
            </soapenv:Body>
        </soapenv:Envelope>';
        // exit(var_dump($params));

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id, $request);

        // exit(var_dump($output));

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = HoldTxnLog::create($logs);

        return $output;


    }

}
