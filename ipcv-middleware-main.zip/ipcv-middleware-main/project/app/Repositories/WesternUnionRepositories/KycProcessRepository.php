<?php

namespace App\Repositories\WesternUnionRepositories;

use App\Http\Controllers\Controller;
use App\KycLookupLog;
use App\Traits\WesternUnionCurlRequestTrait;

class KycProcessRepository extends Controller
{
    use WesternUnionCurlRequestTrait;

    //Search for Customer using Name, ID, or MyWU Number
    public function kycRequest($request, $client_id)
    {

        try {

            $complianceDetails = '';
            if(!empty($request['idNum']))
            {
                $complianceDetails = '<compliance_details>';
                $complianceDetails .= '<template_id>UNI_01</template_id>';
                $complianceDetails .= '<id_details>';
                $complianceDetails .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
                $complianceDetails .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
                $complianceDetails .= '</id_details>';
                $complianceDetails .= '</compliance_details>';
            }

            $name = '';
            if(!empty($request['firstName']))
            {
                $name = '<name name_type="D">';
                $name .= !empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '';
                $name .= !empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '';
                $name .= '</name>';
            }

            $mywuDetails = '';
            if(!empty($request['myWuNumber']))
            {
                $mywuDetails = '<mywu_details>';
                $mywuDetails .= !empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '';
                $mywuDetails .= '</mywu_details>';
            }

            // $ftid = "PH994ARP001B"; //Staging Credentials
            // $fsid = "WGHHPH9940P"; //Staging Credentials
            $fsid = "WGHHPH5130P"; //Prod Credentials
            $ftid = "PH513ARP001A"; //Prod Credentials

            if(empty($request['mobileFlag']))
            {
                $ftid = $this->getFtid($request);

                // $branchLocation = $request['branchLocation'];
                // if($branchLocation != 'IPCV')
                // {
                //     // echo $branchLocation;
                //     $ftid = config('subagentftid.' . $branchLocation);
                // }
            }

            $params = '
            <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/kyc/schema/xrsi">
                <soapenv:Header/>
                    <soapenv:Body>
                        <xrsi:kyc-customer-lookup-request>
                            <channel>
                                <type>' . $request['channelType'] . '</type>
                                <name>IPCV</name>
                                <version>' . $request['channelVersion'] . '</version>
                            </channel>
                            <foreign_remote_system>
                                <identifier>' . $fsid . '</identifier>
                                <reference_no>115210-000000003</reference_no>
                                <counter_id>' . $ftid . '</counter_id>
                            </foreign_remote_system>
                            <customer>
                                '. $name .'
                                '. $mywuDetails .'
                                ' . $complianceDetails . '
                                ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                            </customer>
                            ' . (!empty($request['searchParameter']) ? '<search_parameter>' . $request['searchParameter'] . '</search_parameter>' : '') . '
                            ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                            ' . (!empty($request['pfcFilter']) ? '<pfc_filter>' . $request['pfcFilter'] . '</pfc_filter>' : '') . '
                            ' . (!empty($request['searchType']) ? '<search_type>' . $request['searchType'] . '</search_type>' : '') . '
                        </xrsi:kyc-customer-lookup-request>
                    </soapenv:Body>
            </soapenv:Envelope>';

            if (!empty($request['dump'])) {
                exit(var_dump($params));
            }

            // exit(var_dump($params));

            $output = $this->requestWUAPI($params, $client_id, $request);

            $logs['clientId'] = $client_id;
            $logs['xml_request'] = $params;
            $logs['request_data'] = json_encode($request);
            $logs['reply_data'] = $output;
            $data_inserted = KycLookupLog::create($logs);

            $response = $output;

        } catch (ClientErrorResponseException $exception) {
            $res = $exception->getResponse()->getBody(true);
        }


        return $output;


    }

}
