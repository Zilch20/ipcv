<?php

namespace App\Repositories\MastercardRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class OtpRepository extends Controller
{
    public function test(){
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }
    public function generateOtp($request)
    {

        $guzzle = new Client([
            'headers' => [
                'Content-Type' => 'application/json'
            ]
        ]);

        $params = [
            "deviceNumber" => $request['parameterOne'], 
            "requestType" => $request['parameterTwo'],
            "channel" => 31
        ];

        $res = $guzzle -> post(env('MASTERCARD_GENERATE_OTP_URL'), [
            'json' => $params
        ]);

        //return if no errors
        return json_decode($res->getBody(), true);

    }
    public function validateOtp($request, $secret){
    
        //Generate a key from a hash
        $key = md5(utf8_encode($secret), true);

        //Take first 8 bytes of $key and append them to the end of $key.
        $key .= substr($key, 0, 8);

        //Pad for PKCS7
        $blockSize = mcrypt_get_block_size('tripledes', 'ecb');
        $len = strlen($request['parameterFour']);
        $pad = $blockSize - ($len % $blockSize);
        $data .= str_repeat(chr($pad), $pad);

        //Encrypt data
        $encData = mcrypt_encrypt('tripledes', $key, $data, 'ecb');

        base64_encode($encData);

        $guzzle = new Client([
            'headers' => [
                'Content-Type' => 'application/json'
            ]
        ]);

        $params = [
            "deviceNumber" => $request['parameterOne'], 
            "requestType" => $request['parameterTwo'],
            "channel" => $request['parameterThree'],
            “encryptedOTP” => $request['parameterFour']
        ];

        $res = $guzzle -> post(env('MASTERCARD_VALIDATE_OTP_URL'), [
            'json' => $params
        ]);

    }
    
}