<?php

namespace App\Repositories\MastercardRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class CardRepository extends Controller
{
    public function test(){
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }
    public function createCard($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'HostRefNo' => $request['parameterOne'],
            'ActionCode' => $request['parameterTwo'],
            'BranchCode' => $request['parameterThree'],
            'ProductCode' => $request['parameterFour'],
            'StatusCode' => $request['parameterFour'],
            'DeliveryFlag' => $request['parameterFive'],
            'DeliveryDate' => $request['parameterSix'],
            'LanguageInd' => $request['parameterSeven'],
            'CreateFlag' => $request['parameterEight'],
            'PhotoIndicator' => $request['parameterNine'],
            'ApplicationDate' => $request['parameterTen'],
            'MobilePhone' => $request['parameterEleven'],
            'cardDetail'=> [
                'card' => [
                    "basicCardFlag" =>$request['parameterTwelve'],
                    "cardIndicator" =>$request['parameterThirteen'],
                ]
            ],
            'customer' => [
                "gender" => "", 
                "customerDemographics" =>[
                    "address" => [ 
                        "addressLine1" => "",
                        "cityCode" => "",
                        "zipCode" => "",
                        "countryCode" => ""
                    ],
                    "mailingAddress" => [ 
                        "addressLine1" => "",
                        "cityCode" => "", 
                        "zipCode" => "", 
                        "countryCode" => ""
                    ],
                    "phonesMap" => [
                        "MOBILE" => [ 
                            "number" => "",
                            "type" => "" 
                        ]
                    ],
                ],
                "primaryAccount" => [
                    "number" => "", 
                    "currency" => "", 
                    "type" => ""
                ]
            ]
        ];

        $res = $guzzle -> post(env('MASTERCARD_CREATE_CARD_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    
}