<?php

namespace App\Repositories\MastercardRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class WalletLinkRepository extends Controller
{
    public function test(){
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }
    public function defaultLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '0',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function savingLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '10',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function checkingLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '20',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function creditcardLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '30',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function creditlineLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '38',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function corporateLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '39',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function universalLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '40',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function moneymarketLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '50',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function storedvalueLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '60',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function revolvingLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '90',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function installmentLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '91',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function realestateLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '92',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function iraLink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'N',
            'AccountTypes' => '58',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }

    //Delinking

    public function defaultDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '0',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function savingDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '10',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function checkingDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '20',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function creditcardDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '30',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function creditlineDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '38',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function corporateDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '39',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function universalDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '40',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function moneymarketDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '50',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function storedvalueDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '60',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function revolvingDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '90',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function installmentDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '91',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function realestateDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '92',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    public function iraDelink($request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json'
            ]
        ]);

        $params = [
            'DeviceNumber' => $request['parameterOne'],
            'WalletNumber' => $request['parameterTwo'],
            'Channel' => '31',
            'DelinkingStatus' => 'Y',
            'AccountTypes' => '58',
            'DefaultWallet' => $request['parameterThree']
        ];

        $res = $guzzle -> post(env('MASTERCARD_WALLET_LINKING_URL'), [
            'json' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
    
}