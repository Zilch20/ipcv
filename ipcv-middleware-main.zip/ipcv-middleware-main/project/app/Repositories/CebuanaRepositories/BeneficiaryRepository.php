<?php

namespace App\Repositories\CebuanaRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class BeneficiaryRepository extends Controller
{

    public function GetBenificiary($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/GetBeneficiaryBySender</Action>
            </s:Header>
            <s:Body>
                <GetBeneficiaryBySender xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://tempuri.org/">
                    <getBeneficiaryBySenderRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <SenderClientID>298</SenderClientID>
                    </getBeneficiaryBySenderRequest>
                </GetBeneficiaryBySender>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function AddBenificiary($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/AddBeneficiary</Action>
            </s:Header> 
            <s:Body>
                <AddBeneficiary xmlns="http://tempuri.org/" xmlns:i="http://www.w3.org/2001/XMLSchema-instance">
                    <addBeneficiaryRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential> 
                        <FirstName>'.$request['firstName'].'</FirstName> 
                        <LastName>'.$request['lastName'].'</LastName> 
                        <SenderClientID>298</SenderClientID> 
                        <BirthDate>'.$request['BrithDate'].'</BirthDate> 
                        <CellphoneCountryID>63</CellphoneCountryID> 
                        <CellphoneNumber>'.$request['phoneNum'].'</CellphoneNumber> 
                        <TelephoneCountryID>63</TelephoneCountryID> 
                        <CountryAddressID>0</CountryAddressID>
                        <UserID>PLFAUSTINO</UserID>
                    </addBeneficiaryRequest>
                </AddBeneficiary>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function UpdateBenificiary($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"> 
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/UpdateBeneficiary</Action>
            </s:Header>
            <s:Body>
                <UpdateBeneficiary xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://tempuri.org/"> 
                    <updateBeneficiaryRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <BeneficiaryID>324</BeneficiaryID>
                        <MiddleName>Garcia</MiddleName>
                        <BirthDate>2001-01-01T00:00:00</BirthDate>
                        <CellphoneCountryID>161</CellphoneCountryID>
                        <CellphoneNumber>9123456712</CellphoneNumber>
                        <TelephoneCountryID>0</TelephoneCountryID>
                        <CountryAddressID>0</CountryAddressID>
                        <UserID>PLFAUSTINO</UserID>
                    </updateBeneficiaryRequest>
                </UpdateBeneficiary>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }

}