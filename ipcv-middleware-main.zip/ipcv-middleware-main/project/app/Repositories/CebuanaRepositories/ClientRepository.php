<?php

namespace App\Repositories\CebuanaRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class ClientRepository extends Controller
{

    public function FindClient($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"> 
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/FindClient</Action>
            </s:Header> 
            <s:Body>
                <FindClient xmlns="http://tempuri.org/">
                    <findClientRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <FirstName>'.$request['firstName'].'</FirstName> 
                        <LastName>'.$request['lastName'].'</LastName> 
                        <BirthDate i:nil="true">'.$request['BrithDate'].'</BirthDate> 
                        <PartnerCode>T00001</PartnerCode>
                    </findClientRequest>
                </FindClient>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }

    public function AddClient($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"> 
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none" http://tempuri.org/IService/AddClient</Action>
            </s:Header> 
            <s:Body>
                <AddClient xmlns="http://tempuri.org/">
                    <addClientRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <FirstName>'.$request['firstName'].'</FirstName> 
                        <LastName>'.$request['lastName'].'</LastName> 
                        <BirthDate>'.$request['BrithDate'].'</BirthDate> 
                        <CellphoneCountryID>63</CellphoneCountryID>
                        <CellphoneNumber>'.$request['phoneNum'].'</CellphoneNumber>
                        <TelephoneCountryID>63</TelephoneCountryID>
                        <CountryAddressID>0</CountryAddressID>
                        <PartnerCode>T00001</PartnerCode>
                        <Token>Token</Token>
                        <AgentCode>T00001A</AgentCode>
                        <UserID>PLFAUSTINO</UserID>
                    </addClientRequest>
                </AddClient>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function UpdateClient($request)
    {
        $guzzle = new Client();

        $params =
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"> 
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/UpdateClient</Action>
            </s:Header>
            <s:Body>
                <UpdateClient xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://tempuri.org/">
                    <updateClientRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential> 
                        <ClientID>'.$request['clientID'].'</ClientID>
                        <ClientNumber>'.$request['clientNum'].'</ClientNumber> 
                        <MiddleName>'.$request['middleName'].'</MiddleName> 
                        <BirthDate>'.$request['birthDate'].'</BirthDate>
                        <CellphoneCountryID>63</CellphoneCountryID>
                        <CellphoneNumber>'.$request['phoneNum'].'</CellphoneNumber>
                        <TelephoneCountryID>63</TelephoneCountryID>
                        <CountryAddressID>0</CountryAddressID> 
                        <PartnerCode>T00001</PartnerCode> 
                        <Token>Token</Token> 
                        <AgentCode>T00001A</AgentCode>
                        <UserID>PLFAUSTINO</UserID>
                    </updateClientRequest>
                </UpdateClient>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }

}