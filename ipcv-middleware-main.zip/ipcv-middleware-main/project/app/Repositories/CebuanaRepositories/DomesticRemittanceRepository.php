<?php

namespace App\Repositories\CebuanaRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class DomesticRemittanceRepository extends Controller
{

    public function SendDomesticRemittance($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">  
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/SendDomesticRemittance</Action>
            </s:Header>
            <s:Body>
                <SendDomesticRemittance xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://tempuri.org/">
                    <sendDomesticRemittanceRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <BeneficiaryID>'.$request['beneficiaryID'].'</BeneficiaryID>
                        <SendCurrencyID>'.$request['currencyID'].'</SendCurrencyID>
                        <PrincipalAmount>'.$request['amount'].'</PrincipalAmount>
                        <ServiceFee>'.$request['serviceFee'].'</ServiceFee>
                        <PartnerCode>'.$request['partnerCode'].'</PartnerCode>
                        <Token>Token</Token>
                        <AgentCode>T00001B</AgentCode>
                        <UserID>00001</UserID>
                        <Pin>'.$request['pin'].'</Pin>
                    </sendDomesticRemittanceRequest>
                </SendDomesticRemittance>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function AmendDomesticRemittance($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"> 
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/AmendDomesticRemittance</Action>
            </s:Header> 
            <s:Body>
                <AmendDomesticRemittance xmlns:i="http://www.w3.org/2001/XMLSchema- instance" xmlns="http://tempuri.org/">
                    <amendDomesticRemittanceRequest> 
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <ControlNumber>'.$request['controlNumber'].'</ControlNumber>
                        <NewBeneficiaryID>'.$request['newbeneficiaryID'].'</NewBeneficiaryID>
                        <PartnerCode>'.$request['partnerCode'].'</PartnerCode>
                        <Token>Token</Token>
                        <AgentCode>T00001B</AgentCode>
                        <UserID>00001</UserID>
                        <AmendmentFee>'.$request['fee'].'</AmendmentFee>
                    </amendDomesticRemittanceRequest>
                </AmendDomesticRemittanceRequest>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function PayoutDomesticRemittance($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/PayoutDomesticRemittance</Action>
            </s:Header>
            <s:Body>
                <PayoutDomesticRemittance xmlns:i="http://www.w3.org/2001/XMLSchema- instance" xmlns="http://tempuri.org/">
                    <payoutDomesticRemittanceRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <ControlNumber>'.$request['controlNumber'].'</ControlNumber>
                        <IdentificationTypeID>1</IdentificationTypeID>
                        <IdentificationNumber>'.$request['idNumber'].'</IdentificationNumber>
                        <PartnerCode>'.$request['partnerCode'].'</PartnerCode>
                        <Token>Token</Token>
                        <AgentCode>T00001B</AgentCode>
                        <UserID>000001</UserID>
                    </payoutDomesticRemittanceRequest>
                </PayoutDomesticRemittance>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function CancelDomesticRemittance($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"> 
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/CancelDomesticRemittance</Action>
            </s:Header> 
            <s:Body>
                <CancelDomesticRemittance xmlns:i="http://www.w3.org/2001/XMLSchema- instance" xmlns="http://tempuri.org/">
                    <cancelDomesticRemittance>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <ControlNumber>'.$request['controlNumber'].'</ControlNumber> 
                        <PartnerCode>'.$request['partnerCode'].'</PartnerCode> 
                        <Token>Token</Token> 
                        <AgentCode>T00001A</AgentCode>
                        <UserID>PLFAUSTINO</UserID>
                    </cancelDomesticRemittance>
                </CancelDomesticRemittance>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function RefundDomesticRemittance($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"> 
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/RefundDomesticRemittance</Action>
            </s:Header> 
            <s:Body>
                <RefundDomesticRemittance xmlns:i="http://www.w3.org/2001/XMLSchema- instance" xmlns="http://tempuri.org/">
                    <refundDomesticRemittance>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <ControlNumber>'.$request['controlNumber'].'</ControlNumber> 
                        <PartnerCode>'.$request['partnerCode'].'</PartnerCode> 
                        <Token>Token</Token> 
                        <AgentCode>T00001A</AgentCode>
                        <UserID>PLFAUSTINO</UserID>
                    </refundDomesticRemittance>
                </RefundDomesticRemittance>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }
    public function FindDomesticRemittance($request)
    {
        $guzzle = new Client();

        $params=
        '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
            <s:Header>
                <Action s:mustUnderstand="1" xmlns="http://schemas.microsoft.com/ws/2005/05/addressing/none">http://tempuri.org/IService/FindDomesticRemittance</Action>
            </s:Header> 
            <s:Body>
                <FindDomesticRemittance xmlns:i="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://tempuri.org/">               <findDomesticRemittanceRequest>
                        <ServiceCredential>
                            <UserID>'.env('CEBUANA_USERNAME').'</UserID>
                            <Password>'.env('CEBUANA_PASSWORD').'</Password>
                        </ServiceCredential>
                        <ControlNumber>'.$request['controlNumber'].'</ControlNumber> 
                        <PartnerCode>'.$request['partnerCode'].'</PartnerCode>
                        <Token>Token</Token> 
                        <AgentCode>T00001A</AgentCode>
                        <UserID>PLFAUSTINO</UserID>
                    </findDomesticRemittanceRequest>
                </FindDomesticRemittance>
            </s:Body>
        </s:Envelope>';

        $res = $guzzle->post(env('CEBUANA_API_TEST_URL'), [
            'body' => $params
        ]);

        $xml = $res->getBody()->getContents();
        $clean_xml = str_ireplace('s:', '', $xml);
        $xml = simplexml_load_string($clean_xml);
    }

}