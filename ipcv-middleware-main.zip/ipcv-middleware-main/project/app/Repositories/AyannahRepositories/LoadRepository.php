<?php

namespace App\Repositories\AyannahRepositories;

use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class LoadRepository extends Controller
{
    public function loadQuote(Request $session, $request)
    {
        //Send Validate Request
        $guzzle = new Client([
            'headers' => [
                'Authorization' => 'Bearer '+ $session->session()->get('tokenA'),
                'Cache-Control' => 'no-cache'
            ]
        ]);

        $params = [
            "sku" => $request['Code'],
            "msisdn" => $request['phoneNum'],
            "reference_num" => $request['referenceId'],
        ];

        $res = $guzzle -> get(env('AYANNAH_LOAD_QUOTE_API_URL'), [
            'json' => $params
        ]);

        $arr = json_decode($res->getBody(), true);
        $loadToken = $arr['data']['token'];
        $request->session()->put('loadToken', $loadToken);

        //return if no errors
        return json_decode($res->getBody(), true);

    }
    public function loadBuy(Request $session, $request)
    {
        //Send Validate Request;
        $guzzle = new Client([
            'headers' => [
                'Authorization' => 'Bearer '+ $session->session()->get('tokenA'),
                'Cache-Control' => 'no-cache'
            ]
        ]);

        $params = [
            "token" => $session->session()->get('loadToken'),
            "password" => $request['Amount'],
        ];

        $res = $guzzle -> post(env('AYANNAH_LOAD_QUOTE_API_URL'), [
            'json' => $params
        ]);

        $request->session()->forget('loadToken');

        //return if no errors
        return json_decode($res->getBody(), true);

    }
}
