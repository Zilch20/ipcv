<?php

namespace App\Repositories\AyannahRepositories;

use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class TransactRepository extends Controller
{
    public function paymentQuote(Request $session, $request)
    {
        //Send Validate Request
        $guzzle = new Client([
            'headers' => [
                'Authorization' => 'Bearer '+ $session->session()->get('tokenA')
            ]
        ]);

        $params = [
            "sku" => $request['Code'],
            "amount" => $request['Amount'],
        ];

        $res = $guzzle -> post(env('AYANNAH_BILLS_PAYMENT_API_URL'), [
            'json' => $params
        ]);

        $arr = json_decode($res->getBody(), true);

        //return if no errors
        return json_decode($res->getBody(), true);

    }
}
