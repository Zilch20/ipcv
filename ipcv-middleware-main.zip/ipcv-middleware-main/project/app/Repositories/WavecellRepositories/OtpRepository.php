<?php

namespace App\Repositories\WavecellRepositories;

use App\Http\Controllers\Controller;
use App\User;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Validator;

class OtpRepository extends Controller
{

    //OTP Function
    public function GenerateOtp(Request $request)
    {

        $email = $request->session()->get('email');

        //Get user phone number
        $phone = User::where('email', $email)->get()->pluck('phone_number');
        $phone = $phone[0];

        //Post to Wavecell API
        $guzzle = new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . env('WAVECELL_API_TOKEN')
            ]
        ]);

        $params = [
            "destination" => $phone,
            "codeLength" => 6,
            // "productname" => "IPAY",
            "codeValidity" => 180,
            "createNew" => true,
        ];

        $res = $guzzle -> post(env('WAVECELL_API_URL_OTP'), [
            'json' => $params
        ]);

        $arr = json_decode($res->getBody(), true);
        $arr = $arr["uid"];
        $request->session()->put('uid', $arr);
        $request->session()->forget('email');
        //return if no errors
        return json_decode($res->getBody(), true);

    }

    //Validate OTP
    public function ValidateOtp(Request $request)
    {
        $uid = $request->session()->get('uid');

        if(is_null($uid)){
            return response()->json(['ERROR'=>'No OTP was generated']);
        }
        //Validate input
        $validate =[
            'pin' => 'required|numeric|digits:6'
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'digits' => 'Invalid Input: Value must be 6 Digits'
        ];

        $this->validate($request, $validate, $messages);

        //Get from Wavecell API
        $otp = $request->pin;
        $url = env('WAVECELL_API_URL_OTP') . "OtpRepository.php/" .$uid."?code=".$otp;

        $guzzle = new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . env('WAVECELL_API_TOKEN')
            ]
        ]);

        $res = $guzzle -> get($url);

        $arr = json_decode($res->getBody(), true);
        $status = $arr["status"];

        if ($status == "FAILED")
        {
            $request->session()->forget('uid');
            return response()->json(['ERROR'=>'Too Many Attempts']);
        }
        if ($status == "EXPIRED")
        {
            $request->session()->forget('uid');
            return response()->json(['ERROR'=>'OTP Expired']);
        }
        if ($status == "VERIFIED")
        {
            $request->session()->forget('uid');
            $json = json_decode($res->getBody(), 200);
            return response()->json(['SUCCESS'=>$json]);
        }

        // $request->session()->forget('uid');

        //return if no errors
        return json_decode($res->getBody(), 200);
    }
}
// $arr = json_decode($res->getBody(), true);
// $arr = $arr["uid"];
// $this->storeUid($arr);
