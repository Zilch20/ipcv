<?php

declare(strict_types=1);

namespace App\Providers;

use GuzzleHttp\Client as GuzzleClient;
use Illuminate\Support\ServiceProvider;
use IPCV\WesternUnion\HttpClient;
use Laravel\Lumen\Application;

class WesternUnionServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->app->singleton('western_union_client', function (Application $app) {
            return new HttpClient($this->createWesternUnionGuzzleClient());
        });
    }

    private function createWesternUnionGuzzleClient(): GuzzleClient
    {
        return new GuzzleClient([
            'base_uri' => config('western_union.base_uri'),
            'timeout' => 30,
            'allow_redirects' => false,
            'cert' => [config('western_union.certificate')],
            'ssl_key' => [
                config('western_union.certificate_key'),
                config('western_union.certificate_key_passphrase')
            ]
        ]);
    }
}
