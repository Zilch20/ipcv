<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CountryCurrencyResource extends JsonResource
{
    /**
     * @param Request $request
     */
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'country_long' => $this->country_long,
            'iso_country_num_cd' => $this->iso_country_num_cd,
            'iso_country_cd' => $this->iso_country_cd,
            'iso_currency_num_cd' => $this->iso_currency_num_cd,
            'currency_cd' => $this->currency_cd,
            'currency_name' => $this->currency_name,
        ];
    }
}
