<?php

namespace App\Http\Controllers\AyannahControllers\OauthControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator; 
use App\Repositories\AyannahRepositories\OauthRepository;
use Illuminate\Validation\Rule;

class OauthController extends Controller
{
    protected $authRepo;
    public function __construct(OauthRepository $authRepo)
    {
        $this->repo = $authRepo;
    }
    public function oauthProcess(Request $request)
    {
        $validate = [
            'username' => 'Required',
            'password' =>  'Required'
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $res = $this->repo->oauthToken($request->all());
    }
    public function refreshProcess(Request $request)
    {
        $res = $this->repo->refreshToken($request->all());
    }
}