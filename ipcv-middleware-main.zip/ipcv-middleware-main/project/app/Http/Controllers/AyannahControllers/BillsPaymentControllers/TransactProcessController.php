<?php

namespace App\Http\Controllers\AyannahControllers\BillsPaymentControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\AyannahRepositories\TransactRepository;
use Illuminate\Validation\Rule;

class TransactProcessController extends Controller
{
    protected $transactRepo;
    public function __construct(TransactRepository $transactRepo)
    {
        $this->repo = $transactRepo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',
            'Code' => Rule::requiredif($request->Category == 'Quote'),
            'Amount' => Rule::requiredif($request->Category == 'Quote')."|numeric",
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;

        if($category == "Quote"){
            $res = $this->repo->paymentQuote($request->all());
        }
    }
}