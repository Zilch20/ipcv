<?php

namespace App\Http\Controllers\AyannahControllers\WalletControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator; 
use App\Repositories\AyannahRepositories\WalletRepository;
use Illuminate\Validation\Rule;

class WalletProcessController extends Controller
{
    protected $walletRepo;
    public function __construct(WalletRepository $walletRepo)
    {
        $this->repo = $walletRepo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'Required',

            'referenceId' => Rule::requiredIf($request['Category'] == 'Fund'),
            'userId' => Rule::requiredIf($request['Category'] == 'Fund'),
            'amount' => Rule::requiredIf($request['Category'] == 'Fund'),
            'wallet' =>  Rule::requiredIf($request['Category'] == 'Fund'),

            'referenceId' => Rule::requiredIf($request['Category'] == 'Fulfill'),

            'userId' => Rule::requiredIf($request['Category'] == 'Centralize')
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;

        if ($category == 'Fund') {
            $res = $this->repo->fundWallet($request->all());
            return response($res, 200);
        }
        if ($category == 'Fulfill') {
            $res = $this->repo->fulfillWallet($request->all());
            return response($res, 200);
        }
        if ($category == 'Centralize') {
            $res = $this->repo->centralizeWallet($request->all());
            return response($res, 200);
        }
    }
}