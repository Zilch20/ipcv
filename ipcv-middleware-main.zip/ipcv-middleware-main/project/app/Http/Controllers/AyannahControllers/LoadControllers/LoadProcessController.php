<?php

namespace App\Http\Controllers\AyannahControllers\LoadControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator; 
use App\Repositories\AyannahRepositories\LoadRepository;
use Illuminate\Validation\Rule;

class LoadProcessController extends Controller
{
    protected $loadRepo;
    public function __construct(LoadRepository $loadRepo)
    {
        $this->repo = $loadRepo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'Required',

            'Code' => Rule::requiredIf($request['Category'] == 'Quote'),
            'phoneNum' => Rule::requiredIf($request['Category'] == 'Quote'),
            'referenceId' => Rule::requiredIf($request['Category'] == 'Quote'),

            'password' =>  Rule::requiredIf($request['Category'] == 'Buy')
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;

        if ($category == 'Quote') {
            $quoteRes = $this->repo->loadQuote($request->all());
        }
        if ($category == 'Buy') {
            $buyRes = $this->repo->loadBuy($request->all());
        }
    }
}