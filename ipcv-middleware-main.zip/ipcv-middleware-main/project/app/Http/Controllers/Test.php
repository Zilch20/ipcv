<?php

namespace App\Http\Controllers;

use App\Traits\WesternUnionCurlRequestTrait;
use Illuminate\Http\Request;
use Illuminate\Validationrule;

class Test extends Controller
{
    use WesternUnionCurlRequestTrait;

    protected $var;

    public function __construct()
    {
        $this->var;
    }

    public function test_write(Request $request)
    {
        // $certFolder = '';
        // $dirCertFolder = base_path($certFolder);
        // chdir($dirCertFolder);

        // $output = shell_exec('php artisan passport:install');

        // $output = explode("\n",$output);

        // $output =
        // [
        //     "Message" => $output[0],
        //     "personalAccessMessage" => $output[1],
        //     "clientID1" => $output[2],
        //     "clientSecret1" => $output[3],
        //     "passwordGrantMessage" => $output[4],
        //     "clientID2" => $output[5],
        //     "clientSecret2" => $output[6]
        // ];

        // return response()->json($output);

        // $data = json_decode($request, true);
        // dd($request['sender']['name']);

        $rules = [
            "sender.name" => "required",
            "sender.age" => "required",
            "sender.hw.height" => "required",
            "sender.hw.weight" => "required",
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'size' => 'Invalid Input: Value must be 2 characters only'
        ];

        $this->validate($request, $rules, $messages);

        echo $request['sender']['name'];


        // dd($dirCertFolder);
    }

    public function testtwo(Request $request)
    {
        $amount = 1000;
        echo "Request: " . $amount . "\n";
        $amount = substr($amount, 0, -2) . 'Controllers' . substr($amount, -2);
        echo "Decimal: " . $amount;
    }

    public function test_debug(Request $request)
    {
        $params = $request->input('xml');
        $results = $this->requestWUAPI([], $params, 0);

        echo $results;
    }
}
