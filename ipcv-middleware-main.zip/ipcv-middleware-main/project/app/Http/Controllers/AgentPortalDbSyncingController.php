<?php

namespace App\Http\Controllers;

use App\AgentPortalTransactionLog;
use App\InstapayTransferMoneyLog;
use App\SyncingDataLog;
use Illuminate\Http\Request;

date_default_timezone_set("Asia/Manila");

class AgentPortalDbSyncingController extends Controller
{
    public function getTransaction(Request $request)
    {

        $mtcn = $request->post('mtcn') ?? "";

        $countTransaction = $this->countInstpayTransactionLogs($mtcn);
        if ($countTransaction > 0)
        {
            return response()->json(['Transaction Has Already Been Processed']);
        }

        $logs = [];

        //Transaction Start
        $logs['agent_portal_transaction_logs'] = $this->getAgentPortalTransaction($mtcn);
        //Transaction End

        echo json_encode($logs);
    }

    private function getAgentPortalTransaction($mtcn)
    {
        $table_logs = 'Receive Money Select logs';
        $logs = AgentPortalTransactionLog::where('mtcn', $mtcn)->orderBy('created_at', 'desc')->take(1)->get();
        $count_data = $logs->count();
        $date = date('Y-m-d H:i:s');
        SyncingDataLog::saveLogs($date, $table_logs, $count_data);
        return $logs->toJson();
    }

    private function countInstpayTransactionLogs($mtcn)
    {
        $logs = InstapayTransferMoneyLog::where('senderReference', $mtcn)->get();
        $count_data = $logs->count();
    }

    public function validateMtcn(Request $request)
    {
        $mtcn = $request->post('mtcn') ?? "";

        $logs = [];

        $logs['agent_portal_transaction_logs'] = $this->countAgentPortalTransactionLogs($mtcn);
    }

    private function countAgentPortalTransactionLogs($mtcn)
    {
        $table_logs = 'Receive Money Select logs';
        $logs = AgentPortalTransactionLog::where('mtcn', $mtcn)->get();
        $count_data = $logs->count();
        if($count_data > 0)
        {
            return response()->json(['Transaction Exists'],200);
        }
        return response()->json(['No Transaction Found'],201);
    }
}
