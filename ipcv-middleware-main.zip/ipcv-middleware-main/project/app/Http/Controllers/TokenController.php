<?php

namespace App\Http\Controllers;
 
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use App\User;
use Validator;

class TokenController extends Controller
{

    public function tokenProcess(Request $request)
    {

        $guzzle = new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json'
            ]
        ]);
        
        try{
            $params = [
                "grant_type" => "password",
        
                "username" => "dave.mercado@test.com",
                
                "password" => "IPCV12345",
                
                "client_id" => env('CLIENT_ID'),
                
                "client_secret" => env('CLIENT_SECRET'),
                
                "scope" => "*"
            ];
    
            $res = $guzzle -> post(env('OAUTH_URL'), [
                'form_params' => $params
            ]);
    
            return json_decode($res->getBody(), true);
        }
        catch(\Exception $e) {
            echo "<pre>";
            echo $e;
            echo "</pre>";
        }

    }
}