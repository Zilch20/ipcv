<?php

namespace App\Http\Controllers\SubAgentControllers;

use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use App\Repositories\SubAgentRepositories\SubAgentProcessRepository;
use Illuminate\Http\Request;
use Validator;

class SubAgentProcessController extends Controller
{
    protected $ProcessRepo;

    public function __construct(SubAgentProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function SubAgentProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validateRules = [
            'Category'   => 'Required',
            'isActive'   => 'Required',
            'agentEmail' => 'Required',
        ];

        if ($request->Category == 'Register') {
            $validateRules['firstName'] = 'Required';
            $validateRules['lastName'] = 'Required';
            $validateRules['branchLocation'] = 'Required';
            $validateRules['password'] = 'Required';
        } elseif ($request->Category == 'Register FE') {
            $validateRules['firstName'] = 'Required';
            $validateRules['lastName'] = 'Required';
            $validateRules['password'] = 'Required';
            $validateRules['branchLocation'] = 'Required';
            $validateRules['groupName'] = 'Required';
        } elseif ($request->Category == 'Update') {
            $validateRules['branchLocation'] = 'Required';
        } elseif ($request->Category == 'Update FE') {
            $validateRules['branchLocation'] = 'Required';
            $validateRules['groupName'] = 'Required';
        } elseif ($request->Category == 'Delete') {
            unset($validateRules['isActive']);
        } elseif ($request->Category == 'Delete FE') {
            unset($validateRules['isActive']);
        } elseif ($request->Category == 'CheckAccount') {
            unset($validateRules['isActive']);
        }

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max'      => 'Invalid Input: Exceeded maximum number of characters'
        ];

        //        $validate = $this->validate($request, $validateRules, $messages);

        $category = $request->Category;

        // Validation to SOAP implementation
        $validator = \Validator::make($request->all(), $validateRules, $messages);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();
            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            // $logs['client_id'] = $client_id;
            // $logs['xml_request'] = 'MW API VALIDATION';
            // $logs['request_data'] = json_encode($request->all());
            // $logs['reply_data'] = $soapResponse;

            // if ($category === 'FeeInquiry') {
            //     FeeInquiryLogs::create($logs);
            // } else if ($category === 'Validate') {
            //     sendmoneyvalidateLogs::create($logs);
            // } else if ($category === 'Store') {
            //     sendmoneystoreLogs::create($logs);
            // } else if ($category === 'Das') {
            //     DasRequestLog::create($logs);
            // }

            return $soapResponse;
        }

        if ($category == 'Register') {
            return $this->repo->RegisterSubAgent($request->all(), $client_id);
        } elseif ($category == 'Register FE') {
            $dataRequest = $request->all();
            $dataRequest['ip_address'] = $request->getClientIp();
            return $this->repo->RegisterFE($dataRequest, $client_id);
        } elseif ($category == 'Update') {
            return $this->repo->UpdateSubAgent($request->all(), $client_id);
        } elseif ($category == 'Update FE') {
            $dataRequest = $request->all();
            $dataRequest['ip_address'] = $request->getClientIp();
            return $this->repo->UpdateFE($dataRequest, $client_id);
        } elseif ($category == 'Delete') {
            return $this->repo->DeleteSubAgent($request->all(), $client_id);
        } elseif ($category == 'Delete FE') {
            return $this->repo->DeleteFE($request->all(), $client_id);
        } elseif ($category == 'CheckAccount') {
            return $this->repo->checkAccount($request->all(), $client_id);
        }
    }
}
