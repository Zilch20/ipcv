<?php

namespace App\Http\Controllers\SubAgentControllers;

use App\BranchManagementTable;
use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\SubAgentRepositories\BranchManagementRepository;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;

class BranchManagementController extends Controller
{
    protected $ProcessRepo;
    public function __construct(BranchManagementRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }
    public function BranchProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validateRules = [
            'Category' => 'Required',
            "branchName" => Rule::requiredif($request->Category == 'Register') . "||" . Rule::requiredif($request->Category == 'Update') . "||" . Rule::requiredif($request->Category == 'Delete') . "||" . Rule::requiredif($request->Category == 'Search'),
            "branchOwner" => Rule::requiredif($request->Category == 'Register') . "||" . Rule::requiredif($request->Category == 'Update') . "||" . Rule::requiredif($request->Category == 'GetByOwner'),
            "branchEmail" => Rule::requiredif($request->Category == 'Register') . "||" . Rule::requiredif($request->Category == 'Update'),
            "branchAddress" => Rule::requiredif($request->Category == 'Register') . "||" . Rule::requiredif($request->Category == 'Update'),
            "branchContact" => Rule::requiredif($request->Category == 'Register') . "||" . Rule::requiredif($request->Category == 'Update'),
            "branchTerminalId" => Rule::requiredif($request->Category == 'Register') . "||" . Rule::requiredif($request->Category == 'Update'),
            "ftid" => Rule::requiredif($request->Category == 'Register') . "||" . Rule::requiredif($request->Category == 'Update'),
        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];

        $validate = $this->validate($request, $validateRules, $messages);

        $category = $request->Category;

        if ($category == 'Get') {
            $RegisterRes = $this->repo->GetBranch($request);
            return $RegisterRes;
        }

        if ($category == 'GetByOwner') {
            $RegisterRes = $this->repo->GetBranchByOwner($request->all());
            return $RegisterRes;
        }

        if ($category == 'Register') {
            $RegisterRes = $this->repo->RegisterBranch($request->all());
            return $RegisterRes;
        }

        if ($category == 'Update') {
            $UpdateRes = $this->repo->UpdateBranch($request->all());
            return $UpdateRes;
        }

        if ($category == 'Delete') {
            $UpdateRes = $this->repo->DeleteBranch($request->all());
            return $UpdateRes;
        }

        if ($category == 'Search') {
            $UpdateRes = $this->repo->searchBranch($request->all());
            return $UpdateRes;
        }

        if ($category == 'GetByOwner') {
            $UpdateRes = $this->repo->GetBranchByOwner($request->all());
            return $UpdateRes;
        }
    }
}
