<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\AwsS3Request;
use App\Repositories\Aws\S3Repository;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;

class AwsController extends Controller
{
    public function __construct(private readonly S3Repository $repository)
    {
    }

    public function upload(AwsS3Request $request): Response
    {
        $file = $request->file('image');
        $fileName = $request->input('file_name');

        $this->repository->uploadObject($file, $fileName);

        return new JsonResponse(['message' => 'Upload Success!']);
    }
}
