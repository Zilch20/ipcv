<?php

namespace App\Http\Controllers\WavecellControllers;

use App\Http\Controllers\Controller;
use App\Repositories\WavecellRepositories\OtpRepository;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class OtpProcessController extends Controller
{
    public function __construct(private readonly OtpRepository $otpRepo)
    {
    }
    public function otpProcess(Request $request)
    {

        $validate = [
            'Category' => 'required',
            'PIN' => Rule::requiredif($request->Category === 'Validate'),
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;

        if($category === 'Generate'){
            $res = $this->otpRepo->GenerateOtp($request);
            return response($res, 200);
        }
    }
}
