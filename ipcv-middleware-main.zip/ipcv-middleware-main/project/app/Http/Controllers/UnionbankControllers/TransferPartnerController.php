<?php

namespace App\Http\Controllers\UnionbankControllers;

use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class TransferPartnerController extends Controller
{
    public function SingleTransferViaPartner(Request $request)
    {
        $validate = [
            //sender
            'sender_name' => 'required',
            'sender_addr_line1' => 'required',
            'sender_addr_line2' => 'required',
            'sender_city' => 'required',
            'sender_province' => 'required',
            'sender_zipCode' => 'required|numeric',
            'sender_country' => 'required|size:2',

            //beneficiary
            'beneficiary_acct_number' => 'required|numeric',
            'beneficiary_name' => 'required',
            'beneficiary_addr_line1' => 'required',-
            'beneficiary_addr_line2' => 'required',
            'beneficiary_city' => 'required',
            'beneficiary_province' => 'required',
            'beneficiary_zipCode' => 'required|numeric',
            'beneficiary_country' => 'required|size:2',

            //remmitance
            'amount' => 'required|numeric',
            'currency' => 'required|size:2',
            'recievingBank' => 'required|numeric',
            'purpose' => 'required|numeric',
            'instructions' => 'required',
         ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'size' => 'Invalid Input: Value must be 2 characters only'
        ];

        $this->validate($request, $validate, $messages);

        // if($validator->fails()){
        //         return response()->json($validator->errors(), 400);
        // }

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => "",
                "x-ibm-client-secret" => "",
                "authorization" => "Bearer ". "",
                "x-partner-id" => ""
            ]
        ]);

        $params = [
            "senderRefId"=> 321,
            "tranRequestDate"=> "2015-10-03T15:29:16.333",
            "sender" => [
                "name"=> $request->sender_name,
                "address"=> [
                    "line1"=> $request->sender_addr_line1,
                    "line2"=> $request->sender_addr_line2,
                    "city"=> $request->sender_city,
                    "province"=> $request->sender_province,
                    "zipCode"=> $request->zipCode,
                    "country"=> $request->sender_country
                ]
            ],
            "beneficiary"=> [
                "accountNumber"=> $request->beneficiary_acct_number,
                "name"=> $request->beneficiary_name,
                "address"=> [
                    "line1"=> $request->beneficiary_addr_line1,
                    "line2"=> $request->beneficiary_addr_line2,
                    "city"=> $request->beneficiary_city,
                    "province"=> $request->beneficiary_province,
                    "zipCode"=> $request->beneficiary_zipCode,
                    "country"=> $request->beneficiary_country
                ]
            ],
            "remittance" => [
                "amount"=> $request->amount,
                "currency"=> $request->currency,
                "receivingBank"=> $request->receivingBank,
                "purpose"=> $request->purpose,
                "instructions"=> $request->instructions
            ]
        ];

        $res = $guzzle -> post(env("INSTAPAY_TRANSFER_VIA_PARTNER_URL"), [
            "json" => $params
        ]);

        return json_decode($res->getBody(), true);
    }

    public function SingleFundTransferStatus($senderID)
    {
        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => "",
                "x-ibm-client-secret" => "",
                "authorization" => "Bearer ". "",
                "x-partner-id" => ""
            ]
        ]);

        $url = env("INSTAPAY_TRANSFER_VIA_PARTNER") . "TransferPartnerController.php/" .$senderID;
        $res = $guzzle -> get($url);

        return json_decode($res->getBody(), true);
    }

    public function RetrievePartnerList(){
        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => "",
                "x-ibm-client-secret" => "",
                "authorization" => "Bearer ". "",
                "x-partner-id" => ""
            ]
        ]);

        $res = $guzzle -> get(env("INSTAPAY_LIST_OF_PARTNERS_URL"));

        return json_decode($res->getBody(), true);
    }

}
