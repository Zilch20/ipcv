<?php

namespace App\Http\Controllers\UnionbankControllers;

use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class CustomerBillsController extends Controller
{
    public function PayBillsOnline(Request $request)
    {
        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => "",
                "x-ibm-client-secret" => "",
                "authorization" => "Bearer ". "",
                "x-partner-id" => ""
            ]
        ]);

        $params = [
            "senderRefId"=> "",
            "tranRequestDate"=> "",
            "biller" => [
                "id" => "1234",
                "name" => "Telecom Biller"
            ],
            "amount" => [
                "currency" => "PHP",
                "value" => "100"
            ],
            "remarks" => "Payment remarks",
            "particulars" => "Payment particulars",
            "references" => [
                [
                    "index" => 1,
                    "name" => "Account Number",
                    "value" => "123456789012"
                ],
                [
                "index" => 2,
                "name" => "Mobile Number",
                "value" => "9991234567"
                ]
            ]
        ];

        $res = $guzzle -> post(env("INSTAPAY_PAY_BILLS_ONLINE_URL"), [
            "json" => $params
        ]);

        return json_decode($res->getBody(), true);
    }

    public function BillsPaymentStatus($senderID){
        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => "",
                "x-ibm-client-secret" => "",
                "authorization" => "Bearer ". "",
                "x-partner-id" => ""
            ]
        ]);

        $url = env("INSTAPAY_PAY_BILLS_ONLINE_URL") . "CustomerBillsController.php/" .$senderID;
        $res = $guzzle -> get($url);

        return json_decode($res->getBody(), true);
    }
}
