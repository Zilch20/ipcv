<?php

namespace App\Http\Controllers\UnionbankControllers\PesonetControllers;

use App\Http\Controllers\Controller;
use App\Repositories\InstapayRepositories\PesonetRepository;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class SingleTransferProcess extends Controller
{
    protected $transferRepo;
    public function __construct(PesonetRepository $transferRepo)
    {
        $this->repo = $transferRepo;
    }
    public function transferProcess(Request $request){
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validate = [
            "Category" => 'required',
            //sender
            'sender_name' => Rule::requiredif($request->Category == 'Transfer'),
            'sender_addr_line1' => Rule::requiredif($request->Category == 'Transfer'),
            'sender_addr_line2' => Rule::requiredif($request->Category == 'Transfer'),
            'sender_city' => Rule::requiredif($request->Category == 'Transfer'),
            'sender_province' => Rule::requiredif($request->Category == 'Transfer'),
            'sender_zipCode' => Rule::requiredif($request->Category == 'Transfer'),
            'sender_country' => Rule::requiredif($request->Category == 'Transfer'),

            //beneficiary
            'beneficiary_acct_number' => Rule::requiredif($request->Category == 'Transfer'),
            'beneficiary_name' => Rule::requiredif($request->Category == 'Transfer'),
            'beneficiary_addr_line1' => Rule::requiredif($request->Category == 'Transfer'),
            'beneficiary_addr_line2' => Rule::requiredif($request->Category == 'Transfer'),
            'beneficiary_city' => Rule::requiredif($request->Category == 'Transfer'),
            'beneficiary_province' => Rule::requiredif($request->Category == 'Transfer'),
            'beneficiary_zipCode' => Rule::requiredif($request->Category == 'Transfer'),
            'beneficiary_country' => Rule::requiredif($request->Category == 'Transfer'),

            //remmitance
            'amount' => Rule::requiredif($request->Category == 'Transfer'),
            'currency' => Rule::requiredif($request->Category == 'Transfer'),
            'receivingBank' => Rule::requiredif($request->Category == 'Transfer'),
            'purpose' => Rule::requiredif($request->Category == 'Transfer'),
            'instructions' => Rule::requiredif($request->Category == 'Transfer'),
            'referenceID' => Rule::requiredif($request->Category == 'Transfer').'|'.Rule::requiredif($request->Category == 'Verify'),

            'status' => Rule::requiredif($request->Category == 'Update'),
            'remittanceNo' => Rule::requiredif($request->Category == 'Update'),
         ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'size' => 'Invalid Input: Value must be 2 characters only'
        ];

        $this->validate($request, $validate, $messages);

        if($request->Category == "Transfer"){
            $res = $this->repo->partnerTransfer($request->all(), $client_id);
            //Return
            return response($res, 200);
        }
        if($request->Category == "Verify"){
            $res = $this->repo->TransferVerification($request->all());
            //Return
            return response($res, 200);
        }
        if($request->Category == "List"){
            $res = $this->repo->BankList();
            //Return
            return response($res, 200);
        }
        if($request->Category == "Update"){
            $res = $this->repo->TransferStatusUpdate($request->all());
            //Return
            return response($res, 200);
        }

    }
}
