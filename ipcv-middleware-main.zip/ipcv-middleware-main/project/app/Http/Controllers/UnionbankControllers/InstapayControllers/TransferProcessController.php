<?php

namespace App\Http\Controllers\UnionbankControllers\InstapayControllers;

use App\Http\Controllers\Controller;
use App\Repositories\UnionbankRepositories\TransferRepository;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TransferProcessController extends Controller
{
    protected $transferRepo;
    public function __construct(TransferRepository $transferRepo)
    {
        $this->repo = $transferRepo;
    }
    public function transferProcess(Request $request){
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validate = [
            "Category" => 'required',
            "token" => 'required',

            // transferStatus Start
                'senderReference' => Rule::requiredif($request->Category == 'Status'),
            // transferStatus End

            // fetchFees Start
                'amount' => Rule::requiredif($request->Category == 'Fee'),
            // fetchFees End

            // generateReport Start
                'startDate' => "Nullable",
                'endDate' => "Nullable",
                'search' => "Nullable",
            // generateReport End

            // validateFields and processTransaction Start
                // Transaction
                'transaction.senderReference' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'transaction.amount' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'transaction.purpose' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'transaction.receiverType' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                // 'transaction.callbackURL' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),

                // sender
                'sender.accountName' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'sender.accountNumber' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'sender.mobileNumber' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'sender.address' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'sender.barangay' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'sender.city' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'sender.zipCode' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),

                // receiver
                'receiver.accountName' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.accountNumber' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.mobileNumber' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.address' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.barangay' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.city' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.zipCode' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.bank.name' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.bank.code' => Rule::requiredif($request->Category == 'Validate')."|".Rule::requiredif($request->Category == 'Process'),
                'receiver.birthDate' => Rule::requiredif($request->Category == 'Validate' && $request['transaction']['receiverType'] == 'INDIVIDUAL')."|".Rule::requiredif($request->Category == 'Process' && $request['transaction']['receiverType'] == 'INDIVIDUAL'),

                // Representative
                'representative.firstName' => 'Nullable',
                'representative.middleName' => 'Nullable',
                'representative.lastName' => 'Nullable',
                'representative.suffix' => 'Nullable',
            // validateFields and processTransaction End
         ];

        //  dd();

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'size' => 'Invalid Input: Value must be 2 characters only'
        ];

        $this->validate($request, $validate, $messages);


        if($request->Category == "Status"){
            $res = $this->repo->transferStatus($request->all());
            //Return
            return response($res, 200);
        }

        if($request->Category == "Report"){
            $res = $this->repo->generateReport($request->all());
            //Return
            return response($res, 200);
        }

        if($request->Category == "Validate"){
            $res = $this->repo->validateFields($request->all(),$client_id);
            //Return
            return response($res, 200);
        }

        if($request->Category == "Process"){
            $res = $this->repo->processTransactions($request->all(), $client_id);
            //Return
            return response($res, 200);
        }

        if($request->Category == "Purpose"){
            $res = $this->repo->transactionPurpose($request->all(), $client_id);
            //Return
            return response($res, 200);
        }

        if($request->Category == "Bank"){
            $res = $this->repo->bankList($request->all(), $client_id);
            //Return
            return response($res, 200);
        }
    }
}
