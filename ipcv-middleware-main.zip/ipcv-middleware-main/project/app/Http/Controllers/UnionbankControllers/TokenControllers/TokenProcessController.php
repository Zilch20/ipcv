<?php

namespace App\Http\Controllers\UnionbankControllers\TokenControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\UnionbankRepositories\TokenRepository;

class TokenProcessController extends Controller
{
    protected $tokenRepo;
    public function __construct(TokenRepository $tokenRepo)
    {
        $this->repo = $tokenRepo;
    }
    public function partnerToken(Request $request){
        $validate = [
            "Category" => 'required',
            "username" => 'required',
            "password" => 'required',
         ];
        
        $messages = [
            'required' => 'Invalid Input: Empty Field',
        ];

        $this->validate($request, $validate, $messages);

        // $res = $this->repo->generateCode($request->all());
        $category = $request->Category;

        if ($category == 'Instapay'){
            $res = $this->repo->generateToken($request->all());
            return response($res, 200);
        }
        if ($category == 'Pesonet'){
            $res = $this->repo->generatePesonetToken($request->all());
            return response($res, 200);
        }
    }
}