<?php

namespace App\Http\Controllers\BayadCenterControllers\BillsPaymentControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\BayadCenterRepositories\TransactRepository;
use Illuminate\Validation\Rule;

class TransactProcessController extends Controller
{
    protected $transactRepo;
    public function __construct(TransactRepository $transactRepo)
    {
        $this->repo = $transactRepo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',
            'Subcategory' => Rule::requiredif($request->Category == 'Payment'),
            'PartnerID' => Rule::requiredif($request->Category == 'Payment'),
            'ParameterOne' => Rule::requiredif($request->Category == 'Payment'),
            'Amount' => Rule::requiredif($request->Category == 'Payment')."|numeric",
            'channel' => Rule::requiredif($request->Category == 'Payment'),
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;
        $subCategory = $request->Subcategory; 
        $partnerID = $request->PartnerID;

        if($category == 'Payment'){
            if($subCategory == 'Telecommunications'){
                //Smart
                if($partnerID == '1'){
                    $res = $this->repo->telecommunicationsTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Globe
                if($partnerID == '2'){
                    $res = $this->repo->telecommunicationsTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Sun Cellular
                if($partnerID == '3'){
                    $res = $this->repo->telecommunicationsTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
            }
        }
        if($category == 'List'){
            $res = $this->repo->billerList();
            return response($res, 200);
        }
        if($category == 'Balance'){
            $res = $this->repo->checkBalance();
            return response($res, 200);
        }
        return response()->json(["ERROR"=>"INVALID REQUEST"], 400);
    }
}