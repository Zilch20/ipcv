<?php
namespace App\Http\Controllers\WesternUnionControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\MyWuProcessRepository;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;
use App\SubAgentManagementTable;
use App\Traits\SubAgentTraits;
use App\MyWuLookupLog;
use App\MyWuEnrollmentLog;
use App\Helpers\JSONSOAPConvert;

class MyWuProcessController extends Controller
{
    use SubAgentTraits;
    
    protected $ProcessRepo;
    public function __construct(MyWuProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }
    public function MyWuLookupProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validateRules = [
            // 'Category' => 'Required',
            // 'channelType' => 'Required',
            // 'channelVersion' => 'Required',


            //Lookup
                // 'cardLookupSearchType' => Rule::requiredif($request->Category == 'Lookup'),
                // 'name' => 'Nullable',
                // 'senderCountryCode' => 'Nullable',
                // 'permanentChange' => Rule::requiredif($request->Category == 'Lookup'),
                // 'myWuNumber' => Rule::requiredif($request->Category == 'Lookup'),

                // 'applyDiscount' => Rule::requiredif($request->Category == 'Lookup'),
                // 'nonpermanentChangeCount' => Rule::requiredif($request->Category == 'Lookup'),
                // 'sharePersonalData' => Rule::requiredif($request->Category == 'Lookup'),
                // 'receiveMail' => Rule::requiredif($request->Category == 'Lookup'),
                // 'desirePrivacyPolicy' => Rule::requiredif($request->Category == 'Lookup'),
                // 'receiverIndexNumber' => Rule::requiredif($request->Category == 'Lookup'),
                // 'sharePersonalData' => Rule::requiredif($request->Category == 'Lookup'),
                // 'loyaltyCardUpdateIndicator' => Rule::requiredif($request->Category == 'Lookup'),

            //Enrollment
                //Sender Details
                // 'firstName' => Rule::requiredif($request->Category == 'Enroll').'|max:80',
                // 'lastName' => Rule::requiredif($request->Category == 'Enroll').'|max:80',

                // 'address' => Rule::requiredif($request->Category == 'Enroll').'|max:84',
                // 'city' => Rule::requiredif($request->Category == 'Enroll').'|max:30',
                // 'postalCode' => Rule::requiredif($request->Category == 'Enroll').'|max:40',

                // 'countryCode' => Rule::requiredif($request->Category == 'Enroll').'|max:3',
                // 'currencyCode' => Rule::requiredif($request->Category == 'Enroll').'|max:3',
                // 'email' => Rule::requiredif($request->Category == 'Enroll'),

                // 'phoneNum' => Rule::requiredif($request->Category == 'Enroll').'|max:31',
                // 'gender' => Rule::requiredif($request->Category == 'Enroll'),

                // 'receiverType' => 'Nullable',

                // 'transferFrequency' =>'Nullable',
                // 'wuTransferFrequency' =>'Nullable',
                // 'interests' =>'Nullable',
                // 'modeToReceive' =>'Nullable',
                // 'transferReason1' =>'Nullable',
                // 'transferReason2' =>'Nullable',
                // 'idOnFile' =>'Nullable',
                // 'preferredLanguage' => 'Nullable',
                // 'cardStatus' =>'Nullable',
                // 'enrollmentSource' =>'Nullable',

                //Payment Details
                // 'destinationCountryCode' => Rule::requiredif($request->Category == 'Enroll').'|max:3',
                // 'destinationCurrencyCode' => Rule::requiredif($request->Category == 'Enroll').'|max:3',
                // 'senderCurrencyCode' => Rule::requiredif($request->Category == 'Enroll').'|max:3',


        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];

        // $this->validate($request, $validate, $messages);

        $validator = \Validator::make($request->all(), $validateRules, $messages);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();
            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'MW API VALIDATION';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;
            
            if ($category === 'Lookup') {
                MyWuLookupLog::create($logs);
            } else if ($category === 'Enroll') {
                MyWuEnrollmentLog::create($logs);
            }

            return $soapResponse;
        }

        if(empty($request['mobileFlag']))
        {
            //get Branch Location
            if(empty($request['branchLocation']))
            {
                $branchLocation = $this->getBranchLocation($request);

                $request['branchLocation'] = $branchLocation;
            }
            // End Get Branch Location

            $checkSuspension = $this->checkSuspended($request);
            if($checkSuspension === true)
            {
                $errorMessage = 'BRANCH SUSPENDED';
                $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

                $logs['client_id'] = $client_id;
                $logs['xml_request'] = 'BRANCH SUSPENDED';
                $logs['request_data'] = json_encode($request->all());
                $logs['reply_data'] = $soapResponse;

                if ($category === 'Lookup') {
                    MyWuLookupLog::create($logs);
                } else if ($category === 'Enroll') {
                    MyWuEnrollmentLog::create($logs);
                }

                return $soapResponse;
            }
        }

        $category = $request->Category;

        if($category == 'Lookup'){
            $feeRes = $this->repo->myWuLookupRequest($request->all(), $client_id);
            return $feeRes;
        }
        if($category == 'Enroll'){
            $feeRes = $this->repo->myWuEnrollmentRequest($request->all(), $client_id);
            return $feeRes;
        }
    }
}
