<?php

declare(strict_types=1);

namespace App\Http\Controllers\WesternUnionControllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\WesternUnion\GetCountryInfoRequest;
use Illuminate\Http\Request;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Client;
use IPCV\WesternUnion\DataAccessServer\Request as DASRequest;
use IPCV\WesternUnion\Filters;
use IPCV\WesternUnion\ForeignRemoteSystem;
use Psr\Container\ContainerExceptionInterface;
use Psr\Container\NotFoundExceptionInterface;
use Symfony\Component\HttpFoundation\Response;

class GetCountryInfo extends Controller
{
    public function __construct()
    {
    }

    public function __invoke(GetCountryInfoRequest $request): Response
    {
        $dasRequest = self::createGetCountryInfoRequest($request);

        $client = self::getWesternUnionClient();
        $response = $client->send($dasRequest);

        return new Response($response->getBody()->getContents());
    }

    private static function createGetCountryInfoRequest(Request $request): DASRequest
    {
        $dasRequest = new DASRequest();
        $dasRequest
            ->setName('GetCountryInfo')
            ->setChannel(new Channel('H2H', 'IPAY MIDDLEWARE', '9500'))
            ->setClientId('H2H')
            ->setForeignRemoteSystem(
                new ForeignRemoteSystem(
                    'WGHHPH9940T',
                    '115210-000000003',
                    'PH994AMP001A'
                )
            )
            ->setFilters(
                (new Filters())
                    ->addFilter('en')
                    ->addFilter(
                        $request->input('iso_country_cd') . ' GetCountryInfo.php' . $request->input('currency_cd')
                    )
            )
        ;

        return $dasRequest;
    }

    /**
     * @throws ContainerExceptionInterface
     * @throws NotFoundExceptionInterface
     */
    private static function getWesternUnionClient(): Client
    {
        return app()->get('western_union_client');
    }
}
