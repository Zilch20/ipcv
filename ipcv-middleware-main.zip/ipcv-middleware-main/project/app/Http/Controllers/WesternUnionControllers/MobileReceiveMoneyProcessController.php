<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\MobileRecieveMoneyProcessRepository;
use Illuminate\Validation\Rule;

class MobileReceiveMoneyProcessController extends Controller
{
    protected $ProcessRepo;
    public function __construct(MobileRecieveMoneyProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function MobileReceiveMoneyProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validate = [
            // 'Category' => 'Required',
            
            // 'channelType' => 'Required',
            // 'channelVersion' => 'Required',

            // 'mtk' => Rule::requiredif($request->Category == 'Select')."|".Rule::requiredif($request->Category == 'Pay'),

            // 'mtcn' => Rule::requiredif($request->Category == 'Search')."|".Rule::requiredif($request->Category == 'Pay'),

            // 'transactionType' => Rule::requiredif($request->Category == 'Pay'),
            
            // 'firstName' => Rule::requiredif($request->Category == 'Pay').'|max:80',
            // 'middleName' => Rule::requiredif($request->Category == 'Pay').'|max:80',
            // 'lastName' => Rule::requiredif($request->Category == 'Pay').'|max:80',
            
            // 'address1' => Rule::requiredif($request->Category == 'Pay').'|max:84',
            // 'city' => Rule::requiredif($request->Category == 'Pay').'|max:30',
            // 'province' => Rule::requiredif($request->Category == 'Pay').'|max:30',
            // 'postalCode' => Rule::requiredif($request->Category == 'Pay').'|max:40',
            // 'receiverCountryCode' => Rule::requiredif($request->Category == 'Pay').'|max:3',
            // 'receiverCountryCurrencyCode' => Rule::requiredif($request->Category == 'Pay').'|max:3',

            // 'idType' => Rule::requiredif($request->Category == 'Pay'),
            // 'idCountryIssued' => Rule::requiredif($request->Category == 'Pay').'|max:30',
            // 'idNum' => Rule::requiredif($request->Category == 'Pay').'|max:30',
            // 'issueDate' => Rule::requiredif($request->Category == 'Pay').'|max:10',
            // 'expiration' => Rule::requiredif($request->Category == 'Pay').'|max:10',
            // 'birthDate' => Rule::requiredif($request->Category == 'Pay').'|max:10',
            // 'countryofBirth' => Rule::requiredif($request->Category == 'Pay'),
            // 'gender' => Rule::requiredif($request->Category == 'Pay'),
            // 'occupation' => Rule::requiredif($request->Category == 'Pay').'|max:50',
            // 'transactionReason' => Rule::requiredif($request->Category == 'Pay').'|max:50',

            // 'phoneCountryCode' => Rule::requiredif($request->Category == 'Pay').'|max:30',
            // 'phoneNum' => Rule::requiredif($request->Category == 'Pay').'|max:31',
            // 'gender' => Rule::requiredif($request->Category == 'Pay').'|max:1',
            // 'fundSource' => Rule::requiredif($request->Category == 'Pay').'|max:30',

            // 'relationshiptoSender' => Rule::requiredif($request->Category == 'Pay').'|max:50',
            // 'positionLevel' => Rule::requiredif($request->Category == 'Pay'),

            // 'stateCode' => 'Nullable|max:30|alpha_num',
            // 'receiverCity' => 'Nullable|max:30|alpha_num',

            // 'destinationCountry' => Rule::requiredif($request->Category == 'Pay')."|".Rule::requiredif($request->Category == 'Search').'|max:3|alpha_num',
            // 'destinationCurrencyCode' => Rule::requiredif($request->Category == 'Pay')."|".Rule::requiredif($request->Category == 'Search').'|max:3|alpha_num',

            // 'originatingCountryCode' => Rule::requiredif($request->Category == 'Pay').'|max:3|alpha_num',
            // 'originatingCurrencyCode' => Rule::requiredif($request->Category == 'Pay').'|max:3|alpha_num',

            // 'new_mtcn' => Rule::requiredif($request->Category == 'Pay'),

            // 'stateCode' => Rule::requiredif($request->Category == 'Pay' && $request->originatingCountryCode == 'US' || $request->Category == 'Pay' && $request->originatingCountryCode == 'MX').'|max:30',
            // 'senderCity' => Rule::requiredif($request->Category == 'Pay' && $request->originatingCountryCode == 'MX' ).'|'.Rule::requiredif($request->Category == 'Pay' && $request->originatingCountryCode == 'MX').'|max:30',

            // 'multiErrorSupported' => Rule::requiredif($request->Category == 'Pay'),
            // 'templateId' => Rule::requiredif($request->Category == 'Pay'),
            // 'version' => Rule::requiredif($request->Category == 'Pay'),
            // 'ackFlag' => Rule::requiredif($request->Category == 'Pay'),

            // 'grossTotalAmount'  => Rule::requiredif($request->Category == 'Pay'),
            // 'payAmount' => Rule::requiredif($request->Category == 'Pay'),
            // 'principalAmount' => Rule::requiredif($request->Category == 'Pay'),
            // 'charges' => Rule::requiredif($request->Category == 'Pay'),
            // 'tolls' => Rule::requiredif($request->Category == 'Pay'),
            // 'exchangeRate' => Rule::requiredif($request->Category == 'Pay'),

            // 'originatingCity' => Rule::requiredif($request->Category == 'Pay'),
            // 'payOrDoNot' => Rule::requiredif($request->Category == 'Pay'),

            // 'bankName' => 'Nullable',
            // 'accountNumber' => 'Nullable',

            // 'deliveryCode' => 'Nullable',

            // 'myWuNumber' => 'Nullable'
        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;

        if($category == "Search"){
            $searchRes = $this->repo->recieveMoneySearchRequest($request->all(), $client_id);
            return $searchRes;
        }

        if($category == "Pay"){
            $payRes = $this->repo->recieveMoneyPayRequest($request->all(), $client_id);
            return $payRes;
        }

        if($category == "Hold"){
            $payRes = $this->repo->holdTxnReleaseRequest($request->all(), $client_id);
            return $payRes;
        }
    }
}