<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\DasProcessRepository;
use Illuminate\Validation\Rule;

class DasProcessController extends Controller
{
    
    protected $ProcessRepo;
    public function __construct(DasProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function dasProcessController(Request $request)
    {
        $validate = [

            'dasRequest' => 'Required',
            'queryFilter1' => Rule::requiredif($request->dasRequest != 'GetMexicoCityState'),
            'queryFilter2' => Rule::requiredif($request->dasRequest != 'GetCascadeList'),
            'queryFilter3' => "Nullable",
            'queryFilter4' => "Nullable",

        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
        ];

        $this->validate($request, $validate, $messages);

        $res = $this->repo->dasRequest($request->all());

    }
}