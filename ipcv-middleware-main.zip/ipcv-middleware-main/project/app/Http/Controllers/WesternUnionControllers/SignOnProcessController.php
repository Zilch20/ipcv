<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class SignOnProcessController extends Controller
{

    public function SignOnRepository(){

        $guzzle = new Client([
            'headers' =>[
                'Content-Type' => 'application/xml',
                'Host' => '172.31.94.182:51280',
                'Content-Length' => '1843',
                'Accept-Encoding' => 'gzip,deflate'
            ]
        ]);
    
        $params =
        '<xrsi:send-money-store-request xmlns:xrsi="http://www.westernunion.com/schema/xrsi">

            <Channel>
                <name>Mobile</name>
            </Channel>

            <foreign_remote_system>
                <Identifier>'.env('WU_API_FSID').'</Identifier>
                <counter_id>'.env('WU_API_TERM_ID').'</counter_id>
            </foreign_remote_system>

        </xrsi:send-money-store-request>';

        $res = $guzzle ->post(env('WU_API_URL'), [
            'Body' => $params
        ]);

        return response()->xml($res);
    }
}