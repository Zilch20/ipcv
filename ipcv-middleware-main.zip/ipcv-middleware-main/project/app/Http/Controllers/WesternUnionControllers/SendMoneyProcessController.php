<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\BranchManagementTable;
use App\DasRequestLog;
use App\FeeInquiryLogs;
use App\Helpers\JSONSOAPConvert;
use App\Helpers\SpecialCharacters;
use App\Http\Controllers\Controller;
use App\Repositories\WesternUnionRepositories\SendMoneyProcessRepository;
use App\SendMoneyStoreLogs;
use App\SendMoneyValidateLogs;
use App\Traits\SubAgentTraits;
use Illuminate\Contracts\Validation\Validator as ValidatorContract;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class SendMoneyProcessController extends Controller
{
    use SubAgentTraits;

    protected $ProcessRepo;

    public function __construct(SendMoneyProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function SendMoneyStoreProcess(Request $request)
    {
        $client_id = $request->user();
        $client_id = $client_id['id'];

        $category = $request->Category;
        // Validation to SOAP implementation
        $validator = $this->createValidator($request);

        // Error Handler if a required request is missing
        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();

            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'MW API VALIDATION';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if ($category === 'FeeInquiry') {
                FeeInquiryLogs::create($logs);
            } else if ($category === 'Validate') {
                SendMoneyValidateLogs::create($logs);
            } else if ($category === 'Store') {
                SendMoneyStoreLogs::create($logs);
            } else if ($category === 'Das') {
                DasRequestLog::create($logs);
            }

            return $soapResponse;
        }

        if(empty($request['mobileFlag']))
        {
            //get Branch Location
            if(!empty($request['agentEmail']) && empty($request['branchLocation']))
            {
                $branchLocation = $this->getBranchLocation($request);

                $request['branchLocation'] = $branchLocation;
            }
            // End Get Branch Location

            //Check Branch Location
            $checkBranch = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
                                                ->get()
                                                ->count();

            if($checkBranch == 0)
            {
                $soapResponse = JSONSOAPConvert::toSoap('BRANCH IS NOT REGISTERED');

                $logs['client_id'] = $client_id;
                $logs['xml_request'] = 'BRANCH SUSPENDED';
                $logs['request_data'] = json_encode($request->all());
                $logs['reply_data'] = $soapResponse;

                if ($category === 'FeeInquiry') {
                    FeeInquiryLogs::create($logs);
                } else if ($category === 'Validate') {
                    SendMoneyValidateLogs::create($logs);
                } else if ($category === 'Store') {
                    SendMoneyStoreLogs::create($logs);
                } else if ($category === 'Das') {
                    DasRequestLog::create($logs);
                }

                return $soapResponse;
            }
            //End Check Branch Location

            //Check Branch Suspension
            $checkSuspension = $this->checkSuspended($request);
            if($checkSuspension === true)
            {
                $errorMessage = 'BRANCH SUSPENDED';
                $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

                $logs['client_id'] = $client_id;
                $logs['xml_request'] = 'BRANCH SUSPENDED';
                $logs['request_data'] = json_encode($request->all());
                $logs['reply_data'] = $soapResponse;

                if ($category === 'FeeInquiry') {
                    FeeInquiryLogs::create($logs);
                } else if ($category === 'Validate') {
                    SendMoneyValidateLogs::create($logs);
                } else if ($category === 'Store') {
                    SendMoneyStoreLogs::create($logs);
                } else if ($category === 'Das') {
                    DasRequestLog::create($logs);
                }

                return $soapResponse;
            }
            //Check Branch Suspension
        }

        // Check for Special Characters Start
        $check = SpecialCharacters::checkCharacter($request->all());
        if($check === true)
        {
            $errorMessage = "Request must not contain accented letters";
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'SPECIAL CHAR ERROR';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if ($category === 'FeeInquiry') {
                FeeInquiryLogs::create($logs);
            } else if ($category === 'Validate') {
                SendMoneyValidateLogs::create($logs);
            } else if ($category === 'Store') {
                SendMoneyStoreLogs::create($logs);
            } else if ($category === 'Das') {
                DasRequestLog::create($logs);
            }

            return $soapResponse;
        }
        // Check for Special Characters End


        if ($category == 'FeeInquiry') {
            $feeRes = $this->repo->feeInquiryRequest($request->all(), $client_id);
            return $feeRes;
        }

        if ($category == 'Validate') {
            $validationRes = $this->repo->sendMoneyValidationRequest($request->all(), $client_id);
            return $validationRes;
        }

        if ($category == 'Store') {
            $storeRes = $this->repo->sendMoneyStoreRequest($request->all(), $client_id);
            return $storeRes;
        }
        if ($category == "Das") {
            $dasRes = $this->repo->dasRequest($request->all(), $client_id);
            return $dasRes;
        }
    }

    private function createValidator(Request $request): ValidatorContract
    {
        $requiredIfRequestisStore = Rule::requiredIf($request->Category === 'Store');
        $requiredIfRequestisValidate = Rule::requiredIf($request->Category === 'Validate');

        $validateRules = [
            'Category' => ['required'],
            'channelType' => ['required', 'max:3'],
            'channelVersion' => ['required', 'max:20'],
            'mtcn' => [$requiredIfRequestisStore, 'max:16'],
            'firstName' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:80'],
            'lastName' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:80'],
            'address1' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:40'],
            'city' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:30'],
            'province' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:30'],
            'postalCode' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:40'],
            'senderCountryCode' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:3'],
            'senderCountryCurrencyCode' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:3'],
            'amount' => [
                Rule::requiredif($request->transactionType === 'WMN' && $request->Category === 'FeeInquiry'),
                $requiredIfRequestisValidate,
                $requiredIfRequestisStore,
                'max:20'
            ],
            'destinationCountry' => [
                Rule::requiredif($request->Category === 'FeeInquiry'),
                $requiredIfRequestisValidate,
                $requiredIfRequestisStore,
                'max:3',
            ],
            'destinationCurrencyCode' => [
                Rule::requiredif($request->Category === 'FeeInquiry'),
                $requiredIfRequestisValidate,
                $requiredIfRequestisStore,
                'max:3',
            ],
            'originatingCountryCode' => [
                Rule::requiredif($request->Category === 'FeeInquiry'),
                $requiredIfRequestisValidate,
                $requiredIfRequestisStore,
            ],
            'currencyCode' => [
                Rule::requiredif($request->Category === 'FeeInquiry'),
                $requiredIfRequestisValidate,
                $requiredIfRequestisStore,
                'max:4',
            ],
            'transactionType' => [
                Rule::requiredif($request->Category === 'FeeInquiry'),
                $requiredIfRequestisValidate,
                $requiredIfRequestisStore,
                'max:4',
            ],
            'destinationAmount' => [
                Rule::requiredif($request->transactionType === 'WMF' && $request->Category === 'FeeInquiry'),
                $requiredIfRequestisValidate,
                $requiredIfRequestisStore,
            ],
            'templateId' => [$requiredIfRequestisValidate, 'max:84'],
            'version' => [$requiredIfRequestisValidate],
            'idType' => [$requiredIfRequestisValidate, 'max:1'],
            'idCountryIssued' => [$requiredIfRequestisValidate, 'max:44'],
            'idNum' => [$requiredIfRequestisValidate, 'max:30'],
            'birthDate' => [$requiredIfRequestisValidate, 'max:10'],
            'occupation' => [$requiredIfRequestisValidate, 'max:30'],
            'transactionReason' => [
                Rule::requiredif($request->Category === 'Validate' && $request->amount >= '500000'),
                'max:50'
            ],
            'gender' => [$requiredIfRequestisValidate, 'max:1'],
            'fundSource' => [$requiredIfRequestisValidate],
            'countryofBirth' => [$requiredIfRequestisValidate, 'max:44'],
            'ackFlag' => [$requiredIfRequestisValidate, 'max:1'],
            'relationshiptoReceiver' => [
                Rule::requiredif($request->Category === 'Validate' && $request->amount >= '500000'),
                'max:20'
            ],
            'complianceDataBuffer' => [$requiredIfRequestisStore, 'max:1024'],
            'phoneCountryCode' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:30'],
            'phoneNum' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:31'],
            'receiverFirstName' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:80'],
            'receiverLastName' => [$requiredIfRequestisValidate, $requiredIfRequestisStore, 'max:80'],
            'new_mtcn' => [$requiredIfRequestisStore],
        ];

        $messages = [
            'max' => 'The :attribute field should not exceed :max characters.',
            'required' => 'The :attribute field is required.',
        ];

        return Validator::make($request->all(), $validateRules, $messages);
    }
}
