<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\HeartbeatRepository;
use Illuminate\Validation\Rule;

class HeartbeatController extends Controller
{
    
    protected $ProcessRepo;
    public function __construct(HeartbeatRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function heartbeatProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $res = $this->repo->heartbeatRequest($client_id);

        return $res;

    }
}