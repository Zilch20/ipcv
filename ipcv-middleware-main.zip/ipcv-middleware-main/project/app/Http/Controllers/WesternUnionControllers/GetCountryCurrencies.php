<?php

declare(strict_types=1);

namespace App\Http\Controllers\WesternUnionControllers;

use App\CountryCurrency;
use App\Http\Controllers\Controller;
use App\Http\Resources\CountryCurrencyCollection;
use Illuminate\Http\Request;

class GetCountryCurrencies extends Controller
{
    public function __invoke(Request $request): CountryCurrencyCollection
    {
        return new CountryCurrencyCollection(CountryCurrency::all());
    }
}
