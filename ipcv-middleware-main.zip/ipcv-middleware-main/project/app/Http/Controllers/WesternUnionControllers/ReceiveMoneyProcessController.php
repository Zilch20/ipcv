<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\BranchManagementTable;
use App\Helpers\JSONSOAPConvert;
use App\Helpers\SpecialCharacters;
use App\Http\Controllers\Controller;
use App\ReceiveMoneyPayLog;
use App\ReceiveMoneySearchLog;
use App\Repositories\WesternUnionRepositories\RecieveMoneyProcessRepository;
use App\Traits\SubAgentTraits;
use Illuminate\Contracts\Validation\Validator as ValidatorContract;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\In;

class ReceiveMoneyProcessController extends Controller
{
    use SubAgentTraits;

    protected $ProcessRepo;
    public function __construct(RecieveMoneyProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function ReceiveMoneyProcess(Request $request)
    {
        $client_id = $request->user();
        $client_id = $client_id['id'];

        $category = $request->Category;
        $validator = $this->createValidator($request);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();

            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'MW API VALIDATION';
            $logs['request_data'] = \json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if($category === "Search"){
                ReceiveMoneySearchLog::create($logs);
            }

            if ($category === 'Pay') {
                ReceiveMoneyPayLog::create($logs);
            }

            return $soapResponse;
        }

        if(empty($request['mobileFlag']))
        {
            //get Branch Location
            if(!empty($request['agentEmail']) && empty($request['branchLocation']))
            {
                $branchLocation = $this->getBranchLocation($request);

                $request['branchLocation'] = $branchLocation;
            }
            // End Get Branch Location

            //Check Branch Location
            $checkBranch = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
                                                ->get()
                                                ->count();

            if($checkBranch == 0)
            {
                $soapResponse = JSONSOAPConvert::toSoap('BRANCH IS NOT REGISTERED');

                $logs['client_id'] = $client_id;
                $logs['xml_request'] = 'BRANCH SUSPENDED';
                $logs['request_data'] = json_encode($request->all());
                $logs['reply_data'] = $soapResponse;

                if($category === "Search"){
                    ReceiveMoneySearchLog::create($logs);
                } elseif ($category === 'Pay') {
                    ReceiveMoneyPayLog::create($logs);
                }

                return $soapResponse;
            }
            //End Check Branch Location


            //Check Branch Suspension
            $checkSuspension = $this->checkSuspended($request);
            if($checkSuspension === true)
            {
                $errorMessage = 'BRANCH SUSPENDED';
                $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

                $logs['client_id'] = $client_id;
                $logs['xml_request'] = 'BRANCH SUSPENDED';
                $logs['request_data'] = json_encode($request->all());
                $logs['reply_data'] = $soapResponse;

                if($category === "Search"){
                    ReceiveMoneySearchLog::create($logs);
                } elseif ($category === 'Pay') {
                    ReceiveMoneyPayLog::create($logs);
                }

                return $soapResponse;
            }
            //End Check Branch Suspension
        }

        // Check for Special Characters Start
        $check = SpecialCharacters::checkCharacter($request->all());
        if($check === true)
        {
            $errorMessage = "Request must not contain accented letters";
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'SPECIAL CHAR ERROR';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if($category === "Search"){
                ReceiveMoneySearchLog::create($logs);
            } elseif ($category === 'Pay') {
                ReceiveMoneyPayLog::create($logs);
            }

            return $soapResponse;
        }
        // Check for Special Characters End

        if($category == "Search"){
            $searchRes = $this->repo->recieveMoneySearchRequest($request->all(), $client_id);
            return $searchRes;
        }

        if($category == "Pay"){
            $payRes = $this->repo->recieveMoneyPayRequest($request->all(), $client_id);
            return $payRes;
        }
    }

    private function createValidator(Request  $request): ValidatorContract
    {
        $requiredIfCategoryIsPay = Rule::requiredIf($request->Category === 'Pay');

        $validateRules = [
            'Category' => 'Required',
            'channelType' => ['required', 'max:3'],
            'channelVersion' => ['required', 'max:20'],
            'mtcn' => [Rule::requiredif($request->Category === 'Search'), $requiredIfCategoryIsPay, 'max:16'],
            'firstName' => [$requiredIfCategoryIsPay, 'max:80'],
            'lastName' => [$requiredIfCategoryIsPay, 'max:80'],
            'address1' => [$requiredIfCategoryIsPay, 'max:40'],
            'city' => [$requiredIfCategoryIsPay, 'max:30'],
            'province' => [$requiredIfCategoryIsPay, 'max:30'],
            'postalCode' => [$requiredIfCategoryIsPay, 'max:30'],
            'receiverCountryCode' => [$requiredIfCategoryIsPay, 'max:3'],
            'receiverCountryCurrencyCode' => [$requiredIfCategoryIsPay, $this->allowUsDollarForBocBranchesOnly($request), 'max:3'],
            'idType' => [$requiredIfCategoryIsPay, 'max:1'],
            'idCountryIssued' => [$requiredIfCategoryIsPay, 'max:44'],
            'idNum' => [$requiredIfCategoryIsPay, 'max:30'],
            'birthDate' => [$requiredIfCategoryIsPay, 'max:10'],
            'countryofBirth' => [$requiredIfCategoryIsPay, 'max:44'],
            'gender' => [$requiredIfCategoryIsPay, 'max:1'],
            'occupation' => [$requiredIfCategoryIsPay, 'max:30'],
            'phoneCountryCode' => [$requiredIfCategoryIsPay, 'max:3'],
            'phoneNum' => [$requiredIfCategoryIsPay, 'max:14'],
            'fundSource' => [$requiredIfCategoryIsPay],
            'new_mtcn' => [$requiredIfCategoryIsPay, 'max:16'],
            'multiErrorSupported' => [$requiredIfCategoryIsPay, 'max:1'],
            'templateId' => [$requiredIfCategoryIsPay, 'max:84'],
            'version' => $requiredIfCategoryIsPay,
            'ackFlag' => [$requiredIfCategoryIsPay, 'max:1'],
        ];

        $messages = [
            'max' => 'The :attribute field should not exceed :max characters.',
            'required' => 'The :attribute field is required.',
        ];

        return Validator::make($request->all(), $validateRules, $messages);
    }

    private function allowUsDollarForBocBranchesOnly(Request $request): In
    {
        return $this->checkIfBranchLocationIsBoc($request->input('branchLocation', '')) ? Rule::in(['PHP', 'USD']) : Rule::in(['PHP']);
    }

    private function checkIfBranchLocationIsBoc(string $branchLocation): bool
    {
        return (bool)\preg_match('/(?i)(^[BOC])\w+|(bank of commerce)/', $branchLocation);
    }
}
