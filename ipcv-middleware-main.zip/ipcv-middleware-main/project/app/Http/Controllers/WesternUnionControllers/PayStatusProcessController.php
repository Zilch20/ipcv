<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\DasRequestLog;
use App\FeeInquiryLogs;
use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use App\PayStatusInquiryLog;
use App\Repositories\WesternUnionRepositories\PayStatusProcessRepository;
use App\SendMoneyStoreLogs;
use App\SendMoneyValidateLogs;
use App\Traits\SubAgentTraits;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class PayStatusProcessController extends Controller
{
    use SubAgentTraits;

    protected $ProcessRepo;

    public function __construct(PayStatusProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function payStatusProcess(Request $request)
    {
        $clientId = $request->user()->id;

        $validator = $this->createValidator($request);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();
            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $clientId;
            $logs['xml_request'] = 'MW API VALIDATION';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;
            PayStatusInquiryLog::create($logs);

            return $soapResponse;
        }

        if ($request['mobileFlag']) {
            return $this->repo->payStatusRequest($request->all(), $clientId);
        }

        if ($request['agentEmail']) {
            try {
                $branchLocation = $this->getBranchLocation($request);
            } catch (ModelNotFoundException $e) {
                $soapResponse = JSONSOAPConvert::toSoap($errorMessage = 'BRANCH NOT FOUND');
                $this->generateLogs($request, $soapResponse, $errorMessage);

                return $soapResponse;
            }

            $request['branchLocation'] = $branchLocation;
        }

        try {
            $isSuspended = $this->checkSuspended($request);
        } catch (ModelNotFoundException $e) {
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage = 'BRANCH NOT FOUND');
            $this->generateLogs($request, $soapResponse, $errorMessage);

            return $soapResponse;
        }

        if ($isSuspended) {
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage = 'BRANCH SUSPENDED');
            $this->generateLogs($request, $soapResponse, $errorMessage);

            return $soapResponse;
        }

        return $this->repo->payStatusRequest($request->all(), $clientId);
    }

    private function createValidator(Request $request): \Illuminate\Validation\Validator
    {
        return Validator::make(
            $request->all(),
            [
                'recordingCountryCode' => 'required|max:3',
                'recordingCountryCurrencyCode' => 'required|max:3',
                'mtcn' => 'required|max:20',
            ],
            [
                'Required' => 'Invalid Input: Empty Field',
                'max' => 'Invalid Input: Exceeded maximum number of characters'
            ]
        );
    }

    private function generateLogs(Request $request , string $response, string $errorMessage): void
    {
        $logs['client_id'] = $request->user()->id;
        $logs['xml_request'] = $errorMessage;
        $logs['request_data'] = \json_encode($request->all());
        $logs['reply_data'] = $response;

        switch ($request['Category']) {
            case 'FeeInquiry':
                FeeInquiryLogs::create($logs);
                break;
            case 'Validate':
                SendMoneyValidateLogs::create($logs);
                break;
            case 'Store':
                SendMoneyStoreLogs::create($logs);
                break;
            case 'Das':
                DasRequestLog::create($logs);
                break;
        }
    }
}
