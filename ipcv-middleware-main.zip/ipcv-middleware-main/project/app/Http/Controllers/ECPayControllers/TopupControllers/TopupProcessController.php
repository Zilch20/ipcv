<?php

namespace App\Http\Controllers\ECPayControllers\TopupControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\ECPayRepositories\TopupRepository;
use Illuminate\Validation\Rule;

class TopupProcessController extends Controller
{
    protected $topupRepo;
    public function __construct(TransactRepository $topupRepo)
    {
        $this->repo = $topupRepo;
    }
    public function topupProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',
            'PartnerID' => Rule::requiredif($request->Category == 'Payment'),
            'phoneNum' => Rule::requiredif($request->Category == 'Payment'),
            'planCode' => Rule::requiredif($request->Category == 'Payment'),
            'Amount' => Rule::requiredif($request->Category == 'Payment')."|numeric",
            'token' => Rule::requiredif($request->Category == 'Payment')."|max:15",
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;
        $subCategory = $request->Subcategory;
        $partnerID = $request->PartnerID;

        if($category == 'Payment'){
            //Smart
            if($partnerID == '1'){
                $res = $this->repo->topupTransact($request->all(), $partnerID);
                return response($res, 200);
            }
            //Globe
            if($partnerID == '2'){
                $res = $this->repo->topupTransact($request->all(), $partnerID);
                return response($res, 200);
            }
            //Sun Cellular
            if($partnerID == '3'){
                $res = $this->repo->topupTransact($request->all(), $partnerID);
                return response($res, 200);
            }
        }
        if($category == 'List'){
            $res = $this->repo->billerList();
            return response($res, 200);
        }
        if($category == 'Balance'){
            $res = $this->repo->checkBalance();
            return response($res, 200);
        }
        return response()->json(["ERROR"=>"INVALID REQUEST"], 400);
    }
}