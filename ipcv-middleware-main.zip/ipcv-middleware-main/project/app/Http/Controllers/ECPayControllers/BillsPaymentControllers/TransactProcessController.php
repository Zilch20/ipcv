<?php

namespace App\Http\Controllers\ECPayControllers\BillsPaymentControllers;

use App\Repositories\ECPayRepositories\TransactRepository;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Validation\Rule;

class TransactProcessController extends Controller
{
    protected $transactRepo;
    public function __construct(TransactRepository $transactRepo)
    {
        $this->repo = $transactRepo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',
            'Subcategory' => Rule::requiredif($request->Category == 'Payment'),
            'PartnerID' => Rule::requiredif($request->Category == 'Payment'),
            'accountNum' => Rule::requiredif($request->Category == 'Payment'),
            'parameterOne' => Rule::requiredif($request->Category == 'Payment'),
            'Amount' => Rule::requiredif($request->Category == 'Payment')."|numeric",
            'ReferenceNo' => Rule::requiredif($request->Category == 'Payment')."|max:15",
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;
        $subCategory = $request->Subcategory;
        $partnerID = $request->PartnerID;

        if($category == 'Payment'){
            if($subCategory == 'Telecommunications'){
                //Smart
                if($partnerID == '1'){
                    $res = $this->repo->telecommunicationsTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Globe
                if($partnerID == '2'){
                    $res = $this->repo->telecommunicationsTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Sun Cellular
                if($partnerID == '3'){
                    $res = $this->repo->telecommunicationsTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
            }
            if($subCategory == 'Water Utilities'){
                //Maynilad
                if($partnerID == '1'){
                    $res = $this->repo->waterUtilitiesTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Manila Waters
                if($partnerID == '2'){
                    $res = $this->repo->waterUtilitiesTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
            }
            if($subCategory == "Cable and Internet"){
                //Cignal
                if($partnerID == '1'){
                    $res = $this->repo->cableTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Sky Cable
                if($partnerID == '2'){
                    $res = $this->repo->cableTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Cable Link
                if($partnerID == '3'){
                    $res = $this->repo->cableTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
            }
            if($subCategory == 'Credit Card'){
                //Asia United Bank
                if($partnerID == '1'){
                    $res = $this->repo->creditCardTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //BPI
                if($partnerID == '2'){
                    $res = $this->repo->creditCardTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
            }
            if($subCategory == 'Insurance'){
                //Axa
                if($partnerID == '1'){
                    $res = $this->repo->InsuranceTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
                //Cocolife
                if($partnerID == '2'){
                    $res = $this->repo->InsuranceTransact($request->all(), $partnerID);
                    return response($res, 200);
                }
            }
        }
        if($category == 'List'){
            $res = $this->repo->billerList();
            return response($res, 200);
        }
        if($category == 'Balance'){
            $res = $this->repo->checkBalance();
            return response($res, 200);
        }
        return response()->json(["ERROR"=>"INVALID REQUEST"], 400);
    }
}