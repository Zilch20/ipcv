<?php

namespace App\Http\Controllers\CebuanaControllers\ClientControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\CebuanaRepositories\ClientRepository;
use Illuminate\Validation\Rule;

class ClientController extends Controller
{
    protected $clientRepo;
    public function __construct(ClientRepository $clientRepo)
    {
        $this->repo = $clientRepo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',

            'firstName' => Rule::requiredif($request->Category == 'Find'),
            'lastName' => Rule::requiredif($request->Category == 'Find'),
            'BrithDate' => Rule::requiredif($request->Category == 'Find'),

            'firstName' => Rule::requiredif($request->Category == 'Add' || $request->Category == 'Update'),
            'lastName' => Rule::requiredif($request->Category == 'Add' || $request->Category == 'Update'),
            'BrithDate' => Rule::requiredif($request->Category == 'Add' || $request->Category == 'Update'),
            'phoneNum' => Rule::requiredif($request->Category == 'Add' || $request->Category == 'Update'),
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->category;

        if ($category == "Find"){
            $this->repo->FindClient($request->all);
        }
        if ($category == "Add"){
            $this->repo->AddClient($request->all);
        }
        if ($category == "Update"){
            $this->repo->UpdateClient($request->all);
        }
    }

}