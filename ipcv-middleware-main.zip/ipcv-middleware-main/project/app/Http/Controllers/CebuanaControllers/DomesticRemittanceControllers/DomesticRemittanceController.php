<?php

namespace App\Http\Controllers\CebuanaControllers\DomesticRemittanceControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\CebuanaRepositories\DomesticRemittanceRepository;
use Illuminate\Validation\Rule;

class DomesticRemittanceController extends Controller
{
    protected $remittanceRepo;
    public function __construct(DomesticRemittanceRepository $remittanceRepo)
    {
        $this->repo = $remittanceRepo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',

            'beneficiaryID' => Rule::requiredif($request->Category == 'Send'),
            'currencyID' => Rule::requiredif($request->Category == 'Send'),
            'amount' => Rule::requiredif($request->Category == 'Send'),
            'serviceFee' => Rule::requiredif($request->Category == 'Send'),
            'partnerCode' => Rule::requiredif($request->Category == 'Send'),
            'pin' => Rule::requiredif($request->Category == 'Send'),

            'controlNumber' => Rule::requiredif($request->Category == 'Amend'),
            'newbeneficiaryID' => Rule::requiredif($request->Category == 'Amend'),
            'partnerCode' => Rule::requiredif($request->Category == 'Amend'),
            'fee' => Rule::requiredif($request->Category == 'Amend'),

            'controlNumber' => Rule::requiredif($request->Category == 'Payout'),
            'idNumber' => Rule::requiredif($request->Category == 'Payout'),
            'partnerCode' => Rule::requiredif($request->Category == 'Payout'),

            'controlNumber' => Rule::requiredif($request->Category == 'Cancel' || $request->Category == 'Refund' || $request->Category == 'Find'),
            'partnerCode' => Rule::requiredif($request->Category == 'Cancel' || $request->Category == 'Refund' || $request->Category == 'Find'),
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;

        if ($category == "Send"){
            $this->repo->SendDomesticRemittance($request->all);
        }
        if ($category == "Amend"){
            $this->repo->AmendDomesticRemittance($request->all);
        }
        if ($category == "Payout"){
            $this->repo->PayoutDomesticRemittance($request->all);
        }
        if ($category == "Cancel"){
            $this->repo->CancelDomesticRemittance($request->all);
        }
        if ($category == "Refund"){
            $this->repo->RefundDomesticRemittance($request->all);
        }
        if ($category == "Find"){
            $this->repo->FindDomesticRemittance($request->all);
        }

    }

}