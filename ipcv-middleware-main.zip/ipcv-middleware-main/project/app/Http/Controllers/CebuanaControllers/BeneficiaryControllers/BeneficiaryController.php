<?php

namespace App\Http\Controllers\CebuanaControllers\BeneficiaryControllers;

use App\Http\Controllers\Controller;
use App\Repositories\CebuanaRepositories\BeneficiaryRepository;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class BeneficiaryController extends Controller
{
    protected $repo;
    public function __construct(BeneficiaryRepository $repo)
    {
        $this->repo = $repo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',

            'Subcategory' => Rule::requiredif($request->Category == 'Payment'),
            'PartnerID' => Rule::requiredif($request->Category == 'Payment'),
            'accountNum' => Rule::requiredif($request->Category == 'Payment'),
            'parameterOne' => Rule::requiredif($request->Category == 'Payment'),
            'Amount' => Rule::requiredif($request->Category == 'Payment')."|numeric",
            'ReferenceNo' => Rule::requiredif($request->Category == 'Payment')."|max:15",
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);
    }

}
