<?php

declare(strict_types=1);

namespace App\Http\Requests\WesternUnion;

use App\Http\Requests\FormRequest;
use Illuminate\Validation\Rule;

class GetCountryInfoRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return string[]
     */
    public function rules(): array
    {
        return [
            'iso_country_cd' => ['required', Rule::exists('country_currencies', 'iso_country_cd')],
            'currency_cd' => ['required', Rule::exists('country_currencies', 'currency_cd')]
        ];
    }
}
