<?php

declare(strict_types=1);

namespace App\Http\Requests\WesternUnion;

use App\Http\Requests\FormRequest;
use Illuminate\Validation\Rule;

class IDImageRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, string[]>
     */
    public function rules(): array
    {
        return [
            'mtcn' => ['alpha_num'],
            'type' => [Rule::in(['send', 'receive'])],
        ];
    }

    public function messages(): array
    {
        return [
            'mtcn.alpha_num' => 'MTCN only allows alpha numeric characters.',
            'type.in' => 'Type should only be send or receive.',
        ];
    }
}
