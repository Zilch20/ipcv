<?php

declare(strict_types=1);

namespace App\Http\Requests;

class AwsS3Request extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return array<string, string[]>
     */
    public function rules(): array
    {
        return [
            'image' => ['required', 'mimes:jpg,jpeg,png', 'max:10240'],
            'file_name' => ['string', 'max:50', 'alpha_dash']
        ];
    }

    public function messages(): array
    {
        return [
            'image.mimes' => 'Image should only be jpeg or png.',
        ];
    }
}
