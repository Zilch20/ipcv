<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;
use Laravel\Lumen\Auth\Authorizable;
use Laravel\Passport\HasApiTokens;

class SendMoneyStoreLogs extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;

    protected $table = 'send_money_store_logs';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'branchOwner',
        'transactionStatus',
        'agentEmail',
        'xml_request',
        'client_id',
        'mtcn',
        'senderName',
        'address',
        'city',
        'province',
        'postalCode',
        'idNum',
        'issueDate',
        'expiration',
        'birthDate',
        'occupation',
        'transactionReason',
        'gender',
        'fundSource',
        'relationshiptoReceiver',
        'positionLevel',
        'phoneNum',
        'accountNumber',
        'receiverName',
        'currencyCode',
        'destinationCountry',
        'destinationCurrencyCode',
        'amount',
        'new_mtcn',
        'request_data',
        'reply_data',
        'countryName',
        'senderCountryCode',
        'senderCountryCurrencyCode',
        'idCountryIssued',
        'countryofBirth',
        'transactionType',
        'paymentType',
        'destinationAmount',
        'grossTotalAmount',
        'plusChargesAmount',
        'charges',
        'myWuNumber',
        'agentName',
        'ftid',
        'branchLocation'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
