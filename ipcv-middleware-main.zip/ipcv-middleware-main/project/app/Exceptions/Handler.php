<?php

declare(strict_types=1);

namespace App\Exceptions;

use Exception;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\AuthenticationException;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\JsonResponse;
use Illuminate\Validation\ValidationException;
use Laravel\Lumen\Exceptions\Handler as ExceptionHandler;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that should not be reported.
     *
     * @var array
     */
    protected $dontReport = [
        AuthorizationException::class,
        HttpException::class,
        ModelNotFoundException::class,
        ValidationException::class,
    ];

    public function render($request, \Throwable $e): Response
    {
        return match ($e::class) {
            ValidationException::class => new JsonResponse(['errors' => $e->errors()], Response::HTTP_UNPROCESSABLE_ENTITY),
            NotFoundHttpException::class => new Response(null, Response::HTTP_NOT_FOUND),
            AuthenticationException::class => new JsonResponse(['error' => $e->getMessage()], Response::HTTP_UNAUTHORIZED),
            default => parent::render($request, $e)
        };
    }

    /**
     * Report or log an exception.
     *
     * This is a great spot to send exceptions to Sentry, Bugsnag, etc.
     *
     * @throws Exception
     */
    public function report(\Throwable $e): void
    {
        parent::report($e);
    }
}
