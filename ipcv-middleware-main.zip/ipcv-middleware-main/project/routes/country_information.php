<?php

declare(strict_types=1);

use App\Http\Controllers\WesternUnionControllers\GetCountryCurrencies;
use App\Http\Controllers\WesternUnionControllers\GetCountryInfo;
use Laravel\Lumen\Routing\Router;

/** @var Router $router */

$router->group(['middleware' => 'client'], static function (Router $router) {
    $router->get('country-currencies', GetCountryCurrencies::class);
    $router->post('country-information', GetCountryInfo::class);
});
