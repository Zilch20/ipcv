<?php

namespace spec\IPCV\Remitly\TransferV1\Request;

use IPCV\Remitly\Request;
use IPCV\Remitly\TransferV1\Request\GetTransferRequest;
use spec\IPCV\Remitly\BaseObjectBehavior;

/**
 * @mixin GetTransferRequest
 */
class GetTransferRequestSpec extends BaseObjectBehavior
{
    function let()
    {
        $this->beConstructedWith($expected = $this->faker()->uuid());

        $this->referenceNumber->shouldBe($expected);
    }

    function it_should_be_a_request()
    {
        $this->shouldHaveType(Request::class);
    }

    function it_should_return_its_json_serializable_form()
    {
        $this->jsonSerialize()->shouldBe([]);
    }
}
