<?php

namespace spec\IPCV\Remitly\TransferV1\Request;

use IPCV\Remitly\TransferV1\Request\Action;
use IPCV\Remitly\TransferV1\Request\ErrorCode;
use IPCV\Remitly\TransferV1\Request\NotifyTransferRequest;
use IPCV\Remitly\TransferV1\Request\UpdateTransferRequest;
use spec\IPCV\Remitly\BaseObjectBehavior;

/**
 * @mixin NotifyTransferRequest
 */
class NotifyTransferRequestSpec extends BaseObjectBehavior
{
    function it_should_be_a_update_transfer_request()
    {
        $this->shouldImplement(UpdateTransferRequest::class);
    }

    function it_should_set_reference_number()
    {
        $this->setReferenceNumber($expected = $this->faker()->uuid());

        $this->referenceNumber->shouldBe($expected);
        $this->referenceNumber()->shouldBe($expected);
    }

    function it_should_set_employee()
    {
        $this->setEmployee($expected = $this->faker()->name());

        $this->employee->shouldBe($expected);
    }

    function it_should_set_host_name()
    {
        $this->setHostName($expected = $this->faker()->company());

        $this->hostName->shouldBe($expected);
    }

    function it_should_set_remarks()
    {
        $this->setRemarks($expected = $this->faker()->sentence(10));

        $this->remarks->shouldBe($expected);
    }

    function it_should_set_error_code()
    {
        $errorCodeAsString = $this->faker()->randomElement(ErrorCode::values());

        $this->setErrorCode($expected = ErrorCode::fromString($errorCodeAsString));

        $this->errorCode->shouldBe($expected);
    }

    function it_should_return_its_json_serializable_form()
    {
        $errorCodeAsString = $this->faker()->randomElement(ErrorCode::values());

        $this
            ->setReferenceNumber($this->faker()->uuid())
            ->setEmployee($this->faker()->name())
            ->setHostName($this->faker()->company())
            ->setRemarks($this->faker()->sentence(10))
            ->setErrorCode(ErrorCode::fromString($errorCodeAsString))
        ;

        $this
            ->jsonSerialize()
            ->shouldBe([
                'action' => Action::NOTIFY,
                'employee' => $this->employee,
                'hostname' => $this->hostName,
                'remarks' => $this->remarks,
                'error_code' => $this->errorCode,
            ]);
    }
}
