<?php

namespace spec\IPCV\Remitly\TransferV1\Request;

use IPCV\Remitly\Request;
use IPCV\Remitly\TransferV1\Exception\InvalidLimitException;
use IPCV\Remitly\TransferV1\Exception\InvalidPageException;
use IPCV\Remitly\TransferV1\Request\ListTransfersRequest;
use IPCV\Remitly\TransferV1\State;
use IPCV\Remitly\TransferV1\Type;
use spec\IPCV\Remitly\BaseObjectBehavior;

/**
 * @mixin ListTransfersRequest
 */
class ListTransfersRequestSpec extends BaseObjectBehavior
{
    function it_should_be_a_request()
    {
        $this->shouldHaveType(Request::class);
    }

    function it_should_set_page()
    {
        $this->setPage($expected = 2);

        $this->page->shouldBe($expected);
    }

    function it_should_throw_invalid_page_exception_when_passed_with_page_less_than_one()
    {
        $this->shouldThrow(InvalidPageException::class)->during('setPage', [-1]);
    }

    function it_should_set_limit()
    {
        $this->setLimit($expected = 250);

        $this->limit->shouldBe($expected);
    }

    function it_should_throw_invalid_limit_exception_when_passed_with_limit_less_than_one()
    {
        $this->shouldThrow(InvalidLimitException::class)->during('setLimit', [-1]);
    }

    function it_should_throw_invalid_limit_exception_when_passed_with_limit_greater_than_500()
    {
        $this->shouldThrow(InvalidLimitException::class)->during('setLimit', [501]);
    }

    function it_should_set_state()
    {
        $stateAsString = $this->faker()->randomElement(State::values());

        $this->setState($expected = State::fromString($stateAsString));

        $this->state->shouldBe($expected);
    }

    function it_should_set_type()
    {
        $typeAsString = $this->faker()->randomElement(Type::values());

        $this->setType($expected = Type::fromString($typeAsString));

        $this->type->shouldBe($expected);
    }

    function it_should_add_payer_code()
    {
        $this
            ->addPayerCode('foo')
            ->addPayerCode('bar')
            ->addPayerCode('baz')
        ;

        $this->payerCode()->shouldBe(['foo', 'bar', 'baz']);
    }

    function it_should_return_its_array_form()
    {
        $stateAsString = $this->faker()->randomElement(State::values());
        $typeAsString = $this->faker()->randomElement(Type::values());

        $this
            ->setPage($page = 25)
            ->setLimit($limit = 250)
            ->setState($state = State::fromString($stateAsString))
            ->setType($type = Type::fromString($typeAsString))
            ->addPayerCode($payerCode1 = 'foo')
            ->addPayerCode($payerCode2 = 'bar')
            ->addPayerCode($payerCode3 = 'baz')
        ;

        $this
            ->toArray()
            ->shouldBe([
                'page' => $page,
                'limit' => $limit,
                'state' => $state,
                'type' => $type,
                'payer_code' => [$payerCode1, $payerCode2, $payerCode3]
            ])
        ;
    }
}
