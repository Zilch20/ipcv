<?php


namespace spec\IPCV\Remitly\TransferV1\Request;

use IPCV\Remitly\TransferV1\Identification;
use IPCV\Remitly\TransferV1\IdentificationType;
use IPCV\Remitly\TransferV1\Request\Action;
use IPCV\Remitly\TransferV1\Request\CompleteTransferRequest;
use IPCV\Remitly\TransferV1\Request\UpdateTransferRequest;
use spec\IPCV\Remitly\BaseObjectBehavior;

/**
 * @mixin CompleteTransferRequest
 */
class CompleteTransferRequestSpec extends BaseObjectBehavior
{
    function it_should_be_a_update_transfer_request()
    {
        $this->shouldImplement(UpdateTransferRequest::class);
    }

    function it_should_set_reference_number()
    {
        $this->setReferenceNumber($expected = $this->faker()->uuid());

        $this->referenceNumber->shouldBe($expected);
        $this->referenceNumber()->shouldBe($expected);
    }

    function it_should_set_employee()
    {
        $this->setEmployee($expected = $this->faker()->name());

        $this->employee->shouldBe($expected);
    }

    function it_should_set_host_name()
    {
        $this->setHostName($expected = $this->faker()->company());

        $this->hostName->shouldBe($expected);
    }

    function it_should_set_remarks()
    {
        $this->setRemarks($expected = $this->faker()->sentence(10));

        $this->remarks->shouldBe($expected);
    }

    function it_should_set_identification()
    {
        $expected = new Identification(IdentificationType::PASSPORT, $this->faker()->uuid());
        $this->setIdentification($expected);

        $this->identification->shouldBe($expected);
    }

    function it_should_set_branch()
    {
        $this->setBranch($expected = $this->faker()->company());

        $this->branch->shouldBe($expected);
    }

    function it_should_set_payer_code()
    {
        $this->setPayerCode($expected = $this->faker()->uuid());

        $this->payerCode->shouldBe($expected);
    }

    function it_should_set_completed_on()
    {
        $this->setCompletedOn($expected = new \DateTimeImmutable());

        $this->completedOn->shouldBe($expected);
    }

    function it_should_return_its_json_serializable_form()
    {
        $this
            ->setReferenceNumber($this->faker()->uuid())
            ->setEmployee($this->faker()->name())
            ->setHostName($this->faker()->company())
            ->setRemarks($this->faker()->sentence(10))
            ->setIdentification(new Identification(IdentificationType::PASSPORT, $this->faker()->uuid()))
            ->setBranch($this->faker()->company())
            ->setPayerCode($this->faker()->uuid())
            ->setCompletedOn(new \DateTimeImmutable())
        ;

        $this
            ->jsonSerialize()
            ->shouldBe([
                'action' => Action::COMPLETE,
                'employee' => $this->employee,
                'hostname' => $this->hostName,
                'remarks' => $this->remarks,
                'identification' => $this->identification->jsonSerialize(),
                'branch' => $this->branch,
                'payer_code' => $this->payerCode,
                'completed_on' => $this->completedOn->format(DATE_ATOM),
            ])
        ;
    }
}
