<?php

namespace spec\IPCV\Remitly\TransferV1;

use IPCV\Remitly\TransferV1\Identification;
use IPCV\Remitly\TransferV1\IdentificationType;
use spec\IPCV\Remitly\BaseObjectBehavior;

/**
 * @mixin Identification
 */
class IdentificationSpec extends BaseObjectBehavior
{
    private IdentificationType $idType;
    private string $idNumber;

    function let()
    {
        $idTypeAsString = $this->faker()->randomElement(IdentificationType::values());

        $this->beConstructedWith(
            $this->idType = IdentificationType::fromString($idTypeAsString),
            $this->idNumber = $this->faker()->uuid()
        );
    }

    function it_should_return_its_identification_type()
    {
        $this->type->shouldBe($this->idType);
    }

    function it_should_return_its_number()
    {
        $this->number->shouldBe($this->idNumber);
    }

    function it_should_return_its_json_serializable_form()
    {
        $this
            ->jsonSerialize()
            ->shouldBe([
                'type' => $this->idType,
                'number' => $this->idNumber,
            ])
        ;
    }
}
