<?php

namespace spec\IPCV\Remitly;

use Faker\Factory;
use Faker\Generator;
use PhpSpec\ObjectBehavior;

class BaseObjectBehavior extends ObjectBehavior
{
    private ?Generator $faker = null;

    protected function faker(): Generator
    {
        if ($this->faker === null) {
            $this->faker = Factory::create();
        }

        return $this->faker;
    }
}
