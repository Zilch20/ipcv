<?php

namespace spec\IPCV\Remitly;

use GuzzleHttp\ClientInterface;
use IPCV\Remitly\Client;
use IPCV\Remitly\TransferV1\Request\GetTransferRequest;
use IPCV\Remitly\TransferV1\Request\ListTransfersRequest;
use IPCV\Remitly\TransferV1\Request\UpdateTransferRequest;
use IPCV\Remitly\TransferV1\State;
use IPCV\Remitly\TransferV1\Type;
use Psr\Http\Message\ResponseInterface;

/**
 * @mixin Client
 */
class ClientSpec extends BaseObjectBehavior
{
    function let(ClientInterface $client)
    {
        $this->beConstructedWith($client);
    }

    function it_should_list_key_pairs(ClientInterface $client, ResponseInterface $response)
    {
        $client->request('GET', '/api/v1/key_management')->shouldBeCalledOnce()->willReturn($response);

        $this->listKeyPairs();
    }

    function it_should_create_new_key_pair(ClientInterface $client, ResponseInterface $response)
    {
        $client->request('POST', '/api/v1/key_management')->shouldBeCalledOnce()->willReturn($response);

        $this->createNewKeyPair();
    }

    function it_should_delete_key_pair(ClientInterface $client, ResponseInterface $response)
    {
        $client
            ->request('DELETE', '/api/v1/key_management/' . $accessKey = $this->faker()->uuid())
            ->shouldBeCalledOnce()
            ->willReturn($response)
        ;

        $this->deleteKeyPair($accessKey);
    }

    function it_should_get_transfer(ClientInterface $client, ResponseInterface $response)
    {
        $getTransferRequest = new GetTransferRequest($this->faker()->uuid());

        $client
            ->request('GET', '/api/v1/transfers/' . $getTransferRequest->referenceNumber)
            ->shouldBeCalledOnce()
            ->willReturn($response)
        ;

        $this->getTransfer($getTransferRequest);
    }

    function it_should_list_transfers(ClientInterface $client, ResponseInterface $response)
    {
        $listTransfersRequest = (new ListTransfersRequest())
            ->setType(Type::BANK_DEPOSIT)
            ->setState(State::PAID)
            ->setLimit(20)
            ->setPage(1)
        ;

        $client->request('GET', '/api/v1/transfers', ['query' => $listTransfersRequest->toArray()]);

        $this->listTransfers($listTransfersRequest);
    }

    function it_should_update_transfer(
        UpdateTransferRequest $request,
        ClientInterface $client,
        ResponseInterface $response
    ) {
        $request->jsonSerialize()->shouldBeCalledOnce()->willReturn($array = ['foo' => 'bar']);
        $request->referenceNumber()->shouldBeCalledOnce()->willReturn($referenceNumber = $this->faker()->uuid());

        $client
            ->request(
                'POST',
                '/api/v1/transfers/' . $referenceNumber,
                ['json' => $array]
            )
            ->shouldBeCalledOnce()
            ->willReturn($response)
        ;

        $this->updateTransfer($request);
    }
}
