<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1;

use ReflectionEnum;

enum IdentificationType: string
{
    case DRIVERS_LICENSE = 'DRIVERS_LICENSE';

    case GOVERNMENT_ISSUED_ID = 'GOVERNMENT_ISSUED_ID';

    case NATIONAL_ID_CARD = 'NATIONAL_ID_CARD';

    case PASSPORT = 'PASSPORT';

    case RESIDENCE_PERMIT = 'RESIDENCE_PERMIT';

    case WORK_PERMIT = 'WORK_PERMIT';

    case OTHER = 'OTHER';

    case CNIC = 'CNIC';

    case NICOP = 'NICOP';

    case POC = 'POC';

    case ARC = 'ARC';

    case DNI = 'DNI';

    case IMMIGRATION_CARD = 'IMMIGRATION_CARD';

    public static function fromString(string $identificationType): ?IdentificationType
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($identificationType) ? $rc->getConstant($identificationType) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(
            static fn(IdentificationType $identificationType) =>
            $identificationType->value,
            self::cases()
        );
    }
}
