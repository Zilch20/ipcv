<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1\Exception;

use Throwable;

class InvalidLimitException extends \Exception
{
    public function __construct(string $message = "", int $code = 0, ?Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);
    }
}
