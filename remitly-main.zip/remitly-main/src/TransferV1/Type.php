<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1;

use ReflectionEnum;

enum Type: string
{
    case BANK_DEPOSIT = 'BANK_DEPOSIT';

    case CASH_PICKUP = 'CASH_PICKUP';

    case CASH_PICKUP_ATM = 'CASH_PICKUP_ATM';

    case DIRECT_TO_PHONE = 'DIRECT_TO_PHONE';

    case HOME_DELIVERY = 'HOME_DELIVERY';

    public static function fromString(string $type): ?Type
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($type) ? $rc->getConstant($type) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(Type $type) => $type->value, self::cases());
    }
}
