<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1\Request;

use DateTimeImmutable;
use IPCV\Remitly\TransferV1\Identification;

final class CompleteTransferRequest implements UpdateTransferRequest
{
    public string $referenceNumber;

    public string $employee;

    public string $hostName;

    public string $remarks;

    public Identification $identification;

    public string $branch;

    public string $payerCode;

    public DateTimeImmutable $completedOn;

    public function referenceNumber(): string
    {
        return $this->referenceNumber;
    }

    public function setReferenceNumber(string $referenceNumber): self
    {
        $this->referenceNumber = $referenceNumber;

        return $this;
    }

    public function setEmployee(string $employee): self
    {
        $this->employee = $employee;

        return $this;
    }

    public function setHostName(string $hostName): self
    {
        $this->hostName = $hostName;

        return $this;
    }

    public function setRemarks(string $remarks): self
    {
        $this->remarks = $remarks;

        return $this;
    }

    public function setIdentification(Identification $identification): self
    {
        $this->identification = $identification;

        return $this;
    }

    public function setBranch(string $branch): self
    {
        $this->branch = $branch;

        return $this;
    }

    public function setPayerCode(string $payerCode): self
    {
        $this->payerCode = $payerCode;

        return $this;
    }

    public function setCompletedOn(DateTimeImmutable $completedOn): self
    {
        $this->completedOn = $completedOn;

        return $this;
    }

    public function jsonSerialize(): array
    {
        return [
            'action' => Action::COMPLETE,
            'employee' => $this->employee,
            'hostname' => $this->hostName,
            'remarks' => $this->remarks,
            'identification' => $this->identification->jsonSerialize(),
            'branch' => $this->branch,
            'payer_code' => $this->payerCode,
            'completed_on' => $this->completedOn->format(DATE_ATOM),
        ];
    }
}
