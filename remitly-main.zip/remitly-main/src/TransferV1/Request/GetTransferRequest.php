<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1\Request;

use IPCV\Remitly\Request;

final class GetTransferRequest implements Request
{
    public function __construct(
        public readonly string $referenceNumber,
    ) {
    }

    public function jsonSerialize(): array
    {
        return [];
    }
}
