<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1\Request;

final class RejectTransferRequest implements UpdateTransferRequest
{
    public readonly string $referenceNumber;

    public readonly string $employee;

    public readonly string $hostName;

    public readonly string $remarks;

    public readonly ErrorCode $errorCode;

    public function referenceNumber(): string
    {
        return $this->referenceNumber;
    }

    public function setReferenceNumber(string $referenceNumber): self
    {
        $this->referenceNumber = $referenceNumber;

        return $this;
    }

    public function setEmployee(string $employee): self
    {
        $this->employee = $employee;

        return $this;
    }

    public function setHostName(string $hostName): self
    {
        $this->hostName = $hostName;

        return $this;
    }

    public function setRemarks(string $remarks): self
    {
        $this->remarks = $remarks;

        return $this;
    }

    public function setErrorCode(ErrorCode $errorCode): self
    {
        $this->errorCode = $errorCode;

        return $this;
    }

    /**
     * @return array{
     *     action: Action,
     *     employee: string,
     *     hostname: string,
     *     remarks: string,
     *     error_code: ErrorCode,
     * }
     */
    public function jsonSerialize(): array
    {
        return [
            'action' => Action::REJECT,
            'employee' => $this->employee,
            'hostname' => $this->hostName,
            'remarks' => $this->remarks,
            'error_code' => $this->errorCode,
        ];
    }
}
