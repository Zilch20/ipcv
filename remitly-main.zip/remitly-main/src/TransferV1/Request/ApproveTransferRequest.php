<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1\Request;

final class ApproveTransferRequest implements UpdateTransferRequest
{
    public readonly string $referenceNumber;

    public readonly string $employee;

    public readonly string $hostName;

    public readonly string $remarks;

    public function referenceNumber(): string
    {
        return $this->referenceNumber;
    }

    public function setReferenceNumber(string $referenceNumber): self
    {
        $this->referenceNumber = $referenceNumber;

        return $this;
    }

    public function setEmployee(string $employee): self
    {
        $this->employee = $employee;

        return $this;
    }

    public function setHostName(string $hostName): self
    {
        $this->hostName = $hostName;

        return $this;
    }

    public function setRemarks(string $remarks): self
    {
        $this->remarks = $remarks;

        return $this;
    }

    /**
     * @return array{
     *     action: Action,
     *     employee: string,
     *     hostname: string,
     *     remarks: string,
     * }
     */
    public function jsonSerialize(): array
    {
        return [
            'action' => Action::APPROVE,
            'employee' => $this->employee,
            'hostname' => $this->hostName,
            'remarks' => $this->remarks,
        ];
    }
}
