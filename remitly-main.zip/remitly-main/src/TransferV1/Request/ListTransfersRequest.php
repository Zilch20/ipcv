<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1\Request;

use IPCV\Remitly\Request;
use IPCV\Remitly\TransferV1\Exception\InvalidLimitException;
use IPCV\Remitly\TransferV1\Exception\InvalidPageException;
use IPCV\Remitly\TransferV1\State;
use IPCV\Remitly\TransferV1\Type;

class ListTransfersRequest implements Request
{
    public readonly int $page;

    public readonly int $limit;

    public readonly State $state;

    public readonly Type $type;

    private array $payerCode = [];

    /**
     * @throws InvalidPageException
     */
    public function setPage(int $page): self
    {
        if ($page < 1) {
            throw new InvalidPageException("Page should not be less than 1, got $page.");
        }

        $this->page = $page;

        return $this;
    }

    /**
     * @throws InvalidLimitException
     */
    public function setLimit(int $limit): self
    {
        if ($limit < 1 || $limit > 500) {
            throw new InvalidLimitException("Limit should not be less than 1 or greater than 500, got $limit.");
        }

        $this->limit = $limit;

        return $this;
    }

    public function setState(State $state): self
    {
        $this->state = $state;

        return $this;
    }

    public function setType(Type $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function addPayerCode(string $payerCode): self
    {
        $this->payerCode[] = $payerCode;

        return $this;
    }

    /**
     * @return string[]
     */
    public function payerCode(): array
    {
        return $this->payerCode;
    }

    /**
     * @return array{
     *     page: int,
     *     limit: int,
     *     state: State,
     *     type: Type,
     *     payer_code: string[]
     * }
     */
    public function toArray(): array
    {
        return [
            'page'  => $this->page,
            'limit' => $this->limit,
            'state' => $this->state,
            'type' => $this->type,
            'payer_code' => $this->payerCode,
        ];
    }

    /**
     * @return array{
     *     page: int,
     *     limit: int,
     *     state: State,
     *     type: Type,
     *     payer_code: string[]
     * }
     */
    public function jsonSerialize(): array
    {
        return $this->toArray();
    }
}
