<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1\Request;

use ReflectionEnum;

enum Action: string
{
    case ABORT = 'abort';

    case APPROVE = 'approve';

    case COMPLETE = 'complete';

    case NOTIFY = 'notify';

    case REJECT = 'reject';

    case RELEASE = 'release';

    case REVERSE = 'reverse';

    case REVIEW = 'review';

    case START = 'start';

    public static function fromString(string $action): ?Action
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($action) ? $rc->getConstant($action) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(Action $action) => $action->value, self::cases());
    }
}
