<?php

namespace IPCV\Remitly\TransferV1\Request;

use IPCV\Remitly\Request;

interface UpdateTransferRequest extends Request
{
    public function referenceNumber(): string;
}
