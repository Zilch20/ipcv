<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1;

final class Identification implements \JsonSerializable
{
    public function __construct(
        public readonly IdentificationType $type,
        public readonly string $number,
    ) {
    }

    /**
     * @return array{
     *     type: IdentificationType,
     *     number: string,
     * }
     */
    public function jsonSerialize(): array
    {
        return [
            'type' => $this->type,
            'number' => $this->number,
        ];
    }
}
