<?php

declare(strict_types=1);

namespace IPCV\Remitly\TransferV1;

use ReflectionEnum;

enum State: string
{
    case CREATED = 'CREATED';

    case READY = 'READY';

    case ON_HOLD = 'ON_HOLD';

    case PAYABLE = 'PAYABLE';

    case PAYING = 'PAYING';

    case CANCELLING = 'CANCELLING';

    case PAID = 'PAID';

    case CANCELLED = 'CANCELLED';

    case REJECTED = 'REJECTED';

    case REVERSED = 'REVERSED';

    public static function fromString(string $state): ?State
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($state) ? $rc->getConstant($state) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(State $state) => $state->value, self::cases());
    }
}
