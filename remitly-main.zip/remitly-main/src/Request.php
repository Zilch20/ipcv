<?php

namespace IPCV\Remitly;

interface Request extends \JsonSerializable
{
}
