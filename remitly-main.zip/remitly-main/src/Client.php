<?php

declare(strict_types=1);

namespace IPCV\Remitly;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;
use IPCV\Remitly\TransferV1\Request\GetTransferRequest;
use IPCV\Remitly\TransferV1\Request\ListTransfersRequest;
use IPCV\Remitly\TransferV1\Request\UpdateTransferRequest;
use Psr\Http\Message\ResponseInterface;

final class Client
{
    public function __construct(private readonly ClientInterface $client)
    {
    }

    /**
     * @throws GuzzleException
     */
    public function listKeyPairs(): ResponseInterface
    {
        return $this->client->request(method: 'GET', uri: '/api/v1/key_management');
    }

    /**
     * @throws GuzzleException
     */
    public function createNewKeyPair(): ResponseInterface
    {
        return $this->client->request(method: 'POST', uri: '/api/v1/key_management');
    }

    /**
     * @throws GuzzleException
     */
    public function deleteKeyPair(string $accessKey): ResponseInterface
    {
        return $this->client->request(method: 'DELETE', uri: '/api/v1/key_management/' . $accessKey);
    }

    /**
     * @throws GuzzleException
     */
    public function getTransfer(GetTransferRequest $request): ResponseInterface
    {
        return $this->client->request(method: 'GET', uri: '/api/v1/transfers/' . $request->referenceNumber);
    }

    /**
     * @throws GuzzleException
     */
    public function listTransfers(ListTransfersRequest $request): ResponseInterface
    {
        return $this->client->request(
            method: 'GET',
            uri: '/api/v1/transfers',
            options: [
                'query' => $request->toArray()
            ]
        );
    }

    /**
     * @throws GuzzleException
     */
    public function updateTransfer(UpdateTransferRequest $request): ResponseInterface
    {
        return $this->client->request(
            method: 'POST',
            uri: '/api/v1/transfers/' . $request->referenceNumber(),
            options: [
                'json' => $request->jsonSerialize()
            ]
        );
    }
}
