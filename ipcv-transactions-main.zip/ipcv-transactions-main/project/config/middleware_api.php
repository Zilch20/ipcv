<?php

return [
    'url' => env('MIDDLEWARE_API_BASE_URL', 'http://13.215.87.97/api/'),
    'access_token' => env('MIDDLEWARE_API_ACCESS_TOKEN'),
];
