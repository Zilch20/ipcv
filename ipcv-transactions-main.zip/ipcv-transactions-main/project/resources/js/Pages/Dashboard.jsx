import React, {useState} from 'react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import {Head, usePage} from '@inertiajs/inertia-react';
import dayjs from "dayjs";
import ReceiveTransactionsTable from "@/Components/ReceiveTransactionsTable";
import SendTransactionsTable from "@/Components/SendTransactionsTable";
import {Inertia} from "@inertiajs/inertia";

const transformDate = (dateString) => {
    if (dateString === '') {
        return dateString;
    }

    return dayjs(dateString).format('YYYY-MM-DD')
}

export default function Dashboard(props) {
    const {errors} = usePage().props
    const [name, setName] = useState("");
    const [mtcn, setMtcn] = useState("");
    const [dateFrom, setDateFrom] = useState("");
    const [dateTo, setDateTo] = useState("");

    let params = {
        name,
        from: dateFrom,
        to: dateTo,
        mtcn,
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        let searchParams = new URLSearchParams(params)
        Inertia.get(`/?${searchParams.toString()}`, {}, {
            preserveState: true,
            preserveScroll: true,
        });
    }

    const sendNextPage = async () => {
        let searchParams = new URLSearchParams({...params, send_cursor: props.send_transactions.next_cursor})
        Inertia.get(`/?${searchParams.toString()}`, {}, {
            preserveState: true,
            preserveScroll: true,
        });
    }

    const sendPrevPage = async () => {
        let searchParams = new URLSearchParams({...params, send_cursor: props.send_transactions.prev_cursor})
        Inertia.get(`/?${searchParams.toString()}`, {}, {
            preserveState: true,
            preserveScroll: true,
        });
    }

    const receiveNextPage = async () => {
        let searchParams = new URLSearchParams({...params, recv_cursor: props.receive_transactions.next_cursor})
        Inertia.get(`/?${searchParams.toString()}`, {}, {
            preserveState: true,
            preserveScroll: true,
        });
    }

    const receivePrevPage = async () => {
        let searchParams = new URLSearchParams({...params, recv_cursor: props.receive_transactions.prev_cursor})
        Inertia.get(`/?${searchParams.toString()}`, {}, {
            preserveState: true,
            preserveScroll: true,
        });
    }

    return (
        <AuthenticatedLayout
            auth={props.auth}
            errors={props.errors}
            header={<h2 className="font-semibold text-xl text-gray-800 leading-tight">Dashboard</h2>}
        >
            <Head title="Dashboard" />
            <div className="py-8">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                        <div className="p-6 bg-white border-b border-gray-200 flex flex-col justify-center items-center">
                            <div className="p6 mb-5 uppercase font-bold text-2xl">
                                Search Transactions
                            </div>
                            <form className="w-full max-w-lg" onSubmit={handleSubmit}>
                                <div className="flex flex-wrap -mx-3 mb-6">
                                    <div className="w-full md:w-full px-3 mb-6 md:mb-0">
                                        <label
                                            className={(errors.name ? "text-red-600" : "text-gray-700") + " block uppercase tracking-wide text-xs font-bold mb-2"}
                                            htmlFor="grid-name">
                                            Name
                                        </label>
                                        <input
                                            onChange={(e) => setName(e.target.value)}
                                            className={(errors.name ? "border-red-500" : "border-gray-200") + " appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"}
                                            id="grid-name" type="text" placeholder="John"
                                        />
                                        { errors.name && <p className="mt-2 text-sm text-red-600">{errors.name}</p> }
                                    </div>
                                </div>
                                <div className="flex flex-wrap -mx-3 mb-6">
                                    <div className="w-full px-3">
                                        <label
                                            className={(errors.mtcn ? "text-red-600" : "text-gray-700") + " block uppercase tracking-wide text-xs font-bold mb-2"}
                                            htmlFor="mtcn">
                                            MTCN
                                        </label>
                                        <input
                                            onChange={(e) => setMtcn(e.target.value)}
                                            className={(errors.mtcn ? "border-red-500": "border-gray-200") + " appearance-none block w-full bg-gray-200 border border-gray-200 text-gray-700 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"}
                                            id="mtcn" type="text" placeholder="0123456789" maxLength={10}
                                        />
                                            <p className="text-gray-600 text-xs italic">Enter 10 Digit MTCN</p>
                                        { errors.mtcn && <p className="mt-2 text-sm text-red-600">{errors.mtcn}</p> }
                                    </div>
                                </div>
                                <div className="flex flex-wrap -mx-3 mb-2">
                                    <div className="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                                        <label
                                            className={(errors.from ? "text-red-600" : "text-gray-700") + " block uppercase tracking-wide text-xs font-bold mb-2"}
                                            htmlFor="grid-from">
                                            From
                                        </label>
                                        <input
                                            onChange={(e) => setDateFrom(transformDate(e.target.value))}
                                            className={(errors.from ? "border-red-600": "border-gray-200") + " appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"}
                                            id="grid-from" type="date"
                                        />
                                        { errors.from && <p className="mt-2 text-sm text-red-600">{errors.from}</p> }
                                    </div>
                                    <div className="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                                        <label
                                            className={(errors.to ? "text-red-600" : "text-gray-700") + " block uppercase tracking-wide text-xs font-bold mb-2"}
                                            htmlFor="grid-to">
                                            To
                                        </label>
                                        <input
                                            onChange={(e) => setDateTo(transformDate(e.target.value))}
                                            className={(errors.to ? "border-red-600": "border-gray-200") + " appearance-none block w-full bg-gray-200 text-gray-700 border rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"}
                                            id="grid-to" type="date"
                                        />
                                        { errors.to && <p className="mt-2 text-sm text-red-600">{errors.to}</p> }
                                    </div>
                                </div>
                                <button
                                    className="shadow bg-blue-400 hover:bg-blue-500 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded w-full"
                                    type="submit">
                                    Submit
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div className="max-w-7xl mx-auto sm:px-6 lg:p-8">
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div className="p-6 bg-white border-b border-gray-200 justify-center items-center">
                        <div className="row flex">
                            <div className="p6 mb-1 uppercase font-bold text-2xl w-full md:w-1/2 md:mb-0">
                                Send Transactions
                            </div>
                            <div className="w-full md:w-1/2 md:mb-0 row">
                                <button
                                    onClick={async () => await sendNextPage()}
                                    disabled={!props.send_transactions.next_cursor}
                                    className="shadow bg-blue-400 hover:bg-blue-500 disabled:bg-gray-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded float-right md:w-1/6 md:mb-0 ml-2">
                                    Next
                                </button>
                                <button
                                    onClick={async () => await sendPrevPage()}
                                    disabled={!props.send_transactions.prev_cursor}
                                    className="shadow bg-blue-400 hover:bg-blue-500 disabled:bg-gray-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded float-right md:w-1/6 md:mb-0">
                                    Prev
                                </button>
                            </div>
                        </div>
                        <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                                <div className="overflow-hidden">
                                    <SendTransactionsTable transactions={props.send_transactions.data} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="max-w-7xl mx-auto sm:px-6 lg:p-8">
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div className="p-6 bg-white border-b border-gray-200 justify-center items-center">
                        <div className="col flex">
                            <div className="p6 mb-1 uppercase font-bold text-2xl w-full md:w-1/2 md:mb-0 row">
                                Receive Transactions
                            </div>
                            <div className="w-full md:w-1/2 md:mb-0 row">
                                <button
                                    onClick={async () => await receiveNextPage()}
                                    disabled={!props.receive_transactions.next_cursor}
                                    className="shadow bg-blue-400 hover:bg-blue-500 disabled:bg-gray-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded float-right md:w-1/6 md:mb-0 ml-2">
                                    Next
                                </button>
                                <button
                                    onClick={async () => await receivePrevPage()}
                                    disabled={!props.receive_transactions.prev_cursor}
                                    className="shadow bg-blue-400 hover:bg-blue-500 disabled:bg-gray-400 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded float-right md:w-1/6 md:mb-0">
                                    Prev
                                </button>
                            </div>
                        </div>
                        <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
                            <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                                <div className="overflow-hidden">
                                    <ReceiveTransactionsTable transactions={props.receive_transactions.data} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
