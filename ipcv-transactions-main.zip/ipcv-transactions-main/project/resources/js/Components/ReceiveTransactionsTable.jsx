import React, {useState} from 'react';
import dayjs from "dayjs";
import ReceiveTransactionModal from "@/Components/ReceiveTransactionModal";

export default function ReceiveTransactionsTable({ transactions }){
    const [visibleModal, setVisibleModal] = useState(null);
    const showModal = (id) => setVisibleModal(id);
    const hideModal = () => setVisibleModal(null);

    return (
            <table className="min-w-full">
                <thead className="bg-white border-b bg-gray-200">
                <tr>
                    <th scope="col" className="text-md uppercase font-bold text-gray-900 px-6 py-4 text-left">
                        MTCN
                    </th>
                    <th scope="col" className="text-md uppercase font-bold text-gray-900 px-6 py-4 text-left">
                        Name
                    </th>
                    <th scope="col" className="text-md uppercase font-bold text-gray-900 px-6 py-4 text-left">
                        Amount
                    </th>
                    <th scope="col" className="text-md uppercase font-bold text-gray-900 px-6 py-4 text-left">
                        Date
                    </th>
                    <th scope="col" className="text-md uppercase font-bold text-gray-900 px-6 py-4 text-left">
                        Actions
                    </th>
                </tr>
                </thead>
                <tbody>
                {transactions && transactions.map((transaction) => {
                    return (
                        <tr key={transaction.id} className="bg-white border-b transition duration-300 ease-in-out hover:bg-gray-100">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{transaction.mtcn}</td>
                            <td className="text-md text-gray-900 font-light px-6 py-2 whitespace-nowrap">
                                {transaction.receiverName}
                            </td>
                            <td className="text-md text-gray-900 font-light px-6 py-2 whitespace-nowrap">
                                {transaction.grossTotalAmount}
                            </td>
                            <td className="text-md text-gray-900 font-light px-6 py-2 whitespace-nowrap">
                                {dayjs.tz(transaction.created_at, "Asia/Manila").format('MMM D YYYY hh:mm:ss z')}
                            </td>
                            <td className="text-md text-gray-900 font-light px-6 py-2 whitespace-nowrap">
                                <button
                                    onClick={() => showModal(transaction.id)}
                                    className="shadow bg-blue-400 hover:bg-blue-500 focus:shadow-outline focus:outline-none text-white font-bold py-2 px-4 rounded w-full"
                                    type="button">
                                    View
                                </button>
                                { (visibleModal === transaction.id) && <ReceiveTransactionModal transaction={transaction} photo={transaction.id_image} hideModal={hideModal} /> }
                            </td>
                        </tr>
                    )})}
                </tbody>
            </table>
    );
}
