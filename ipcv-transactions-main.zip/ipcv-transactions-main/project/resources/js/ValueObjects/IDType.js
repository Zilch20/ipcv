class IDTypeMap {
    static IDTypes = {
        'A': "Passport",
        'C': "Driver's license",
        '5': "PRC ID",
        '7': "NBI Clearance",
        'D': "Police Clearance",
        '1': "Postal ID",
        'M': "Voter's ID",
        '3': "Barangay Certification",
        'E': "Government Service Insurance System (GSIS) e-Card",
        'N': "Social Security System (SSS) ID",
        'B': "Government issued national identification card",
        'W': "Senior Citizen ID",
        'V': "Overseas Workers Welfare Administration (OWWA) ID",
        '6': "OFW ID",
        'R': "Seaman's Book",
        '8': "Alien/Immigrant Certificate of Registration",
        'H': "PWD/NCWDP ID",
        '9': "DSWD Certificate",
        'U': "IBP ID",
        'X': "Student ID",
        '2': "Unified Multi Purpose ID (UMID)",
        '4': "Taxpayer's ID (TIN)",
        'I': "Other government issued IDs",
    };

    static fromType(type) {
        return this.IDTypes[type] ?? '';
    }
}

export default IDTypeMap;
