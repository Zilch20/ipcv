import dayjs from "dayjs";
import IDTypeMap from "@/ValueObjects/IDType";

class ReplyData {
    constructor(replyData) {
        const data = JSON.parse(replyData);

        // Sender Details
        this.senderFirstName = data.firstName
        this.senderMiddleName = data.middleName
        this.senderLastName = data.lastName
        this.address1 = data.address1
        this.address2 = data.address2
        this.city = data.city
        this.province = data.province
        this.birthDate = data.birthDate
        this.countryOfBirth = data.countryOfBirth
        this.nationality = data.nationality
        this.occupation = data.occupation
        this.phoneCountryCode = data.phoneCountryCode
        this.phoneNumber = data.phoneNum

        // Sender ID
        this.idType = data.idType
        this.idIssueDate = data.issueDate
        this.idNumber = data.idNum
        this.idExpiration = data.expiration

        // Transaction Details
        this.myWuNumber = data.myWuNumber
        this.mtcn = data.mtcn
        this.newMtcn = data.new_mtcn
        this.originatingCountryCode = data.originatingCountryCode
        this.currencyCode = data.currencyCode
        this.amount = data.amount
        this.charges = data.charges
        this.grossAmount = data.grossAmount
        this.destionationCountry = data.destionationCountry
        this.destinationAmount = data.destinationAmount
        this.destinationCurrencyCode = data.destinationCurrencyCode
        this.transactionReason = data.transactionReason

        // Receiver Details
        this.receiverFirstName = data.receiverFirstName
        this.receiverMiddleName = data.receiverMiddleName
        this.receiverLastName = data.receiverLastName
        this.receiverAddress1 = data.receiverAddress1
        this.receiverCity = data.receiverCity
        this.receiverState = data.receiverState
        this.receiverPhoneCountryCode = data.receiverPhoneCountryCode
        this.receiverPhoneNumber = data.receiverPhoneNum
    }

    birthDateFormatted() {
        return dayjs(this.birthDate, 'DDMMYYYY').format('MMMM D, YYYY')
    }

    idIssueDateFormatted() {
        return dayjs(this.idIssueDate, 'DDMMYYYY').format('MMMM D, YYYY')
    }

    idExpirationDateFormatted() {
        return dayjs(this.idExpiration, 'DDMMYYYY').format('MMMM D, YYYY')
    }

    idTypeDescription() {
        return IDTypeMap.fromType(this.idType)
    }
}

export default ReplyData;
