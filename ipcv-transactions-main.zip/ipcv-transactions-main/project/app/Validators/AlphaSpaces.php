<?php

declare(strict_types=1);

namespace App\Validators;

use Closure;
use Illuminate\Contracts\Validation\InvokableRule;
use function preg_match;
use function trim;

final class AlphaSpaces implements InvokableRule
{
    private static string $pattern = '/^[\pL\s]+$/u';

    private static string $message = "The :attribute must only contain letters and spaces.";

    /**
     * @param string $attribute
     * @param mixed $value
     * @param Closure $fail
     */
    public function __invoke($attribute, $value, $fail): void
    {
        if (false === (bool)(preg_match(self::$pattern, trim($value)))) {
            $fail(self::$message);
        }
    }
}
