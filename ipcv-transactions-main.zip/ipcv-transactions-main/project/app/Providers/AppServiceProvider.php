<?php

declare(strict_types=1);

namespace App\Providers;

use App\Services\MiddlewareApiService;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->singleton(
            MiddlewareApiService::class,
            fn () =>
            new MiddlewareApiService(self::newGuzzleClientForMiddleware())

        );
    }

    private static function newGuzzleClientForMiddleware(): Client
    {
        return new Client([
          'base_uri' => config('middleware_api.url'),
          'timeout' => 0,
          'allow_redirects' => false,
        ]);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        if ($this->app->environment() === 'production') {
            URL::forceScheme('https');
            URL::forceRootUrl(config('app.url'));
        }
    }
}
