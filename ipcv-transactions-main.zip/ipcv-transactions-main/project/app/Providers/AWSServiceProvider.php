<?php

declare(strict_types=1);

namespace App\Providers;

use App\Services\AWSS3Service;
use Aws\S3\S3Client;
use Aws\S3\S3ClientInterface;
use Illuminate\Support\ServiceProvider;

class AWSServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(
            S3ClientInterface::class,
            fn (): S3Client => (
                new S3Client([
                    'region' => config('aws.s3.region'),
                    'credentials' => array(
                        'key' => config('aws.s3.access_key'),
                        'secret' => config('aws.s3.secret_key')
                    ),
                    'version' => '2006-03-01'
                ])
            )
        );

        $this->app->singleton(
            AWSS3Service::class,
            fn() => new AWSS3Service(
                $this->app->get(S3ClientInterface::class),
                bucket: config('aws.s3.bucket'),
                directory: 'id-photos'
            )
        );
    }
}
