<?php

declare(strict_types=1);

namespace App\Services;

use DateTimeImmutable;
use DateTimeZone;
use Exception;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Artisan;
use JsonException;
use function base64_decode;
use function explode;
use function file_get_contents;
use function file_put_contents;
use function json_decode;
use function preg_quote;
use function preg_replace;

class MiddlewareJwtService
{
    private const PAYLOAD = 1;

    public function __construct(
        private readonly MiddlewareApiService $service,
        private readonly Application $app
    ) {
    }

    /**
     * @throws GuzzleException
     * @throws JsonException
     */
    public function refreshToken(): void
    {
        $this->setNewToken($this->requestForNewToken());
        Artisan::call('config:cache');
    }

    /**
     * @throws GuzzleException
     * @throws JsonException
     */
    public function accessToken(): string
    {
        $currentToken = config('middleware_api.access_token');

        if (null === $currentToken || '' === $currentToken) {
            $this->setNewToken($token = $this->requestForNewToken());
            Artisan::call('config:cache');

            return $token;
        }

        if (false === self::isExpired($currentToken)) {
            return $currentToken;
        }

        $this->setNewToken($token = $this->requestForNewToken());
        Artisan::call('config:cache');

        return $token;
    }

    /**
     * @throws JsonException
     * @throws Exception
     */
    public static function isExpired(string $token): bool
    {
        $encodedPayload = explode('.', $token)[self::PAYLOAD];
        $payload = json_decode(base64_decode($encodedPayload, strict: true), true, 512, JSON_THROW_ON_ERROR);

        $tz = new DateTimeZone('UTC');
        $expiryDateTime = DateTimeImmutable::createFromFormat('U.u', (string)$payload['exp'], $tz);
        $currentDateTime = new DateTimeImmutable('now', $tz);

        return ($currentDateTime > $expiryDateTime);
    }

    /**
     * @throws GuzzleException
     * @throws JsonException
     */
    private function requestForNewToken(): string
    {
        $responseBody = $this->service->authenticate()->getBody()->getContents();
        return json_decode($responseBody, true, 512, JSON_THROW_ON_ERROR)['access_token'];
    }

    private function setNewToken(string $token): void
    {
        $this->writeNewEnvFileWith($token);
    }

    /**
     * Write a new environment file with the given key.
     */
    protected function writeNewEnvFileWith(string $key): void
    {
        file_put_contents($this->app->environmentFilePath(), preg_replace(
            $this->keyReplacementPattern(),
            'MIDDLEWARE_API_ACCESS_TOKEN='.$key,
            file_get_contents($this->app->environmentFilePath())
        ));
    }

    /**
     * Get a regex pattern that will match env APP_KEY with any random key.
     *
     * @return string
     */
    protected function keyReplacementPattern(): string
    {
        $escaped = preg_quote('='.$this->app['config']['middleware_api.access_token'], '/');

        return "/^MIDDLEWARE_API_ACCESS_TOKEN{$escaped}/m";
    }
}
