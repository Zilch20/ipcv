<?php

declare(strict_types=1);

namespace App\Services;

use Aws\Result;
use Aws\S3\Exception\S3Exception;
use Aws\S3\S3ClientInterface;
use GuzzleHttp\Psr7\Stream;

class AWSS3Service
{
    public function __construct(
        private readonly S3ClientInterface $client,
        private readonly string $bucket,
        private readonly string $directory,
    ) {
    }

    /**
     * @throws S3Exception
     */
    public function getObject(string $fileName): Stream
    {
        /** @var Result $object */
        $object = $this->client->getObject([
            'Bucket' => $this->bucket,
            'Key' => "$this->directory/$fileName",
        ]);

        return $object->get('Body');
    }
}
