<?php

declare(strict_types=1);

namespace App\Services;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Http\Message\ResponseInterface;

class MiddlewareApiService
{
    public function __construct(
        private readonly ClientInterface $client
    ) {
    }

    /**
     * @throws GuzzleException
     */
    public function authenticate(): ResponseInterface
    {
        return $this->client->request('POST', 'oauth/token', [
            'json' => [
                'grant_type' => 'password',
                'username' => 'ej_staging@i-pcv.com',
                'password' => 'D@iC*RK2vvSt^i&w!Kf2',
                'client_id' => '57',
                'client_secret' => 'jkuag91ETGjEtjCJ2nINRRvQUvmvAEpjkAz7b5Pu',
                'scope' => '*'
            ]
        ]);
    }

    /**
     * @throws GuzzleException
     */
    public function sendTransactions(string $token, array $params): ResponseInterface
    {
        return $this->client->request('GET', 'send-transactions', [
            'headers' => [
                'authorization' => 'Bearer ' . $token
            ],
            'query' => $params
        ]);
    }

    /**
     * @throws GuzzleException
     */
    public function receiveTransactions(string $token, array $params): ResponseInterface
    {
        return $this->client->request('GET', 'receive-transactions', [
            'headers' => [
                'authorization' => 'Bearer ' . $token
            ],
            'query' => $params
        ]);
    }

    /**
     * @throws GuzzleException
     */
    public function getIdPhoto(string $token, string $mtcn, string $type): ResponseInterface
    {
        return $this->client->request('GET', 'id-image', [
            'headers' => [
                'authorization' => 'Bearer ' . $token
            ],
            'query' => [
                'mtcn' => $mtcn,
                'type' => $type
            ]
        ]);
    }
}
