<?php

declare(strict_types=1);

namespace App\ValueObjects;

use function array_map;
use function explode;
use function implode;
use function trim;

final class Name
{
    private function __construct(
        public readonly array $nameFragments
    ) {
    }

    public static function fromString(string $name): Name
    {
        $nameFragments = explode(' ', trim($name));

        return new Name($nameFragments);
    }

    private static function prefixWithPlusSign(string $nameFragment): string
    {
        return "+$nameFragment";
    }

    public function toStringWithPlusSignPrefix(): string
    {
        $array = array_map([$this, 'prefixWithPlusSign'], $this->nameFragments);

        return implode(' ', $array);
    }
}
