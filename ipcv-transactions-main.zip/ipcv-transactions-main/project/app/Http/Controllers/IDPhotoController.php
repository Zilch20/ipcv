<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\AWSS3Service;
use Aws\S3\Exception\S3Exception;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\Response as BaseResponse;

class IDPhotoController
{
    public function __construct(
        private readonly AWSS3Service $service
    ) {
    }

    public function __invoke(Request $request): Response
    {
        $fileName = \sprintf(
            '%s_%s',
            $request->input('mtcn'),
            $request->input('type'),
        );

        try {
            $stream = $this->service->getObject($fileName);
        } catch (S3Exception) {
            return new Response(['error' => 'Image not found.'], BaseResponse::HTTP_NOT_FOUND);
        }

        return new Response($stream->getContents(), 200, ['content-type' => 'image/jpeg']);
    }
}
