<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\SendTransaction;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SendTransactionsController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $q = $this
            ->buildQuery(SendTransaction::query(), $request)
            ->orderBy('created_at')
            ->cursorPaginate(
                perPage: $request->input('per_page', 25),
                cursor: $request->input('cursor')
            )
            ->toArray();
        ;

        return new JsonResponse($q);
    }

    private function buildQuery(Builder $builder, Request $request): Builder
    {
        if ($mtcn = $request->input('mtcn')) {
            $builder->where('mtcn', $mtcn);
        }

        if ($name = $request->input('name')) {
            $builder->whereRaw('MATCH (senderName) AGAINST (?)', $name);
        }

        if ($from = $request->input('from')) {
            $builder->where('created_at', '>=', $from);
        }

        if ($to = $request->input('to')) {
            $builder->where('created_at', '<=', $to);
        }

        return $builder;
    }
}
