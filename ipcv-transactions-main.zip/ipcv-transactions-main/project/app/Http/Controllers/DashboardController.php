<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\DashboardRequest;
use App\Models\ReceiveTransaction;
use App\Models\SendTransaction;
use App\ValueObjects\Name;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;

class DashboardController extends Controller
{
    public function __invoke(DashboardRequest $request): Response
    {
        if (true === self::queryStringExists($request)) {
            $result = $this->runQuery($request);

            $sendTransactions = $result['send_transactions'];
            $recvTransactions = $result['receive_transactions'];
        }

        return Inertia::render('Dashboard', [
            'send_transactions' => $sendTransactions ?? [],
            'receive_transactions' => $recvTransactions ?? [],
        ]);
    }

    private static function queryStringExists(Request $request): bool
    {
        $searchFields = ['mtcn', 'from', 'to', 'first_name', 'last_name', 'cursor'];

        foreach ($searchFields as $queryStr) {
            if ($request->has($queryStr)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array{send_transactions: array, receive_transactions: array}
     */
    private function runQuery(DashboardRequest $request): array
    {
        $sendTransaction = SendTransaction::query();
        $recvTransaction = ReceiveTransaction::query();

        if ($mtcn = $request->input('mtcn')) {
            $sendTransaction->where('mtcn',  $mtcn);
            $recvTransaction->where('mtcn',  $mtcn);
        }

        if ($from = $request->input('from')) {
            $sendTransaction->where('created_at', '>=', $from);
            $recvTransaction->where('created_at', '>=', $from);
        }

        if ($to = $request->input('to')) {
            $sendTransaction->where('created_at', '<=', $to);
            $recvTransaction->where('created_at', '<=', $to);
        }

        if ($name = $request->input('name')) {
            $name = Name::fromString($name);
            $sendTransaction->whereRaw('MATCH (senderName) AGAINST (? IN BOOLEAN MODE)',  [$name->toStringWithPlusSignPrefix()]);
            $recvTransaction->whereRaw('MATCH (receiverName) AGAINST (? IN BOOLEAN MODE)',   [$name->toStringWithPlusSignPrefix()]);
        }

        $sendTransaction->orderBy('created_at', 'desc');
        $recvTransaction->orderBy('created_at', 'desc');

        $sendTransaction = $sendTransaction->cursorPaginate(
            perPage: $request->input('per_page', 25),
            cursor: $request->input('send_cursor')
        );

        $recvTransaction = $recvTransaction->cursorPaginate(
            perPage: $request->input('per_page', 25),
            cursor: $request->input('recv_cursor')
        );

        $sendTransaction
            ->through(fn (SendTransaction $sendTransaction) => [
                'id' => $sendTransaction->id,
                'senderName' => $sendTransaction->senderName,
                'grossTotalAmount' => $sendTransaction->grossTotalAmount,
                'mtcn' => $sendTransaction->mtcn,
                'request_data' => $sendTransaction->request_data,
                'created_at' => $sendTransaction->created_at,
                'id_image' => config('app.url') . "/id-image?mtcn=" . $sendTransaction->mtcn . "&type=send",
            ]);

        $recvTransaction
            ->through(fn (ReceiveTransaction $receiveTransaction) => [
                'id' => $receiveTransaction->id,
                'receiverName' => $receiveTransaction->receiverName,
                'grossTotalAmount' => $receiveTransaction->grossTotalAmount,
                'mtcn' => $receiveTransaction->mtcn,
                'request_data' => $receiveTransaction->request_data,
                'created_at' => $receiveTransaction->created_at,
                'id_image' => config('app.url') . "/id-image?mtcn=" . $receiveTransaction->mtcn . "&type=receive",
            ]);

        return [
            'send_transactions' => $sendTransaction->toArray(),
            'receive_transactions' => $recvTransaction->toArray(),
        ];
    }
}
