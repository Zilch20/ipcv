<?php

namespace App\Http\Controllers;

use App\Models\ReceiveTransaction;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReceiveTransactionsController
{
    public function __invoke(Request $request): JsonResponse
    {
        $b = $this
            ->buildQuery(ReceiveTransaction::query(), $request)
            ->cursorPaginate(
                perPage: $request->input('per_page', 25),
                cursor: $request->input('cursor')
            )
            ->toArray();

        return new JsonResponse($b);
    }

    private function buildQuery(Builder $builder, Request $request): Builder
    {
        if ($mtcn = $request->input('mtcn')) {
            $builder->where('mtcn', $mtcn);
        }

        if ($name = $request->input('name')) {
            $builder->whereRaw('MATCH (receiverName) AGAINST (?)',  $name);
        }

        if ($from = $request->input('from')) {
            $builder->where('created_at', '>=', $from);
        }

        if ($to = $request->input('to')) {
            $builder->where('created_at', '<=', $to);
        }

        return $builder;
    }
}
