<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Validators\AlphaSpaces;
use Illuminate\Foundation\Http\FormRequest;

class DashboardRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * @return string[]
     */
    public function rules(): array
    {
        return [
            'mtcn' => ['alpha_num', 'nullable'],
            'name' => [new AlphaSpaces(), 'nullable'],
            'from' => ['date_format:Y-m-d', 'nullable'],
            'to' => ['date_format:Y-m-d', 'nullable'],
            'cursor' => ['alpa_num', 'nullable'],
        ];
    }
}
