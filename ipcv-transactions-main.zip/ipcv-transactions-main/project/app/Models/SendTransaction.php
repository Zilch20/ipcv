<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SendTransaction extends Model
{
    protected $table = 'send_money_store_logs';

    protected $connection = 'middleware_db';
}
