<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReceiveTransaction extends Model
{
    protected $table = 'receive_money_pay_logs';

    protected $connection = 'middleware_db';
}
