<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IDPhotoController;
use App\Http\Controllers\ReceiveTransactionsController;
use App\Http\Controllers\SendTransactionsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware('auth')->group(function () {
    Route::get('/', DashboardController::class)
        ->middleware('verified')
        ->name('dashboard')
    ;
    Route::get('id-image', IDPhotoController::class);
    Route::get('send-transactions', SendTransactionsController::class);
    Route::get('receive-transactions', ReceiveTransactionsController::class);
});

require __DIR__.'/auth.php';
