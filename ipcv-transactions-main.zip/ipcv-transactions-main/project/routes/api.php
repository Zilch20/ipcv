<?php

use App\Http\Controllers\IDPhotoController;
use App\Http\Controllers\ReceiveTransactionsController;
use App\Http\Controllers\SendTransactionsController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::get('id-image', IDPhotoController::class);
Route::get('send-transactions', SendTransactionsController::class);
Route::get('receive-transactions', ReceiveTransactionsController::class);
