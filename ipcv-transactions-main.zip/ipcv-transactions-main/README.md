<style>
.container {
    text-align: center;
    display: block;
    margin: auto;
}
</style>

<div class="container">
    <h1>IPCV Transactions</h1>
</div>

## About IPCV Transactions
This web app was made to comply with Digitization of Customer Records (DIGICUR)

## Running locally
> In order to not worry about external dependencies, it is recommended to run this application in a Docker container.

Copy docker-compose.yml.dist to docker-compose.yml
```shell
cp docker-compose.yml.dist docker-compose.yml
```
Build
```shell
docker compose up -d --build
```
Verify everything was built successfully and running
```shell
docker ps -af name=transactions
```
Go inside the `transactions-app` container and install project dependencies
```shell
docker exec -it transactions-app bash
composer install -o
```
