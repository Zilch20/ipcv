Release Notes

On Development - Still in development
Beta - Have partial development but is not yet ready for QA testing
Alpha - Fixing of QA test not done
Done - Finished module
