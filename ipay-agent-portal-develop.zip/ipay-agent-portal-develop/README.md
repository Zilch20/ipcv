# DTI - Core

- Branches

  - Production - []()
  - Staging - []()
  - Test - []()
  - Develop - []()

### Run it as:

```
Start = npm start
Build = npm build
Preview = npm preview
```

### Conventional Commit

```
Feat - Committing features
Fix - Committing fix
Chore - Committing setup or maintenance
Docs - Committing documentation
Test - Committing test
Style - Committing css style or plotting of design
Refactor - Committing code refactor
Perf - Committing perf
Build - Committing build
Ci - Committing ci
Revert - Committing Revert
```

### Node & NPM Version:

```
node = v16.4.0
npm = v6.13.4
```
