const defaultTheme = require('tailwindcss/defaultTheme');
const tailwindForms = require("@tailwindcss/forms")({
  strategy: 'class',
});

const withOpacity =
  (variableName) =>
  ({ opacityValue }) => {
    if (opacityValue !== undefined) {
      return `rgba(var(${variableName}), ${opacityValue})`;
    }
    return `rgb(var(${variableName}))`;
  };

module.exports = {
  mode: "jit",
  important: true,
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html",
    "./src/**/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-family)', ...defaultTheme.fontFamily.sans],
      },
      colors: {
        "form-active": "var(--form-active)",
        "form-inactive": "var(--form-inactive)",
        primary: {
          50: withOpacity("--color-primary-50"),
          100: withOpacity("--color-primary-100"),
          200: withOpacity("--color-primary-200"),
          300: withOpacity("--color-primary-300"),
          400: withOpacity("--color-primary-400"),
          500: withOpacity("--color-primary-500"),
          600: withOpacity("--color-primary-600"),
          700: withOpacity("--color-primary-700"),
          800: withOpacity("--color-primary-800"),
          900: withOpacity("--color-primary-900"),
        },
        secondary: {
          50: withOpacity("--color-secondary-50"),
          100: withOpacity("--color-secondary-100"),
          200: withOpacity("--color-secondary-200"),
          300: withOpacity("--color-secondary-300"),
          400: withOpacity("--color-secondary-400"),
          500: withOpacity("--color-secondary-500"),
          600: withOpacity("--color-secondary-600"),
          700: withOpacity("--color-secondary-700"),
          800: withOpacity("--color-secondary-800"),
          900: withOpacity("--color-secondary-900"),
        },
      },
      fontSize: {
        xxxs: [
          '0.62rem',
          {
            letterSpacing: '-0.01em',
          },
        ],
        xxs: [
          '0.65rem',
          {
            letterSpacing: '-0.01em',
          },
        ],
      },
      spacing: {
        104: '26rem',
        112: '28rem',
        120: '30rem',
        130: '35rem',
        140: '40rem',
        150: '45rem',
        160: '50rem',
        170: '55rem',
        180: '60rem',
      },
      screens: {
        'xs':{max:'320px'},
        '3xl': {min: '2560px'},
        ...defaultTheme.screens,
      },
      backgroundImage: {
        'landing-image': "url('assets/images/home-background.png')",
        'greetings-image': "url('assets/images/bg-greetings.png')"
      },
    },
  },
  plugins: [
    tailwindForms,
  ],
};
