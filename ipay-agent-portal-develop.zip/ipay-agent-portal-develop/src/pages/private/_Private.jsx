import React from 'react';

import { isEmpty } from 'lodash';
import { Route, Routes as Switch } from 'react-router-dom';

import ProfileProvider from 'context/profile';
import RootUrlProvider from 'context/root-url';
import PrivateLayout from 'layouts/private-shell';
import Breaded, { BreadedRoute } from 'context/breaded';
import { Page404, NoPermission, PageLoader, PageTitle } from 'ui/components';

import Logout from './_Logout';
import { useSideBarOutlet } from './_directory';

const SandBox = React.lazy(() => import('features/sandbox'));

const renderOutlet = (i, parentPath = false) => {
  const { key, path, to, name, groups } = i;

  const hasGroup = !!groups;

  const $path = !parentPath ? path : parentPath + path;
  const $to = !parentPath ? path : parentPath + to;

  return (
    <Route
      key={key}
      path={`${path}/*`}
      element={
        <RootUrlProvider value={$path}>
          <React.Suspense fallback={<PageLoader />}>
            <BreadedRoute url={$to} key={key} label={name}>
              {!hasGroup ? (
                <>
                  <PageTitle title={name} />
                  <i.component />
                </>
              ) : (
                <Switch>
                  {groups?.map((x) => renderOutlet(x, path))}
                  <Route path="*" element={<Page404 withDelay />} />
                </Switch>
              )}
            </BreadedRoute>
          </React.Suspense>
        </RootUrlProvider>
      }
    />
  );
};

function Private() {
  const SIDEBAR_OUTLET = useSideBarOutlet();

  if (isEmpty(SIDEBAR_OUTLET))
    return (
      <Switch>
        <Route path="/*" element={<NoPermission />} />
        <Route path="/logout" element={<Logout />} />
      </Switch>
    );

  return (
    <ProfileProvider>
      <div className="3xl:container 3xl:mx-auto flex flex-col h-full">
        <Breaded>
          <Switch>
            <Route path="/" element={<PrivateLayout />}>
              {SIDEBAR_OUTLET?.map((i) => renderOutlet(i))}
              <Route path="*" element={<Page404 withDelay />} />
              <Route path="/sandbox" element={<SandBox />} />
            </Route>
            <Route path="/logout" element={<Logout />} />
          </Switch>
        </Breaded>
      </div>
    </ProfileProvider>
  );
}

Private.defaultProps = {};

Private.propTypes = {};

export default Private;
