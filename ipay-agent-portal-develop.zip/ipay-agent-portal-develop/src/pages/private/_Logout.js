import Logout from 'features/logout';

export default Logout;
