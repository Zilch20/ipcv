import React from 'react';

import { HiCash } from 'react-icons/hi';
import { FaUsersCog } from 'react-icons/fa';
import { RiSettings2Fill } from 'react-icons/ri';
import { AiFillHome, AiFillReconciliation } from 'react-icons/ai';

import { checkHasPermission } from 'utils';

const WipContainer = React.lazy(() =>
  import('ui/components').then((m) => ({ default: m?.WipContainer }))
);

const Home = React.lazy(() => import('features/home'));
const ChannelReports = React.lazy(() => import('features/channel-reports'));

const ROUTE_LIST = [
  {
    key: 'home',
    name: 'Home',
    icon: AiFillHome,
    component: Home,
    to: '/home',
    path: '/home',
    module_permission: ['static-access'],
    group_by: 'menu',
    groups: false,
  },
  {
    key: 'transactions',
    name: 'Transactions',
    icon: HiCash,
    component: null,
    to: '/transactions',
    path: '/transactions',
    module_permission: ['static-access'],
    group_by: 'menu',
    groups: [
      {
        key: 'channel-reports',
        name: 'Channel Reports',
        icon: null,
        component: ChannelReports,
        to: '/channel-reports',
        path: '/channel-reports',
        module_permission: ['static-access'],
      },
      {
        key: 'source-reports',
        name: 'Source Reports',
        icon: null,
        component: () => (
          <WipContainer label="Work in progress. (Source Reports)" />
        ),
        to: '/source-reports',
        path: '/source-reports',
        module_permission: ['static-access'],
      },
    ],
  },
  {
    key: 'reconciliation',
    name: 'Reconciliation',
    icon: AiFillReconciliation,
    component: () => (
      <WipContainer label="Work in progress. (Reconciliation)" />
    ),
    to: '/reconciliation',
    path: '/reconciliation',
    module_permission: ['static-access'],
    group_by: 'menu',
    groups: false,
  },
  {
    key: 'user-management',
    name: 'User Management',
    icon: FaUsersCog,
    component: () => (
      <WipContainer label="Work in progress. (User Management)" />
    ),
    to: '/user-management',
    path: '/user-management',
    module_permission: ['static-access'],
    group_by: 'settings',
    groups: false,
  },
  {
    key: 'acces-management',
    name: 'Acces Management',
    icon: RiSettings2Fill,
    component: () => (
      <WipContainer label="Work in progress. (Acces Management)" />
    ),
    to: '/acces-management',
    path: '/acces-management',
    module_permission: ['static-access'],
    group_by: 'settings',
    groups: false,
  },
];

const filterRoutes = (rt) => {
  const modules = rt?.map((x) => {
    const { groups } = x;
    if (groups?.length > 0) {
      return {
        ...x,
        groups: x?.groups?.filter((y) =>
          checkHasPermission(y?.module_permission)
        ),
      };
    }

    return x;
  });

  const o = modules?.filter(
    (x) =>
      (checkHasPermission(x?.module_permission) &&
        typeof x?.groups === 'boolean') ||
      x?.groups?.length > 0
  );

  return o;
};

const groupRoute = (list) =>
  list?.reduce((r, a) => {
    const $r = r;
    $r[a?.group_by] = r[a?.group_by] || [];
    $r[a?.group_by].push(a);
    return $r;
  }, Object.create(null));

export const useSideBarMenu = () => {
  const SIDEBAR_MENU = groupRoute(filterRoutes(ROUTE_LIST));
  return SIDEBAR_MENU;
};

export const useSideBarOutlet = () => {
  const SIDEBAR_OUTLET = filterRoutes(ROUTE_LIST);
  return SIDEBAR_OUTLET;
};
