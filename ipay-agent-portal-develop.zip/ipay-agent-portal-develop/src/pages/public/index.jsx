import React from "react";

import { Route, Routes as Switch } from "react-router-dom";

import Home from "./_Home";

function Public() {
  return (
    <Switch>
      <Route path="*" element={<Home />} />
    </Switch>
  );
}

Public.defaultProps = {};

Public.propTypes = {};

export default Public;
