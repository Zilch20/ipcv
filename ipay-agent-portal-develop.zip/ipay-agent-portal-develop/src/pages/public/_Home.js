import Home from 'features/authentication';

export default Home;
