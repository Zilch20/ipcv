import { useQuery } from '@tanstack/react-query';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetGraphTransactions = (params) => {
  const { isLoading, data = {} } = useQuery(
    [c.GET_GRAPH_TRANSACTIONS, params],
    actions.getGraphTrasactions
  );
  return [isLoading, data];
};
