import React from "react";

import PageWrapper from "layouts/wrapper";

import TableContainer from "./TableContainer";
import ChartContainer from "./ChartContainer";

function SandBox() {
  return (
    <PageWrapper withScroll>
      <div>
        <h4 className="font-bold text-3xl">Common - Components</h4>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5" />
      <TableContainer />
      <ChartContainer />
    </PageWrapper>
  );
}
SandBox.defaultProps = {};

SandBox.propTypes = {};

export default SandBox;
