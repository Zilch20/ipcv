import React from "react";

import { Button } from "ui/components";
import Table, { Column } from "ui/table";

import { INIT_DATA } from "../_constants";

function TableContainer() {
  const renderButton = React.useCallback(
    () => (
      <Button
        className="btn sm primary"
        label="Action"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          // eslint-disable-next-line no-console
          console.log("Me", " here");
        }}
      />
    ),
    []
  );

  const handleOnSelectRow = (i) => {
    // eslint-disable-next-line no-console
    console.log(i, " here");
  };

  return (
    <div className="card drop-shadow space-y-2">
      <h4 className="text-lg font-semibold">Table</h4>
      <Table
        data={INIT_DATA}
        isLoading={false}
        withHover
        containerClassName="h-120"
        onSelectRow={handleOnSelectRow}
      >
        <Column label="Name" value="name" />
        <Column label="Date" value="date" />
        <Column label="No" value={(i) => i?.id} />
        <Column label="Count" value={() => 0} className="text-center" />
        <Column value={renderButton} />
      </Table>
    </div>
  );
}
TableContainer.defaultProps = {};

TableContainer.propTypes = {};

export default TableContainer;
