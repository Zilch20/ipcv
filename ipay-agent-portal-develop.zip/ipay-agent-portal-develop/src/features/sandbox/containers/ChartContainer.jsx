import React from "react";

import dayjs from "dayjs";

import { AreaChart } from "ui/chart";

import { useGetGraphTransactions } from "../_hooks";

export const INIT_FILTER = {
  date: {
    from: dayjs().format("ll"),
    to: dayjs().format("ll"),
    range: {
      label: "Today",
      value: "today",
    },
  },
};

function ChartContainer() {
  const [isLoading, data] = useGetGraphTransactions(INIT_FILTER);

  const { dates = [] } = data || {};

  return (
    <div className="card drop-shadow space-y-2">
      <h4 className="text-lg font-semibold">Chart</h4>
      <AreaChart
        name="Data"
        data={dates}
        category="label"
        isLoading={isLoading}
        value={["count1", "count2"]}
      />
    </div>
  );
}
ChartContainer.defaultProps = {};

ChartContainer.propTypes = {};

export default ChartContainer;
