import dayjs from 'dayjs';
import { uniqueId } from 'lodash';

export const INIT_DATA = [
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
  {
    name: 'Juan Dela Cruz',
    date: dayjs().format('ll'),
    id: uniqueId(),
  },
];

export const GET_GRAPH_TRANSACTIONS = 'GET_GRAPH_TRANSACTIONS';
