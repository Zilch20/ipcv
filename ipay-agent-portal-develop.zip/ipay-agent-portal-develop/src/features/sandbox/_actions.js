import { $req } from 'services';
import { generateGraphLabels, generateGraphStats } from 'utils';

const x = (i) => Math.floor(Math.random() * i);

export const getGraphTrasactions = ({ queryKey }) => {
  const [, params] = queryKey;
  return $req.get({
    transform: {
      dates: generateGraphStats(
        generateGraphLabels(params)?.map((i) => ({
          count1: x(1000),
          count2: x(1000),
          label: i,
        })),
        params?.date
      ),
      labels: generateGraphLabels(params),
    },
  });
};
