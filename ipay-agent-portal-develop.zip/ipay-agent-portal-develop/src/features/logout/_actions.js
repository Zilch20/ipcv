import Cookies from 'js-cookie';

import { storage } from 'utils';

export const logout = (cb) => {
  storage.clear();
  Cookies.remove('_token');
  Cookies.remove('user_key');
  cb();
};
