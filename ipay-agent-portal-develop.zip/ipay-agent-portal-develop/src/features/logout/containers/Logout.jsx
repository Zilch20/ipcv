import React from 'react';

import { useNavigate } from 'react-router-dom';

import { ROOT_SESSION } from 'context/session';
import { Brand } from 'ui/components';

import { useLogout } from '../_hooks';

function Logout() {
  const [logout] = useLogout();
  const navigate = useNavigate();

  const { setIfAuthenticated } = React.useContext(ROOT_SESSION);

  React.useEffect(() => {
    const timer = setTimeout(() => {
      logout(() => {
        setIfAuthenticated(false);
        navigate('/');
      });
    }, 1000);
    return () => {
      clearInterval(timer);
    };
  }, []);

  return (
    <div className="flex w-screen h-screen bg-secondary-500 bg-landing-image bg-no-repeat bg-cover bg-center">
      <div className="m-auto text-center space-y-6">
        <div className="flex justify-center">
          <Brand className="h-8" type="wide" />
        </div>
        <div className="space-y-1">
          <div className="text-xl tracking-wide text-white font-semibold">
            Signing out.
          </div>
          <div className="text-xs text-white tracking-wide font-semibold">
            Please wait...
          </div>
        </div>
      </div>
    </div>
  );
}

Logout.propTypes = {};

export default Logout;
