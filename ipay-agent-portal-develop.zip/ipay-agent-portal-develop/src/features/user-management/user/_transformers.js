import dayjs from 'dayjs';
import { omit } from 'lodash';

import {
  convertNullToStringOfObject,
  getAge,
  jsUcFirst,
  removeEmpty,
  replaceAllString,
} from 'utils';

export const transformParams = (item) => {
  const { sort_by, order_by } = item;
  const x = {
    ...omit(item, ['sort_by']),
    sort_by: sort_by?.value || '',
    order_by: order_by?.value || '',
  };

  return removeEmpty(x);
};

export const tranformUser = (item) => {
  try {
    const {
      uuid = '',
      gender,
      service,
      address,
      zip_code,
      religion,
      position,
      division,
      date_hired,
      birth_date,
      region_name,
      region_code,
      civil_status,
      province_name,
      barangay_name,
      barangay_code,
      province_code,
      district_office,
      regional_office,
      municipality_name,
      municipality_code,
    } = item?.profile;

    const x = {
      ...omit(item, ['profile']),
      ...omit(item?.profile, [
        'uuid',
        'address',
        'zip_code',
        'division',
        'region_name',
        'region_code',
        'province_name',
        'province_code',
        'barangay_name',
        'barangay_code',
        'municipality_name',
        'municipality_code',
      ]),
      age: birth_date ? getAge(birth_date) : '',
      role: position ? replaceAllString(jsUcFirst(position), '-', ' ') : '',
      profile_uuid: uuid,
      uuid: item?.uuid,
      human_date_hired: date_hired ? dayjs(date_hired)?.format('ll') : null,
      human_birth_date: birth_date ? dayjs(birth_date)?.format('ll') : null,
      address: {
        region: {
          label: region_name || '',
          value: region_code || '',
        },
        province: {
          label: province_name || '',
          value: province_code || '',
        },
        municipality: {
          label: municipality_name || '',
          value: municipality_code || '',
        },
        barangay: {
          label: barangay_name || '',
          value: barangay_code || '',
        },
        full_address: address || '',
        zip_code: zip_code || '',
      },
      civil_status: civil_status
        ? {
            label: civil_status || '',
            value: civil_status || '',
          }
        : '',
      district_uuid: district_office
        ? {
            label: district_office?.name || '',
            value: district_office?.uuid || '',
          }
        : '',
      division_uuid: division
        ? {
            label: division?.name || '',
            value: division?.value || '',
          }
        : '',
      gender: gender
        ? {
            label: gender || '',
            value: gender || '',
          }
        : '',
      region_uuid: regional_office
        ? {
            label: regional_office?.name || '',
            value: regional_office?.uuid || '',
          }
        : '',
      religion: religion
        ? {
            label: religion || '',
            value: religion || '',
          }
        : '',
      role_uuid: item?.role
        ? {
            label: item?.role.name || '',
            value: item?.role.uuid || '',
          }
        : '',
      service_uuid: service
        ? {
            label: service?.name || '',
            value: service?.uuid || '',
          }
        : '',
    };

    return convertNullToStringOfObject(x);
  } catch (error) {
    // eslint-disable-next-line no-console
    console.log(error, ' here');
    return {};
  }
};
