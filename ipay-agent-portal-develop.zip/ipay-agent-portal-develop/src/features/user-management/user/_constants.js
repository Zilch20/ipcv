import React from 'react';

const rootConst = 'USERS';

export const GET_USER_LIST = `${rootConst}/GET_USER_LIST`;
export const GET_SELECTED_USER = `${rootConst}/GET_SELECTED_USER`;

export const CREATE_USER = `${rootConst}/CREATE_USER`;
export const UPDATE_USER = `${rootConst}/UPDATE_USER`;
export const REMOVE_USER = `${rootConst}/REMOVE_USER`;

export const SELECTED_USER = React.createContext();

export const OPTION_SORT_BY = [
  {
    label: 'ASCENDING',
    value: 'asc',
  },
  {
    label: 'DESCENDING',
    value: 'desc',
  },
];

export const OPTION_ORDER_BY = [
  { label: 'FIRST NAME', value: 'first_name' },
  { label: 'LAST NAME', value: 'last_name' },
  {
    label: 'DATE HIRED',
    value: 'date_hired',
  },
];
