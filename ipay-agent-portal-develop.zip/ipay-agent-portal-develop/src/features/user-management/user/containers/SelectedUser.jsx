import React from "react";

import { isEmpty, isNil } from "lodash";
import { useMatch, useParams, Route, Routes as Switch } from "react-router-dom";

import { ROOT_URL } from "context/root-url";
import { BreadedRoute } from "context/breaded";
import useCustomNavigate from "hooks/useCustomNavigate";
import { checkHasDomPermission } from "utils/permissions";
import WorkInfo from "features/user-management/work-info";
import { CardWithTabs, PageLoader, WipContainer } from "ui/components";

import Header from "../components/Header";
import { SELECTED_USER } from "../_constants";
import { useGetSelectedUser } from "../_hooks";

const ROUTES = [
  {
    label: "Work Info",
    url: "/work-info",
    key: "work-info",
    component: WorkInfo,
  },
  {
    label: "Personal Info",
    url: "/personal-info",
    key: "personal-info",
    component: () => <WipContainer label="Work in progress. (Personal Info)" />,
  },
  {
    label: "Other Documents",
    url: "/other-documents",
    key: "other-documents",
    component: () => (
      <WipContainer label="Work in progress. (Other Documents)" />
    ),
  },
  checkHasDomPermission(
    {
      label: "Permission",
      url: "/permission",
      key: "permission",
      component: () => <WipContainer label="Work in progress. (Permission)" />,
    },
    "static-access"
  ),
];

const $ROUTES = ROUTES?.filter((i) => !isNil(i));

function SelectedUser() {
  const navigate = useCustomNavigate();
  const rootUrl = React.useContext(ROOT_URL);

  const { user_uuid } = useParams();

  const url = `${rootUrl}/${user_uuid}`;

  const parentMatch = useMatch(`${url}/:module_code/*`);
  const { module_code } = parentMatch?.params || {};

  const [isLoading, data] = useGetSelectedUser(user_uuid);

  const handleOnClickTab = (v) => {
    const { key } = v;
    navigate(`${url}/${key}`);
  };

  if (isLoading && isEmpty(data)) return <PageLoader />;

  return (
    <SELECTED_USER.Provider value={data}>
      <div className="space-y-4 flex flex-1 flex-col overflow-hidden">
        <Header />
        <CardWithTabs
          tabs={$ROUTES}
          selected={module_code}
          onClick={handleOnClickTab}
        >
          <Switch>
            {$ROUTES?.map((i) => {
              const { url: _url, key, label } = i;
              return (
                <Route
                  key={key}
                  path={_url}
                  element={
                    <React.Suspense fallback={<PageLoader />}>
                      <BreadedRoute
                        url={url + _url}
                        path={url + _url}
                        label={label}
                      >
                        <i.component />
                      </BreadedRoute>
                    </React.Suspense>
                  }
                />
              );
            })}
          </Switch>
        </CardWithTabs>
      </div>
    </SELECTED_USER.Provider>
  );
}

SelectedUser.defaultProps = {};

SelectedUser.propTypes = {};

export default SelectedUser;
