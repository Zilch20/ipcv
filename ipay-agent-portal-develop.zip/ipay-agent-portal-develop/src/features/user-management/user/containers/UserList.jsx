import React from 'react';

import { GoPlus } from 'react-icons/go';
import { Outlet, useMatch, useNavigate } from 'react-router-dom';

import useSetQuery from 'hooks/useSetQuery';
import { ROOT_URL } from 'context/root-url';
import { checkHasDomPermission } from 'utils/permissions';
import { Button, GenericList, Pagination } from 'ui/components';
import PageWrapper, { ListPageWrapper, PageHeader } from 'layouts/wrapper';

import { useGetUserList } from '../_hooks';
import Filter, { INIT_FILTER } from '../components/Filter';

function UserList() {
  const navigate = useNavigate();

  const rootUrl = React.useContext(ROOT_URL);

  const [query, setQuery] = useSetQuery(INIT_FILTER);

  const parentMatch = useMatch(`${rootUrl}/:user_uuid/*`);
  const { user_uuid = null } = parentMatch?.params || {};

  const [isLoading, list, pagination] = useGetUserList(query);

  const handleOnSubmit = (value) => {
    const args = {
      ...query,
      ...value,
      page: 1,
    };

    setQuery(args, (search) => {
      navigate({
        pathname: rootUrl,
        search,
      });
    });
  };

  const handleChangePage = (page) => {
    const args = { ...query, page };
    setQuery(args, (search) => {
      navigate({
        pathname: rootUrl,
        search,
      });
    });
  };

  const handleOnRowClick = (item) => {
    const { uuid } = item;
    if (`${uuid}` !== `${user_uuid}`) {
      setQuery(query, (search) => {
        navigate({
          pathname: `${rootUrl}/${uuid}/work-info`,
          search,
        });
      });
    }
  };

  return (
    <PageWrapper>
      <PageHeader
        title="User Management"
        render={checkHasDomPermission(
          <Button
            label="Add New User"
            to={`${rootUrl}/create-user`}
            className="btn md primary px-5 w-full md:w-auto"
            icon={<GoPlus className="h-4 w-4" />}
          />,
          'static-access'
        )}
      />
      <ListPageWrapper
        title="Users"
        isLoading={isLoading}
        render={
          <>
            <Filter form={query} onSubmit={handleOnSubmit} />
            <GenericList
              data={list}
              selectedKey="uuid"
              selected={user_uuid}
              isLoading={isLoading}
              onRowClick={handleOnRowClick}
              sortBy={query?.sort_by?.value}
              nameKey={query?.order_by?.value}
              renderRow={(item) => {
                const { full_name, role } = item;
                return (
                  <div className="w-full">
                    <div>
                      <p className="text-sm font-medium text-gray-900 capitalize truncate">
                        {full_name ?? '--'}
                      </p>
                      <p className="text-xs text-gray-500 truncate">
                        {role ?? '--'}
                      </p>
                    </div>
                  </div>
                );
              }}
            />
            <Pagination onChange={handleChangePage} value={pagination} small />
          </>
        }
      >
        <Outlet />
      </ListPageWrapper>
    </PageWrapper>
  );
}
UserList.defaultProps = {};

UserList.propTypes = {};

export default UserList;
