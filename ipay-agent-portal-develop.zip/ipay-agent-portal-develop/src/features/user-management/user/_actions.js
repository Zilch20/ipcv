import { req } from 'services';

import { tranformUser, transformParams } from './_transformers';

export const getUserList = ({ queryKey }) => {
  const [, params] = queryKey;
  return req.get({
    url: '/v1/user',
    params: transformParams(params),
    transform: (res) => {
      const { data, meta } = res;
      const x = data?.map((i) => tranformUser(i));
      return {
        list: x,
        pagination: meta,
      };
    },
  });
};

export const getSelectedUser = ({ queryKey }) => {
  const [, user_uud] = queryKey;
  return req.get({
    url: `/v1/user/${user_uud}`,
    transform: (res) => {
      const { data } = res;
      const x = tranformUser(data);
      return x;
    },
  });
};
