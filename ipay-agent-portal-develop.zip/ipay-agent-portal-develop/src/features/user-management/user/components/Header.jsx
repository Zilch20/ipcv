import React from "react";

import { MdEdit } from "react-icons/md";

import { ViewImage } from "ui/media";
import { showAlert } from "ui/modals";
import { Button } from "ui/components";
import { ROOT_URL } from "context/root-url";
import useCustomNavigate from "hooks/useCustomNavigate";
import { checkHasDomPermission } from "utils/permissions";

import { useRemoveUser } from "../_hooks";
import { SELECTED_USER } from "../_constants";

const renderContent = () => (
  <div className="text-gray-600">
    <h4 className="font-medium text-lg text-black">Archive this User</h4>
    <p className="text-sm leading-6 tracking-wide">
      Archiving this user will remove its information from our database. This
      cannot be undone!
    </p>
  </div>
);

function Header() {
  const navigate = useCustomNavigate();
  const rootUrl = React.useContext(ROOT_URL);
  const data = React.useContext(SELECTED_USER);

  const [, remove] = useRemoveUser();

  const { full_name = "", avatar = "", uuid = "" } = data || {};

  const handleOnArchive = (e) => {
    e.preventDefault();
    showAlert({
      title: "Confirmation!",
      content: () => renderContent(),
      className: "modal-sm",
      isLoading: false,
      onYes: (close) => {
        remove(uuid, () => {
          close();
          navigate(rootUrl);
        });
      },
      onYesLabel: "Confirm",
      onNoLabel: "Cancel",
    });
  };

  return (
    <div className="sm:flex lg:flex-col xl:flex-row sm:items-center">
      <div>
        <div className="flex flex-col md:flex-row lg:flex-col xl:flex-row items-center space-x-3">
          <ViewImage
            src={avatar}
            className="w-16 h-16 rounded-full flex-shrink-0"
          />
          <h4 className="text-xl font-semibold text-primary-500">
            {full_name}
          </h4>
        </div>
      </div>
      <div className="ml-auto flex-shrink-0">
        <div className="flex justify-center md:justify-end mt-2 xl:mt-0 gap-2">
          {checkHasDomPermission(
            <Button
              icon={<MdEdit />}
              label="Edit Profile"
              className="btn sm primary w-28"
              to={`${rootUrl}/update-user/${uuid}`}
            />,
            "update-user-management"
          )}
          {checkHasDomPermission(
            <Button
              onClick={handleOnArchive}
              className="btn sm outline-primary w-28"
              label="Archive"
            />,
            "delete-user-management"
          )}
        </div>
      </div>
    </div>
  );
}
Header.defaultProps = {};

Header.propTypes = {};

export default Header;
