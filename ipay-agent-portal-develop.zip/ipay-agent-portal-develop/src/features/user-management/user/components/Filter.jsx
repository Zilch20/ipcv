import React from "react";

import PropTypes from "prop-types";

import { FormInputSelect } from "ui/forms";
import { FilterWrapper } from "layouts/wrapper";

import { OPTION_ORDER_BY, OPTION_SORT_BY } from "../_constants";

export const INIT_FILTER = {
  order_by: { label: "DATE HIRED", value: "date_hired" },
  sort_by: {
    label: "ASCENDING",
    value: "asc",
  },
  per_page: 50,
  page: 1,
  keyword: "",
};

function Filter({ form, onSubmit }) {
  const [filter, setFilter] = React.useState({
    ...INIT_FILTER,
    ...form,
  });

  const handleOnSubmit = (v) => {
    setFilter({
      ...filter,
      ...v,
    });

    onSubmit({
      ...filter,
      ...v,
    });
  };

  return (
    <FilterWrapper
      form={filter}
      onSubmit={handleOnSubmit}
      defaultValue={INIT_FILTER}
      searchClassName="w-full"
      hideSearchIcon
      placeholder="Search..."
    >
      {(state, onChange) => (
        <div className="flex flex-1 flex-col gap-3">
          <FormInputSelect
            label="Sort By"
            placeholder="Sort by..."
            name="sort_by"
            isSorted={false}
            value={state?.sort_by ?? ""}
            options={OPTION_SORT_BY}
            onChange={onChange}
          />
          <FormInputSelect
            label="Order By"
            placeholder="Order by..."
            name="order_by"
            isSorted={false}
            value={state?.order_by ?? ""}
            options={OPTION_ORDER_BY}
            onChange={onChange}
          />
        </div>
      )}
    </FilterWrapper>
  );
}
Filter.defaultProps = {
  form: {},
};

Filter.propTypes = {
  form: PropTypes.instanceOf(Object),
  onSubmit: PropTypes.instanceOf(Function).isRequired,
};

export default Filter;
