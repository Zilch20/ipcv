import { useQuery } from '@tanstack/react-query';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetUserList = (params) => {
  const { isLoading, data: { list = [], pagination = {} } = {} } = useQuery(
    [c.GET_USER_LIST, params],
    actions.getUserList
  );
  return [isLoading, list, pagination];
};

export const useGetSelectedUser = (user_uuid) => {
  const { isLoading, data = {} } = useQuery(
    [c.GET_SELECTED_USER, user_uuid],
    actions.getSelectedUser
  );
  return [isLoading, data];
};

export const useRemoveUser = () => {
  const isLoading = false;
  const remove = () => {};

  return [isLoading, remove];
};
