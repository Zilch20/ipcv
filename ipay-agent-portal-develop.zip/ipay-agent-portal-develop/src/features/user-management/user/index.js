import UserList from './containers/UserList';
import SelectedUser from './containers/SelectedUser';

export { SelectedUser };

export default UserList;
