import React from "react";

import { WipContainer } from "ui/components";

function WorkInfo() {
  return <WipContainer />;
}
WorkInfo.defaultProps = {};

WorkInfo.propTypes = {};

export default React.memo(WorkInfo);
