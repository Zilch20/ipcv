import React from "react";

import { Route, Routes as Switch } from "react-router-dom";

import { EmptyState, WipContainer } from "ui/components";

import UserList, { SelectedUser } from "./user";

function Routes() {
  return (
    <Switch>
      <Route element={<UserList />}>
        <Route path=":user_uuid/*" element={<SelectedUser />} />
        <Route path="*" element={<EmptyState />} />
      </Route>
      <Route path="/update-user/:user_uuid" element={<WipContainer />} />
      <Route path="/create-user" element={<WipContainer />} />
    </Switch>
  );
}
Routes.defaultProps = {};

Routes.propTypes = {};

export default Routes;
