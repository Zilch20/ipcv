import UserManagement from './_Routes';

export default UserManagement;
