import React from 'react';

import Cookie from 'js-cookie';

import { storage } from 'utils';
import { useMutation } from 'services';

import * as actions from './_actions';

export const useLogin = () => {
  const { isLoading, mutate } = useMutation(actions.login);

  const login = React.useCallback((payload, cb) => {
    mutate(payload, {
      onSuccess: (res) => {
        const { bearer_token = '', profile } = res;
        Cookie.set('_token', bearer_token);
        Cookie.set('user_key', new Date(profile?.updated_at).getTime());
        storage.set('permissions', ['static-access'] || []);
        cb();
      },
    });
  }, []);

  return [isLoading, login];
};
