import React from 'react';

import { useFormik } from 'formik';
import { useNavigate } from 'react-router-dom';

import { FormInput } from 'ui/forms';
import { Button } from 'ui/components';
import { ROOT_SESSION } from 'context/session';

import { useLogin } from '../_hooks';
import { loginSchema } from '../_validations';

const INIT_FORM = {
  email: 'test@foo.com',
  password: 'password',
};

function LoginForm() {
  const navigate = useNavigate();
  const { setIfAuthenticated } = React.useContext(ROOT_SESSION);

  const [validation, setValidation] = React.useState(false);

  const [isApiLoading, login] = useLogin();

  const { handleSubmit, setFieldValue, values, errors } = useFormik({
    initialValues: INIT_FORM,
    validationSchema: loginSchema,
    validateOnChange: validation,
    validateOnBlur: validation,
    onSubmit: async (form) => {
      login(form, () => {
        setIfAuthenticated(true);
      });
      navigate('/');
    },
  });

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        handleSubmit();
        setValidation(true);
      }}
      noValidate
      autoComplete="off"
    >
      <div className="space-y-8">
        <h4 className="text-base font-bold text-center">
          Login to Agent Portal
        </h4>
        <div className="space-y-5">
          <FormInput
            name="email"
            label="Email"
            type="email"
            placeholder="Ex. juandelacruz@email.com"
            autoFocus
            noautofill="true"
            value={values?.email || ''}
            onSetFieldValue={setFieldValue}
            error={errors?.email}
            required
          />
          <div>
            <FormInput
              label="Password"
              name="password"
              placeholder="Enter your password"
              value={values?.password || ''}
              type="password"
              autoComplete="none"
              onSetFieldValue={setFieldValue}
              withShowPassword
              error={errors?.password}
              required
            />
            <div className="mt-2 flex">
              <Button
                size="sm"
                className="font-medium text-secondary-500 ml-auto"
                label="Forgot Password?"
                to="/forgot-password"
              />
            </div>
          </div>
        </div>
        <Button
          withLoader
          className="w-full py-3"
          id="login"
          type="submit"
          label="Login"
          color="primary"
          disabled={isApiLoading}
          isLoading={isApiLoading}
        />
      </div>
    </form>
  );
}
LoginForm.defaultProps = {};

LoginForm.propTypes = {};

export default LoginForm;
