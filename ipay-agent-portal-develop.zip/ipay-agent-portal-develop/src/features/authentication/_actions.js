import { req } from 'services';

export const login = (payload) =>
  req.post({
    url: '/login',
    payload,
  });
