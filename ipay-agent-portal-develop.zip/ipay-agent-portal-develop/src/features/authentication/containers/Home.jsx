import React from 'react';

import dayjs from 'dayjs';

import { Brand } from 'ui/components';

import LoginForm from '../forms/LoginForm';

function Home() {
  return (
    <div className="flex w-screen h-screen bg-secondary-500 bg-landing-image bg-no-repeat bg-cover bg-center">
      <div className="m-auto px-5 md:px-10 py-14 space-y-5 w-full md:max-w-screen-sm mx-auto">
        <div className="space-y-10 mb-24">
          <div className="flex justify-center">
            <Brand className="h-8" type="wide" />
          </div>
          <div className="card shadow-secondary-500 p-8 md:p-10">
            <LoginForm />
          </div>
        </div>
        <h4 className="text-white font-normal text-sm text-center">
          © WUPOS | All Rights Reserved {dayjs().format('YYYY')}
        </h4>
      </div>
    </div>
  );
}

Home.defaultProps = {};

Home.propTypes = {};

export default Home;
