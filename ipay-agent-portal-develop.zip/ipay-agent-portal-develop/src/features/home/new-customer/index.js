import NewCustomer from './_Routes';

export default NewCustomer;
