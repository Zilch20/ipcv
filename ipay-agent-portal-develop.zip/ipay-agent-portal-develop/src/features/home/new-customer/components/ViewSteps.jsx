import React from 'react';

import {
  HiUser,
  HiCash,
  HiDocumentText,
  HiLocationMarker,
} from 'react-icons/hi';
import { useMatch, useNavigate } from 'react-router-dom';

import Steps, { Step } from 'ui/steps';
import { ROOT_URL } from 'context/root-url';

function ViewSteps() {
  const navigate = useNavigate();

  const url = React.useContext(ROOT_URL);
  const rootUrl = `${url}/new-customer`;

  const parentMatch = useMatch(`${rootUrl}/:module_code/*`);
  const { module_code = null } = parentMatch?.params || {};

  const handleOnClick = (v) => {
    navigate(`${rootUrl}${v}`);
  };

  React.useEffect(() => {
    if (!module_code) {
      navigate(`${rootUrl}/step-1`);
    }
  }, [module_code]);

  return (
    <div className="w-full flex justify-center">
      <Steps onClick={handleOnClick} activeValue={`/${module_code}`}>
        <Step value="/step-1" label="Sender Personal Details" icon={HiUser} />
        <Step
          value="/step-2"
          label="Sender Personal Details"
          icon={HiLocationMarker}
        />
        <Step value="/step-3" label="Receiver Details" icon={HiUser} />
        <Step value="/step-4" label="Transfer Details" icon={HiCash} />
        <Step value="/step-5" label="Review Details" icon={HiDocumentText} />
      </Steps>
    </div>
  );
}
ViewSteps.defaultProps = {};

ViewSteps.propTypes = {};

export default ViewSteps;
