import React from 'react';

import { Formik } from 'formik';
import { keys, pick } from 'lodash';
import { useNavigate } from 'react-router-dom';
import { HiInformationCircle } from 'react-icons/hi';

import { storage } from 'utils';
import { ROOT_URL } from 'context/root-url';

import Step3Form from '../forms/Step3Form';
import { step1Schema } from '../_validations';
import { STEP3_INIT_FORM } from '../_constants';

function Step1() {
  const data = storage.get('step-3');

  const navigate = useNavigate();
  const url = React.useContext(ROOT_URL);
  const rootUrl = `${url}/new-customer`;

  const [validation, setValidation] = React.useState(false);

  const handleOnSubmit = (form, { resetForm }) => {
    storage.set('step-3', form);
    resetForm(form);
    navigate(`${rootUrl}/step-4`);
  };

  return (
    <div>
      <div className="card card-light shadow-none rounded">
        <div className="text-gray-500 flex items-center gap-3">
          <HiInformationCircle className="w-5 h-5" />
          <h4 className="font-normal text-sm">
            Enter the correct details for receiver name as it has given to you.
            Make sure to also confirm with the sender that the receiver name
            they have given, will match the receiver’s ID.
          </h4>
        </div>
      </div>
      <div className="mt-5">
        <Formik
          initialValues={{
            ...STEP3_INIT_FORM,
            ...pick(data, keys(STEP3_INIT_FORM)),
          }}
          validationSchema={step1Schema}
          enableReinitialize
          onSubmit={handleOnSubmit}
          validateOnChange={validation}
          validateOnBlur={validation}
        >
          {({ submitForm }) => (
            <form
              noValidate
              className="h-full"
              onSubmit={(e) => {
                e.preventDefault();
                submitForm();
                setValidation(true);
              }}
            >
              <Step3Form />
            </form>
          )}
        </Formik>
      </div>
    </div>
  );
}

Step1.defaultProps = {};

Step1.propTypes = {};

export default Step1;
