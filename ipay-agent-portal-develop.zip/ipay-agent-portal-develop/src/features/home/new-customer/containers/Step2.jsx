import React from 'react';

import { Formik } from 'formik';
import { keys, pick } from 'lodash';
import { useNavigate } from 'react-router-dom';

import { storage } from 'utils';
import { ROOT_URL } from 'context/root-url';

import Step2Form from '../forms/Step2Form';
import { step2Schema } from '../_validations';
import { STEP2_INIT_FORM } from '../_constants';

function Step1() {
  const data = storage.get('step-2');

  const navigate = useNavigate();
  const url = React.useContext(ROOT_URL);
  const rootUrl = `${url}/new-customer`;

  const [validation, setValidation] = React.useState(false);

  const handleOnSubmit = (form, { resetForm }) => {
    storage.set('step-2', form);
    resetForm(form);
    navigate(`${rootUrl}/step-3`);
  };

  return (
    <Formik
      initialValues={{
        ...STEP2_INIT_FORM,
        ...pick(data, keys(STEP2_INIT_FORM)),
      }}
      validationSchema={step2Schema}
      enableReinitialize
      onSubmit={handleOnSubmit}
      validateOnChange={validation}
      validateOnBlur={validation}
    >
      {({ submitForm }) => (
        <form
          noValidate
          className="h-full"
          onSubmit={(e) => {
            e.preventDefault();
            submitForm();
            setValidation(true);
          }}
        >
          <Step2Form />
        </form>
      )}
    </Formik>
  );
}

Step1.defaultProps = {};

Step1.propTypes = {};

export default Step1;
