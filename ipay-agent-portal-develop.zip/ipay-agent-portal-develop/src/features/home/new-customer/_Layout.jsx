import React from 'react';

import { Outlet, useLocation, useNavigate } from 'react-router-dom';

import { ROOT_URL } from 'context/root-url';
import { BreadedRoute } from 'context/breaded';
import PageWrapper, { PageHeader } from 'layouts/wrapper';

import ViewSteps from './components/ViewSteps';

function Layout() {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const rootUrl = React.useContext(ROOT_URL);

  const handleGoBack = () => {
    navigate(rootUrl);
  };

  return (
    <BreadedRoute url={pathname} label="Send Money">
      <PageWrapper withScroll>
        <PageHeader title="Send Money - New Customer" goBack={handleGoBack} />
        <div className="card p-0">
          <div className="p-5 border-b border-gray-100">
            <h4 className="card-title">Customer Information</h4>
          </div>
          <div className="py-12 px-12 2xl:px-20">
            <div className="grid xl:grid-cols-6 gap-3">
              <div className="xl:col-span-2">
                <ViewSteps />
              </div>
              <div className="xl:col-span-4 -mt-2">
                <Outlet />
              </div>
            </div>
          </div>
        </div>
      </PageWrapper>
    </BreadedRoute>
  );
}

Layout.defaultProps = {};

Layout.propTypes = {};

export default Layout;
