import * as yup from 'yup';

export const step1Schema = yup.object({
  id_type: '',
  id_number: '',
  expiry_date: '',
  date_issued: '',
  first_name: yup.string().required('First name is required'),
  last_name: yup.string().required('Last name is required'),
  suffix: '',
  country_of_birth: '',
  date_of_birth: '',
  gender: '',
  nationality: '',
  source_of_funds: '',
  occupation: '',
  employment_position_level: '',
  mobile_number: '',
  telephone_number: '',
});

export const step2Schema = yup.object({});
export const step3Schema = yup.object({});
