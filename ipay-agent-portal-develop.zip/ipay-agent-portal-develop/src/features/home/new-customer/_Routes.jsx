import React from 'react';

import { Route, Routes as Switch } from 'react-router-dom';

import Layout from './_Layout';
import Step1 from './containers/Step1';
import Step2 from './containers/Step2';
import Step3 from './containers/Step3';

function Routes() {
  return (
    <Switch>
      <Route path="/" element={<Layout />}>
        <Route path="/step-1" element={<Step1 />} />
        <Route path="/step-2" element={<Step2 />} />
        <Route path="/step-3" element={<Step3 />} />
        <Route path="/step-4" element={<div>Step 4</div>} />
        <Route path="/step-5" element={<div>Step 5</div>} />
      </Route>
    </Switch>
  );
}
Routes.defaultProps = {};

Routes.propTypes = {};

export default Routes;
