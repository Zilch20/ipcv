import React from 'react';

import { useFormikContext } from 'formik';
import { useNavigate } from 'react-router-dom';
import { HiOutlineArrowSmRight } from 'react-icons/hi';

import { Button } from 'ui/components';
import { FormInput, FormInputSelect } from 'ui/forms';
import { ROOT_URL } from 'context/root-url';

function Step2Form() {
  const navigate = useNavigate();

  const url = React.useContext(ROOT_URL);
  const rootUrl = `${url}/new-customer`;

  const handleOnGoBack = (e) => {
    e.preventDefault();
    navigate(`${rootUrl}/step-1`);
  };

  const { values, setFieldValue, errors } = useFormikContext();

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <FormInput
            required
            label="Home Address"
            name="home_address"
            placeholder="House / Unit Number and Street Name"
            value={values?.home_address || ''}
            onSetFieldValue={setFieldValue}
            error={errors?.home_address}
          />
        </div>
        <FormInputSelect
          required
          name="country"
          label="Country"
          value={values?.country || ''}
          error={errors?.country}
          options={[]}
          placeholder="Select country..."
          onSetFieldValue={setFieldValue}
        />
        <FormInputSelect
          required
          name="state"
          label="State"
          value={values?.state || ''}
          error={errors?.state}
          options={[]}
          placeholder="Select state..."
          onSetFieldValue={setFieldValue}
        />
        <FormInputSelect
          required
          name="city"
          label="City"
          value={values?.city || ''}
          error={errors?.city}
          options={[]}
          placeholder="Select city..."
          onSetFieldValue={setFieldValue}
        />
        <FormInput
          required
          label="Postal Code"
          name="postal_code"
          value={values?.postal_code || ''}
          onSetFieldValue={setFieldValue}
          error={errors?.postal_code}
        />
      </div>
      <div className="flex justify-end gap-4">
        <Button
          label="Back"
          color="light"
          className="w-24"
          onClick={handleOnGoBack}
        />
        <Button
          label="Next"
          type="submit"
          color="primary"
          className="w-24"
          icon={<HiOutlineArrowSmRight className="order-last w-5 h-5" />}
        />
      </div>
    </div>
  );
}
Step2Form.defaultProps = {};

Step2Form.propTypes = {};

export default Step2Form;
