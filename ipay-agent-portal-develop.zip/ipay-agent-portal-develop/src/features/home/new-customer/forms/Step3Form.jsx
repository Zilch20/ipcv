import React from 'react';

import { useFormikContext } from 'formik';
import { useNavigate } from 'react-router-dom';
import { HiOutlineArrowSmRight } from 'react-icons/hi';

import { Button } from 'ui/components';
import { ROOT_URL } from 'context/root-url';
import { FormInput, FormInputSelect } from 'ui/forms';

function Step3Form() {
  const navigate = useNavigate();

  const url = React.useContext(ROOT_URL);
  const rootUrl = `${url}/new-customer`;

  const handleOnGoBack = (e) => {
    e.preventDefault();
    navigate(`${rootUrl}/step-2`);
  };

  const { values, setFieldValue, errors } = useFormikContext();

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 2xl:grid-cols-7 gap-4">
        <div className="2xl:col-span-2">
          <FormInput
            label="First Name"
            name="first_name"
            value={values?.first_name || ''}
            onSetFieldValue={setFieldValue}
            error={errors?.first_name}
            required
          />
        </div>
        <div className="2xl:col-span-2">
          <FormInput
            label="Middle Name"
            name="middle_name"
            value={values?.middle_name || ''}
            onSetFieldValue={setFieldValue}
            error={errors?.middle_name}
          />
        </div>
        <div className="2xl:col-span-2">
          <FormInput
            label="Last Name"
            name="last_name"
            value={values?.last_name || ''}
            onSetFieldValue={setFieldValue}
            error={errors?.last_name}
            required
          />
        </div>
        <div className="2xl:col-span-1">
          <FormInput
            label="Suffix (Optional)"
            name="suffix"
            value={values?.suffix || ''}
            onSetFieldValue={setFieldValue}
            error={errors?.suffix}
          />
        </div>
        <div className="col-span-full">
          <h4 className="font-semibold text-sm">
            How does the receiver want the money?
          </h4>
        </div>
        <div className="2xl:col-span-4">
          <FormInputSelect
            required
            name="receiving_method"
            label="Receiving Method"
            value={values?.receiving_method || ''}
            error={errors?.receiving_method}
            options={[]}
            placeholder="Select method..."
            onSetFieldValue={setFieldValue}
          />
        </div>
      </div>
      <div className="flex justify-end gap-4">
        <Button
          label="Back"
          color="light"
          className="w-24"
          onClick={handleOnGoBack}
        />
        <Button
          label="Next"
          type="submit"
          color="primary"
          className="w-24"
          icon={<HiOutlineArrowSmRight className="order-last w-5 h-5" />}
        />
      </div>
    </div>
  );
}
Step3Form.defaultProps = {};

Step3Form.propTypes = {};

export default Step3Form;
