import React from 'react';

import { useFormikContext } from 'formik';
import { HiOutlineArrowSmRight } from 'react-icons/hi';

import {
  FormInput,
  FormInputDate,
  FormInputSelect,
  FormInputMobileNumber,
  FormInputTelephoneNumber,
} from 'ui/forms';
import { Button } from 'ui/components';

function Step1Form() {
  const { values, setFieldValue, errors } = useFormikContext();

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 gap-4">
        <FormInputSelect
          required
          name="id_type"
          label="ID Type"
          value={values?.id_type || ''}
          error={errors?.id_type}
          options={[]}
          placeholder="Select type..."
          onSetFieldValue={setFieldValue}
        />
        <FormInput
          label="ID Number"
          name="id_number"
          placeholder="Enter ID Number"
          value={values?.id_number || ''}
          onSetFieldValue={setFieldValue}
          error={errors?.id_number}
          required
        />
        <FormInputDate
          name="expiry_date"
          label="Expiry Date"
          value={values?.expiry_date || ''}
          error={errors?.expiry_date}
          onSetFieldValue={setFieldValue}
          required
        />
        <FormInputDate
          name="date_issued"
          label="Date of Issue"
          value={values?.date_issued || ''}
          error={errors?.date_issued}
          onSetFieldValue={setFieldValue}
          required
        />
        <div className="col-span-2">
          <div className="grid grid-cols-2 2xl:grid-cols-7 gap-4">
            <div className="2xl:col-span-2">
              <FormInput
                label="First Name"
                name="first_name"
                value={values?.first_name || ''}
                onSetFieldValue={setFieldValue}
                error={errors?.first_name}
                required
              />
            </div>
            <div className="2xl:col-span-2">
              <FormInput
                label="Middle Name"
                name="middle_name"
                value={values?.middle_name || ''}
                onSetFieldValue={setFieldValue}
                error={errors?.middle_name}
              />
            </div>
            <div className="2xl:col-span-2">
              <FormInput
                label="Last Name"
                name="last_name"
                value={values?.last_name || ''}
                onSetFieldValue={setFieldValue}
                error={errors?.last_name}
                required
              />
            </div>
            <div className="2xl:col-span-1">
              <FormInput
                label="Suffix (Optional)"
                name="suffix"
                value={values?.suffix || ''}
                onSetFieldValue={setFieldValue}
                error={errors?.suffix}
              />
            </div>
          </div>
        </div>
        <FormInputSelect
          required
          name="country_of_birth"
          label="Country of Birth"
          value={values?.country_of_birth || ''}
          error={errors?.country_of_birth}
          options={[]}
          placeholder="Select country..."
          onSetFieldValue={setFieldValue}
        />
        <FormInputDate
          name="date_of_birth"
          label="Date of Birth"
          value={values?.date_of_birth || ''}
          error={errors?.date_of_birth}
          onSetFieldValue={setFieldValue}
          required
        />
        <FormInputSelect
          required
          name="gender"
          label="Gender"
          value={values?.gender || ''}
          error={errors?.gender}
          options={[]}
          placeholder="Select gender..."
          onSetFieldValue={setFieldValue}
        />
        <FormInputSelect
          required
          name="nationality"
          label="Nationality"
          value={values?.nationality || ''}
          error={errors?.nationality}
          options={[]}
          placeholder="Select nationality..."
          onSetFieldValue={setFieldValue}
        />
        <div className="col-span-2">
          <div className="grid grid-cols-2 2xl:grid-cols-3 gap-4">
            <FormInputSelect
              required
              name="source_of_funds"
              label="Source of Funds"
              value={values?.source_of_funds || ''}
              error={errors?.source_of_funds}
              options={[]}
              placeholder="Select Source of Funds..."
              onSetFieldValue={setFieldValue}
            />
            <FormInputSelect
              required
              name="occupation"
              label="Occupation"
              value={values?.occupation || ''}
              error={errors?.occupation}
              options={[]}
              placeholder="Select Occupation..."
              onSetFieldValue={setFieldValue}
            />
            <div className="col-span-2 2xl:col-span-1">
              <FormInputSelect
                required
                name="employment_position_level"
                label="Employment Position Level"
                value={values?.employment_position_level || ''}
                error={errors?.employment_position_level}
                options={[]}
                placeholder="Select Level..."
                onSetFieldValue={setFieldValue}
              />
            </div>
          </div>
        </div>
        <FormInputMobileNumber
          name="mobile_number"
          value={values?.mobile_number || ''}
          error={errors?.mobile_number}
          label="Mobile Number"
          onSetFieldValue={setFieldValue}
          required
        />
        <FormInputTelephoneNumber
          name="telephone_number"
          value={values?.telephone_number || ''}
          error={errors?.telephone_number}
          label="Telephone Number"
          onSetFieldValue={setFieldValue}
        />
      </div>
      <div className="flex justify-end">
        <Button
          label="Next"
          type="submit"
          color="primary"
          className="w-24"
          icon={<HiOutlineArrowSmRight className="order-last w-5 h-5" />}
        />
      </div>
    </div>
  );
}
Step1Form.defaultProps = {};

Step1Form.propTypes = {};

export default Step1Form;
