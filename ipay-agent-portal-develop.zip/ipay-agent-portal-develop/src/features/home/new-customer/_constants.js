export const STEP1_INIT_FORM = {
  id_type: '',
  id_number: '',
  expiry_date: '',
  date_issued: '',
  first_name: '',
  middle_name: '',
  last_name: '',
  suffix: '',
  country_of_birth: '',
  date_of_birth: '',
  gender: '',
  nationality: '',
  source_of_funds: '',
  occupation: '',
  employment_position_level: '',
  mobile_number: '',
  telephone_number: '',
};

export const STEP2_INIT_FORM = {};
export const STEP3_INIT_FORM = {};
