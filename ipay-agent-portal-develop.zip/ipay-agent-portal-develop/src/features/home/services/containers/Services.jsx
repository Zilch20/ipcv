import React from 'react';

import cn from 'classnames';
import { useNavigate } from 'react-router-dom';

import { showModal } from 'ui/modals';
import { ROOT_URL } from 'context/root-url';
import { PageHeader } from 'layouts/wrapper';
import { SkeletonLoader } from 'ui/components';
import { LOADER_PROVIDER } from 'features/home/_context';
// Assets Icons
import modify from 'assets/images/services/modify.svg';
import sendMoney from 'assets/images/services/send-money.svg';
import receiveMoney from 'assets/images/services/recieve-money.svg';
import refundCancel from 'assets/images/services/refund-cancel.svg';
import sendQuickPay from 'assets/images/services/send-quick-pay.svg';

import SendMoneyModal from '../modals/SendMoneyModal';

const SERVICES = [
  {
    title: 'Send Money',
    id: 'send-money',
    icon: sendMoney,
  },
  {
    title: 'Receive Money',
    id: 'receive-money',
    icon: receiveMoney,
  },
  {
    title: 'Send Quick Pay',
    id: 'send quick pay',
    icon: sendQuickPay,
  },
  {
    title: 'Refund/Cancel',
    id: 'refund-cancel',
    icon: refundCancel,
  },
  {
    id: 'modify',
    title: 'Modify',
    icon: modify,
  },
];

function Services() {
  const navigate = useNavigate();
  const rootUrl = React.useContext(ROOT_URL);

  const { isLoading } = React.useContext(LOADER_PROVIDER);

  const handleOnCallback = React.useCallback((v) => {
    navigate(`${rootUrl}${v}`);
  }, []);

  const handleOnService = (type) => (e) => {
    e.preventDefault();
    if (type === 'send-money') {
      showModal({
        title: 'Send Money',
        focusTrap: false,
        modalSize: 'modal-xs',
        content: (onClose) =>
          React.useMemo(
            () => (
              <SendMoneyModal close={onClose} callback={handleOnCallback} />
            ),
            []
          ),
      });
    }
  };

  return (
    <>
      <PageHeader title="Services" isLoading={isLoading} />
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3 xl:gap-5">
        {SERVICES?.map((i) => {
          const { title, icon, id } = i;
          return (
            <SkeletonLoader key={id} isLoading={isLoading}>
              <div
                onClick={handleOnService(id)}
                role="presentation"
                className={cn(
                  'card py-8 space-y-4 h-full cursor-pointer',
                  'hover:bg-primary-600 hover:shadow-inner',
                  'hover:ring-1 ring-inset ring-primary-700',
                  'transition duration-200 ease-in-out'
                )}
              >
                <div className="flex justify-center">
                  <img className="h-[79px]" src={icon} alt={title} />
                </div>
                <div className="text-center">
                  <h4 className="font-semibold text-xs">{title}</h4>
                </div>
              </div>
            </SkeletonLoader>
          );
        })}
      </div>
    </>
  );
}
Services.defaultProps = {};

Services.propTypes = {};

export default Services;
