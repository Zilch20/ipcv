import React from 'react';

import PropTypes from 'prop-types';

// Assets Icons
import newCustomer from 'assets/images/services/new-customer.svg';
import returningCustomer from 'assets/images/services/returning-customer.svg';

function SendMoneyModal({ close, callback }) {
  const handleOnClick = (v) => async (e) => {
    e.preventDefault();
    close();
    callback(v);
  };

  return (
    <div className="space-y-4">
      <p className="text-sm">
        Please select type of customer for this feature.
      </p>
      <div className="grid grid-cols-2 gap-3">
        <div
          role="presentation"
          className="cursor-pointer group"
          onClick={handleOnClick('/new-customer')}
        >
          <div className="rounded-t-md border border-b-0 overflow-hidden group-hover:bg-primary-600 group-hover:shadow-inner">
            <div className="px-5 py-8 flex justify-center">
              <img className="h-40" src={newCustomer} alt="New Customer" />
            </div>
          </div>
          <div className="bg-secondary-300 p-4 rounded-b-md">
            <h4 className="text-white text-center text-sm font-semibold">
              New Customer
            </h4>
          </div>
        </div>
        <div
          role="presentation"
          className="cursor-pointer group"
          onClick={handleOnClick('/returning-customer')}
        >
          <div className="rounded-t-md border border-b-0 overflow-hidden group-hover:bg-primary-600 group-hover:shadow-inner">
            <div className="px-5 py-8 flex justify-center">
              <img
                className="h-40"
                src={returningCustomer}
                alt="Returning Customer"
              />
            </div>
          </div>
          <div className="bg-secondary-300 p-4 rounded-b-md">
            <h4 className="text-white text-center text-sm font-semibold">
              Returning Customer
            </h4>
          </div>
        </div>
      </div>
    </div>
  );
}

SendMoneyModal.defaultProps = {};

SendMoneyModal.propTypes = {
  close: PropTypes.instanceOf(Function).isRequired,
  callback: PropTypes.instanceOf(Function).isRequired,
};

export default SendMoneyModal;
