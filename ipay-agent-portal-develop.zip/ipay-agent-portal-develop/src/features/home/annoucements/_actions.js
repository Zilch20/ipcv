import { uniqueId } from 'lodash';

import { $req } from 'services';

export const getAnnouncements = () =>
  $req.get({
    transform: {
      list: [
        {
          uuid: uniqueId(),
          content:
            'Due to civil disturbances in Haiti, expect service disruption',
        },
        {
          uuid: uniqueId(),
          content:
            'Due to civil disturbances in Haiti, expect service disruption',
        },
        {
          uuid: uniqueId(),
          content:
            'Due to civil disturbances in Haiti, expect service disruption',
        },
        {
          uuid: uniqueId(),
          content:
            'Due to civil disturbances in Haiti, expect service disruption',
        },
      ],
    },
  });
