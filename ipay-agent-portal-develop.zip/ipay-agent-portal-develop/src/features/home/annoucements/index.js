import Annoucements from './containers/Annoucements';

export default Annoucements;
