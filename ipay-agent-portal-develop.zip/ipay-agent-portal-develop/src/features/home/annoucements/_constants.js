const rootConst = 'HOME';

export const GET_ANNOUNCEMENTS = `${rootConst}/GET_ANNOUNCEMENTS`;
