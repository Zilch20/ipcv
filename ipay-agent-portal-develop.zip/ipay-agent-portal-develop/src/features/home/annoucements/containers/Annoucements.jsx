import React from 'react';

import { HiInformationCircle, HiOutlineSpeakerphone } from 'react-icons/hi';

import { PageHeader } from 'layouts/wrapper';
import { SkeletonLoader } from 'ui/components';

import { useGetAnnouncements } from '../_hooks';

function Annoucements() {
  const [isLoading, list] = useGetAnnouncements();

  return (
    <>
      <PageHeader title="Annoucements" isLoading={isLoading} />
      <div className="space-y-5">
        <SkeletonLoader isLoading={isLoading} className="min-h-72">
          <div className="card p-0 divide-y">
            {list?.map((i) => {
              const { content, uuid } = i;
              return (
                <div key={uuid} className="p-5">
                  <div className="flex items-center gap-5">
                    <div className="flex-shrink-0">
                      <HiOutlineSpeakerphone className="w-7 h-7 text-secondary-300" />
                    </div>
                    <p className="font-normal text-sm text-secondary-50 mr-auto">
                      {content}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </SkeletonLoader>
        <SkeletonLoader isLoading={isLoading}>
          <div className="card p-0">
            <div className="bg-primary-500 p-5 rounded-t">
              <div className="card-title text-secondary-500">
                Price Estimator
              </div>
            </div>
            <div className="flex items-start p-5 gap-5">
              <div className="flex-shrink-0">
                <HiInformationCircle className="w-5 h-5 text-primary-500" />
              </div>
              <p className="text-sm text-secondary-300">
                Fees and rates provided areestimates only and are not
                guaranteed. Additional taxes and fees may apply.
              </p>
            </div>
          </div>
        </SkeletonLoader>
      </div>
    </>
  );
}
Annoucements.defaultProps = {};

Annoucements.propTypes = {};

export default Annoucements;
