import { useQuery } from '@tanstack/react-query';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetAnnouncements = () => {
  const { isLoading, data: { list = [] } = {} } = useQuery(
    [c.GET_ANNOUNCEMENTS],
    actions.getAnnouncements
  );

  return [isLoading, list];
};
