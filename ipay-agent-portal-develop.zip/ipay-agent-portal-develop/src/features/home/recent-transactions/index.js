import RecentTransactions from './containers/RecentTransactions';

export default RecentTransactions;
