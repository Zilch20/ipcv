import { useQuery } from '@tanstack/react-query';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetListRecentTransactions = (params) => {
  const {
    isLoading,
    isFetching,
    data: { list = [] } = {},
  } = useQuery(
    [c.GET_RECENT_TRANSACTIONS, params],
    actions.getRecentTransactions
  );

  return [isLoading, isFetching, list];
};
