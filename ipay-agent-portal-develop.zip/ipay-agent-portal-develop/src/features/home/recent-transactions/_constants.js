const rootConst = 'HOME';

export const GET_RECENT_TRANSACTIONS = `${rootConst}/GET_RECENT_TRANSACTIONS`;
