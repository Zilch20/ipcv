import React from 'react';

import { Badge } from 'ui/components';
import Table, { Column } from 'ui/table';
import useSetQuery from 'hooks/useSetQuery';
import { PageHeader } from 'layouts/wrapper';
import { LOADER_PROVIDER } from 'features/home/_context';

import { useGetListRecentTransactions } from '../_hooks';

export const INIT_FILTER = {
  order_by: '',
  sort_by: '',
  per_page: 50,
  page: 1,
};

function RecentTransactions() {
  const { setIfLoading } = React.useContext(LOADER_PROVIDER);

  const [query] = useSetQuery(INIT_FILTER, 'transaction-query');

  const [isLoading, isFetching, list] = useGetListRecentTransactions(query);

  const renderBadge = React.useCallback((i) => {
    const { status } = i;
    return <Badge label={status} color="success" />;
  }, []);

  React.useEffect(() => {
    setIfLoading(isLoading);
  }, [isLoading]);

  return (
    <>
      <PageHeader title="Recent Transactions" isLoading={isLoading} />
      <div className="h-150">
        <Table
          withHover
          data={list}
          selectedKey="uuid"
          isLoading={isLoading}
          isFetching={isFetching}
        >
          <Column
            label="Send Date/Time"
            value="date"
            className="w-44 xl:w-auto"
          />
          <Column
            label="MTCN"
            value="mtcn"
            className="w-36 md:w-44 xl:w-auto"
          />
          <Column
            label="Sender Name"
            value="sender_name"
            className="w-44 xl:w-auto"
          />
          <Column
            label="Reciever Name"
            value="reciever_name"
            className="w-44 xl:w-auto"
          />
          <Column
            label="Status"
            value={renderBadge}
            className="w-32 md:w-44 justify-center flex xl:w-auto"
          />
        </Table>
      </div>
    </>
  );
}
RecentTransactions.defaultProps = {};

RecentTransactions.propTypes = {};

export default RecentTransactions;
