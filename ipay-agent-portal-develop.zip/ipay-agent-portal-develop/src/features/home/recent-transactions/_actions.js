import dayjs from 'dayjs';
import { uniqueId } from 'lodash';

import { $req } from 'services';

const x = (i) => Math.floor(Math.random() * i);

export const getRecentTransactions = ({ queryKey }) => {
  // eslint-disable-next-line no-unused-vars
  const [, params] = queryKey;
  return $req.get({
    transform: {
      list: [
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },

        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
        {
          uuid: uniqueId(),
          date: dayjs().format('lll'),
          mtcn: `${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(9)}-${x(9)}${x(9)}${x(
            9
          )}`,
          sender_name: 'Joy Santos',
          reciever_name: 'Jane Cruz',
          status: 'DONE',
        },
      ],
    },
  });
};
