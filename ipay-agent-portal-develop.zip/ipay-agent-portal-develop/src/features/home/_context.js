import React from 'react';

export const LOADER_PROVIDER = React.createContext();
