import React from 'react';

import PageWrapper from 'layouts/wrapper';

import Services from './services';
import Greetings from './greetings';
import Annoucements from './annoucements';
import { LOADER_PROVIDER } from './_context';
import RecentTransactions from './recent-transactions';

function Layout() {
  const [isLoading, setIfLoading] = React.useState(true);

  const x = React.useMemo(() => ({ isLoading, setIfLoading }), [isLoading]);

  return (
    <LOADER_PROVIDER.Provider value={x}>
      <PageWrapper withScroll>
        <Greetings />
        <div className="grid grid-cols-1 xl:grid-cols-7 gap-5">
          <div className="xl:col-span-5 space-y-5">
            <Services />
            <RecentTransactions />
          </div>
          <div className="xl:col-span-2 order-first xl:order-none">
            <div className="sticky top-0 space-y-5">
              <Annoucements />
            </div>
          </div>
        </div>
      </PageWrapper>
    </LOADER_PROVIDER.Provider>
  );
}
Layout.defaultProps = {};

Layout.propTypes = {};

export default Layout;
