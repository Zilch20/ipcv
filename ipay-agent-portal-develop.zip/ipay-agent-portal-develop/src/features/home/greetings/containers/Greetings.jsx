import React from 'react';

import dayjs from 'dayjs';

import { ROOT_PROFILE } from 'context/profile';
import greetings from 'assets/images/greetings.svg';
import { SkeletonLoader } from 'ui/components';
import { LOADER_PROVIDER } from 'features/home/_context';

function Greetings() {
  const { isLoading } = React.useContext(LOADER_PROVIDER);

  const profile = React.useContext(ROOT_PROFILE);
  const { full_name = '' } = profile || {};

  return (
    <SkeletonLoader isLoading={isLoading}>
      <div className="card p-5 md:p-10 md:mt-5 relative bg-greetings-image bg-no-repeat bg-cover md:bg-contain bg-right h-full md:h-36">
        <div className="h-full flex md:items-center">
          <div className="space-y-1">
            <h4 className="text-lg md:text-xl font-bold text-secondary-500">
              Hi Good Morning, {full_name}
            </h4>
            <p className="text-xs md:text-sm font-normal text-secondary-100">
              Last Log in: {dayjs().format('lll')}
            </p>
          </div>
        </div>
        <div className="absolute bottom-0 right-5 lg:right-32">
          <img className="h-20 md:h-40" src={greetings} alt="ipay-wupos" />
        </div>
      </div>
    </SkeletonLoader>
  );
}
Greetings.defaultProps = {};

Greetings.propTypes = {};

export default Greetings;
