import Greetings from './containers/Greetings';

export default Greetings;
