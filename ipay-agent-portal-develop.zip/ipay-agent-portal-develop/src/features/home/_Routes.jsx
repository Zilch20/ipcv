import React from 'react';

import { Route, Routes as Switch } from 'react-router-dom';

import Layout from './_Layout';
// Route element per service
import NewCustomer from './new-customer';

function Routes() {
  return (
    <Switch>
      <Route path="/*" element={<Layout />} />
      <Route path="/new-customer/*" element={<NewCustomer />} />
    </Switch>
  );
}
Routes.defaultProps = {};

Routes.propTypes = {};

export default Routes;
