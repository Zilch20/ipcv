import Home from './_Routes';

export default Home;
