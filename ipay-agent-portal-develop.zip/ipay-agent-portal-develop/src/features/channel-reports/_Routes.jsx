import React from 'react';

import { Route, Routes as Switch } from 'react-router-dom';

import Report from './report';
import SelectedReport from './selected-report';

function Routes() {
  return (
    <Switch>
      <Route path="/*" element={<Report />} />
      <Route path=":report_uuid" element={<SelectedReport />} />
    </Switch>
  );
}
Routes.defaultProps = {};

Routes.propTypes = {};

export default Routes;
