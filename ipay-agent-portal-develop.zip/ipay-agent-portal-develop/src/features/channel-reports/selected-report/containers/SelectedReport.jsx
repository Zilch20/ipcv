import React from 'react';

import { useLocation, useNavigate } from 'react-router-dom';

import Table, { Column } from 'ui/table';
import { Pagination, SkeletonLoader } from 'ui/components';
import { ROOT_URL } from 'context/root-url';
import useSetQuery from 'hooks/useSetQuery';
import { BreadedRoute } from 'context/breaded';
import PageWrapper, { PageHeader } from 'layouts/wrapper';

import Analytics from '../components/Analytics';
import { useGetTransactionList } from '../_hooks';
import Filter, { INIT_FILTER } from '../components/Filter';

function SelectedReport() {
  const navigate = useNavigate();

  const [query, setQuery] = useSetQuery(INIT_FILTER);

  const [isLoading, isFetching, list, pagination] =
    useGetTransactionList(query);

  const rootUrl = React.useContext(ROOT_URL);

  const { pathname, state } = useLocation();

  const handleOnGoBack = () => {
    navigate(rootUrl);
  };

  const handleOnSubmit = (value) => {
    const args = {
      ...query,
      ...value,
      page: 1,
    };

    setQuery(args);
  };

  const handleChangePage = (page) => {
    const args = { ...query, page };
    setQuery(args);
  };

  return (
    <BreadedRoute url={pathname} label="Channel Report Details">
      <PageWrapper withScroll>
        <PageHeader goBack={handleOnGoBack} title={state} />
        <Analytics />
        <div className="flex items-center">
          <Filter
            form={query}
            isLoading={isLoading}
            onSubmit={handleOnSubmit}
          />
          <div className="ml-auto">
            <SkeletonLoader isLoading={isLoading}>
              <div className="card border-l-4 border-primary-700 rounded-l-none">
                <h4 className="font-bold text-xl">Total Amount: 10,000</h4>
              </div>
            </SkeletonLoader>
          </div>
        </div>
        <div className="h-130 2xl:h-150">
          <Table
            data={list}
            isLoading={isLoading}
            isFetching={isFetching}
            withHover
          >
            <Column label="Reference Number" value="reference_no" />
            <Column label="Amount" value="amount" />
            <Column label="Date" value="date" />
            <Column label="Customer" value="customer" />
          </Table>
        </div>
        <Pagination
          small
          value={pagination}
          isLoading={isLoading}
          onChange={handleChangePage}
        />
      </PageWrapper>
    </BreadedRoute>
  );
}
SelectedReport.defaultProps = {};

SelectedReport.propTypes = {};

export default SelectedReport;
