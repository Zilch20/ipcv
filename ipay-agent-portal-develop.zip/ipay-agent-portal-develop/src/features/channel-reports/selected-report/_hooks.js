import { useQuery } from '@tanstack/react-query';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetAnalyticsData = () => {
  const { isLoading, data = {} } = useQuery(
    [c.GET_ANALYTICS_DATA],
    actions.getAnalytics
  );

  return [isLoading, data];
};

export const useGetTransactionList = (params) => {
  const {
    isLoading,
    isFetching,
    data: { list = [], pagination = {} } = {},
  } = useQuery([c.GET_TRANSACTION_LIST, params], actions.getListTrasactions);

  return [isLoading, isFetching, list, pagination];
};
