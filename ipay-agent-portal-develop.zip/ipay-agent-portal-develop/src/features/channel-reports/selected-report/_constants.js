const rootConst = 'SELECTED_REPORT_ANALYTICS';

export const GET_ANALYTICS_DATA = `${rootConst}/GET_ANALYTICS_DATA`;
export const GET_TRANSACTION_LIST = `${rootConst}/GET_TRANSACTION_LIST`;
