import React from 'react';

import {
  HiHand,
  HiThumbDown,
  HiShieldCheck,
  HiShieldExclamation,
} from 'react-icons/hi';

import { CountCard } from 'ui/components';

import { useGetAnalyticsData } from '../_hooks';

function Analytics() {
  const [isLoading, data] = useGetAnalyticsData();

  const {
    total_wpc = 0,
    total_paid = 0,
    total_void = 0,
    total_failed = 0,
  } = data;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
      <CountCard
        title="Paid"
        value={total_paid}
        isLoading={isLoading}
        iconType="primary"
        icon={<HiShieldCheck className="h-7 w-7 text-white" />}
      />
      <CountCard
        isLoading={isLoading}
        value={total_wpc}
        title="WPC"
        iconType="gray"
        icon={<HiShieldExclamation className="h-7 w-7 text-white" />}
      />
      <CountCard
        isLoading={isLoading}
        value={total_void}
        title="Void"
        iconType="warning"
        icon={<HiHand className="h-7 w-7 text-white" />}
      />
      <CountCard
        isLoading={isLoading}
        value={total_failed}
        title="Failed"
        iconType="danger"
        icon={<HiThumbDown className="h-7 w-7 text-white" />}
      />
    </div>
  );
}
Analytics.defaultProps = {};

Analytics.propTypes = {};

export default Analytics;
