import React from 'react';

import PropTypes from 'prop-types';

import { FilterWrapper } from 'layouts/wrapper';
import { FormInputSelect } from 'ui/forms';
import { SkeletonLoader } from 'ui/components';

export const INIT_FILTER = {
  status: '',
  keyword: '',
  sort_by: '',
  order_by: '',

  page: 1,
  per_page: 50,
};

function Filter({ form, isLoading, onSubmit }) {
  const [filter, setFilter] = React.useState({
    ...INIT_FILTER,
    ...form,
  });

  const handleOnSubmit = (v) => {
    setFilter({
      ...filter,
      ...v,
    });

    onSubmit({
      ...filter,
      ...v,
    });
  };

  return (
    <FilterWrapper
      form={filter}
      withoutFilter
      className="w-72"
      isLoading={isLoading}
      hideSerachLabel={false}
      onSubmit={handleOnSubmit}
      defaultValue={INIT_FILTER}
      placeholder="Search REF No. / Customer"
      inlineFilter={
        <SkeletonLoader isLoading={isLoading}>
          <div className="w-72">
            <FormInputSelect
              name="status"
              label={false}
              value={{
                label: 'All Status',
                value: '',
              }}
              options={[]}
              placeholder="Select status..."
              onChange={setFilter}
            />
          </div>
        </SkeletonLoader>
      }
    />
  );
}
Filter.defaultProps = {
  form: {},
  isLoading: false,
};

Filter.propTypes = {
  isLoading: PropTypes.bool,
  form: PropTypes.instanceOf(Object),
  onSubmit: PropTypes.instanceOf(Function).isRequired,
};

export default Filter;
