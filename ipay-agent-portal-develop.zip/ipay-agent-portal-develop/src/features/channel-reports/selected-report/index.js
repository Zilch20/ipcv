import SelectedReport from './containers/SelectedReport';

export default SelectedReport;
