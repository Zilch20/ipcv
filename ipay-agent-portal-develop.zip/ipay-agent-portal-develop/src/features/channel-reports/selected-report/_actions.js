import dayjs from 'dayjs';
import { uniqueId } from 'lodash';

import { $req } from 'services';
import { formatNumber } from 'utils';

const x = (i) => Math.floor(Math.random() * i);

export const getAnalytics = () =>
  $req.get({
    transform: {
      total_paid: formatNumber(x(1000000), 0),
      total_wpc: formatNumber(x(100000), 0),
      total_void: formatNumber(x(100000), 0),
      total_failed: formatNumber(x(50000), 0),
    },
  });

export const getListTrasactions = ({ queryKey }) => {
  // eslint-disable-next-line no-unused-vars
  const [, params] = queryKey;
  return $req.get({
    transform: {
      list: [
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
        {
          id: uniqueId(),
          reference_no: 'EFWE123123',
          customer: 'Juan Dela Cruz',
          date: dayjs().format('ll'),
          amount: formatNumber(x(10000), 0),
        },
      ],
      pagination: {
        page: 1,
        total: 12,
      },
    },
  });
};
