import React from "react";

import dayjs from "dayjs";
import PropTypes from "prop-types";

import { FormDateRangePicker, FormInputSelect } from "ui/forms";
import { SkeletonLoader } from "ui/components";

export const INIT_FILTER = {
  channel: "",
  service: "",
  sort_by: "",
  date: {
    from: dayjs().format("ll"),
    to: dayjs().format("ll"),
    range: {
      label: "Today",
      value: "today",
    },
  },
  per_page: 50,
  page: 1,
};

function Filter({ form, isLoading, onSubmit }) {
  const [filter, setFilter] = React.useState({
    ...INIT_FILTER,
    ...form,
  });

  const onChangeSelect = ($v) => {
    const v = $v();
    setFilter({
      ...filter,
      ...v,
    });

    onSubmit({
      ...filter,
      ...v(),
    });
  };

  const handleOnChangeDateRange = (v) => {
    setFilter({
      ...filter,
      ...v(),
    });

    onSubmit({
      ...filter,
      ...v(),
    });
  };

  const { date, channel, service } = filter;

  return (
    <div className="flex gap-3">
      <SkeletonLoader isLoading={isLoading}>
        <div className="w-64">
          <FormInputSelect
            label={false}
            placeholder="Select channel..."
            name="channel"
            isSorted={false}
            value={channel || ""}
            options={[]}
            onChange={onChangeSelect}
          />
        </div>
      </SkeletonLoader>
      <SkeletonLoader isLoading={isLoading}>
        <div className="w-64">
          <FormInputSelect
            label={false}
            value={service || ""}
            placeholder="Select service..."
            name="service"
            isSorted={false}
            options={[]}
            onChange={onChangeSelect}
          />
        </div>
      </SkeletonLoader>
      <SkeletonLoader isLoading={isLoading}>
        <div className="w-64">
          <FormDateRangePicker
            name="date"
            label={false}
            value={date}
            onChange={handleOnChangeDateRange}
          />
        </div>
      </SkeletonLoader>
    </div>
  );
}
Filter.defaultProps = {
  form: {},
  isLoading: false,
};

Filter.propTypes = {
  isLoading: PropTypes.bool,
  form: PropTypes.instanceOf(Object),
  onSubmit: PropTypes.instanceOf(Function).isRequired,
};

export default Filter;
