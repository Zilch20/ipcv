import React from 'react';

import { useNavigate } from 'react-router-dom';

import { showModal } from 'ui/modals';
import Table, { Column } from 'ui/table';
import useSetQuery from 'hooks/useSetQuery';
import { ROOT_URL } from 'context/root-url';
import { Button, Pagination, SkeletonLoader } from 'ui/components';

import { useGetListReports } from '../_hooks';
import ReportModal from '../modals/ReportModal';
import Filter, { INIT_FILTER } from '../components/Filter';

function Reports() {
  const navigate = useNavigate();
  const rootUrl = React.useContext(ROOT_URL);

  const [query, setQuery] = useSetQuery(INIT_FILTER, 'channel-query');

  const [isLoading, isFetching, list, pagination] = useGetListReports(query);

  const handleOnSubmit = (value) => {
    const args = {
      ...query,
      ...value,
      page: 1,
    };
    setQuery(args);
  };

  const handleOnUploadReportModal = (e) => {
    e.preventDefault();
    showModal({
      title: 'Import Collections',
      modalSize: 'modal-xs',
      content: (onClose) =>
        React.useMemo(() => <ReportModal close={onClose} />, []),
    });
  };

  const handleChangePage = (page) => {
    const args = { ...query, page };
    setQuery(args);
  };

  const handleOnSelectRow = ({ channel, date, uuid }) => {
    navigate(`${rootUrl}/${uuid}`, {
      state: `${channel} ${date}`,
    });
  };

  const renderAction = React.useCallback(
    () => (
      <div className="flex justify-end space-x-2">
        <Button
          size="xs"
          icon="view"
          label="View"
          color="light"
          className="px-3"
        />
        <Button
          size="xs"
          color="light"
          icon="download"
          className="px-3"
          label="Download"
        />
      </div>
    ),
    []
  );

  return (
    <div className="card">
      <div className="space-y-3">
        <div className="flex items-center">
          <Filter
            form={query}
            isLoading={isLoading}
            onSubmit={handleOnSubmit}
          />
          <div className="ml-auto">
            <SkeletonLoader isLoading={isLoading}>
              <Button
                color="primary"
                onClick={handleOnUploadReportModal}
                label="Import Collection Report"
              />
            </SkeletonLoader>
          </div>
        </div>
        <div className="h-130 2xl:h-150">
          <Table
            withHover
            data={list}
            selectedKey="uuid"
            isLoading={isLoading}
            isFetching={isFetching}
            onSelectRow={handleOnSelectRow}
          >
            <Column label="Channel" value="channel" />
            <Column label="Date" value="date" />
            <Column label="Collection" value="collection" />
            <Column label="Transaction" value="transaction" />
            <Column label={false} value={() => renderAction()} />
          </Table>
        </div>
        <Pagination
          small
          value={pagination}
          isLoading={isLoading}
          onChange={handleChangePage}
        />
      </div>
    </div>
  );
}

Reports.defaultProps = {};

Reports.propTypes = {};

export default Reports;
