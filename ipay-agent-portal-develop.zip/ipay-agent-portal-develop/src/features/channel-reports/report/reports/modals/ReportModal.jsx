import React from 'react';

import PropTypes from 'prop-types';
import { useFormik } from 'formik';

import { Button } from 'ui/components';
import { FormInputSelect } from 'ui/forms';

import { INIT_FORM } from '../_constants';
import { reportSchema } from '../_validations';

function ReportModal({ close }) {
  const [validation, setValidation] = React.useState(false);

  const { handleSubmit, setFieldValue, values, errors } = useFormik({
    initialValues: INIT_FORM,
    validationSchema: reportSchema,
    validateOnChange: validation,
    validateOnBlur: validation,
    onSubmit: (form) => {
      // eslint-disable-next-line no-console
      console.log(form, ' here');
      close();
    },
  });

  const { source = '', channel = '' } = values;

  return (
    <form
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        handleSubmit();
        setValidation(true);
      }}
      autoComplete="off"
      className="space-y-5 mt-3"
    >
      <div className="grid grid-cols-1 gap-4">
        <FormInputSelect
          required
          name="source"
          label="Source"
          value={source}
          error={errors?.source}
          options={[]}
          placeholder="Select source..."
          onSetFieldValue={setFieldValue}
        />
        <FormInputSelect
          name="channel"
          label="Channel"
          value={channel}
          options={[]}
          placeholder="Select channel..."
          onSetFieldValue={setFieldValue}
        />
      </div>
      <div className="flex justify-end space-x-2">
        <Button type="submit" color="primary" label="Done" className="w-28" />
      </div>
    </form>
  );
}
ReportModal.defaultProps = {};

ReportModal.propTypes = {
  close: PropTypes.instanceOf(Function).isRequired,
};

export default ReportModal;
