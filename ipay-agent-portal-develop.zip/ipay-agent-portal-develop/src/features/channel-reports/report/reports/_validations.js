import * as yup from 'yup';

export const reportSchema = yup.object({
  source: yup.object().required('Source is required').nullable(true),
});
