const rootConst = 'CHANNEL_REPORT';

export const GET_LIST_REPORTS = `${rootConst}/GET_LIST_REPORTS`;

export const INIT_FORM = {
  source: '',
  channel: '',
};
