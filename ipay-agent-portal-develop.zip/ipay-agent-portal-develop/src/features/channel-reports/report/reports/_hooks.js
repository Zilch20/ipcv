import { useQuery } from '@tanstack/react-query';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetListReports = (params) => {
  const {
    isLoading,
    isFetching,
    data: { list = [], pagination = {} } = {},
  } = useQuery([c.GET_LIST_REPORTS, params], actions.getListReports);

  return [isLoading, isFetching, list, pagination];
};
