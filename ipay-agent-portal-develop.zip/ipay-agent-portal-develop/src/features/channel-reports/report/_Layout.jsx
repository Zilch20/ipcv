import React from "react";

import PageWrapper from "layouts/wrapper";

import Reports from "./reports";
import Analytics from "./analytics";

function Layout() {
  return (
    <PageWrapper withScroll>
      <Analytics />
      <Reports />
    </PageWrapper>
  );
}
Layout.defaultProps = {};

Layout.propTypes = {};

export default Layout;
