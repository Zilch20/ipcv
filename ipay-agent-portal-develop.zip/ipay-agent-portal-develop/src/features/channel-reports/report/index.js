import Report from './_Layout';

export default Report;
