import { $req } from 'services';
import { formatNumber } from 'utils';

const x = (i) => Math.floor(Math.random() * i);
export const getAnalytics = () =>
  $req.get({
    transform: {
      stats: [
        {
          count: formatNumber(x(1000), 0),
          label: 'Lanbank',
        },
        {
          count: formatNumber(x(5000), 0),
          label: 'GCash',
        },
        {
          count: formatNumber(x(3000), 0),
          label: 'PayMaya',
        },
      ],
      total_transactions: formatNumber(x(100000), 0),
      paymaya: formatNumber(x(100000), 0),
      landbank: formatNumber(x(100000), 0),
      gcash: formatNumber(x(50000), 0),
    },
  });
