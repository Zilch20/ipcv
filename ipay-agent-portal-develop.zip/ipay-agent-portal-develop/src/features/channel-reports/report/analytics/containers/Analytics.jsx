import React from 'react';

import {
  HiChartBar,
  HiChartPie,
  HiClipboardList,
  HiOfficeBuilding,
} from 'react-icons/hi';

import { BarChart, PieChart } from 'ui/chart';
import { Button, CountCard, SkeletonLoader } from 'ui/components';

import { useGetAnalyticsData } from '../_hooks';

function Analytics() {
  const [isLoading, isFetching, data] = useGetAnalyticsData();

  const [graph, setGraph] = React.useState('pie');

  const {
    stats = [],
    gcash = 0,
    paymaya = 0,
    landbank = 0,
    total_transactions = 0,
  } = data || {};

  const handleOnSetGraph = (type) => (e) => {
    e.preventDefault();
    setGraph(type);
  };

  const renderGraph = {
    pie: (
      <PieChart
        data={stats}
        height="h-[220px]"
        value="count"
        category="label"
        isLoading={isLoading}
        isFetching={isFetching}
      />
    ),
    bar: (
      <BarChart
        data={stats}
        height="h-[220px]"
        value="count"
        category="label"
        isLoading={isLoading}
        isFetching={isFetching}
      />
    ),
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-5 gap-3">
      <div className="col-span-1 lg:col-span-2">
        <div className="card space-y-2 h-full">
          <div className="flex items-center">
            <SkeletonLoader isLoading={isLoading}>
              <h4 className="card-title">Top Transactions</h4>
            </SkeletonLoader>
            <div className="ml-auto">
              <SkeletonLoader isLoading={isLoading}>
                <div className="space-x-1 flex items-center">
                  <Button
                    size="xs"
                    color="light"
                    focus={graph === 'pie'}
                    className="shadow-inner"
                    onClick={handleOnSetGraph('pie')}
                    icon={<HiChartPie className="h-5 w-5" />}
                  />
                  <Button
                    size="xs"
                    color="light"
                    focus={graph === 'bar'}
                    className="shadow-inner"
                    onClick={handleOnSetGraph('bar')}
                    icon={<HiChartBar className="h-5 w-5" />}
                  />
                </div>
              </SkeletonLoader>
            </div>
          </div>
          {renderGraph[graph]}
        </div>
      </div>
      <div className="col-span-1 lg:col-span-3">
        <div className="grid grid-cols-2 gap-3 h-full">
          <CountCard
            isLoading={isLoading}
            value={total_transactions}
            title="Total Transactions"
            containerClassName="items-start"
            iconContainerClassName="h-full flex items-end"
            icon={<HiClipboardList className="h-12 w-12 text-white" />}
          />
          <div className="grid grid-cols-1 gap-3">
            <CountCard
              isLoading={isLoading}
              value={paymaya}
              title="Channel"
              icon={<HiOfficeBuilding className="h-7 w-7 text-white" />}
            />
            <CountCard
              isLoading={isLoading}
              value={landbank}
              title="Channel"
              icon={<HiOfficeBuilding className="h-7 w-7 text-white" />}
            />
            <CountCard
              isLoading={isLoading}
              value={gcash}
              title="Channel"
              icon={<HiOfficeBuilding className="h-7 w-7 text-white" />}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
Analytics.defaultProps = {};

Analytics.propTypes = {};

export default Analytics;
