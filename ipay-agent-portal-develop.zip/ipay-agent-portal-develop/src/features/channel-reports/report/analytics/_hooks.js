import { useQuery } from '@tanstack/react-query';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetAnalyticsData = () => {
  const {
    isLoading,
    isFetching,
    data = {},
  } = useQuery([c.GET_ANALYTICS_DATA], actions.getAnalytics);

  return [isLoading, isFetching, data];
};
