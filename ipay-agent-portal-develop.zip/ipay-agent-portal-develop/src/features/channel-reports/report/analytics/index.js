import Analytics from './containers/Analytics';

export default Analytics;
