const rootConst = 'CHANNEL_REPORT';

export const GET_ANALYTICS_DATA = `${rootConst}/GET_ANALYTICS_DATA`;
