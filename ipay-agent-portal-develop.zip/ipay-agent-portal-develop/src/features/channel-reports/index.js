import ChannelReports from './_Routes';

export default ChannelReports;
