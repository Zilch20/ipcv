import React from 'react';

import qs from 'qs';
import { useLocation, useNavigate } from 'react-router-dom';

import { removeEmpty } from 'utils';

function useCustomNavigate() {
  const nav = useNavigate();

  const { search } = useLocation();

  const navigate = React.useCallback((url, args = false) => {
    if (args) {
      nav({
        pathname: url,
        search: `?${qs.stringify(removeEmpty(args))}`,
      });
      return;
    }

    nav({
      pathname: url,
      search,
    });
  }, []);

  return navigate;
}

export default useCustomNavigate;
