import React from 'react';

import qs from 'qs';
import { useLocation, useSearchParams } from 'react-router-dom';

import { removeEmpty } from 'utils';

let timer;

const useSetQuery = (INIT_STATE, prefix = 'query') => {
  const { state } = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  const x = qs.parse(searchParams.get(prefix));

  const [filter, setFilter] = React.useState({
    ...INIT_STATE,
    ...x,
  });

  const updateQuery = React.useCallback((args, cb) => {
    setFilter(args);
    searchParams.set(prefix, qs.stringify(removeEmpty(args)));
    searchParams.sort();
    setTimeout(() => {
      setSearchParams(searchParams, { state });
      if (cb) cb(searchParams.toString());
    }, 10);
  }, []);

  React.useEffect(() => {
    if (!searchParams.has(prefix)) {
      searchParams.set(prefix, qs.stringify(removeEmpty(INIT_STATE)));
      setTimeout(() => {
        setSearchParams(searchParams, { state });
      }, 10);
    }
    return () => {
      clearTimeout(timer);
      searchParams.delete(prefix);
    };
  }, []);

  return [
    removeEmpty({
      ...filter,
      page: `${filter?.page || ''}`,
      per_page: `${filter?.per_page || ''}`,
    }),
    updateQuery,
  ];
};

export default useSetQuery;
