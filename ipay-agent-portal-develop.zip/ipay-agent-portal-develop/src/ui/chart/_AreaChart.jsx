import React from "react";

import PropTypes from "prop-types";
import ApexChart from "react-apexcharts";

import { parseNumber, jsUcFirst, formatNumber } from "utils";
import { EmptyState, PageLoader, SkeletonLoader } from "ui/components";

export const COLORS = ["#454CB5", "#7d82cb", "#c7c9e9", "#d7d7d7"];

const opts = {
  chart: {
    zoom: {
      enabled: false,
    },
    toolbar: {
      show: false,
    },
  },
  tooltip: {
    enabled: true,
    y: {
      formatter: (i) => formatNumber(i, 0),
      title: {
        formatter: (i) => i,
      },
    },
  },
  dataLabels: {
    enabled: false,
  },
  grid: {
    padding: {
      left: 20,
      right: 10,
    },
    row: {
      colors: ["#f1f1f1", "transparent"], // takes an array which will be repeated on columns
      opacity: 0.5,
    },
    xaxis: {
      lines: {
        show: false,
      },
    },
  },
  theme: {
    mode: "light",
    palette: "palette1",
    monochrome: {
      enabled: false,
      color: "#255aee",
      shadeTo: "dark",
      shadeIntensity: 0.65,
    },
  },
  stroke: {
    curve: "smooth",
  },
  markers: {
    size: 5,
    strokeWidth: 0,
  },
  legend: {
    markers: {
      offsetX: -1,
      width: 12,
      height: 12,
      radius: 12,
    },
    itemMargin: {
      vertical: 0,
      horizontal: 15,
    },
    fontSize: "15px",
    fontWeight: "500",
    fontFamily: "Poppins, Arial",
  },
  colors: COLORS,
};

function AreaChart({
  data,
  grid,
  name,
  xaxis,
  value,
  height,
  legend,
  colors,
  category,
  isLoading,
  isFetching,
  ...rest
}) {
  const { markers, ...legendRest } = legend || {};

  const [rows, setRows] = React.useState([]);

  const getSeries = () => {
    let sr = [];
    if (Array.isArray(value)) {
      sr = value?.map((i) => ({
        name: jsUcFirst(i),
        data: rows?.map((x) => parseNumber(x[i])),
      }));
      return sr;
    }
    sr = [
      {
        name,
        data: rows?.map((i) => parseNumber(i[value])),
      },
    ];
    return sr;
  };

  const options = {
    ...opts,
    ...rest,
    xaxis: {
      categories: rows?.map((i) => i[category]),
      ...xaxis,
    },
    grid: {
      ...opts.grid,
      ...grid,
    },
    legend: {
      ...opts?.legend,
      markers: {
        ...opts?.markers,
        ...markers,
      },
      ...legendRest,
    },
  };

  React.useLayoutEffect(() => {
    if (!isLoading && !isFetching) {
      setRows(data);
    }
  }, [JSON.stringify(data), isLoading, isFetching]);

  return (
    <div className={`relative w-full ${height}`}>
      <SkeletonLoader isLoading={isLoading}>
        {rows?.length > 0 ? (
          <div className="w-full h-full relative place-content-evenly">
            {isFetching && (
              <div className="absolute bg-white bg-opacity-25 top-0 rounded left-1/2 -translate-x-1/2 z-10 h-full w-full flex">
                <div className="m-auto">
                  <PageLoader
                    className="px-2 py-1 rounded-sm bg-white drop-shadow"
                    labelClassName="text-base"
                    label="Please wait..."
                  />
                </div>
              </div>
            )}
            <ApexChart
              type="area"
              height="100%"
              options={options}
              series={getSeries()}
            />
          </div>
        ) : (
          <EmptyState />
        )}
      </SkeletonLoader>
    </div>
  );
}

AreaChart.defaultProps = {
  data: [],
  grid: {},
  xaxis: {},
  legend: {},
  name: "Data",
  value: "count",
  colors: COLORS,
  height: "h-130",
  isLoading: false,
  isFetching: false,
  category: "label",
};

AreaChart.propTypes = {
  height: PropTypes.string,
  isLoading: PropTypes.bool,
  isFetching: PropTypes.bool,
  category: PropTypes.string,
  colors: PropTypes.oneOfType([
    PropTypes.instanceOf(Array),
    PropTypes.instanceOf(Function),
  ]),
  data: PropTypes.instanceOf(Array),
  grid: PropTypes.instanceOf(Object),
  xaxis: PropTypes.instanceOf(Object),
  legend: PropTypes.instanceOf(Object),
  name: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Array)]),
};

export default React.memo(AreaChart);
