import React from "react";

import PropTypes from "prop-types";
import ApexChart from "react-apexcharts";

import { EmptyState, PageLoader, SkeletonLoader } from "ui/components";
import { formatNumber, jsUcFirst, parseNumber } from "utils";

export const COLORS = ["#454CB5", "#7d82cb", "#c7c9e9", "#d7d7d7"];

const opts = {
  chart: {
    zoom: {
      enabled: false,
    },
    toolbar: {
      show: false,
    },
  },
  tooltip: {
    enabled: true,
    y: {
      formatter: (i) => formatNumber(i, 0),
      title: {
        formatter: (i) => i,
      },
    },
  },
  plotOptions: {
    pie: {
      donut: {
        size: "45%",
      },
      customScale: 1,
      expandOnClick: true,
    },
  },
  dataLabels: {
    enabled: true,
  },
  theme: {
    mode: "light",
    palette: "palette1",
    monochrome: {
      enabled: false,
      color: "#255aee",
      shadeTo: "dark",
      shadeIntensity: 0.65,
    },
  },
  stroke: {
    width: 0,
  },
  markers: {
    size: 5,
    strokeWidth: 0,
  },
  legend: {
    markers: {
      offsetX: -1,
      width: 12,
      height: 12,
      radius: 12,
    },
    itemMargin: {
      vertical: 3,
      horizontal: 15,
    },
    fontSize: "15px",
    fontWeight: "500",
    fontFamily: "Poppins, Arial",
  },
  colors: COLORS,
};

function PieChart({
  data,
  name,
  value,
  height,
  legend,
  category,
  isLoading,
  isFetching,
  ...rest
}) {
  const { markers, ...legendRest } = legend || {};

  const [rows, setRows] = React.useState([]);

  const getSeries = () => rows?.map((i) => parseNumber(i[value]));

  const options = {
    ...opts,
    ...rest,
    labels: rows?.map((i) => jsUcFirst(i[category])),
    legend: {
      ...opts?.legend,
      markers: {
        ...opts?.markers,
        ...markers,
      },
      ...legendRest,
    },
  };

  React.useLayoutEffect(() => {
    if (!isLoading && !isFetching) {
      setRows(data);
    }
  }, [JSON.stringify(data), isLoading, isFetching]);

  return (
    <div className={`relative w-full  ${height}`}>
      <SkeletonLoader isLoading={isLoading}>
        {rows?.length > 0 ? (
          <div className="w-full h-full relative place-content-evenly">
            {isFetching && (
              <div className="absolute bg-white bg-opacity-25 top-0 rounded left-1/2 -translate-x-1/2 z-10 h-full w-full flex">
                <div className="m-auto">
                  <PageLoader
                    className="px-2 py-1 rounded-sm bg-white drop-shadow"
                    labelClassName="text-base"
                    label="Please wait..."
                  />
                </div>
              </div>
            )}
            <ApexChart
              type="donut"
              height="100%"
              options={options}
              series={getSeries()}
            />
          </div>
        ) : (
          <EmptyState />
        )}
      </SkeletonLoader>
    </div>
  );
}
PieChart.defaultProps = {
  data: [],
  legend: {},
  name: "Data",
  value: "count",
  height: "h-130",
  isLoading: false,
  isFetching: false,
  category: "label",
};

PieChart.propTypes = {
  height: PropTypes.string,
  isLoading: PropTypes.bool,
  isFetching: PropTypes.bool,
  category: PropTypes.string,
  data: PropTypes.instanceOf(Array),
  legend: PropTypes.instanceOf(Object),
  name: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Array)]),
};

export default React.memo(PieChart);
