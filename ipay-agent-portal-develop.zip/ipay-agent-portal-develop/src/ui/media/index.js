import ViewImage from './_ViewImage';
import AvatarImage from './_AvatarImage';

export { AvatarImage, ViewImage };
