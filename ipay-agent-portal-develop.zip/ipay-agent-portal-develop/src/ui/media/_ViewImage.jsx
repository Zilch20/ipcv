import React from "react";

import cn from "classnames";
import PropTypes from "prop-types";

import placeholder from "assets/images/no-image-placeholder.svg";

function IconLoader() {
  return (
    <svg className="animate-spin text-gray-400" fill="none" viewBox="0 0 24 24">
      <circle
        className="opacity-25"
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
      />
    </svg>
  );
}

function ViewImage({ src, defaultSrc, className }) {
  const [url, setUrl] = React.useState(src);
  const [imageLoaded, setImageLoaded] = React.useState(false);

  const handleLoad = () => {
    setTimeout(() => {
      setImageLoaded(true);
    }, 1000);
  };

  const handleError = () => {
    setTimeout(() => {
      setUrl(defaultSrc);
      setImageLoaded(true);
    }, 1000);
  };

  React.useLayoutEffect(() => {
    if (src !== "") {
      setUrl(src);
    }
    return () => {
      setUrl("");
    };
  }, [src]);

  return (
    <div
      className={cn(
        "group relative bg-gray-100 overflow-hidden flex items-center justify-center rounded",
        {
          [`${className}`]: className,
          "w-24 h-24": !className,
        }
      )}
    >
      {!imageLoaded && (
        <div className="absolute h-full w-full">
          <div className="flex h-full w-full justify-center items-center">
            <div className="w-4 h-4">
              <IconLoader />
            </div>
          </div>
        </div>
      )}
      <img
        src={url}
        alt=""
        className="object-contain h-full w-auto"
        onLoad={handleLoad}
        onError={handleError}
      />
    </div>
  );
}
ViewImage.defaultProps = {
  src: "",
  className: "",
  defaultSrc: placeholder, // https://via.placeholder.com/128?text=Img,
};

ViewImage.propTypes = {
  src: PropTypes.string,
  defaultSrc: PropTypes.string,
  className: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
};

export default ViewImage;
