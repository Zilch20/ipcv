import React from 'react';

import Avatar from 'react-avatar';
import PropTypes from 'prop-types';

function AvatarImage({ className, name, testSize, src, size, ...rest }) {
  return (
    <>
      <Avatar
        name={name}
        alt={name}
        className={className}
        maxInitials={2}
        textSizeRatio={testSize}
        src={src}
        size={size}
        {...rest}
      />
    </>
  );
}
AvatarImage.defaultProps = {
  className: '',
  name: 'Name',
  testSize: 2,
  src: null,
  size: '50px',
};

AvatarImage.propTypes = {
  className: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  name: PropTypes.string,
  testSize: PropTypes.number,
  src: PropTypes.oneOfType([PropTypes.string]),
  size: PropTypes.string,
};

export default AvatarImage;
