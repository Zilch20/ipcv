import React from 'react';

import cn from 'classnames';
import PropTypes from 'prop-types';
import { ImRadioChecked } from 'react-icons/im';

import { STEP_PROVIDER } from './_context';

function Step({ value, icon: Icon, label, ...rest }) {
  const type = React.useContext(STEP_PROVIDER);

  const { isActive, isLast, onClick } = rest;
  const handleOnClick = (e) => {
    e.preventDefault();
    onClick(value);
  };

  return (
    <div
      className={cn('flex', {
        'flex-col gap-2': type === 'vertical',
        'flex-row items-center gap-5': type === 'horizontal',
        'cursor-pointer': onClick && isActive,
        'pointer-events-none': !isActive,
      })}
      onClick={handleOnClick}
      role="presentation"
    >
      <div
        className={cn('flex', {
          'flex-row justify-start items-center space-x-3': type === 'vertical',
          'flex-col items-center gap-2': type === 'horizontal',
        })}
      >
        {isActive ? (
          <ImRadioChecked className="w-4 h-4 text-primary-500" />
        ) : (
          <span className="w-4 h-4 bg-gray-200 rounded-full" />
        )}
        <div className={cn('flex items-center gap-2')}>
          {Icon && (
            <Icon
              className={cn('w-5 h-5', {
                'text-gray-200': !isActive,
              })}
            />
          )}
          <h4
            className={cn('text-sm font-semibold', {
              'text-gray-300': !isActive,
            })}
          >
            {label}
          </h4>
        </div>
      </div>
      {!isLast && (
        <span
          className={cn('border-dashed', {
            'border-primary-500': isActive,
            'border-l-2 h-10 ml-[7px]': type === 'vertical',
            'border-t-2 w-28': type === 'horizontal',
          })}
        />
      )}
    </div>
  );
}
Step.defaultProps = {
  value: 'value',
  label: 'label',
  icon: false,
};

Step.propTypes = {
  value: PropTypes.string,
  label: PropTypes.string,
  icon: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.element,
    PropTypes.instanceOf(Object),
  ]),
};

export default Step;
