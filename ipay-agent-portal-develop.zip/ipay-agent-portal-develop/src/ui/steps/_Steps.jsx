import React, { Children, cloneElement } from 'react';

import cn from 'classnames';
import PropTypes from 'prop-types';

import { STEP_PROVIDER } from './_context';

function Steps({ activeValue, type, onClick, children }) {
  const activeIndex = children?.findIndex(
    (i) => i?.props?.value === activeValue
  );

  return (
    <STEP_PROVIDER.Provider value={type}>
      <div
        className={cn('flex', {
          'flex-col gap-2': type === 'vertical',
          'flex-row gap-5': type === 'horizontal',
        })}
      >
        {Children.map(children, (child, index) =>
          cloneElement(child, {
            isActive: index <= activeIndex,
            isLast: index === children?.length - 1,
            onClick,
          })
        )}
      </div>
    </STEP_PROVIDER.Provider>
  );
}

Steps.defaultProps = {
  activeValue: '',
  onClick: false,
  type: 'vertical',
};

Steps.propTypes = {
  type: PropTypes.string,
  activeValue: PropTypes.string,
  onClick: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.instanceOf(Function),
  ]),
  children: PropTypes.instanceOf(Object).isRequired,
};

export default Steps;
