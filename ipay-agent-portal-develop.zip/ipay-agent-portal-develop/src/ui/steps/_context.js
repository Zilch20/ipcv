import React from 'react';

export const STEP_PROVIDER = React.createContext();
