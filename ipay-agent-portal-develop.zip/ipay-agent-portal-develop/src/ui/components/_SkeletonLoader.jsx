import React, { forwardRef } from 'react';

import PropTypes from 'prop-types';
import cn from 'classnames';

const SkeletonLoader = forwardRef((props, ref) => {
  const { isLoading, color, className, children } = props;

  const cln = cn('animate-pulse shadow-inner rounded h-full', color);

  return (
    <div
      ref={ref}
      className={cn({
        [cln]: isLoading,
        'h-full': !isLoading,
        [className]: className,
      })}
      id="skeleton-container"
    >
      <div
        id="skeleton-inner"
        className={cn({
          invisible: isLoading,
          'h-full': !isLoading,
        })}
      >
        {children}
      </div>
    </div>
  );
});

SkeletonLoader.displayName = 'Skeleton';

SkeletonLoader.defaultProps = {
  className: '',
  children: null,
  isLoading: true,
  color: 'bg-gray-200',
};

SkeletonLoader.propTypes = {
  color: PropTypes.string,
  children: PropTypes.node,
  isLoading: PropTypes.bool,
  className: PropTypes.string,
};

export default SkeletonLoader;
