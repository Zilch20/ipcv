import React from "react";

import PropTypes from "prop-types";

import TabNavigation from "./_TabNavigation";

function CardWithTabs({ tabs, selected, onClick, children }) {
  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <TabNavigation
        tabs={tabs}
        selected={selected}
        onClick={onClick}
        containerClassName="-mb-[1px]"
        className="rounded-b-none rounded-t-md px-4"
      />
      <div className="card rounded-tl-none flex flex-1 overflow-hidden">
        <div className="overflow-y-auto flex-1 flex flex-col">{children}</div>
      </div>
    </div>
  );
}
CardWithTabs.defaultProps = {
  tabs: [],
  selected: "",
  onClick: () => {},
  children: <></>,
};

CardWithTabs.propTypes = {
  selected: PropTypes.string,
  tabs: PropTypes.instanceOf(Array),
  onClick: PropTypes.instanceOf(Function),
  children: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.element,
    PropTypes.instanceOf(Object),
  ]),
};

export default CardWithTabs;
