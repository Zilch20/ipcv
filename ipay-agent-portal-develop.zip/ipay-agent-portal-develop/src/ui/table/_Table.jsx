import React from 'react';

import cn from 'classnames';
import PropTypes from 'prop-types';
import { HiSortAscending, HiSortDescending } from 'react-icons/hi';

import { EmptyState, PageLoader, SkeletonLoader } from 'ui/components';

import { TD_PROVIDER } from './_constants';

function Table({
  id,
  data,
  children,
  selected,
  isLoading,
  withHover,
  isFetching,
  tClassName,
  pagination,
  showHeader,
  selectedKey,
  onSelectRow,
  trClassName,
  theadClassName,
  tbodyClassName,
  containerClassName,
}) {
  const [rows, setRows] = React.useState([]);

  const handleSelectRow = (value) => (e) => {
    e.preventDefault();
    e.stopPropagation();
    onSelectRow(value);
  };

  React.useEffect(() => {
    if (!isLoading) {
      setRows(data);
    }
  }, [data, isLoading]);

  return (
    <div className="relative w-full h-full md:min-h-0 overflow-hidden rounded">
      <SkeletonLoader
        className="w-full h-full"
        isLoading={rows?.length === 0 && isLoading}
      >
        {isFetching && (
          <div className="absolute bg-white bg-opacity-40 top-0 rounded left-1/2 -translate-x-1/2 z-20 h-full w-full flex">
            <div className="m-auto">
              <PageLoader
                labelClassName="text-base px-3 py-2"
                label="Please wait..."
              />
            </div>
          </div>
        )}
        {rows?.length === 0 && !isLoading && !isFetching && (
          <div className="absolute bg-white bg-opacity-40 top-0 rounded left-1/2 -translate-x-1/2 z-20 h-full w-full flex">
            <div className="m-auto">
              <EmptyState />
            </div>
          </div>
        )}
        <div
          id="gt-table-container"
          className={cn('gt-table-container', {
            [containerClassName]: containerClassName,
          })}
        >
          <div id={id} className="gt-table-inner-container">
            <table
              className={cn('gt-table', {
                [tClassName]: tClassName,
              })}
            >
              {showHeader && (
                <thead
                  className={cn('gt-table-head', {
                    [theadClassName]: theadClassName,
                  })}
                >
                  <tr>
                    {children?.map(({ props }, i) => {
                      const { className = false, label } = props || {};
                      const $i = i;
                      const iconClassName =
                        'h-[15px] w-[15px] text-secondary-500';

                      const sortType = 'desc';

                      return (
                        <th
                          key={$i}
                          className={cn('', {
                            [className]: className,
                          })}
                        >
                          {!label ? null : (
                            <div className="flex items-center gap-2">
                              {label}
                              {sortType === 'asc' ? (
                                <HiSortAscending className={iconClassName} />
                              ) : (
                                <HiSortDescending className={iconClassName} />
                              )}
                            </div>
                          )}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
              )}
              <tbody
                className={cn('gt-table-body', {
                  [tbodyClassName]: tbodyClassName,
                })}
              >
                {rows?.length < 1 ? (
                  <tr />
                ) : (
                  rows?.map((item) => {
                    const isSelected = `${selected}` === `${item[selectedKey]}`;
                    const current_page = pagination?.current_page ?? 0;
                    const per_page = pagination?.per_page ?? 0;

                    return (
                      <tr
                        key={item?.[selectedKey]}
                        id={item?.[selectedKey]}
                        className={cn('gt-table-row', {
                          'gt-table-row-selected': isSelected,
                          [trClassName]: trClassName,
                          'gt-table-row-hover': withHover && !isSelected,
                        })}
                        onClick={onSelectRow ? handleSelectRow(item) : () => {}}
                      >
                        {children?.map((ci, i) => {
                          const { className = false, index } = ci?.props || {};
                          const $i = i;
                          if (index === '_count') {
                            return (
                              <td
                                key={index}
                                className={cn({
                                  [className]: className,
                                })}
                              >
                                <span className="font-semibold">
                                  {(current_page - 1) * per_page + i + 1}.
                                </span>
                              </td>
                            );
                          }
                          return (
                            <td
                              key={$i}
                              className={cn({
                                [className]: className,
                              })}
                            >
                              <TD_PROVIDER.Provider value={item}>
                                {ci}
                              </TD_PROVIDER.Provider>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </SkeletonLoader>
    </div>
  );
}
Table.defaultProps = {
  data: [],
  selected: '',
  isLoading: false,
  showHeader: true,
  isFetching: false,
  withHover: false,
  tClassName: false,
  selectedKey: 'id',
  pagination: false,
  trClassName: false,
  onSelectRow: false,
  id: 'generic-table',
  theadClassName: false,
  tbodyClassName: false,
  containerClassName: false,
};

Table.propTypes = {
  id: PropTypes.string,
  isLoading: PropTypes.bool,
  withHover: PropTypes.bool,
  isFetching: PropTypes.bool,
  showHeader: PropTypes.bool,
  selectedKey: PropTypes.string,
  data: PropTypes.instanceOf(Array),
  pagination: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.instanceOf(Object),
  ]),
  children: PropTypes.instanceOf(Array).isRequired,
  onSelectRow: PropTypes.oneOfType([PropTypes.func, PropTypes.bool]),
  selected: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  tClassName: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  trClassName: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  theadClassName: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  tbodyClassName: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  containerClassName: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
};

export default Table;
