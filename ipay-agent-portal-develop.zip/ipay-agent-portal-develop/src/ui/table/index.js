import Table from './_Table';
import Column from './_Column';

export { Column };
export default Table;
