import React from "react";

import PropTypes from "prop-types";

import { TD_PROVIDER } from "./_constants";

const getCell = (item, i) => {
  const renderItem = `${item?.[i]}` === "0" ? item?.[i] : item?.[i] || "--";
  try {
    return typeof i === "function" ? i(item) : renderItem;
  } catch (err) {
    return "";
  }
};

function Column({ value, label, className }) {
  const data = React.useContext(TD_PROVIDER);

  return getCell(data, value, label, className);
}

Column.defaultProps = {
  label: false,
  className: false,
};

Column.propTypes = {
  value: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Function),
  ]),
  label: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  className: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
};

export default Column;
