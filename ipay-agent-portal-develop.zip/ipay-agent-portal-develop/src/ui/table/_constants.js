import React from 'react';

export const TD_PROVIDER = React.createContext();
