import React from 'react';

import ToastMarker from 'ui/toast';
import { DrawerMarker } from 'ui/drawer';
import { ScreenLoader } from 'ui/components';
import { ROOT_SESSION } from 'context/session/index';
import { AlertMarker, ModalMarker } from 'ui/modals';

const Public = React.lazy(() => import('pages/public'));
const Private = React.lazy(() => import('pages/private'));

function App() {
  const { isAuthenticated } = React.useContext(ROOT_SESSION);

  return (
    <>
      <ToastMarker />
      <AlertMarker />
      <ModalMarker />
      <DrawerMarker />
      <React.Suspense fallback={<ScreenLoader />}>
        {isAuthenticated ? <Private /> : <Public />}
      </React.Suspense>
    </>
  );
}

export default App;
