import React from "react";

import cn from "classnames";
import PropTypes from "prop-types";

function PageWrapper({
  children,
  className,
  withScroll,
  outerClassName,
  innerClassName,
}) {
  return (
    <div
      className={cn("page-outer-wrapper", {
        [outerClassName]: outerClassName,
      })}
    >
      <div
        className={cn("page-inner-wrapper", {
          [innerClassName]: innerClassName,
        })}
      >
        <div
          className={cn("page-wrapper", {
            "with-scroll": !withScroll,
            [className]: className,
          })}
        >
          {children}
        </div>
      </div>
    </div>
  );
}
PageWrapper.defaultProps = {
  children: <></>,
  className: false,
  withScroll: false,
  outerClassName: false,
  innerClassName: false,
};

PageWrapper.propTypes = {
  withScroll: PropTypes.bool,
  children: PropTypes.instanceOf(Object),
  className: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  innerClassName: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  outerClassName: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
};

export default PageWrapper;
