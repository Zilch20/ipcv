import React from 'react';

import cn from 'classnames';
import PropTypes from 'prop-types';
import { HiOutlineArrowSmLeft } from 'react-icons/hi';

import { Button, SkeletonLoader } from 'ui/components';

function PageHeader({ title, goBack, isLoading, className, render }) {
  const handleOnGoBack = (e) => {
    e.preventDefault();
    goBack();
  };

  return (
    <div className="md:flex gap-3 items-center min-h-[42px]">
      <div
        className={cn('flex items-center space-x-2', {
          'cursor-pointer': goBack,
        })}
      >
        {goBack && (
          <SkeletonLoader isLoading={isLoading} className="h-auto">
            <div>
              <Button
                label={false}
                className="p-0"
                icon={
                  <div
                    className={cn(
                      'flex justify-center items-center',
                      'ring-1 ring-inset ring-gray-300',
                      'hover:ring-0 group hover:bg-secondary-500',
                      'overflow-hidden rounded w-8 h-8',
                      'transform duration-200 ease-in-out'
                    )}
                  >
                    <HiOutlineArrowSmLeft className="group-hover:text-white h-6 w-6 text-secondary-500" />
                  </div>
                }
                onClick={handleOnGoBack}
              />
            </div>
          </SkeletonLoader>
        )}
        <SkeletonLoader isLoading={isLoading}>
          <h4
            className={cn('text-lg font-semibold text-secondary-500', {
              [className]: className,
            })}
          >
            {title}
          </h4>
        </SkeletonLoader>
      </div>
      {render && (
        <div className="w-full mt-2 md:mt-0 md:w-auto md:ml-auto">{render}</div>
      )}
    </div>
  );
}
PageHeader.defaultProps = {
  title: false,
  render: false,
  goBack: false,
  isLoading: false,
  className: false,
};

PageHeader.propTypes = {
  isLoading: PropTypes.bool,
  title: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.bool,
    PropTypes.element,
  ]),
  className: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
  render: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.element,
    PropTypes.instanceOf(Object),
  ]),
  goBack: PropTypes.oneOfType([PropTypes.instanceOf(Function), PropTypes.bool]),
};

export default PageHeader;
