import React from 'react';

import cn from 'classnames';
import PropTypes from 'prop-types';
import { BiSliderAlt } from 'react-icons/bi';
import { debounce } from 'lodash';

import { Button, SkeletonLoader } from 'ui/components';
import { FormInputSearch } from 'ui/forms';

function FilterWrapper({
  form,
  render,
  children,
  onSubmit,
  isLoading,
  className,
  placeholder,
  defaultValue,
  inlineFilter,
  withoutFilter,
  hideSerachLabel,
}) {
  const [show, setShow] = React.useState(false);
  const [animate, setAnimate] = React.useState(false);

  const [filter, setFilter] = React.useState(form);

  const dispatchSearchByKeyword = React.useCallback(
    debounce(onSubmit, 500),
    []
  );

  const onChangeSearch = ($v) => {
    const v = $v();
    const x = {
      ...filter,
      ...v,
    };
    setFilter(x);
    dispatchSearchByKeyword(x);
  };

  const handleOnSubmit = (e) => {
    e.preventDefault();
    document.body.removeAttribute('class');
    setAnimate(false);
    onSubmit(filter);
    setTimeout(() => {
      setShow(false);
    }, 300);
  };

  const handleOnClear = (e) => {
    e.preventDefault();
    setFilter(defaultValue);
  };

  const handleOnOpenDrawer = (e) => {
    e.preventDefault();
    document.body.className = 'overflow-hidden';
    setShow(true);
    setTimeout(() => {
      setAnimate(true);
    }, 300);
  };

  const handleOnCloseDrawer = (e) => {
    if (e) e.preventDefault();
    document.body.removeAttribute('class');
    setAnimate(false);
    setTimeout(() => {
      setShow(false);
    }, 300);
  };

  const onChange = ($v) => {
    if (typeof $v === 'function') {
      setFilter({
        ...filter,
        ...$v(),
      });
      return;
    }

    const [key] = Object.keys($v);
    const v = $v[key]();
    setFilter({
      ...filter,
      ...v,
    });
  };

  React.useEffect(() => {
    setFilter(form);
  }, [JSON.stringify(form)]);

  return (
    <>
      <div className="flex flex-col md:flex-row items-center gap-3">
        <div className="flex items-center space-x-2 w-full">
          <SkeletonLoader isLoading={isLoading}>
            <div className={className}>
              <FormInputSearch
                name="keyword"
                withClearButton
                onChange={onChangeSearch}
                placeholder={placeholder}
                value={filter?.keyword || ''}
              />
            </div>
          </SkeletonLoader>
          {!withoutFilter && (
            <SkeletonLoader isLoading={isLoading}>
              <Button
                onClick={handleOnOpenDrawer}
                className="btn md primary text-sm"
                title="Advance Filters"
                label={
                  <div className="flex md:gap-2">
                    <BiSliderAlt className="w-5 h-5" />
                    {!hideSerachLabel && (
                      <span className="hidden md:block">Advance</span>
                    )}
                  </div>
                }
              />
            </SkeletonLoader>
          )}
          {inlineFilter}
        </div>
        {render && <div className="ml-auto">{render}</div>}
      </div>
      {show && children && (
        <form
          onSubmit={handleOnSubmit}
          className="fixed inset-0 overflow-hidden z-40 w-full h-full"
        >
          <div className="fixed inset-0 overflow-hidden">
            <div
              role="presentation"
              onClick={handleOnCloseDrawer}
              className={cn(
                'fixed inset-0 bg-black transition-opacity bg-opacity-30 ease-in-out',
                {
                  'opacity-100 duration-300': animate,
                  'opacity-0 duration-200': !animate,
                }
              )}
            />
            <div className="fixed inset-y-0 max-w-full right-0 flex">
              <div
                className={cn(
                  'relative w-screen max-w-sm transition duration-200 ease-in-out',
                  {
                    'translate-x-0': animate,
                    'translate-x-full': !animate,
                  }
                )}
              >
                <div className="flex flex-col bg-white w-full h-full py-5">
                  <div className="flex items-center px-5">
                    <p className="text-xl text-black font-bold">
                      Advanced Search
                    </p>
                    <div className="ml-auto">
                      <button
                        type="button"
                        tabIndex="-1"
                        className="rounded-full transition duration-300 ease-in-out group outline-none group hover:bg-primary-500 p-1"
                        onClick={handleOnCloseDrawer}
                      >
                        <svg
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                          className="w-6 h-6 transition duration-300 ease-in-out group-hover:text-white text-primary-500 rounded-full"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth="4"
                            d="M6 18L18 6M6 6l12 12"
                          />
                        </svg>
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-col flex-1 overflow-auto px-5 space-y-3 pointer-events-auto">
                    <div className="flex-1 space-y-3 mt-3">
                      {typeof children === 'function' &&
                        children(filter, onChange)}
                    </div>
                    <div className="flex gap-3">
                      <Button
                        className="btn md outline w-full"
                        label="Clear"
                        onClick={handleOnClear}
                      />
                      <Button
                        type="submit"
                        label="Apply Filter"
                        className="btn md primary w-full"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      )}
    </>
  );
}
FilterWrapper.defaultProps = {
  form: {},
  className: '',
  render: false,
  children: null,
  isLoading: false,
  defaultValue: {},
  onSubmit: () => {},
  inlineFilter: false,
  withoutFilter: false,
  hideSerachLabel: false,
  placeholder: 'Search...',
};

FilterWrapper.propTypes = {
  placeholder: PropTypes.string,
  withoutFilter: PropTypes.bool,
  hideSerachLabel: PropTypes.bool,
  children: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Function),
  ]),
  render: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.string,
    PropTypes.element,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Function),
  ]),
  inlineFilter: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.string,
    PropTypes.element,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Function),
  ]),
  className: PropTypes.string,
  isLoading: PropTypes.bool,
  form: PropTypes.instanceOf(Object),
  onSubmit: PropTypes.instanceOf(Function),
  defaultValue: PropTypes.instanceOf(Object),
};

export default FilterWrapper;
