import React from "react";

import cn from "classnames";
import PropTypes from "prop-types";
import { HiArrowLeft } from "react-icons/hi";

import { Button } from "ui/components";

function ListPageWrapper({ children, render, title, isLoading }) {
  const [show, setShow] = React.useState(false);
  const [animate, setAnimate] = React.useState(false);

  const handleOnCloseDrawer = (e) => {
    if (e) e.preventDefault();
    document.body.removeAttribute("class");
    setAnimate(false);
    setTimeout(() => {
      setShow(false);
    }, 300);
  };

  const handleOnOpenDrawer = (e) => {
    e.preventDefault();
    document.body.className = "overflow-hidden";
    setShow(true);
    setTimeout(() => {
      setAnimate(true);
    }, 300);
  };

  const dispatchChild = React.useMemo(() => children, [children]);
  const dispatchRender = React.useMemo(() => render, [render]);

  return (
    <>
      {show && (
        <div className="fixed inset-0 flex z-20">
          <div
            className={cn(
              "fixed inset-0 bg-black transition-opacity bg-opacity-30 ease-in-out",
              {
                "opacity-100": animate,
                "opacity-0": !animate,
              }
            )}
          />
          <div className="fixed inset-y-0 max-w-full right-0 flex">
            <div
              className={cn(
                "relative w-screen transition duration-200 max-w-xs ease-in-out",
                {
                  "translate-x-0": animate,
                  "translate-x-full": !animate,
                }
              )}
            >
              <div className="card rounded p-3 space-y-3 flex flex-col h-full">
                <div className="flex">
                  <div className="flex items-center">
                    <h4 className="card-title">{title}</h4>
                    {isLoading && (
                      <svg
                        className="animate-spin h-5 w-5 text-primary-500 ml-auto"
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                      >
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        />
                      </svg>
                    )}
                  </div>
                  <div className="ml-auto">
                    <button
                      type="button"
                      tabIndex="-1"
                      className="rounded-full transition duration-300 ease-in-out group outline-none group hover:bg-primary-500 p-1"
                      onClick={handleOnCloseDrawer}
                    >
                      <svg
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        className="w-6 h-6 transition duration-300 ease-in-out group-hover:text-white text-primary-500 rounded-full"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="4"
                          d="M6 18L18 6M6 6l12 12"
                        />
                      </svg>
                    </button>
                  </div>
                </div>
                {dispatchRender}
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="flex h-full flex-1 overflow-hidden">
        <div className="flex gap-4 flex-1 overflow-hidden">
          <div className="hidden xl:flex flex-shrink-0 card p-3 space-y-3 flex-col xl:w-64 2xl:w-screen xl:max-w-xs overflow-hidden">
            <div className="flex items-center">
              <h4 className="card-title">{title}</h4>
              {isLoading && (
                <svg
                  className="animate-spin h-5 w-5 text-primary-500 ml-auto"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
              )}
            </div>
            {dispatchRender}
          </div>
          <div className="w-full flex flex-col flex-1 overflow-hidden">
            <div>
              <Button
                onClick={handleOnOpenDrawer}
                className="btn sm primary rounded-md rounded-b-none text-sm block xl:hidden px-4"
                title={`View ${title}`}
                icon={<HiArrowLeft className="w-4 h-4" />}
                label={`View ${title}`}
              />
            </div>
            <div className="card w-full flex flex-col flex-1 overflow-hidden rounded-tl-none xl:rounded-lg">
              {dispatchChild}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

ListPageWrapper.defaultProps = {
  render: null,
  children: null,
  isLoading: false,
  title: "List Name",
};

ListPageWrapper.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Function),
  ]),
  render: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.instanceOf(Object),
    PropTypes.instanceOf(Function),
  ]),
  isLoading: PropTypes.bool,
  title: PropTypes.string,
};

export default React.memo(ListPageWrapper);
