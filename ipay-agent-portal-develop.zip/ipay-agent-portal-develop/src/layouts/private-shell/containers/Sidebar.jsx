import React from 'react';

import cn from 'classnames';
import { BiArrowToLeft } from 'react-icons/bi';
import { useMatch, useNavigate } from 'react-router-dom';

import { useSideBarOutlet } from 'pages/private/_directory';

import Navigation from './Navigation';
import { SIDEBAR_PROVIDER } from '../_constants';

function Sidebar() {
  const navigate = useNavigate();
  const SIDEBAR_OUTLET = useSideBarOutlet();
  const parentMatch = useMatch('/:module_code/*');
  const { module_code = null } = parentMatch?.params || {};

  const isMounted = React.useRef(true);

  const { show, setShow } = React.useContext(SIDEBAR_PROVIDER);

  const [animate, setAnimate] = React.useState(false);

  const handleOnClose = (e) => {
    e.preventDefault();
    if (!isMounted.current) return;
    if (show) {
      setAnimate(false);
      document.body.removeAttribute('class');
      setTimeout(() => {
        setShow(false);
      }, 300);
    }
  };

  const handleOnCloseTab = () => {
    if (show) {
      setAnimate(false);
      setTimeout(() => {
        document.body.removeAttribute('class');
        setShow(false);
      }, 400);
    }
  };

  React.useEffect(() => {
    if (!isMounted.current) return;
    if (show) {
      document.body.className = 'overflow-hidden';
      setShow(show);
      setTimeout(() => {
        setAnimate(true);
      }, 300);
    }
  }, [show]);

  React.useEffect(() => {
    if (!module_code && SIDEBAR_OUTLET?.length > 0) {
      navigate(`${SIDEBAR_OUTLET[0]?.to}`);
    }
  }, [module_code]);

  return (
    <>
      {show && (
        <div className="fixed inset-0 flex z-20">
          <div
            role="presentation"
            onClick={handleOnClose}
            className={cn(
              'bg-black w-full transition-opacity duration-500 h-full fixed bg-opacity-40',
              {
                'opacity-100 ease-out': animate,
                'opacity-0 ease-in': !animate,
              }
            )}
          />
          <div className="flex flex-shrink-0 h-full">
            <div
              className={cn(
                'flex flex-col w-60 transition duration-200 relative',
                {
                  'translate-x-0 ease-out': animate,
                  '-translate-x-full ease-in': !animate,
                }
              )}
            >
              <Navigation
                module_code={module_code}
                onCloseCallback={handleOnCloseTab}
              />
              <div
                className={cn(
                  'absolute top-2 -right-10 transition duration-100',
                  {
                    'opacity-100 ease-out': animate,
                    'opacity-0 ease-in': !animate,
                  }
                )}
              >
                <a href="/" onClick={handleOnClose} className="outline-none">
                  <span className="sr-only">Close sidebar</span>
                  <BiArrowToLeft className="w-8 h-8 text-white" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
      <div className="hidden lg:flex">
        <div className="flex flex-shrink-0 z-20">
          <div className="flex flex-col lg:w-60 2xl:w-64">
            <Navigation module_code={module_code} />
          </div>
        </div>
      </div>
    </>
  );
}

Sidebar.defaultProps = {};

Sidebar.propTypes = {};

export default React.memo(Sidebar);
