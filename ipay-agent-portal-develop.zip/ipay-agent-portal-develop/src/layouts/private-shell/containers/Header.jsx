import React from 'react';

import { HiMenuAlt2 } from 'react-icons/hi';

import { AvatarImage } from 'ui/media';
import { Button } from 'ui/components';
import { BreadedNav } from 'context/breaded';
import { ROOT_PROFILE } from 'context/profile';
import { useSideBarOutlet } from 'pages/private/_directory';

import { SIDEBAR_PROVIDER } from '../_constants';

function Header() {
  const SIDEBAR_OUTLET = useSideBarOutlet();

  const profile = React.useContext(ROOT_PROFILE);
  const { setShow } = React.useContext(SIDEBAR_PROVIDER);

  const handleOnSideOpenBar = (e) => {
    e.preventDefault();
    setShow(true);
  };

  const { full_name = '', avatar } = profile || {};

  return (
    <>
      <div className="border-b border-gray-200 bg-white">
        <div className="flex items-center py-2 lg:py-3 px-4 lg:px-6">
          <div className="hidden lg:block">
            <BreadedNav main={SIDEBAR_OUTLET[0]?.to} />
          </div>
          <div className="block lg:hidden z-10">
            <Button
              size="sm"
              label={false}
              color="primary"
              onClick={handleOnSideOpenBar}
              icon={<HiMenuAlt2 className="h-5 w-5 !p-0" />}
            />
          </div>
          <div className="ml-auto flex items-center">
            <div className="flex-shrink-0 flex items-center space-x-2">
              <AvatarImage
                name={full_name}
                src={avatar}
                className="object-cover rounded-full"
                color="#252424"
                fgColor="#FFFFFF"
                size="28px"
              />
              <div className="capitalize">
                <h4 className="text-secondary-500 text-xs font-semibold">
                  {full_name}
                </h4>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="sticky top-0 z-10 bg-white block lg:hidden">
        <div className="px-4 py-2 flex items-center">
          <BreadedNav main={SIDEBAR_OUTLET[0]?.to} />
        </div>
      </div>
    </>
  );
}
Header.defaultProps = {};

Header.propTypes = {};

export default Header;
