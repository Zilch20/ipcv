import React from 'react';

import cn from 'classnames';
import PropTypes from 'prop-types';
import { TbLogout } from 'react-icons/tb';
import { HiChevronDown } from 'react-icons/hi';
import { Link, Navigate, useMatch } from 'react-router-dom';

import { Brand } from 'ui/components';
import { replaceAllString } from 'utils';
import { useSideBarMenu } from 'pages/private/_directory';

function Navigation({ module_code }) {
  const match = useMatch(`${module_code}/:sub_module_code/*`);
  const { sub_module_code = null } = match?.params || {};

  const sideBar = useSideBarMenu();

  const renderSubNav = React.useCallback(
    (rt) =>
      rt?.map((i) => {
        const { to, key, name } = i;
        const isActive = sub_module_code === key;

        return (
          <Link
            key={key}
            to={`${module_code}${to}`}
            className={cn(
              'z-20 group flex items-center py-[2px] gap-5 my-1',
              'ease-out-in transition duration-200',
              {
                'text-primary-500': isActive,
                'hover:text-primary-600': !isActive,
              },
              {
                'pointer-events-none': isActive,
              }
            )}
            title={name}
          >
            <div
              className={cn(
                'bg-primary-500 h-9 w-1 z-20 rounded-r',
                'ease-out-in transition transform duration-200',
                {
                  'opacity-100': isActive,
                  'opacity-0': !isActive,
                }
              )}
            />
            <div className="flex space-x-3 items-center">
              <div className="h-4 w-4 invisible" />
              <span className="text-xs lg:text-sm font-semibold">{name}</span>
            </div>
          </Link>
        );
      }),
    [sub_module_code]
  );

  return (
    <div className="bg-secondary-500 h-full flex overflow-y-auto">
      <div className="py-12 flex flex-1 flex-col">
        <div className="px-4 flex flex-col">
          <div className="flex mx-auto flex-shrink-0">
            <Brand className="w-auto h-14 md:h-14" />
          </div>
        </div>
        <nav
          aria-label="Sidebar"
          className="mt-8 justify-start flex flex-col flex-1"
          id="sidebar-navigation"
        >
          <div className="w-full flex flex-col text-white space-y-4 lg:space-y-6 flex-1">
            {sideBar &&
              Object?.keys(sideBar)?.map((k) => {
                const i = sideBar[k];
                const group_name = replaceAllString(k, '-', ' ');
                return (
                  <React.Fragment key={k}>
                    <div>
                      <h4 className="text-xxs px-6 font-bold text-white uppercase mb-1 lg:mb-2">
                        {group_name}
                      </h4>
                      {i &&
                        i?.map((o) => {
                          const { name, to, key, groups } = o;
                          const hasGroup = !!groups;

                          const isActive = module_code === key;
                          return (
                            <React.Fragment key={key}>
                              <Link
                                to={to}
                                className={cn(
                                  'z-20 group flex items-center py-[2px] gap-5 my-1',
                                  'ease-out-in transition transform duration-200',
                                  {
                                    'text-primary-500': isActive,
                                    'text-white hover:text-primary-500':
                                      !isActive,
                                  },
                                  {
                                    'pointer-events-none': isActive,
                                  }
                                )}
                                title={name}
                              >
                                <div
                                  className={cn(
                                    'bg-primary-500 h-9 w-1 z-20 rounded-r',
                                    'ease-out-in transition transform duration-200',
                                    {
                                      'opacity-100': isActive && !hasGroup,
                                      'opacity-0': !isActive,
                                      invisible: hasGroup,
                                    }
                                  )}
                                />
                                <div className="flex space-x-3 items-center">
                                  {o?.icon && <o.icon className="h-4 w-4" />}
                                  <span className="text-xs lg:text-sm font-semibold">
                                    {name}
                                  </span>
                                </div>
                                {hasGroup && (
                                  <HiChevronDown
                                    className={cn('h-5 w-5 ml-auto mr-6', {
                                      'rotate-180 group-focus-within:duration-700':
                                        isActive,
                                      'rotate-0 duration-200': !isActive,
                                    })}
                                  />
                                )}
                              </Link>
                              {hasGroup && (
                                <div
                                  className={cn(
                                    'transition transform ease-out-in',
                                    {
                                      'h-auto duration-300 opacity-300 opacity-100':
                                        isActive,
                                      'h-0 overflow-hidden duration-200 opacity-0 ':
                                        !isActive,
                                    }
                                  )}
                                >
                                  {renderSubNav(groups)}
                                  {isActive &&
                                    groups?.length > 0 &&
                                    !sub_module_code && (
                                      <Navigate to={to + groups[0]?.to} />
                                    )}
                                </div>
                              )}
                            </React.Fragment>
                          );
                        })}
                    </div>
                    <div className="border-b border-gray-400 mx-6 mt-7 last:hidden" />
                  </React.Fragment>
                );
              })}
          </div>
          <div>
            <Link
              to="/logout"
              className={cn(
                'z-20 group flex items-center py-[2px] gap-5 my-1',
                'ease-out-in transition transform duration-200',
                'text-white hover:text-primary-500'
              )}
              title="Logout"
            >
              <div
                className={cn(
                  'bg-primary-500 h-9 w-1 z-20 rounded-r',
                  'ease-out-in transition transform duration-200',
                  'opacity-0'
                )}
              />
              <div className="flex space-x-3 items-center">
                <TbLogout className="h-4 w-4" />
                <span className="text-xs lg:text-sm font-semibold">Logout</span>
              </div>
            </Link>
          </div>
        </nav>
      </div>
    </div>
  );
}

Navigation.defaultProps = {
  module_code: '',
};

Navigation.propTypes = {
  module_code: PropTypes.string,
};

export default React.memo(Navigation);
