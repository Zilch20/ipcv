import React from "react";

import { Outlet } from "react-router-dom";

import Header from "./Header";
import Sidebar from "./Sidebar";
import { SIDEBAR_PROVIDER } from "../_constants";

function Layout() {
  const [show, setShow] = React.useState(false);

  const x = React.useMemo(() => ({ show, setShow }), [show, setShow]);

  return (
    <SIDEBAR_PROVIDER.Provider value={x}>
      <div
        className="flex flex-col flex-1 md:flex md:h-screen md:overflow-hidden md:flex-row"
        id="root-wrapper"
      >
        <Sidebar />
        <div className="flex-1 md:flex md:flex-col md:overflow-hidden">
          <Header />
          <main className="flex flex-1 flex-col h-full w-full relative md:overflow-hidden bg-gray-50 focus:outline-none">
            <Outlet />
          </main>
        </div>
      </div>
    </SIDEBAR_PROVIDER.Provider>
  );
}

Layout.defaultProps = {};

Layout.propTypes = {};

export default Layout;
