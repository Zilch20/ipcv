import PrivateLayout from './containers/Layout';

export default PrivateLayout;
