import React from 'react';

export const SIDEBAR_PROVIDER = React.createContext();
