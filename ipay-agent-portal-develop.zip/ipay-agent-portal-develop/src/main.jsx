import React from 'react';

import 'assets/styles/styles.css';
import 'react-datepicker/dist/react-datepicker.css';

import dayjs from 'dayjs';
import ReactDOM from 'react-dom/client';
import duration from 'dayjs/plugin/duration';
import { BrowserRouter } from 'react-router-dom';
import quarterOfYear from 'dayjs/plugin/quarterOfYear';
import advancedFormat from 'dayjs/plugin/advancedFormat';
import LocalizedFormat from 'dayjs/plugin/localizedFormat';

import SessionProvider from 'context/session';
import ErrorBoundryWrapper from 'layouts/error-boundry';
import QueryProvider, { AxiosInterceptor } from 'services';

import App from './App';
import reportWebVitals from './reportWebVitals';

dayjs.extend(duration);
dayjs.extend(quarterOfYear);
dayjs.extend(advancedFormat);
dayjs.extend(LocalizedFormat);

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <QueryProvider>
    <BrowserRouter>
      <ErrorBoundryWrapper>
        <SessionProvider>
          <AxiosInterceptor>
            <App />
          </AxiosInterceptor>
        </SessionProvider>
      </ErrorBoundryWrapper>
    </BrowserRouter>
  </QueryProvider>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
