import React from 'react';

import Cookies from 'js-cookie';

import { TOKEN_KEY } from 'services';

const BASE_URL = import.meta.env.VITE_APP_END_POINT;

export const useDownloadFile = ({ downloadUrl = '', fileName = '' }) => {
  const token = Cookies.get(TOKEN_KEY);
  const [isLoading, setIsLoading] = React.useState(false);
  const downloadFile = React.useCallback(async () => {
    if (downloadUrl) {
      setIsLoading(true);
      const response = await fetch(`${BASE_URL}/${downloadUrl}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });

      const blob = await response.blob();

      const url = window.URL.createObjectURL(blob);
      const downloadLink = document.createElement('a');
      downloadLink.setAttribute('hidden', '');
      downloadLink.setAttribute('href', url);
      downloadLink.setAttribute('download', `${fileName}.xlsx`);
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      setIsLoading(false);
    }
  }, [downloadUrl, fileName, token]);
  return [downloadFile, isLoading];
};
