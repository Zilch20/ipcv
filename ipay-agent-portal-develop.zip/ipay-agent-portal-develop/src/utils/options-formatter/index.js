import { get } from 'lodash';

const optionFormatter = (
  list = [],
  value = 'id',
  label = 'name',
  { isLabelUpperCase = true, isValueUpperCase = false, withData = false } = {}
) => {
  const newData = [];

  list.forEach((item) => {
    const args = {
      value: isValueUpperCase
        ? get(item, `${value}`).toUpperCase()
        : get(item, `${value}`),
      label: isLabelUpperCase
        ? get(item, `${label}`).toUpperCase()
        : get(item, `${label}`),
    };
    newData.push(
      !withData
        ? args
        : {
            ...args,
            data: item,
          }
    );
  });

  return newData;
};

export default optionFormatter;
