import storage from './storage';
import {
  jsUcFirst,
  jsUcOnlyFirst,
  replaceAllString,
  stringToUpperCase,
} from './string-formaters';
import {
  removeNull,
  removeEmpty,
  convertNullToStringOfObject,
} from './object-transformers';
import { getAge } from './age-generator';
import { parseNumber, formatNumber } from './number-formater';
import {
  generateArrayHours,
  generateArrayDates,
  generateGraphStats,
  generateGraphLabels,
} from './graph-label-formater';
import optionFormatter from './options-formatter';
import { getFirstMessage } from './message-getter';
import {
  insertUpdateObjectToList,
  insertNewObjectToList,
  removeObjectToList,
} from './array-inserter';
import { recursiveFlatArray, groupArray } from './array-grouper';
import { checkHasPermission } from './permissions';

export {
  getAge,
  storage,
  jsUcFirst,
  removeNull,
  groupArray,
  removeEmpty,
  parseNumber,
  formatNumber,
  jsUcOnlyFirst,
  optionFormatter,
  getFirstMessage,
  replaceAllString,
  stringToUpperCase,
  recursiveFlatArray,
  generateArrayHours,
  generateArrayDates,
  generateGraphStats,
  removeObjectToList,
  checkHasPermission,
  generateGraphLabels,
  insertNewObjectToList,
  insertUpdateObjectToList,
  convertNullToStringOfObject,
};
