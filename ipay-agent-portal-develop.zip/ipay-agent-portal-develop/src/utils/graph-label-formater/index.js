import dayjs from 'dayjs';

export const generateArrayHours = () => {
  const hours = [];
  for (let i = 0; i < 24; i += 1) {
    const time = i < 10 ? `0${i}` : `${i}`;
    const $time = time % 12 || 12;
    const hour = `${$time < 10 ? `0${$time}` : $time}:00 ${
      time < 12 ? 'AM' : 'PM'
    }`;
    hours.push(hour);
  }

  return hours;
};

export const generateArrayDates = (
  startDate = new Date(new Date().getFullYear(), 0, 1),
  endDate = new Date(new Date().getFullYear(), 11, 31),
  difference = 'month',
  format = 'MMMM, YYYY'
) => {
  try {
    const dates = [];
    const end = dayjs(endDate);
    const start = dayjs(startDate);
    const diff = end?.diff(start, difference);

    if (!start.isValid() || !end.isValid() || diff <= 0) {
      return [];
    }

    for (let i = 0; i <= diff; i += 1) {
      dates.push(end.subtract(i, difference).format(format));
    }

    return dates?.reverse();
  } catch (err) {
    // eslint-disable-next-line no-console
    console.log(err, ' here');
    return [];
  }
};

export const generateGraphLabels = (params) => {
  const { from = '', to = '', range } = params?.date || {};
  const date_type = range?.value || '';

  let labels = [];

  if (from === to) {
    // Same date
    labels = generateArrayHours();
  }

  if (
    date_type === 'last_7_days' ||
    date_type === 'last_30_days' ||
    date_type === 'last_month' ||
    (date_type === 'custom' && from !== to)
  ) {
    // For 30 days || For 7 days
    const outputFormat = {
      custom: 'MMM Do',
      last_month: 'MMM Do',
      last_30_days: 'MMM Do',
      last_7_days: 'ddd, MMM D, YYYY',
    };

    const dates = generateArrayDates(from, to, 'day', 'YYYY-MM-DD');
    labels = dates?.map((d) => dayjs(d).format(outputFormat[date_type]));
  }

  if (
    date_type === 'last_year' ||
    date_type === 'last_6_months' ||
    date_type === 'last_9_months'
  ) {
    // Last year
    labels = generateArrayDates(from, to);
  }

  return labels;
};

export const generateGraphStats = (graph, params) => {
  const { from = '', to = '', range } = params || {};
  const date_type = range?.value || '';
  let dates = [];

  try {
    if (from === to) {
      // Same date
      const hours = generateArrayHours();
      dates = hours?.map((t) => {
        const selected = graph?.find((o) => o?.label === t);
        if (selected?.label === t) {
          return {
            ...selected,
            label: t,
          };
        }
        return {
          label: t,
          count: 0,
        };
      });
    }

    if (
      date_type === 'last_30_days' ||
      date_type === 'last_7_days' ||
      date_type === 'last_month' ||
      (date_type === 'custom' && from !== to)
    ) {
      // For 30 days || For 7 days

      const format = 'YYYY-MM-DD';
      const outputFormat = {
        custom: 'MMM Do',
        last_30_days: 'MMM Do',
        last_7_days: 'ddd, MMM D, YYYY',
      };
      const $graph = graph?.map((i) => ({
        ...i,
        label: dayjs(i?.label).format(format),
      }));

      const days = generateArrayDates(from, to, 'day', 'YYYY-MM-DD');

      dates = days?.map((d) => {
        const date = dayjs(d).format(format);
        const selected = $graph?.find((o) => o?.label === date);

        if (selected?.label === date) {
          return {
            ...selected,
            label: dayjs(selected?.label).format(outputFormat[date_type]),
          };
        }
        return {
          label: dayjs(date).format(outputFormat[date_type]),
          count: 0,
        };
      });
    }

    if (
      date_type === 'last_year' ||
      date_type === 'last_6_months' ||
      date_type === 'last_9_months'
    ) {
      // Last year
      const months = generateArrayDates(from, to);

      const $graph = graph?.map((o) => ({
        ...o,
        label: dayjs(o?.label).format('MMMM, YYYY'),
      }));

      dates = months?.map((m) => {
        const selected = $graph?.find((o) => o?.label === m);

        if (selected?.label === m) {
          return {
            ...selected,
            label: `${m?.label}`,
          };
        }
        return {
          label: `${m?.label}`,
          count: 0,
        };
      });
    }
  } catch (error) {
    // eslint-disable-next-line no-console
    console.log(error, ' here');
  }
  const x = dates;

  return x;
};
