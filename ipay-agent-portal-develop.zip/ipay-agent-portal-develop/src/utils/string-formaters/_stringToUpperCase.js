import { isNil } from 'lodash';

const stringToUpperCase = (string) => {
  if (!isNil(string) && typeof string === 'string') {
    return string.toUpperCase();
  }
  return '';
};

export default stringToUpperCase;
