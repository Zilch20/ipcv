const jsUcFirst = (string, replacement = '') => {
  const regEx = /(?:\b|_)([a-z])/g;
  if (string) {
    const x = (string || '')
      .toLowerCase()
      .replace(new RegExp(regEx), (e) => e.toUpperCase());
    return x;
  }
  return replacement;
};

export default jsUcFirst;
