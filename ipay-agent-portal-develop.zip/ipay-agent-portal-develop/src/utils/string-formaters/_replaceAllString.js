const replaceAllString = (str, target, replacement = '') => {
  if (!str) return '';
  const x = str?.replaceAll(target, replacement);
  return x;
};

export default replaceAllString;
