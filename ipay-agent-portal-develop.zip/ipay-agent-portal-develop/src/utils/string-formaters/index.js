import jsUcFirst from './_jsUcFirst';
import jsUcOnlyFirst from './_jsUcOnlyFirst';
import replaceAllString from './_replaceAllString';
import stringToUpperCase from './_stringToUpperCase';

export { jsUcOnlyFirst, jsUcFirst, replaceAllString, stringToUpperCase };
