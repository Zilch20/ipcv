const jsUcOnlyFirst = (string, replacement = '') => {
  if (!string) return replacement;
  return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
};

export default jsUcOnlyFirst;
