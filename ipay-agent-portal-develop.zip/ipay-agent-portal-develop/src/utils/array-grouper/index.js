import { get, groupBy } from 'lodash';

export const recursiveFlatArray = (
  array,
  target_id = 'id',
  link = 'parent_id',
  child_key = 'child',
  id = null
) => {
  array?.filter((x) => get(x, link) === id);
  return array
    ?.filter((x) => get(x, link) === id)
    .map((x) => ({
      ...x,
      [child_key]: recursiveFlatArray(
        array,
        `${target_id}`,
        `${link}`,
        `${child_key}`,
        get(x, target_id)
      ),
    }));
};

export const groupArray = (array = [], key = 'group') => {
  const columns = groupBy(array, key);

  const sorted = Object.keys(columns)
    .sort()
    .reduce(
      (a, b) => ({
        ...a,
        [b]: columns[b],
      }),
      {}
    );

  return sorted;
};
