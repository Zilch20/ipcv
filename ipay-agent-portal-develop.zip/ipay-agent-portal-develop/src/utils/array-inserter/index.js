import { assign, get } from 'lodash';

export const insertUpdateObjectToList = (list = [], data = {}, id = 'id') => {
  const newList = list.map((item) => {
    if (`${data[id]}` !== `${item[id]}`) return item;
    return assign({}, item, data);
  });

  return newList;
};

export const insertNewObjectToList = (
  list = [],
  data = {},
  position = 'end'
) => {
  if (position === 'start') {
    return [data].concat(list);
  }
  return list.concat([data]);
};

export const removeObjectToList = (list = [], id, target_id = 'id') => {
  let newList = [];
  newList = list.filter((item) => get(item, target_id) !== `${id}`);
  return newList;
};
