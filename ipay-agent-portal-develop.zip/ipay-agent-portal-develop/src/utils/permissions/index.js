import storage from '../storage';

export const checkHasPermission = (value) => {
  const permissions = storage.get('permissions', []);
  const x = permissions?.filter((i) => value?.indexOf(i) > -1)?.length > 0;
  return x;
};

export const checkHasDomPermission = (dom, permissionReq) => {
  const permissions = storage.get('permissions', []);
  if (permissions?.filter((i) => i === permissionReq)?.length > 0) {
    return dom;
  }
  return null;
};
