import { isNaN } from 'lodash';

export const parseNumber = (str, default_value = false) => {
  const v = parseFloat(`${str}`.replace(/,/g, ''));
  if (isNaN(v)) return typeof default_value !== 'boolean' ? default_value : str;
  return v;
};

export const formatNumber = (v, decimal = 2) => {
  try {
    const n = parseNumber(v);
    if (isNaN(n)) return v;
    return n.toLocaleString(undefined, {
      minimumFractionDigits: decimal,
      maximumFractionDigits: decimal,
    });
  } catch (err) {
    return v;
  }
};

export const formatCurrency = (number, currency = 'PHP', fraction = 2) =>
  Intl.NumberFormat('en-PH', {
    style: 'currency',
    currency,
    minimumFractionDigits: fraction,
  }).format(number);
