import React from "react";

import PropTypes from "prop-types";

import { ROOT_URL } from "./_constants";

function RootUrlProvider({ value, children }) {
  return <ROOT_URL.Provider value={value}>{children}</ROOT_URL.Provider>;
}
RootUrlProvider.defaultProps = {};

RootUrlProvider.propTypes = {
  value: PropTypes.string.isRequired,
  children: PropTypes.instanceOf(Object).isRequired,
};

export default RootUrlProvider;
