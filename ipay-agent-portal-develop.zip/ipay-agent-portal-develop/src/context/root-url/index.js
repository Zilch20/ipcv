import { ROOT_URL } from './_constants';
import RootUrlProvider from './_RootUrlProvider';

export { ROOT_URL };
export default RootUrlProvider;
