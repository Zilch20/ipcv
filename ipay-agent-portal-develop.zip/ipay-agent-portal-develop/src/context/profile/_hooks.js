import { useQuery } from 'services';

import * as c from './_constants';
import * as actions from './_actions';

export const useGetMyProfile = (user_key) => {
  const { isLoading, data = {} } = useQuery(
    [c.GET_MY_PROFILE, user_key],
    actions.getMyProfile
  );

  return [isLoading, data];
};
