import React from 'react';

const rootConst = 'PROFILE';

export const ROOT_PROFILE = React.createContext();

export const GET_MY_PROFILE = `${rootConst}/GET_MY_PROFILE`;
