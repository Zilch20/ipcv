import { req } from 'services';

import { tranformProfile } from './_transformers';

export const getMyProfile = () =>
  req.get({
    url: '/profile',
    transform: (res) => {
      const x = tranformProfile(res?.data);
      return x;
    },
  });
