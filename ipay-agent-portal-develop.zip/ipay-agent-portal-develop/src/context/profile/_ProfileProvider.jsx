import React from 'react';

import Cookies from 'js-cookie';
import PropTypes from 'prop-types';

import { useGetMyProfile } from './_hooks';
import { ROOT_PROFILE } from './_constants';

function ProfileProvider({ children }) {
  const user_key = Cookies.get('user_key');

  const [, data] = useGetMyProfile(user_key);

  return <ROOT_PROFILE.Provider value={data}>{children}</ROOT_PROFILE.Provider>;
}
ProfileProvider.defaultProps = {};

ProfileProvider.propTypes = {
  children: PropTypes.instanceOf(Object).isRequired,
};

export default ProfileProvider;
