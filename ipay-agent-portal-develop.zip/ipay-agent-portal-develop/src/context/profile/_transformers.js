import { jsUcFirst } from 'utils';

export const tranformProfile = (item) => {
  const { first_name, last_name } = item;
  const full_name = `${first_name} ${last_name}`;
  const x = {
    ...item,
    full_name: jsUcFirst(full_name),
  };

  return x;
};
