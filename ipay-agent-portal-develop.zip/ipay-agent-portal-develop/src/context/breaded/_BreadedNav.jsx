import React from 'react';

import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { IoMdHome } from 'react-icons/io';
import { HiChevronRight } from 'react-icons/hi';

import { BreadedContext } from './_Breaded';

function BreadedNav({ main }) {
  const { path } = React.useContext(BreadedContext);

  const paths = React.useMemo(() => {
    const list = Object.keys(path)
      .sort((a, b) => a.length - b.length)
      .map((key) => ({
        url: key,
        label: path[key],
      }));
    return list;
  }, [path]);

  const isMain = paths?.length === 1 && paths[0]?.url === main;
  const $paths = paths.filter((i) => i?.url !== main);

  return (
    <div className="flex items-center text-gray-700 gap-1">
      <Link
        to={main}
        className={isMain ? 'pointer-events-none' : 'pointer-events-auto'}
      >
        <IoMdHome className="h-4 w-4" />
      </Link>
      {!isMain && paths.length > 0 && (
        <>
          <HiChevronRight className="h-4 w-4" />
          <div className="flex items-center gap-1">
            {$paths.map((x, i) => (
              <React.Fragment key={`${x?.url}-${x?.label}`}>
                {i > 0 && <HiChevronRight className="h-4 w-4" />}
                <Link className="text-xs font-semibold" to={x.url}>
                  {x.label}
                </Link>
              </React.Fragment>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

BreadedNav.defaultProps = {};

BreadedNav.propTypes = {
  main: PropTypes.string.isRequired,
};

export default React.memo(BreadedNav);
