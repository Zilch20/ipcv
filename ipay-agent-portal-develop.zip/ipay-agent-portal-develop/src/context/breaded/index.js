import Breaded from './_Breaded';
import BreadedNav from './_BreadedNav';
import BreadedRoute from './_BreadedRoute';

export { BreadedNav, BreadedRoute };

export default Breaded;
