import React from "react";

import PropTypes from "prop-types";

export const BreadedContext = React.createContext();

function Breaded({ children }) {
  const [path, setPath] = React.useState({});

  const x = React.useMemo(() => ({ path, setPath }), [JSON.stringify(path)]);

  return (
    <BreadedContext.Provider value={x}>{children}</BreadedContext.Provider>
  );
}

Breaded.defaultProps = {};

Breaded.propTypes = {
  children: PropTypes.instanceOf(Object).isRequired,
};

export default React.memo(Breaded);
