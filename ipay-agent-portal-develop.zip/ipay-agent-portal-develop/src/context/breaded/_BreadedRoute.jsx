import React from "react";

import PropTypes from "prop-types";

import { BreadedContext } from "./_Breaded";

function BreadedRoute({ label, url, children }) {
  const { setPath } = React.useContext(BreadedContext);

  React.useEffect(() => {
    setPath((state) => {
      const newState = { ...state };
      newState[url] = label;
      return newState;
    });
    return () => {
      setPath((state) => {
        const oldState = { ...state };
        delete oldState[url];
        return oldState;
      });
    };
  }, [label, url, setPath]);
  return children;
}

BreadedRoute.defaultProps = {
  children: null,
};

BreadedRoute.propTypes = {
  url: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  children: PropTypes.oneOfType([
    PropTypes.string,
    PropTypes.number,
    PropTypes.instanceOf(Object),
  ]),
};

export default React.memo(BreadedRoute);
