import React from 'react';

export const ROOT_SESSION = React.createContext();
