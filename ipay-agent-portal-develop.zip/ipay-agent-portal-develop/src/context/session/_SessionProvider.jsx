import React from 'react';

import PropTypes from 'prop-types';

import { useAuth } from './_hooks';
import { ROOT_SESSION } from './_constants';

function SessionProvider({ children }) {
  const [, authenticated] = useAuth();

  const [isAuthenticated, setIfAuthenticated] = React.useState(authenticated);

  const x = React.useMemo(
    () => ({ isAuthenticated, setIfAuthenticated }),
    [JSON.stringify(isAuthenticated)]
  );

  return <ROOT_SESSION.Provider value={x}>{children}</ROOT_SESSION.Provider>;
}

SessionProvider.defaultProps = {};

SessionProvider.propTypes = {
  children: PropTypes.instanceOf(Object).isRequired,
};

export default SessionProvider;
