import QueryProvider from './_QueryProvider';
import {
  Hydrate,
  useQuery,
  dehydrate,
  TOKEN_KEY,
  END_POINT,
  queryClient,
  useMutation,
} from './_config';

export {
  Hydrate,
  useQuery,
  dehydrate,
  TOKEN_KEY,
  END_POINT,
  useMutation,
  queryClient,
};
export default QueryProvider;
