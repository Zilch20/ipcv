import React from 'react';

import { useNavigate } from 'react-router-dom';

import { toastError } from 'ui/toast';
import { getFirstMessage, jsUcOnlyFirst } from 'utils';

import { instance } from './_axios';

const AxiosInterceptor = ({ children }) => {
  const navigate = useNavigate();

  React.useEffect(() => {
    instance.interceptors.response.use(
      (response) => response,
      (res) => {
        const { status, data } = res?.response;
        const { message, error_description, error, errors } = data;
        const dispatchStatus = {
          400: () => {
            if (error) {
              toastError(message);
              return;
            }
            toastError(getFirstMessage(errors?.message));
          },
          401: () => {
            const isError =
              error === 'token_expired' ||
              error === 'token_invalid' ||
              error === 'token_missing' ||
              error === 'unauthorized';

            if (isError) {
              toastError(message);
              navigate('/logout');
              return;
            }
            toastError(message);
          },

          422: () => {
            if (error) {
              toastError(error?.message);
              return;
            }
            toastError(getFirstMessage(errors?.message));
          },
          429: () => toastError('Too many attempts!'),
          500: () => {
            if (error) {
              toastError(error?.message);
              return;
            }
            toastError(getFirstMessage(errors?.message));
          },
          default: () => toastError(jsUcOnlyFirst(message)),
        };

        const err = {
          name: res?.name,
          message,
          error,
          error_description,
          status,
        };

        if (dispatchStatus[status]) {
          dispatchStatus[status]();
          throw err;
        }

        dispatchStatus.default();
        throw err;
      }
    );
  }, []);

  return children;
};

export default AxiosInterceptor;
