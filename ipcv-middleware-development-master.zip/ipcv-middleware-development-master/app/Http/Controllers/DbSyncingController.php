<?php

namespace App\Http\Controllers;

use App\feeinquirylogs;
use App\Http\Controllers\Controller;
use App\ReceiveMoneyPayLog;
use App\ReceiveMoneySearchLog;
use App\ReceiveMoneySelectLog;
use App\sendmoneystorelogs;
use App\sendmoneyvalidatelogs;
use App\SyncingDataLog;
use App\WavecellLogs;
use Illuminate\Http\Request;

date_default_timezone_set("Asia/Manila");

class DbSyncingController extends Controller
{
    public function getlogs(Request $request){
//        $date = date('Y-m-d');
        $dateFrom = $request->dateFrom;
        $dateTo = $request->dateTo;
        $status = $request->status;

        $agentEmail = $request->post('agentEmail') ?? "";
        // dd($agentEmail);
//        dump('start syncing');
       
       $logs = [];
       
        //western union
        $logs['send_money_validate_logs'] = $this->getSendMoneyValidateLogs($dateFrom);
        $logs['send_money_store_logs'] = $this->getSendMoneyStoreLogs($dateFrom, $dateTo, $status, $agentEmail);
        $logs['fee_inquiry_logs'] = $this->getFeeInquiryLogs($dateFrom);
        $logs['receive_money_pay_logs'] = $this->getReceiveMoneyPayLogs($dateFrom, $dateTo, $status, $agentEmail);
        $logs['receive_money_search_logs'] = $this->getReceiveMoneySearchLogs($dateFrom);
        $logs['receive_money_select_logs'] = $this->getReceiveMoneySelectLogs($dateFrom);
        //end western union
        
        //wave cell data
        $logs['wavecell_logs'] = $this->getWaveCellLogs($dateFrom);
        
        
//       dump($logs);
        echo json_encode($logs);
    }
    
    private function getReceiveMoneySelectLogs($date){
        $table_logs = 'Receive Money Select logs';
        $logs = ReceiveMoneySelectLog::whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
    
    private function getReceiveMoneySearchLogs($date){
        $table_logs = 'Receive Money Search logs';
        $logs = ReceiveMoneySearchLog::whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
    
    private function getReceiveMoneyPayLogs($dateFrom, $dateTo, $status, $agentEmail){
        $table_logs = 'Receive Money Pay logs';

        if(!empty($agentEmail))
        {
            $logs = ReceiveMoneyPayLog::where('created_at','>', $dateFrom.' 00:00:00')
                                        ->where('created_at','<', $dateTo.' 23:59:59')
                                        ->where('agentEmail', '=', $agentEmail)
                                        ->where('transactionStatus','=', $status);
        }
        else{
            $logs = ReceiveMoneyPayLog::where('created_at','>', $dateFrom.' 00:00:00')
                                        ->where('created_at','<', $dateTo.' 23:59:59')
                                        ->where('transactionStatus','=', $status);
        }

        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($dateFrom,$table_logs,$count_data);
        return $data->toJson();
    }
    
    private function getFeeInquiryLogs($date){
        $table_logs = 'Fee Inquiry logs';
        $logs = feeinquirylogs::whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
    
    private function getSendMoneyStoreLogs($dateFrom,$dateTo, $status, $agentEmail){
        $table_logs = 'Send Money Store logs';
        
        if(!empty($agentEmail))
        {
            $logs = sendmoneystorelogs::where('created_at','>', $dateFrom.' 00:00:00')
                                        ->where('created_at','<', $dateTo.' 23:59:59')
                                        ->where('transactionStatus','=', $status)
                                        ->where('agentEmail', '=', $agentEmail);
        }
        else{
            $logs = sendmoneystorelogs::where('created_at','>', $dateFrom.' 00:00:00')
                                        ->where('created_at','<', $dateTo.' 23:59:59')
                                        ->where('transactionStatus','=', $status);
        }
        
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($dateFrom,$table_logs,$count_data);
        return $data->toJson();
    }
    
    private function getSendMoneyValidateLogs($date){
        $table_logs = 'Send Money Validate logs';
        $logs = sendmoneyvalidatelogs::whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
    
    private function getWaveCellLogs($date){
        $table_logs = 'WaveCell logs';
        //wave cell data
        $waveCell = WavecellLogs::where('Date',$date);
        $count_data = $waveCell->count();
        $data = $waveCell->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
    
    public function viewlogs(){
       $list= SyncingDataLog::all()->toJson();
       echo $list;
    }

    public function getLogsForBranches(Request $request)
    {
        $branchLocation = $request->branchLocation;
        $date = $request->date;

        $logs = [];

        $logs['send_money_store_logs'] = $this->getBranchSendMoneyStoreLogs($branchLocation,$date);
        $logs['receive_money_pay_logs'] = $this->getBranchReceiveMoneyPayLogs($branchLocation,$date);

        echo json_encode($logs);
    }

    private function getBranchReceiveMoneyPayLogs($branchLocation, $date){
        $table_logs = $branchLocation . ' Receive Money Pay logs';
        $logs = ReceiveMoneyPayLog::where('branchLocation', $branchLocation)
                                        ->whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
    private function getBranchSendMoneyStoreLogs($branchLocation, $date){
        $table_logs = $branchLocation . ' Send Money Store logs';
        $logs = sendmoneystorelogs::where('branchLocation', $branchLocation)
                                        ->whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }

    public function getLogsForSubAgent(Request $request)
    {
        $branchOwner = $request->branchOwner;
        $date = $request->date;

        $logs = [];

        $logs['send_money_store_logs'] = $this->getSubAgentSendMoneyStoreLogs($branchOwner,$date);
        $logs['receive_money_pay_logs'] = $this->getSubAgentReceiveMoneyPayLogs($branchOwner,$date);

        echo json_encode($logs);
    }

    private function getSubAgentReceiveMoneyPayLogs($branchOwner, $date){
        $table_logs = $branchOwner . ' Receive Money Pay logs';
        $logs = ReceiveMoneyPayLog::where('branchOwner', $branchOwner)
                                        ->whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
    private function getSubAgentSendMoneyStoreLogs($branchOwner, $date){
        $table_logs = $branchOwner . ' Send Money Store logs';
        $logs = sendmoneystorelogs::where('branchOwner', $branchOwner)
                                        ->whereDate('created_at',$date);
        $count_data = $logs->count();
        $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
}
