<?php
namespace App\Http\Controllers\SubAgentControllers;

use App\DasRequestLog;
use App\feeinquirylogs;
use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\SubAgentRepositories\SubAgentProcessRepository;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;

class SubAgentProcessController extends Controller
{
    protected $ProcessRepo;
    public function __construct(SubAgentProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }
    public function SubAgentProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validateRules = [
             'Category' => 'Required',

             'firstName' => Rule::requiredif($request->Category == 'Register'),
             'lastName' => Rule::requiredif($request->Category == 'Register'),
             'agentEmail' => Rule::requiredif($request->Category == 'Register').'||'. Rule::requiredif($request->Category == 'Update'),
             'branchLocation' => Rule::requiredif($request->Category == 'Register'),
             'accountType' => Rule::requiredif($request->Category == 'Register'),
             'accountStatus' => Rule::requiredif($request->Category == 'Register').'||'. Rule::requiredif($request->Category == 'Update'),
        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];

//        $validate = $this->validate($request, $validateRules, $messages);

        $category = $request->Category;

        // Validation to SOAP implementation
        $validator = \Validator::make($request->all(), $validateRules, $messages);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();
            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            // $logs['client_id'] = $client_id;
            // $logs['xml_request'] = 'MW API VALIDATION';
            // $logs['request_data'] = json_encode($request->all());
            // $logs['reply_data'] = $soapResponse;

            // if ($category === 'FeeInquiry') {
            //     feeinquirylogs::create($logs);
            // } else if ($category === 'Validate') {
            //     sendmoneyvalidateLogs::create($logs);
            // } else if ($category === 'Store') {
            //     sendmoneystoreLogs::create($logs);
            // } else if ($category === 'Das') {
            //     DasRequestLog::create($logs);
            // }

            return $soapResponse;
        }

        if($category == 'Get'){
            $RegisterRes = $this->repo->GetSubAgent($request->all(), $client_id);
            return $RegisterRes;
        }

        if($category == 'Register'){
            $RegisterRes = $this->repo->RegisterSubAgent($request->all(), $client_id);
            return $RegisterRes;
        }

        if($category == 'Update'){
            $UpdateRes = $this->repo->UpdateSubAgent($request->all(), $client_id);
            return $UpdateRes;
        }




    }
}
