<?php

namespace App\Http\Controllers\CebuanaControllers\ClientControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\CebuanaRepositories\BeneficiaryRepository;
use Illuminate\Validation\Rule;

class BeneficiaryController extends Controller
{
    protected $repo;
    public function __construct(BeneficiaryRepository $repo)
    {
        $this->repo = $repo;
    }
    public function transactProcess(Request $request)
    {
        $validate = [
            'Category' => 'required',
            
            'Subcategory' => Rule::requiredif($request->Category == 'Payment'),
            'PartnerID' => Rule::requiredif($request->Category == 'Payment'),
            'accountNum' => Rule::requiredif($request->Category == 'Payment'),
            'parameterOne' => Rule::requiredif($request->Category == 'Payment'),
            'Amount' => Rule::requiredif($request->Category == 'Payment')."|numeric",
            'ReferenceNo' => Rule::requiredif($request->Category == 'Payment')."|max:15",
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Input must be Numeric',
            'max:15' => 'Invalid Input: Input must have maximum of 15 characters'
        ];

        $this->validate($request, $validate, $messages);
    }

}