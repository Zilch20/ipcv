<?php

namespace App\Http\Controllers\WesternUnionControllers;

use App\feeinquirylogs;
use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use App\ReceiveMoneyPayLog;
use App\ReceiveMoneySearchLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\RecieveMoneyProcessRepository;
use Illuminate\Validation\Rule;
use App\SubAgentManagementTable;
use App\Traits\SubAgentTraits;
use App\Helpers\SpecialCharacters;

class ReceiveMoneyProcessController extends Controller
{
    use SubAgentTraits;

    protected $ProcessRepo;
    public function __construct(RecieveMoneyProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }

    public function ReceiveMoneyProcess(Request $request)
    {
        $client_id = $request->user();
        
        $client_id = $client_id['id'];
        // echo "Bye";
        // dd($client_id);
        

        $validateRules = [
            'Category' => 'Required',
            // 'agentEmail'=> 'Required',
            'channelType' => 'Required',
            'channelVersion' => 'Required',

            // 'mtk' => Rule::requiredif($request->Category == 'Select')."|".Rule::requiredif($request->Category == 'Pay'),

            'mtcn' => Rule::requiredif($request->Category == 'Search')."|".Rule::requiredif($request->Category == 'Pay'),

            // 'transactionType' => Rule::requiredif($request->Category == 'Pay'),

            'firstName' => Rule::requiredif($request->Category == 'Pay'),
            // 'middleName' => Rule::requiredif($request->Category == 'Pay').'|max:80',
            'lastName' => Rule::requiredif($request->Category == 'Pay'),

            'address1' => Rule::requiredif($request->Category == 'Pay'),
            'city' => Rule::requiredif($request->Category == 'Pay'),
            'province' => Rule::requiredif($request->Category == 'Pay'),
            'postalCode' => Rule::requiredif($request->Category == 'Pay'),
            'receiverCountryCode' => Rule::requiredif($request->Category == 'Pay'),
            'receiverCountryCurrencyCode' => Rule::requiredif($request->Category == 'Pay'),

            'idType' => Rule::requiredif($request->Category == 'Pay'),
            'idCountryIssued' => Rule::requiredif($request->Category == 'Pay'),
            'idNum' => Rule::requiredif($request->Category == 'Pay'),
            // 'issueDate' => Rule::requiredif($request->Category == 'Pay'),
            // 'expiration' => Rule::requiredif($request->Category == 'Pay'),
            'birthDate' => Rule::requiredif($request->Category == 'Pay'),
            'countryofBirth' => Rule::requiredif($request->Category == 'Pay'),
            'gender' => Rule::requiredif($request->Category == 'Pay'),
            'occupation' => Rule::requiredif($request->Category == 'Pay'),
            // 'transactionReason' => Rule::requiredif($request->Category == 'Pay').'|max:50',

            'phoneCountryCode' => Rule::requiredif($request->Category == 'Pay'),
            'phoneNum' => Rule::requiredif($request->Category == 'Pay'),
            'gender' => Rule::requiredif($request->Category == 'Pay'),
            'fundSource' => Rule::requiredif($request->Category == 'Pay'),

            // 'relationshiptoSender' => Rule::requiredif($request->Category == 'Pay').'|max:50',
            // 'positionLevel' => Rule::requiredif($request->Category == 'Pay'),

            // 'stateCode' => 'Nullable|max:30|alpha_num',
            // 'receiverCity' => 'Nullable|max:30|alpha_num',

            // 'destinationCountry' => Rule::requiredif($request->Category == 'Pay')."|".Rule::requiredif($request->Category == 'Search').'|max:3|alpha_num',
            // 'destinationCurrencyCode' => Rule::requiredif($request->Category == 'Pay')."|".Rule::requiredif($request->Category == 'Search').'|max:3|alpha_num',

            // 'originatingCountryCode' => Rule::requiredif($request->Category == 'Pay').'|max:3|alpha_num',
            // 'originatingCurrencyCode' => Rule::requiredif($request->Category == 'Pay').'|max:3|alpha_num',

            'new_mtcn' => Rule::requiredif($request->Category == 'Pay'),

            // 'stateCode' => Rule::requiredif($request->Category == 'Pay' && $request->originatingCountryCode == 'US' || $request->Category == 'Pay' && $request->originatingCountryCode == 'MX').'|max:30',
            // 'senderCity' => Rule::requiredif($request->Category == 'Pay' && $request->originatingCountryCode == 'MX' ).'|'.Rule::requiredif($request->Category == 'Pay' && $request->originatingCountryCode == 'MX').'|max:30',

            'multiErrorSupported' => Rule::requiredif($request->Category == 'Pay'),
            'templateId' => Rule::requiredif($request->Category == 'Pay'),
            'version' => Rule::requiredif($request->Category == 'Pay'),
            'ackFlag' => Rule::requiredif($request->Category == 'Pay'),

            // 'grossTotalAmount'  => Rule::requiredif($request->Category == 'Pay'),
            // 'payAmount' => Rule::requiredif($request->Category == 'Pay'),
            // 'principalAmount' => Rule::requiredif($request->Category == 'Pay'),
            // 'charges' => Rule::requiredif($request->Category == 'Pay'),
            // 'tolls' => Rule::requiredif($request->Category == 'Pay'),
            // 'exchangeRate' => Rule::requiredif($request->Category == 'Pay'),

            // 'originatingCity' => Rule::requiredif($request->Category == 'Pay'),
            // 'payOrDoNot' => Rule::requiredif($request->Category == 'Pay'),

            // 'bankName' => 'Nullable',
            // 'accountNumber' => 'Nullable',

            // 'deliveryCode' => 'Nullable',

            // 'myWuNumber' => 'Nullable'
        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            // 'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];

        // $this->validate($request, $validate, $messages);

        $category = $request->Category;

        $validator = \Validator::make($request->all(), $validateRules, $messages);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();
            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'MW API VALIDATION';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if($category === "Search"){
                ReceiveMoneySearchLog::create($logs);
            } elseif ($category === 'Pay') {
                ReceiveMoneyPayLog::create($logs);
            }

            return $soapResponse;
        }

        if(empty($request['mobileFlag']))
        {
            if(!empty($request['agentEmail'])){
                //get Branch Location
                $branchLocation = $this->getBranchLocation($request);

                $request['branchLocation'] = $branchLocation;
            }

            // $checkSuspension = $this->checkSuspended($request);
            // // dd($checkSuspension);
            // if($checkSuspension === true)
            // {
            //     $errorMessage = 'Branch is Suspended';
            //     $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            //     return $soapResponse;
            // }
            // End Get Branch Location
        }

        // Check for Special Characters Start
        $check = SpecialCharacters::checkCharacter($request->all());
        if($check === true)
        {
            $errorMessage = "Request must not contain accented letters";
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'SPECIAL CHAR ERROR';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if($category === "Search"){
                ReceiveMoneySearchLog::create($logs);
            } elseif ($category === 'Pay') {
                ReceiveMoneyPayLog::create($logs);
            }

            return $soapResponse;
        }
        // Check for Special Characters End

        if($category == "Search"){
            $searchRes = $this->repo->recieveMoneySearchRequest($request->all(), $client_id);
            return $searchRes;
        }

        if($category == "Pay"){
            $payRes = $this->repo->recieveMoneyPayRequest($request->all(), $client_id);
            return $payRes;
        }
    }
}
