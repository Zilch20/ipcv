<?php
namespace App\Http\Controllers\WesternUnionControllers;

use App\DasRequestLog;
use App\feeinquiryLogs;
use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use App\sendmoneystoreLogs;
use App\sendmoneyvalidateLogs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\SendMoneyProcessRepository;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;
use App\SubAgentManagementTable;
use App\Traits\SubAgentTraits;
use App\Helpers\SpecialCharacters;

class SendMoneyProcessController extends Controller
{
    use SubAgentTraits;

    protected $ProcessRepo;
    public function __construct(SendMoneyProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }
    public function SendMoneyStoreProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];
        // echo "Bye";
        // dd($client_id);

        $validateRules = [
             'Category' => 'Required',
            //  'agentEmail'=> 'Required',
             'channelType' => 'Required',
             'channelVersion' => 'Required',

            // Fee Inquiry
            'amount' => Rule::requiredif($request->transactionType == 'WMN' && $request->Category == 'FeeInquiry').'|'.Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:20',
            'destinationCountry' => Rule::requiredif($request->Category == 'FeeInquiry').'|'.Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:3',
            'destinationCurrencyCode' => Rule::requiredif($request->Category == 'FeeInquiry').'|'.Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:3',
            'originatingCountryCode' => Rule::requiredif($request->Category == 'FeeInquiry').'|'.Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),
            'currencyCode' => Rule::requiredif($request->Category == 'FeeInquiry').'|'.Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:4',

            'transactionType' => Rule::requiredif($request->Category == 'FeeInquiry').'|'.Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:4',
            'destinationAmount' => Rule::requiredif($request->transactionType == 'WMF' && $request->Category == 'FeeInquiry').'|'.Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),
            // 'plusChargesAmount' => Rule::requiredif($request->Category == 'Store'),
            // 'charges' => Rule::requiredif($request->Category == 'Store'),
            // 'grossTotalAmount'  => Rule::requiredif($request->Category == 'Store'),


            //Send Money Validate and Store Request
            'firstName' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:80',
            // 'middleName' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:80',
            'lastName' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:80',

            'address1' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:84',
            'city' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:30',
            'province' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:30',
            'postalCode' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:40',
            'senderCountryCode' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:3',
            'senderCountryCurrencyCode' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:3',

            'templateId' => Rule::requiredif($request->Category == 'Validate'),
            'version' => Rule::requiredif($request->Category == 'Validate'),
            'idType' => Rule::requiredif($request->Category == 'Validate'),
            'idCountryIssued' => Rule::requiredif($request->Category == 'Validate'),
            'idNum' => Rule::requiredif($request->Category == 'Validate'),
            // 'issueDate' => Rule::requiredif($request->Category == 'Validate'),
            // 'expiration' => Rule::requiredif($request->Category == 'Validate'),
            'birthDate' => Rule::requiredif($request->Category == 'Validate'),
            'occupation' => Rule::requiredif($request->Category == 'Validate'),
            'transactionReason' => Rule::requiredif($request->Category == 'Validate' && $request->amount >= '500000'),
            'gender' => Rule::requiredif($request->Category == 'Validate'),
            'fundSource' => Rule::requiredif($request->Category == 'Validate'),
            'countryofBirth' => Rule::requiredif($request->Category == 'Validate'),
            'ackFlag' => Rule::requiredif($request->Category == 'Validate'),
            'relationshiptoReceiver' => Rule::requiredif($request->Category == 'Validate' && $request->amount >= '500000'),
            // 'positionLevel' => Rule::requiredif($request->Category == 'Validate'),

            'complianceDataBuffer' => Rule::requiredif($request->Category == 'Store'),

            'phoneCountryCode' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:30',
            'phoneNum' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:31',

            'receiverFirstName' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:80',
            // 'receiverMiddleName' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:80',
            'receiverLastName' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:80',

            // 'paymentType' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store').'|max:30',

            'mtcn' => Rule::requiredif($request->Category == 'Store'),
            'new_mtcn' => Rule::requiredif($request->Category == 'Store'),

            // 'bankName' =>'Nullable',
            // 'accountNumber' => 'Nullable',

            // 'stateCode' => Rule::requiredif($request->Category == 'Validate' && $request->destinationCountry == 'US' || $request->Category == 'Validate' && $request->destinationCountry == 'MX').'|'.Rule::requiredif($request->Category == 'Store' && $request->destinationCountry == 'US' || $request->Category == 'Store' && $request->destinationCountry == 'MX').'|max:30',
            // 'receiverCity' => Rule::requiredif($request->Category == 'Validate' && $request->destinationCountry == 'MX' ).'|'.Rule::requiredif($request->Category == 'Store' && $request->destinationCountry == 'MX').'|max:30',

            // 'multiErrorSupported' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),
            // 'templateId' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),
            // 'version' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),

            // 'dasRequest' => Rule::requiredif($request->Category == 'Das'),
            // 'queryFilter1' => "Nullable",
            // 'queryFilter2' => "Nullable",
            // 'queryFilter3' => "Nullable",
            // 'queryFilter4' => "Nullable",
            // 'queryFilter5' => "Nullable",
            // 'accountNum' => "Nullable",

            // 'payWoIdIndicator' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),
            // 'deliveryCode' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),
            // 'duplicateDetectionFlag' => Rule::requiredif($request->Category == 'Validate').'|'.Rule::requiredif($request->Category == 'Store'),
            // 'myWuNumber' => 'Nullable',

            // 'bic' => 'Nullable',
            // 'bankLocation' => 'Nullable',
            // 'accountPrefix' => 'Nullable',
            // 'bankCode' => 'Nullable',
            // 'accountSuffix' => 'Nullable',
            // 'branchNumber' => 'Nullable',
            // 'routingCode' => 'Nullable'
        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];
//        $validate = $this->validate($request, $validateRules, $messages);

        $category = $request->Category;
        // Validation to SOAP implementation
        $validator = \Validator::make($request->all(), $validateRules, $messages);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();
            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'MW API VALIDATION';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if ($category === 'FeeInquiry') {
                feeinquirylogs::create($logs);
            } else if ($category === 'Validate') {
                sendmoneyvalidateLogs::create($logs);
            } else if ($category === 'Store') {
                sendmoneystoreLogs::create($logs);
            } else if ($category === 'Das') {
                DasRequestLog::create($logs);
            }

            return $soapResponse;
        }

        if(empty($request['mobileFlag']))
        {
            if(!empty($request['agentEmail'])){
                //get Branch Location
                $branchLocation = $this->getBranchLocation($request);

                $request['branchLocation'] = $branchLocation;
            }

            // $checkSuspension = $this->checkSuspended($request);
            // // dd($checkSuspension);
            // if($checkSuspension === true)
            // {
            //     $errorMessage = 'Branch is Suspended';
            //     $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            //     return $soapResponse;
            // }
            // End Get Branch Location
        }

        // Check for Special Characters Start
        $check = SpecialCharacters::checkCharacter($request->all());
        if($check === true)
        {
            $errorMessage = "Request must not contain accented letters";
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'SPECIAL CHAR ERROR';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;

            if ($category === 'FeeInquiry') {
                feeinquirylogs::create($logs);
            } else if ($category === 'Validate') {
                sendmoneyvalidateLogs::create($logs);
            } else if ($category === 'Store') {
                sendmoneystoreLogs::create($logs);
            } else if ($category === 'Das') {
                DasRequestLog::create($logs);
            }

            return $soapResponse;
        }
        // Check for Special Characters End

        if($category == 'FeeInquiry'){
            $feeRes = $this->repo->feeInquiryRequest($request->all(), $client_id);
            return $feeRes;
        }

        if($category == 'Validate'){
            $validationRes = $this->repo->sendMoneyValidationRequest($request->all(), $client_id);
            return $validationRes;
        }

        if($category == 'Store'){
            $storeRes = $this->repo->sendMoneyStoreRequest($request->all(), $client_id);
            return $storeRes;
        }
        if($category == "Das"){
            $dasRes = $this->repo->dasRequest($request->all(), $client_id);
            return $dasRes;
        }




    }
}
