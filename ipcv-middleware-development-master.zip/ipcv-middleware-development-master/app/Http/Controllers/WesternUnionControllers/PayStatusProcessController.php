<?php
namespace App\Http\Controllers\WesternUnionControllers;

use App\feeinquirylogs;
use App\Helpers\JSONSOAPConvert;
use App\Http\Controllers\Controller;
use App\PayStatusInquiryLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\PayStatusProcessRepository;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;
use App\SubAgentManagementTable;
use App\Traits\SubAgentTraits;

class PayStatusProcessController extends Controller
{
    use SubAgentTraits;
    
    protected $ProcessRepo;
    public function __construct(PayStatusProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }
    public function payStatusProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validateRules = [

            // 'channelType' => 'Required',
            // 'channelVersion' => 'Required',

            //Payment Details
           'recordingCountryCode' => 'required|max:3',
           'recordingCountryCurrencyCode' => 'required|max:3',
           'mtcn' => 'required|max:20',

        //    'payWoIdIndicator' => 'required'


        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];

        // $this->validate($request, $validate, $messages);

        $validator = \Validator::make($request->all(), $validateRules, $messages);

        if ($validator->fails()) {
            $errMsgs = $validator->errors()->messages();
            $errMsgKey = array_key_first($errMsgs);
            $errorMessage = $errMsgs[$errMsgKey][0];
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['xml_request'] = 'MW API VALIDATION';
            $logs['request_data'] = json_encode($request->all());
            $logs['reply_data'] = $soapResponse;
            $data_inserted = PayStatusInquiryLog::create($logs);

            return $soapResponse;
        }

        if(empty($request['mobileFlag']))
        {
            if(!empty($request['agentEmail'])){
                //get Branch Location
                $branchLocation = $this->getBranchLocation($request);

                $request['branchLocation'] = $branchLocation;
            }

            // $checkSuspension = $this->checkSuspended($request);
            // // dd($checkSuspension);
            // if($checkSuspension === true)
            // {
            //     $errorMessage = 'Branch is Suspended';
            //     $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            //     return $soapResponse;
            // }
            // End Get Branch Location
        }

        $category = $request->Category;

        $statusRes = $this->repo->payStatusRequest($request->all(), $client_id);
        return $statusRes;
    }
}
