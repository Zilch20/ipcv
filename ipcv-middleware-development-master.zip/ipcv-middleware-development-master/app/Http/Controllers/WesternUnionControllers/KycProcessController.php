<?php
namespace App\Http\Controllers\WesternUnionControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WesternUnionRepositories\KycProcessRepository;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Cache;

class KycProcessController extends Controller
{
    protected $ProcessRepo;
    public function __construct(KycProcessRepository $ProcessRepo)
    {
        $this->repo = $ProcessRepo;
    }
    public function kycProcess(Request $request)
    {
        $client_id = $request->user();

        $client_id = $client_id['id'];

        $validate = [
            // 'searchParameter' => 'Required',
            // 'pfcFilter' => 'Required',
            // 'channelType' => 'Required',
            // 'channelVersion' => 'Required',

            // 'firstName' => Rule::requiredif($request->searchParameter == 'MYWU_NUMBER').'|'. Rule::requiredif($request->searchParameter == 'COMPLIANCE_ID' && $request->pfcFilter == 'FSA').'|'. Rule::requiredif($request->searchParameter == 'PHONE_NUMBER'),
            // 'lastName'  => Rule::requiredif($request->searchParameter == 'MYWU_NUMBER').'|'. Rule::requiredif($request->searchParameter == 'COMPLIANCE_ID' && $request->pfcFilter == 'FSA').'|'. Rule::requiredif($request->searchParameter == 'PHONE_NUMBER'),
            // 'myWuNumber'  => Rule::requiredif($request->searchParameter == 'MYWU_NUMBER').'|'. Rule::requiredif($request->searchParameter == 'COMPLIANCE_ID' && $request->pfcFilter == 'FSA').'|'. Rule::requiredif($request->searchParameter == 'PHONE_NUMBER' && $request->pfcFilter == 'FSA'),

            // 'idType'  => Rule::requiredif($request->searchParameter == 'COMPLIANCE_ID'),
            // 'idNum'  => Rule::requiredif($request->searchParameter == 'COMPLIANCE_ID'),

            // 'phoneNum'=> Rule::requiredif($request->searchParameter == 'PHONE_NUMBER'),

            // 'transactionType' => 'Required',
            // 'searchType' => 'Required'

        ];

        $messages = [
            'Required' => 'Invalid Input: Empty Field',
            'max' => 'Invalid Input: Exceeded maximum number of characters'
        ];

        $this->validate($request, $validate, $messages);

        $kycRes = $this->repo->kycRequest($request->all(), $client_id);

        return $kycRes;
        

    }
}