<?php

namespace App\Http\Controllers\WavecellControllers\OtpProcessController;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\WavecellRepositories;
use Illuminate\Validation\Rule;

class OtpProcessController extends Controller
{
    protected $otpRepo;
    public function __construct(OtpRepository $otpRepo)
    {
        $this->repo = $otpRepo;
    }
    public function otpProcess(Request $request)
    {

        $validate = [
            'Category' => 'required',
            'PIN' => Rule::requiredif($request->Category == 'Validate'),
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->Category;

        if($category == 'Generate'){
            $res = $this->repo->GenerateOtp($request->all());
            return response($res, 200);
        }
    }
}