<?php

namespace App\Http\Controllers\MastercardControllers\WalletLinkingControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\MastercardRepositories\OtpRepository;
use Illuminate\Validation\Rule;

class LinkingProcessController extends Controller
{
    protected $linkRepo;
    public function __construct(WalletLinkRepository $linkRepo)
    {
        $this->repo = $linkRepo;
    }
    public function walletLinkProcess(Request $request)
    {

        //Validate input
        $validate =[
            /* Linking or Delinking */'category' => 'required',
            /* AccountType */'subcategory' => 'required',
            /* DeviceNumber */'parameterOne' => 'required|numeric',
            /* WalletNumber */'parameterTwo' => 'required|numeric',
            /* DefaultWallet */'parameterThree' => 'required',
            // 'parameterFour' => 'required'
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'digits' => 'Invalid Input: Value must be 6 Digits'
        ];

        $this->validate($request, $validate, $messages);

        $category = $request->category;
        $subcategory = $request->subcategory;

        if($category == 'Linking'){
            if($subcategory == 'Default Account'){
                $res = $this->repo->defaultLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Saving Account'){
                $res = $this->repo->savingLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Checking Account'){
                $res = $this->repo->checkingLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Credit Card Account'){
                $res = $this->repo->creditcardLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Credit Line Account'){
                $res = $this->repo->creditlineLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Corporate'){
                $res = $this->repo->corporateLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Universal Account'){
                $res = $this->repo->universalLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Money Market Investment Account'){
                $res = $this->repo->moneymarketLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Stored Value Account'){
                $res = $this->repo->storedvalueLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Revolving Loan Account'){
                $res = $this->repo->revolvingLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Installment Loan Account'){
                $res = $this->repo->installmentLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Real Estate Loan Account'){
                $res = $this->repo->realestateLink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'IRA Investment Account'){
                $res = $this->repo->iraLink($request->all());
        
                return response($res, 200);
            }
        }
        if($category == 'Delinking'){
            if($subcategory == 'Default Account'){
                $res = $this->repo->defaultDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Saving Account'){
                $res = $this->repo->savingDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Checking Account'){
                $res = $this->repo->checkingDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Credit Card Account'){
                $res = $this->repo->creditcardDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Credit Line Account'){
                $res = $this->repo->creditlineDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Corporate'){
                $res = $this->repo->corporateDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Universal Account'){
                $res = $this->repo->universalDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Money Market Investment Account'){
                $res = $this->repo->moneymarketDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Stored Value Account'){
                $res = $this->repo->storedvalueDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Revolving Loan Account'){
                $res = $this->repo->revolvingDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Installment Loan Account'){
                $res = $this->repo->installmentDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'Real Estate Loan Account'){
                $res = $this->repo->realestateDelink($request->all());
        
                return response($res, 200);
            }
            if($subcategory == 'IRA Investment Account'){
                $res = $this->repo->iraDelink($request->all());
        
                return response($res, 200);
            }
        }

    }
}