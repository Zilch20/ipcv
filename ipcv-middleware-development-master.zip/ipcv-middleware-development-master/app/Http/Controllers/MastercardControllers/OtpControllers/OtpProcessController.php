<?php

namespace App\Http\Controllers\MastercardControllers\OtpControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\MastercardRepositories\OtpRepository;
use Illuminate\Validation\Rule;

class OtpProcessController extends Controller
{
    protected $otpRepo;
    public function __construct(OtpRepository $otpRepo)
    {
        $this->repo = $otpRepo;
    }
    public function otpProcess(Request $request)
    {

        //Validate input
        $validate =[
            'category' => 'required',
            /*deviceNumber*/'parameterOne' => 'required|numeric',
            /*requestType*/'parameterTwo' => 'required',
            /*OTP*/'parameterThree' => Rule::requiredif($request->category == 'Validate')
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'digits' => 'Invalid Input: Value must be 6 Digits'
        ];

        $this->validate($request, $validate, $messages);

        if($request->category == 'Generate'){
            $res = $this->repo->generateOtp($request->all());
        
            return response($res, 200);
        }
        if($request->category == 'Validate'){
            $res = $this->repo->validateOtp($request->all());
        
            return response($res, 200);
        }
    }
}