<?php

namespace App\Http\Controllers\MastercardControllers\CardControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\MastercardRepositories\CardRepository;
use Illuminate\Validation\Rule;

class OtpProcessController extends Controller
{
    protected $cardRepo;
    public function __construct(CardRepository $cardRepo)
    {
        $this->repo = $cardRepo;
    }
    public function createcardProcess(Request $request)
    {
        $validate = [
            'ParameterOne' => 'required|alpha_num|size:100',
            'ParameterTwo' => 'required',
            'ParameterThree' => 'required|alpha_num|size:6',
            'ParameterFour' => 'required|alpha_num|size:10',
            'ParameterFive' => 'required',
            'ParameterSix' => 'required',
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
        ];

        $this->validate($request, $validate, $messages);
    }
}