<?php

namespace App\Http\Controllers;

use App\feeinquirylogs;
use App\Http\Controllers\Controller;
use App\SyncingDataLog;
use App\AgentPortalTransactionLogs;
use Illuminate\Http\Request;

date_default_timezone_set("Asia/Manila");

class AgentPortalDbSyncingController extends Controller
{
    public function getTransaction(Request $request){

        $mtcn = $request->post('mtcn') ?? "";
       
        $logs = [];
       
        //Transaction Start
        $logs['agent_portal_transaction_logs'] = $this->getAgentPortalTransaction($mtcn);
        //Transaction End
        
        echo json_encode($logs);
    }
    
    private function getAgentPortalTransaction($date){
        $table_logs = 'Receive Money Select logs';
        $logs = AgentPortalTransactionLogs::where('mtcn',$mtcn)
                                            ->orderBy('created_at', 'desc')
                                            ->take(5)
                                            ->get();
        $count_data = $logs->count();
        // $data = $logs->get();
        SyncingDataLog::saveLogs($date,$table_logs,$count_data);
        return $data->toJson();
    }
}

