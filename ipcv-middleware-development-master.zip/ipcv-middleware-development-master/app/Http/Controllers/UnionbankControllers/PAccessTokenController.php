<?php

namespace App\Http\Controllers\InstapayControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Validator;

class PAccessTokenController extends Controller
{
    public function RequestAccessToken(Request $request)
    {
        $guzzle = new Client([
            'headers' => [
                'accept' => 'application/json',
                'Content-Type' => 'application/x-www-form-urlencoded'
            ]
        ]);

        $params = [
            'grant_type' => 'password',
            'client_id' => '5dff2cdf-ef15-48fb-a87b-375ebff415bb',
            'username' => 'partner_sb',
            'password' => 'p@ssw0rd',
            'scope' => '*'
        ];

        $res = $guzzle -> post(env('INSTAPAY_P_ACCESS_TOKEN_URL'), [
            'query' => $params
        ]);

        return json_decode($res->getBody(), true);
    }
}