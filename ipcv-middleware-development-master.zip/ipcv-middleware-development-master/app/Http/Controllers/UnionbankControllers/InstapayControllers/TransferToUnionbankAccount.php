<?php

namespace App\Http\Controllers\InstapayControllers\TransferControllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use App\Repositories\InstapayRepositories\PartnerToPartnerRepository;
use Illuminate\Validation\Rule;

class TransferToUnionBankAccount extends Controller
{
    protected $transferRepo;
    public function __construct(PartnerToPartnerRepository $transferRepo)
    {
        $this->repo = $transferRepo;
    }
    public function transferProcess(Request $request){
        $validate = [
            "Category" => 'required',
            "token" => Rule::requiredif($request->Category == 'Transfer'),

            'accountNo' => Rule::requiredif($request->Category == 'Transfer'),
            'amount' => Rule::requiredif($request->Category == 'Transfer'),
            'remarks' => Rule::requiredif($request->Category == 'Transfer'),
            'particulars' => Rule::requiredif($request->Category == 'Transfer'),
            'receiverName' => Rule::requiredif($request->Category == 'Transfer'),
            'message' => Rule::requiredif($request->Category == 'Transfer'),

            'senderRefId' => Rule::requiredif($request->Category == 'Status')
         ];
        
        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'size' => 'Invalid Input: Value must be 2 characters only'
        ];
        
        $this->validate($request, $validate, $messages);

        if($request->Category == "Transfer"){
            $res = $this->repo->partnerTransfer($request->all());
            //Return
            return response($res, 200);
        }
        if($request->Category == "Status"){
            $res = $this->repo->partnerTransfer($request->all());
            //Return
            return response($res, 200);
        }
    }
}