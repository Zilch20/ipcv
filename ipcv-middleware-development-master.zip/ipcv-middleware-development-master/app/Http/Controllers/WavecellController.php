<?php

namespace App\Http\Controllers;
 
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use App\User;
use Validator;
use App\WavecellLogs;
use Illuminate\Support\Facades\DB;
date_default_timezone_set("Asia/Manila");

class WavecellController extends Controller
{

    //OTP Function
    public function OneTimePin(Request $request,$id)
    {
        $date = date("Y-m-d");
        $time = date("h:i:sa");
        $ip = $request->ip();

        DB::insert('insert into WavecellLogs (Date,Time,IP_Address) values (?, ?, ?)', [$date, $time, $ip]);

        // return redirect('/service/1/otp/validate');

        //Get user phone number
        $phone = User::where('id', $id)->get()->pluck('phone_number');
        $phone = $phone[0];

        //Post to Wavecell API
        $guzzle = new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . env('WAVECELL_API_TOKEN')
            ]
        ]);

        $params = [
            "destination" => $phone,
            "codeLength" => 6,
            // "productname" => "IPAY",
            "codeValidity" => 180,
            "createNew" => true,
        ];

        $res = $guzzle -> post(env('WAVECELL_API_URL_OTP'), [
            'json' => $params
        ]);

        $arr = json_decode($res->getBody(), true);
        $arr = $arr["uid"];
        $request->session()->put('uid', $arr);

        //return if no errors
        return json_decode($res->getBody(), true);

    }

    //Validate OTP
    public function ValidateOtp(Request $request)
    {
        $uid = $request->session()->get('uid');

        if(is_null($uid)){
            return response()->json(['ERROR'=>'No OTP was generated'],500);
        }
        //Validate input
        $validate =[
            'pin' => 'required|numeric|digits:6'
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'digits' => 'Invalid Input: Value must be 6 Digits'
        ];

        $this->validate($request, $validate, $messages);

        //Get from Wavecell API
        $otp = $request->pin;
        $url = env('WAVECELL_API_URL_OTP')."/".$uid."?code=".$otp;

        $guzzle = new Client([
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . env('WAVECELL_API_TOKEN')
            ]
        ]);

        $res = $guzzle -> get($url);

        $arr = json_decode($res->getBody(), true);
        $status = $arr["status"];
        $attempt = $arr["attempt"];

        if ($status == "FAILED")
        {
            $request->session()->forget('uid');
            return response()->json(['ERROR'=>'Too Many Attempts']);
        }
        else if ($status == "EXPIRED")
        {                                                    
            $request->session()->forget('uid');
            return response()->json(['ERROR'=>'OTP Expired']);
        }
        else if ($status == "VERIFIED")
        {
            $request->session()->forget('uid');
            $json = json_decode($res->getBody(), 200);
            return response()->json(['SUCCESS'=>$json]);
        }
        else
        {
            return response()->json(['ERROR'=>'Wrong OTP: Attempt No.'.$attempt]);
        }

        // $request->session()->forget('uid');
    
        //return if no errors
        return json_decode($res->getBody(),200);
    }
}