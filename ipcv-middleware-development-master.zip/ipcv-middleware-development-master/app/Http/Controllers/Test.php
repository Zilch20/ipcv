<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Traits\WesternUnionCurlRequestTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Validationrule;
use Illuminate\Support\Facades\Cache;
use App\feeinquirylogs;
use App\sendmoneyvalidatelogs;
use App\sendmoneystorelogs;
use App\ReceiveMoneySearchLog;
use App\ReceiveMoneySelectLog;
use App\ReceiveMoneyPayLog;

class Test extends Controller
{
    use WesternUnionCurlRequestTrait;

    protected $var;

    public function __construct()
    {
        $this->var;
    }

    public function test_write(Request $request)
    {
        // $certFolder = '';
        // $dirCertFolder = base_path($certFolder);
        // chdir($dirCertFolder);

        // $output = shell_exec('php artisan passport:install');

        // $output = explode("\n",$output);

        // $output = 
        // [
        //     "Message" => $output[0],
        //     "personalAccessMessage" => $output[1],
        //     "clientID1" => $output[2],
        //     "clientSecret1" => $output[3],
        //     "passwordGrantMessage" => $output[4],
        //     "clientID2" => $output[5],
        //     "clientSecret2" => $output[6]
        // ];

        // return response()->json($output);

        // $data = json_decode($request, true);
        // dd($request['sender']['name']);
        
        $rules = [
            "sender.name" => "required",
            "sender.age" => "required",
            "sender.hw.height" => "required",
            "sender.hw.weight" => "required",
        ];

        $messages = [
            'required' => 'Invalid Input: Empty Field',
            'numeric' => 'Invalid Input: Value must be Numeric',
            'size' => 'Invalid Input: Value must be 2 characters only'
        ];
        
        $this->validate($request, $rules, $messages);

        echo $request['sender']['name'];


        // dd($dirCertFolder);
    }

    public function testtwo(Request $request)
    {
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
        <soapenv:Envelope
            xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/"
            xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
            xmlns:xsd="http://www.w3.org/2001/XMLSchema"
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            <soapenv:Body>
                <xrsi:receive-money-search-reply
                    xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
                    <instant_notification>
                        <addl_service_charges/>
                    </instant_notification>
                    <payment_transactions>
                        <payment_transaction>
                            <sender>
                                <name name_type="D">
                                    <first_name>TIMOTHY</first_name>
                                    <last_name>GLENN</last_name>
                                </name>
                                <address>
                                    <city>PIKETON</city>
                                    <state>OH</state>
                                    <country_code>
                                        <iso_code>
                                            <country_code>US</country_code>
                                            <currency_code>USD</currency_code>
                                        </iso_code>
                                    </country_code>
                                    <state_zip>45661</state_zip>
                                    <street>14121 STATE ROUTE 124</street>
                                </address>
                                <contact_phone>7404933732</contact_phone>
                                <mobile_phone>
                                    <phone_number>
                                        <country_code>1</country_code>
                                        <national_number>7409701358</national_number>
                                    </phone_number>
                                </mobile_phone>
                                <mobile_details>
                                    <city_code>1</city_code>
                                    <number>7409701358</number>
                                </mobile_details>
                            </sender>
                            <receiver>
                                <name name_type="M">
                                    <given_name>NEMESIA</given_name>
                                    <paternal_name>OLIVA</paternal_name>
                                    <maternal_name>CLERIGO</maternal_name>
                                </name>
                                <address>
                                    <country_code>
                                        <iso_code>
                                            <country_code>PH</country_code>
                                            <currency_code>PHP</currency_code>
                                        </iso_code>
                                    </country_code>
                                </address>
                                <mobile_phone>
                                    <phone_number/>
                                </mobile_phone>
                                <mobile_details/>
                            </receiver>
                            <financials>
                                <taxes>
                                    <tax_worksheet/>
                                </taxes>
                                <gross_total_amount>2499</gross_total_amount>
                                <pay_amount>96156</pay_amount>
                                <principal_amount>2000</principal_amount>
                                <charges>499</charges>
                                <tolls>0</tolls>
                            </financials>
                            <payment_details>
                                <expected_payout_location>
                                    <state_code/>
                                    <city/>
                                </expected_payout_location>
                                <destination_country_currency>
                                    <iso_code>
                                        <country_code>PH</country_code>
                                        <currency_code>PHP</currency_code>
                                    </iso_code>
                                </destination_country_currency>
                                <originating_country_currency>
                                    <iso_code>
                                        <country_code>US</country_code>
                                        <currency_code>USD</currency_code>
                                    </iso_code>
                                </originating_country_currency>
                                <originating_city>PIKETONOH4</originating_city>
                                <transaction_type>CCW</transaction_type>
                                <exchange_rate>48.0782</exchange_rate>
                                <original_destination_country_currency>
                                    <iso_code>
                                        <country_code>PH</country_code>
                                        <currency_code>PHP</currency_code>
                                    </iso_code>
                                </original_destination_country_currency>
                            </payment_details>
                            <filing_date>07-02-21 </filing_date>
                            <filing_time>1156P EDT</filing_time>
                            <money_transfer_key>3624024637</money_transfer_key>
                            <pay_status_description>W/C</pay_status_description>
                            <mtcn>5791892808</mtcn>
                            <new_mtcn>2118385791892808</new_mtcn>
                            <fusion>
                                <fusion_status>W/C</fusion_status>
                                <account_number/>
                            </fusion>
                            <wu_network_agent_indicator/>
                        </payment_transaction>
                    </payment_transactions>
                    <delivery_services/>
                    <misc_buffer/>
                    <foreign_remote_system>
                        <identifier>WGHHPH9940P</identifier>
                        <reference_no>115210-000000003</reference_no>
                        <counter_id>HPPHA28</counter_id>
                    </foreign_remote_system>
                </xrsi:receive-money-search-reply>
            </soapenv:Body>
        </soapenv:Envelope>';

        $pattern = "/given_name/";
        if(preg_match($pattern, $xml)) {
            $xml = preg_replace('/given_name/','first_name', $xml);
        }

        $pattern = "/maternal_name/";
        if(preg_match($pattern, $xml)) {
            $xml = preg_replace('/maternal_name/','middle_name', $xml);
        }

        $pattern = "/paternal_name/";
        if(preg_match($pattern, $xml)) {
            $xml = preg_replace('/paternal_name/','last_name', $xml);
        }

        echo $xml;
    }

    public function test_debug(Request $request)
    {
        $params = $request->input('xml');
        $results = $this->requestWUAPI([], $params, 0);

        echo $results;
    }

}
