<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class ReceiveMoneyPayLog extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;
    protected $table = 'receive_money_pay_logs';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'branchOwner','transactionStatus','agentName', 'ftid', 'branchLocation', 'agentEmail','xml_request','client_id','mtcn','receiverName','address','city','province','postalCode','idNum','issueDate','expiration','birthDate','occupation','transactionReason','gender','fundSource','relationshiptoSender','positionLevel','phoneNum','originatingCountry','originatingCurrencyCode','new_mtcn','request_data','reply_data','countryName','receiverCountryCode','receiverCountryCurrencyCode','idCountryIssued','countryofBirth','transactionType','mtk','myWuNumber'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
