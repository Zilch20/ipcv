<?php

namespace App\repositories\WesternUnionRepositories;

use App\Helpers\Debugger;
use App\Http\Controllers\Controller;
use App\RetryMechanismLog;
use App\Traits\RetryMechanismTrait;
use App\Traits\WesternUnionCurlRequestTrait;
use App\Traits\WuLookupXmlTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Support\Facades\Cache;
use App\sendmoneyvalidatelogs;
use App\sendmoneystorelogs;
use App\feeinquirylogs;
use App\DasRequestLog;
use App\HoldTxnLog;
use Illuminate\Database\Eloquent\Model;
use App\Traits\D2B\RoutingCodeTrait;

class MobileSendMoneyProcessRepository extends Controller
{
    use RoutingCodeTrait;
    use WesternUnionCurlRequestTrait;
    use RetryMechanismTrait;
    use WuLookupXmlTrait;

    public function feeSurveyRequest($request, $client_id)
    {
        if ($request['transactionType'] == "WMN") {
            $originPrincipalAmount = $request['amount'];
            $destinationPrincipalAmount = 0;
        }
        if ($request['transactionType'] == "WMF") {
            $originPrincipalAmount = 0;
            $destinationPrincipalAmount = $request['destinationAmount'];
        }
        // dd($originPrincipalAmount." ".$destinationPrincipalAmount);
        $params = '
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
            <xrsi:feesurvey-request>
                <device>
                    <id>MOBILE</id>
                    <type>MOBILE</type>
                </device>
                <channel>
                    <type>SFSS</type>
                    <name>IPCV</name>
                    <version>9525</version>
                </channel>
                <financials>
                    ' . (!empty($request['amount']) ? '<originators_principal_amount>' . $request['amount'] . '</originators_principal_amount>' : '') . '
                    ' . (!empty($request['destinationAmount']) ? '<destination_principal_amount>' . $request['destinationAmount'] . '</destination_principal_amount>' : '') . '
                </financials>
                <payment_details>
                    <recording_country_currency>
                        <iso_code>
                            ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </recording_country_currency>
                    <destination_country_currency>
                        <iso_code>
                            ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                            ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </destination_country_currency>
                    <originating_country_currency>
                        <iso_code>
                            ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                            ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </originating_country_currency>
                    ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                    ' . (!empty($request['paymentType']) ? '<payment_type>' . $request['paymentType'] . '</payment_type>' : '') . '
                    ' . (!empty($request['fixOnSend']) ? '<fix_on_send>' . $request['fixOnSend'] . '</fix_on_send>' : '') . '
                    <stage_pay_fields>
                        ' . (!empty($request['snpIndicator']) ? '<snp_indicator>' . $request['snpIndicator'] . '</snp_indicator>' : '') . '
                    </stage_pay_fields>
                </payment_details>
                <delivery_services>
                    <code>000</code>
                    <message>
                        <message_details context="4">
                            ' . (!empty($request['message1']) ? '<text>' . $request['message1'] . '</text>' : '') . '
                            ' . (!empty($request['message2']) ? '<text>' . $request['message2'] . '</text>' : '') . '
                            ' . (!empty($request['message3']) ? '<text>' . $request['message3'] . '</text>' : '') . '
                            ' . (!empty($request['message4']) ? '<text>' . $request['message4'] . '</text>' : '') . '
                        </message_details>
                    </message>
                </delivery_services>
                <foreign_remote_system>
                    <identifier>WGSSPH5131T</identifier>
                    <reference_no>0000000015782274</reference_no>
                    <counter_id>PH513DSAP01B</counter_id>
                </foreign_remote_system>
            </xrsi:feesurvey-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPIMobile($params, $client_id, $request);

        // exit(var_dump($output));

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = feeinquirylogs::create($logs);

        return $output;

    }

    // <fraud_scoring_buffer>
    //                     <risk_info>
    //                         ' . (!empty($request['riskScore']) ? '<risk_score>' . $request['riskScore'] . '</risk_score>' : '') . '
    //                     </risk_info>
    //                 </fraud_scoring_buffer>

    public function sendMoneyValidationRequest($request, $client_id)
    {
        $countryCode = $request['senderCountryCode'];
        $countryName = config('country.' . $countryCode);

        $destcountryCode = $request['destinationCountry'];
        $destcountryName = config('country.' . $destcountryCode);

        //Bank Details
        $bank_details = '';
        if (!empty($request['accountNumber'])) {
            $bank_details = '<bank_details>';
            $bank_details .= !empty($request['bankName']) ? '<name>' . $request['bankName'] . '</name>' : '';
            $bank_details .= !empty($request['accountNumber']) ? '<account_number>' . $request['accountNumber'] . '</account_number>' : '';
            $bank_details .= !empty($request['branchNumber']) ? '<branch_number>' . $request['branchNumber'] . '</branch_number>' : '';
            $bank_details .= !empty($request['branchLocation']) ? '<bank_location>' . $request['branchLocation'] . '</bank_location>' : '';
            $bank_details .= !empty($request['bic']) ? '<bic>' . $request['bic'] . '</bic>' : '';
            $bank_details .= !empty($request['bankCode']) ? '<bank_code>' . $request['bankCode'] . '</bank_code>' : '';
            $bank_details .= !empty($request['sortCode']) ? '<sort_code>' . $request['sortCode'] . '</sort_code>' : '';
            $bank_details .= !empty($request['accountPrefix']) ? '<account_prefix>' . $request['accountPrefix'] . '</account_prefix>' : '';
            $bank_details .= !empty($request['accountSuffix']) ? '<account_suffix>' . $request['accountSuffix'] . '</account_suffix>' : '';
            $bank_details .= !empty($request['accountName']) ? '<bank_account_holder>' . $request['accountName'] . '</bank_account_holder>' : '';
            $bank_details .= '</bank_details>';
        }

        $request['issueDate'] = !empty($request['issueDate']) ? str_replace('/', '', $request['issueDate']) : '';
        $request['expiration'] = !empty($request['expiration']) ? str_replace('/', '', $request['expiration']) : '';
        $request['birthDate'] = str_replace('/', '', $request['birthDate']);

        // <fraud_scoring_buffer>
        //                 <risk_info>
        //                     ' . (!empty($request['riskScore']) ? '<risk_score>' . $request['riskScore'] . '</risk_score>' : '') . '
        //                 </risk_info>
        //                 <fraud_scoring_enabled>Y</fraud_scoring_enabled>
        //             </fraud_scoring_buffer>

        $id_details = '';
        if (!empty($request['idType']) || !empty($request['idCountryIssued']) || !empty($request['idNum'])) {
            $id_details = '<id_details>';
            $id_details .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
            $id_details .= !empty($request['idCountryIssued']) ? '<id_country_of_issue>' . $request['idCountryIssued'] . '</id_country_of_issue>' : '';
            $id_details .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
            $id_details .= '</id_details>';
        }


        if (empty($request['myWuNumber'])) {
            $request['myWuNumber'] = '';
        }
        if (empty($request['mtcn'])) {
            $request['mtcn'] = '';
        }
        $retryMechanism = RetryMechanismLog::findLog('mobile_send_money_validation', $request, 'mobile_send')->get();
        if (!empty($retryMechanism[0])) {
            $retryMechanismData = $retryMechanism[0];
            $request['myWuNumber'] = !empty($retryMechanismData['account_nbr']) ? $retryMechanismData['account_nbr'] : $request['myWuNumber'];
            $request['mtcn'] = !empty($retryMechanismData['mtcn']) ? $retryMechanismData['mtcn'] : $request['mtcn'];
            $request['galactic_id'] = !empty($retryMechanismData['galactic_id']) ? $retryMechanismData['galactic_id'] : null;
            $request['mtcn_digest'] = !empty($retryMechanismData['mtcn_digest']) ? $retryMechanismData['mtcn_digest'] : null;
        }
//        Debugger::dd($request);

        $params = '
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:send-money-validation-request>
                    <device>
                        <id>MOBILE</id>
                        <type>MOBILE</type>
                    </device>
                    <channel>
                        <type>SFSS</type>
                        <name>IPCV</name>
                        <version>9525</version>
                    </channel>
                    <operator>
                        <id/>
                        <password/>
                    </operator>
                    <terminal>
                        <id>*Ske</id>
                    </terminal>
                    <sender>
                        <name name_type="D">
                            ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['middleName']) ? '<middle_name>' . $request['middleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                        </name>
                        <address>
                            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                            ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . (!empty($request['senderCountryCode']) ? '<country_code>' . $request['senderCountryCode'] . '</country_code>' : '') . '
                                    ' . (!empty($request['senderCountryCurrencyCode']) ? '<currency_code>' . $request['senderCountryCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $countryName . '</country_name>
                            </country_code>
                        </address>
                        <preferred_customer>
                            ' . (!empty($request['permanentChange']) ? '<permanent_change>' . $request['permanentChange'] . '</permanent_change>' : '') . '
                            ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                        </preferred_customer>
                        <compliance_details>
                            ' . $this->getRoutingCode($request)['templateId'] . '
                            ' . (!empty($request['version']) ? '<version>' . $request['version'] . '</version>' : '') . '

                            ' . $id_details . '

                            ' . (!empty($request['flagPay']) ? '<third_party_details><flag_pay>' . $request['flagPay'] . '</flag_pay></third_party_details>' : '') . '

                            ' . (!empty($request['issueDate']) ? '<id_issue_date>' . $request['issueDate'] . '</id_issue_date>' : '') . '
                            ' . (!empty($request['expiration']) ? '<id_expiration_date>' . $request['expiration'] . '</id_expiration_date>' : '') . '
                            ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                            ' . (!empty($request['occupation']) ? '<occupation>' . $request['occupation'] . '</occupation>' : '') . '
                            ' . (!empty($request['transactionReason']) ? '<transaction_reason>' . $request['transactionReason'] . '</transaction_reason>' : '') . '

                            <Current_address>
                                ' . (!empty($request['currentAddress1']) ? '<addr_line1>' . $request['currentAddress1'] . '</addr_line1>' : '') . '
                                ' . (!empty($request['currentAddress2']) ? '<addr_line2>' . $request['currentAddress2'] . '</addr_line2>' : '') . '
                                ' . (!empty($request['currentCity']) ? '<city>' . $request['currentCity'] . '</city>' : '') . '
                                ' . (!empty($request['currentProvince']) ? '<state_name>' . $request['currentProvince'] . '</state_name>' : '') . '
                                ' . (!empty($request['currentPostalCode']) ? '<postal_code>' . $request['currentPostalCode'] . '</postal_code>' : '') . '
                                ' . (!empty($request['currentCountry']) ? '<country>' . $request['currentCountry'] . '</country>' : '') . '
                                ' . (empty($request['currentCountry']) ? '<country>' . $countryName . '</country>' : '') . '
                            </Current_address>

                            ' . (!empty($request['countryofBirth']) ? '<Country_of_Birth>' . $request['countryofBirth'] . '</Country_of_Birth>' : '') . '

                            ' . (!empty($request['nationality']) ? '<nationality>' . $request['nationality'] . '</nationality>' : '') . '
                            ' . (!empty($request['gender']) ? '<Gender>' . $request['gender'] . '</Gender>' : '') . '
                            ' . (!empty($request['fundSource']) ? '<Source_of_Funds>' . $request['fundSource'] . '</Source_of_Funds>' : '') . '
                            ' . (!empty($request['relationshiptoReceiver']) ? '<Relationship_to_Receiver_Sender>' . $request['relationshiptoReceiver'] . '</Relationship_to_Receiver_Sender>' : '') . '

                            ' . (!empty($request['ackFlag']) ? '<ack_flag>' . strtoupper($request['ackFlag']) . '</ack_flag>' : '') . '
                            ' . (!empty($request['galactic_id']) ? '<galactic_id>' . $request['galactic_id'] . '</galactic_id>' : '') . '
                            ' . (!empty($request['multiErrorSupported']) ? '<multi_error_supported>' . $request['multiErrorSupported'] . '</multi_error_supported>' : '') . '
                            ' . (!empty($request['positionLevel']) ? '<employment_position_level>' . $request['positionLevel'] . '</employment_position_level>' : '') . '
                        </compliance_details>
                        ' . (!empty($request['phoneCountryCode']) ? '<phone_country_code>' . $request['phoneCountryCode'] . '</phone_country_code>' : '') . '
                        ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                        <mobile_phone>
                            <phone_number>
                                ' . (!empty($request['phoneCountryCode']) ? '<country_code>' . $request['phoneCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['phoneNum']) ? '<national_number>' . $request['phoneNum'] . '</national_number>' : '') . '
                            </phone_number>
                        </mobile_phone>
                        ' . (!empty($request['smsNotificationFlag']) ? '<sms_notification_flag>' . $request['smsNotificationFlag'] . '</sms_notification_flag>' : '') . '
                    </sender>
                    <receiver>
                        <name name_type="D">
                            ' . (!empty($request['receiverFirstName']) ? '<first_name>' . $request['receiverFirstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['receiverMiddleName']) ? '<middle_name>' . $request['receiverMiddleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['receiverLastName']) ? '<last_name>' . $request['receiverLastName'] . '</last_name>' : '') . '
                        </name>
                        <address>
                            ' . (!empty($request['receiverAddress1']) ? '<addr_line1>' . $request['receiverAddress1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['receiverAddress2']) ? '<addr_line2>' . $request['receiverAddress2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['receiverHomeCity']) ? '<city>' . $request['receiverHomeCity'] . '</city>' : '') . '
                            ' . (!empty($request['receiverState']) ? '<state>' . $request['receiverState'] . '</state>' : '') . '
                            ' . (!empty($request['receiverPostalCode']) ? '<postal_code>' . $request['receiverPostalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                    ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $destcountryName . '</country_name>
                            </country_code>
                        </address>
                    </receiver>
                    <payment_details>
                        <origination/>
                        <destination/>
                        <expected_payout_location>
                            ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                            ' . (!empty($request['receiverCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                        </expected_payout_location>
                        <recording_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </recording_country_currency>
                        <destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </destination_country_currency>
                        <originating_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </originating_country_currency>

                        ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                        ' . (!empty($request['paymentType']) ? '<payment_type>' . $request['paymentType'] . '</payment_type>' : '') . '
                        ' . (!empty($request['fixOnSend']) ? '<fix_on_send>' . $request['fixOnSend'] . '</fix_on_send>' : '') . '
                        ' . (!empty($request['duplicateDetectionFlag']) ? '<duplicate_detection_flag>' . $request['duplicateDetectionFlag'] . '</duplicate_detection_flag>' : '') . '

                        <stage_pay_fields>
                            ' . (!empty($request['snpIndicator']) ? '<snp_indicator>' . $request['snpIndicator'] . '</snp_indicator>' : '') . '
                            ' . (!empty($request['stagingBuffer']) ? '<staging_buffer>' . $request['stagingBuffer'] . '</staging_buffer>' : '') . '
                        </stage_pay_fields>
                    </payment_details>
                        <financials>
                            ' . (!empty($request['amount']) ? '<originators_principal_amount>' . $request['amount'] . '</originators_principal_amount>' : '') . '
                            ' . (!empty($request['destinationAmount']) ? '<destination_principal_amount>' . $request['destinationAmount'] . '</destination_principal_amount>' : '') . '
                            ' . (!empty($request['grossTotalAmount']) ? '<gross_total_amount>' . $request['grossTotalAmount'] . '</gross_total_amount>' : '') . '
                            ' . (!empty($request['sumCharges']) ? '<sum_charges>' . $request['sumCharges'] . '</sum_charges>' : '') . '
                            ' . (!empty($request['minTransactionLimit']) ? '<min_transaction_limit>' . $request['minTransactionLimit'] . '</min_transaction_limit>' : '') . '
                            ' . (!empty($request['maxTransactionLimit']) ? '<max_transaction_limit>' . $request['maxTransactionLimit'] . '</max_transaction_limit>' : '') . '
                        </financials>
                        <delivery_services>
                            <code>000</code>
                            <message>
                                <message_details context="4">
                                    ' . (!empty($request['message1']) ? '<text>' . $request['message1'] . '</text>' : '') . '
                                    ' . (!empty($request['message2']) ? '<text>' . $request['message2'] . '</text>' : '') . '
                                    ' . (!empty($request['message3']) ? '<text>' . $request['message3'] . '</text>' : '') . '
                                    ' . (!empty($request['message4']) ? '<text>' . $request['message4'] . '</text>' : '') . '
                                </message_details>
                            </message>
                        </delivery_services>
                        <promotions>
                            ' . (!empty($request['promoSequenceNo']) ? '<promo_sequence_no>' . $request['promoSequenceNo'] . '</promo_sequence_no>' : '') . '
                            ' . (!empty($request['promoName']) ? '<promo_name>' . $request['promoName'] . '</promo_name>' : '') . '
                            ' . (!empty($request['promoMessage']) ? '<promo_message>' . $request['promoMessage'] . '</promo_message>' : '') . '
                            ' . (!empty($request['senderPromoCode']) ? '<sender_promo_code>' . $request['senderPromoCode'] . '</sender_promo_code>' : '') . '
                        </promotions>
                        ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                    <foreign_remote_system>
                        <identifier>WGSSPH5131T</identifier>
                        <reference_no>0000000015782274</reference_no>
                        <counter_id>PH513DSAP01B</counter_id>
                    </foreign_remote_system>
                        ' . (!empty($request['mtcn_digest']) ? '<mtcn_digest>' . $request['mtcn_digest'] . '</mtcn_digest>' : '') . '
                </xrsi:send-money-validation-request>
            </soapenv:Body>
            </soapenv:Envelope>
        ';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }
        //  exit(var_dump($params));

        $output = $this->requestWUAPIMobile($params, $client_id, $request);

        $this->retryMechanism($output, 'mobile_send_money_validation', $request, $client_id);

        // exit(var_dump($output));

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = sendmoneyvalidateLogs::create($logs);

        return $output;

    }

    public function sendMoneyStoreRequest($request, $client_id)
    {

        $destcountryCode = $request['destinationCountry'];
        $destcountryName = config('country.' . $destcountryCode);

        $countryCode = $request['senderCountryCode'];
        $countryName = config('country.' . $countryCode);

        if (array_key_exists("flagPay", $request)) {
            $flagPay = $request['flagPay'];
        } else {
            $flagPay = "N";
        }

        if (!array_key_exists("stateCode", $request) || $request['stateCode'] == '') {
            $stateCode = "";
        } else {
            $stateCode = $request['stateCode'];
        }
        if (!array_key_exists("receiverCity", $request) || $request['receiverCity'] == '') {
            $city = "";
        } else {
            $city = $request['receiverCity'];
        }

        if (!array_key_exists("myWuNumber", $request)) {
            $myWuNumber = "";
        } else {
            $myWuNumber = $request['myWuNumber'];
        }

        if (!array_key_exists("accountNumber", $request)) {
            $accountNumber = "";
        } else {
            $accountNumber = $request['accountNumber'];
        }

        if (!array_key_exists("bankName", $request)) {
            $bankName = "";
        } else {
            $bankName = $request['bankName'];
        }
        if (!array_key_exists("bic", $request)) {
            $bic = "";
        } else {
            $bic = $request['bic'];
        }
        if (!array_key_exists("accountPrefix", $request)) {
            $accountPrefix = "";
        } else {
            $accountPrefix = $request['accountPrefix'];
        }
        if (!array_key_exists("bankCode", $request)) {
            $bankCode = "";
        } else {
            $bankCode = $request['bankCode'];
        }
        if (!array_key_exists("accountSuffix", $request)) {
            $accountSuffix = "";
        } else {
            $accountSuffix = $request['accountSuffix'];
        }
        if (!array_key_exists("branchNumber", $request)) {
            $branchNumber = "";
        } else {
            $branchNumber = $request['branchNumber'];
        }

        //Bank Details
        $bank_details = '';
        if (!empty($request['accountNumber'])) {
            $bank_details = '<bank_details>';
            $bank_details .= !empty($request['bankName']) ? '<name>' . $request['bankName'] . '</name>' : '';
            $bank_details .= !empty($request['accountNumber']) ? '<account_number>' . $request['accountNumber'] . '</account_number>' : '';
            $bank_details .= !empty($request['branchNumber']) ? '<branch_number>' . $request['branchNumber'] . '</branch_number>' : '';
            $bank_details .= !empty($request['branchLocation']) ? '<bank_location>' . $request['branchLocation'] . '</bank_location>' : '';
            $bank_details .= !empty($request['bic']) ? '<bic>' . $request['bic'] . '</bic>' : '';
            $bank_details .= !empty($request['bankCode']) ? '<bank_code>' . $request['bankCode'] . '</bank_code>' : '';
            $bank_details .= !empty($request['sortCode']) ? '<sort_code>' . $request['sortCode'] . '</sort_code>' : '';
            $bank_details .= !empty($request['accountPrefix']) ? '<account_prefix>' . $request['accountPrefix'] . '</account_prefix>' : '';
            $bank_details .= !empty($request['accountSuffix']) ? '<account_suffix>' . $request['accountSuffix'] . '</account_suffix>' : '';
            $bank_details .= !empty($request['accountName']) ? '<bank_account_holder>' . $request['accountName'] . '</bank_account_holder>' : '';
            $bank_details .= '</bank_details>';
        }

        if (!empty($request['issueDate'])) {
            $request['issueDate'] = str_replace('/', '', $request['issueDate']);
        }
        if (!empty($request['expiration'])) {
            $request['expiration'] = str_replace('/', '', $request['expiration']);
        }
        if (!empty($request['birthDate'])) {
            $request['birthDate'] = str_replace('/', '', $request['birthDate']);
        }

        $id_details = '';
        if (!empty($request['idType']) || !empty($request['idCountryIssued']) || !empty($request['idNum'])) {
            $id_details = '<id_details>';
            $id_details .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
            $id_details .= !empty($request['idCountryIssued']) ? '<id_country_of_issue>' . $request['idCountryIssued'] . '</id_country_of_issue>' : '';
            $id_details .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
            $id_details .= '</id_details>';
        }

        $device = '<device>
            <type>MOBILE</type>
        </device>';
        $channel = '
        <channel>
            <type>SFSS</type>
            <name>IPCV</name>
            <version>9525</version>
        </channel>';
        $terminal = '<terminal>
            <id>*Ske</id>
        </terminal>';
        $foreignRemoteSystem = '<foreign_remote_system>
            <identifier>WGSSPH5131T</identifier>
            <reference_no>0000000015782274</reference_no>
            <counter_id>PH513DSAP01B</counter_id>
        </foreign_remote_system>';
        // if($request['mtRequestedStatus'] == 'RELEASE')
        // {
        //     $terminal='';
        //     $device =
        //     '<device>
        //         <type>AGENT</type>
        //     </device>';

        //     $channel =
        //     '<channel>
        //         <type>SFPS</type>
        //         <name>IPCV</name>
        //         <version>9520</version>
        //     </channel>';

        //     $foreignRemoteSystem =
        //     '<foreign_remote_system>
        //         <identifier>WGPSPH5130T</identifier>
        //         <reference_no>115210-000000003</reference_no>
        //         <counter_id>PH513PST001D</counter_id>
        //     </foreign_remote_system>';
        // }

        $params = '
        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
            <soap:Body>
                <ns2:send-money-store-request xmlns:ns2="http://www.westernunion.com/schema/xrsi">
                    ' . $device . '
                    ' . $channel . '
                    <instant_notification>
                        ' . (!empty($request['addlServiceCharges']) ? '<addl_service_charges>' . $request['addlServiceCharges'] . '</addl_service_charges>' : '') . '
                    </instant_notification>
                    ' . $terminal . '
                    <sender>
                        <name name_type="D">
                            ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['middleName']) ? '<middle_name>' . $request['middleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                        </name>
                        <address>
                            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                            ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . (!empty($request['senderCountryCode']) ? '<country_code>' . $request['senderCountryCode'] . '</country_code>' : '') . '
                                    ' . (!empty($request['senderCountryCurrencyCode']) ? '<currency_code>' . $request['senderCountryCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $countryName . '</country_name>
                            </country_code>
                            ' . (!empty($request['addressType']) ? '<address_type>' . $request['senderCountryCurrencyCode'] . '</address_type>' : '') . '
                        </address>
                        <preferred_customer>
                            ' . (!empty($request['permanentChange']) ? '<permanent_change>' . $request['permanentChange'] . '</permanent_change>' : '') . '
                            ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                        </preferred_customer>
                        <compliance_details>

                            ' . $this->getRoutingCode($request)['templateId'] . '
                            ' . (!empty($request['version']) ? '<version>' . $request['version'] . '</version>' : '') . '
                            ' . $id_details . '
                            ' . (!empty($request['flagPay']) ? '<third_party_details><flag_pay>' . $request['flagPay'] . '</flag_pay></third_party_details>' : '') . '

                            ' . (!empty($request['complianceFlagBuffer']) ? '<compliance_flags_buffer>' . $request['complianceFlagBuffer'] . '</compliance_flags_buffer>' : '') . '
                            ' . (!empty($request['complianceDataBuffer']) ? '<compliance_data_buffer>' . $request['complianceDataBuffer'] . '</compliance_data_buffer>' : '') . '

                            ' . (!empty($request['issueDate']) ? '<id_issue_date>' . $request['issueDate'] . '</id_issue_date>' : '') . '
                            ' . (!empty($request['expiration']) ? '<id_expiration_date>' . $request['expiration'] . '</id_expiration_date>' : '') . '
                            ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                            ' . (!empty($request['occupation']) ? '<occupation>' . $request['occupation'] . '</occupation>' : '') . '
                            ' . (!empty($request['transactionReason']) ? '<transaction_reason>' . $request['transactionReason'] . '</transaction_reason>' : '') . '

                            ' . (!empty($request['countryofBirth']) ? '<Country_of_Birth>' . $request['countryofBirth'] . '</Country_of_Birth>' : '') . '

                            ' . (!empty($request['nationality']) ? '<nationality>' . $request['nationality'] . '</nationality>' : '') . '
                            ' . (!empty($request['gender']) ? '<Gender>' . $request['gender'] . '</Gender>' : '') . '
                            ' . (!empty($request['fundSource']) ? '<Source_of_Funds>' . $request['fundSource'] . '</Source_of_Funds>' : '') . '
                            ' . (!empty($request['relationshiptoReceiver']) ? '<Relationship_to_Receiver_Sender>' . $request['relationshiptoReceiver'] . '</Relationship_to_Receiver_Sender>' : '') . '

                            ' . (!empty($request['ackFlag']) ? '<ack_flag>' . strtoupper($request['ackFlag']) . '</ack_flag>' : '') . '
                            ' . (!empty($request['idDocControlNumber']) ? '<id_doc_control_number>' . $request['idDocControlNumber'] . '</id_doc_control_number>' : '') . '
                            ' . (!empty($request['galacticId']) ? '<galactic_id>' . $request['galacticId'] . '</galactic_id>' : '') . '
                            ' . (!empty($request['multiErrorSupported']) ? '<multi_error_supported>' . $request['multiErrorSupported'] . '</multi_error_supported>' : '') . '
                            ' . (!empty($request['positionLevel']) ? '<employment_position_level>' . $request['positionLevel'] . '</employment_position_level>' : '') . '
                        </compliance_details>
                        ' . (!empty($request['phoneCountryCode']) ? '<phone_country_code>' . $request['phoneCountryCode'] . '</phone_country_code>' : '') . '
                        ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                        ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                    </sender>
                    <receiver>
                        <name name_type="D">
                            ' . (!empty($request['receiverFirstName']) ? '<first_name>' . $request['receiverFirstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['receiverMiddleName']) ? '<middle_name>' . $request['receiverMiddleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['receiverLastName']) ? '<last_name>' . $request['receiverLastName'] . '</last_name>' : '') . '
                        </name>
                        <address>
                            ' . (!empty($request['receiverAddress1']) ? '<addr_line1>' . $request['receiverAddress1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['receiverAddress2']) ? '<addr_line2>' . $request['receiverAddress2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['receiverHomeCity']) ? '<city>' . $request['receiverHomeCity'] . '</city>' : '') . '
                            ' . (!empty($request['receiverState']) ? '<state>' . $request['receiverState'] . '</state>' : '') . '
                            ' . (!empty($request['receiverPostalCode']) ? '<postal_code>' . $request['receiverPostalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                    ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $destcountryName . '</country_name>
                            </country_code>
                            ' . (!empty($request['receiverAddressType']) ? '<address_type>' . $request['receiverAddressType'] . '</address_type>' : '') . '
                        </address>
                    </receiver>
                    <promotions>
                        ' . (!empty($request['promoSequenceNo']) ? '<promo_sequence_no>' . $request['promoSequenceNo'] . '</promo_sequence_no>' : '') . '
                        ' . (!empty($request['promoName']) ? '<promo_name>' . $request['promoName'] . '</promo_name>' : '') . '
                        ' . (!empty($request['promoMessage']) ? '<promo_message>' . $request['promoMessage'] . '</promo_message>' : '') . '
                        ' . (!empty($request['senderPromoCode']) ? '<sender_promo_code>' . $request['senderPromoCode'] . '</sender_promo_code>' : '') . '
                    </promotions>
                    <payment_details>
                        <expected_payout_location>
                            ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                            ' . (!empty($request['receiverCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                        </expected_payout_location>
                        <recording_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </recording_country_currency>
                        <destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </destination_country_currency>
                        <originating_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </originating_country_currency>

                        ' . (!empty($request['originatingCity']) ? '<originating_city>' . $request['originatingCity'] . '</originating_city>' : '') . '
                        ' . (!empty($request['originatingState']) ? '<originating_state>' . $request['originatingState'] . '</originating_state>' : '') . '
                        ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                        ' . (!empty($request['paymentType']) ? '<payment_type>' . $request['paymentType'] . '</payment_type>' : '') . '
                        ' . (!empty($request['exchangeRate']) ? '<exchange_rate>' . $request['exchangeRate'] . '</exchange_rate>' : '') . '
                        ' . (!empty($request['fixOnSend']) ? '<fix_on_send>' . $request['fixOnSend'] . '</fix_on_send>' : '') . '

                        ' . (!empty($request['duplicateDetectionFlag']) ? '<duplicate_detection_flag>' . $request['duplicateDetectionFlag'] . '</duplicate_detection_flag>' : '') . '
                        ' . (!empty($request['mtRequestedStatus']) ? '<mt_requested_status>' . $request['mtRequestedStatus'] . '</mt_requested_status>' : '') . '
                        <stage_pay_fields>
                            ' . (!empty($request['stagingBuffer']) ? '<staging_buffer>' . $request['stagingBuffer'] . '</staging_buffer>' : '') . '
                        </stage_pay_fields>
                    </payment_details>
                    <financials>
                        <taxes>
                            ' . (!empty($request['municipalTax']) ? '<municipal_tax>' . $request['municipalTax'] . '</municipal_tax>' : '') . '
                            ' . (!empty($request['stateTax']) ? '<state_tax>' . $request['stateTax'] . '</state_tax>' : '') . '
                            ' . (!empty($request['countyTax']) ? '<county_tax>' . $request['countyTax'] . '</county_tax>' : '') . '
                            ' . (!empty($request['taxWorksheet']) ? '<tax_worksheet>' . $request['taxWorksheet'] . '</tax_worksheet>' : '') . '
                        </taxes>
                        ' . (!empty($request['amount']) ? '<originators_principal_amount>' . $request['amount'] . '</originators_principal_amount>' : '') . '
                        ' . (!empty($request['destinationAmount']) ? '<destination_principal_amount>' . $request['destinationAmount'] . '</destination_principal_amount>' : '') . '

                        ' . (!empty($request['grossTotalAmount']) ? '<gross_total_amount>' . $request['grossTotalAmount'] . '</gross_total_amount>' : '') . '
                        ' . (!empty($request['plusChargesAmount']) ? '<plus_charges_amount>' . $request['plusChargesAmount'] . '</plus_charges_amount>' : '') . '

                        ' . (!empty($request['charges']) ? '<charges>' . $request['charges'] . '</charges>' : '') . '
                        ' . (!empty($request['messageCharge']) ? '<message_charge>' . $request['messageCharge'] . '</message_charge>' : '') . '

                        ' . (!empty($request['totalUndiscountedCharges']) ? '<total_undiscounted_charges>' . $request['totalUndiscountedCharges'] . '</total_undiscounted_charges>' : '') . '
                        ' . (!empty($request['totalDiscountedCharges']) ? '<total_discounted_charges>' . $request['totalDiscountedCharges'] . '</total_discounted_charges>' : '') . '
                    </financials>
                    <delivery_services>
                        <code>000</code>
                        <message>
                            <message_details context="4">
                                ' . (!empty($request['message1']) ? '<text>' . $request['message1'] . '</text>' : '') . '
                                ' . (!empty($request['message2']) ? '<text>' . $request['message2'] . '</text>' : '') . '
                                ' . (!empty($request['message3']) ? '<text>' . $request['message3'] . '</text>' : '') . '
                                ' . (!empty($request['message4']) ? '<text>' . $request['message4'] . '</text>' : '') . '
                            </message_details>
                        </message>
                    </delivery_services>
                    ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                    ' . (!empty($request['new_mtcn']) ? '<new_mtcn>' . $request['new_mtcn'] . '</new_mtcn>' : '') . '
                    ' . $foreignRemoteSystem . '
                </ns2:send-money-store-request>
            </soap:Body>
        </soap:Envelope>';

        // exit(var_dump($params));
        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPIMobile($params, $client_id, $request);

        $senderFirstName = !empty($request['firstName']) ? $request['firstName'] : '';
        $senderLastName = !empty($request['lastName']) ? $request['lastName'] : '';
        $senderName = $senderFirstName . " " . $senderLastName;

        $receiverFirstName = !empty($request['receiverFirstName']) ? $request['receiverFirstName'] : '';
        $receiverLastName = !empty($request['receiverLastName']) ? $request['receiverLastName'] : '';
        $receiverName = $receiverFirstName . " " . $receiverLastName;


        $logs['senderName'] = $senderName;
        $logs['amount'] = !empty($request['amount']) ? $request['amount'] : '';
        $logs['receiverName'] = $receiverName;

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $logs['mtcn'] = !empty($request['mtcn']) ? $request['mtcn'] : '';
        $logs['new_mtcn'] = !empty($request['new_mtcn']) ? $request['new_mtcn'] : '';

        $logs['address1'] = !empty($request['address1']) ? $request['address1'] : '';
        $logs['city'] = !empty($request['city']) ? $request['city'] : '';
        $logs['province'] = !empty($request['province']) ? $request['province'] : '';
        $logs['postalCode'] = !empty($request['postalCode']) ? $request['postalCode'] : '';
        $logs['senderCountryCode'] = !empty($request['senderCountryCode']) ? $request['senderCountryCode'] : '';
        $logs['senderCountryCurrencyCode'] = !empty($request['senderCountryCurrencyCode']) ? $request['senderCountryCurrencyCode'] : '';
        $logs['myWuNumber'] = !empty($request['myWuNumber']) ? $request['myWuNumber'] : '';
        $logs['destinationCountry'] = !empty($request['destinationCountry']) ? $request['destinationCountry'] : '';
        $logs['destinationCurrencyCode'] = !empty($request['destinationCurrencyCode']) ? $request['destinationCurrencyCode'] : '';
        $logs['currencyCode'] = !empty($request['currencyCode']) ? $request['currencyCode'] : '';
        $logs['transactionType'] = !empty($request['transactionType']) ? $request['transactionType'] : '';
        $logs['paymentType'] = !empty($request['paymentType']) ? $request['paymentType'] : '';
        $logs['destinationAmount'] = !empty($request['destinationAmount']) ? $request['destinationAmount'] : '';
        $logs['grossTotalAmount'] = !empty($request['grossTotalAmount']) ? $request['grossTotalAmount'] : '';
        $logs['plusChargesAmount'] = !empty($request['plusChargesAmount']) ? $request['plusChargesAmount'] : '';
        $logs['charges'] = !empty($request['charges']) ? $request['charges'] : '';
        $logs['phoneNum'] = !empty($request['phoneNum']) ? $request['phoneNum'] : '';

        $data_inserted = sendmoneystoreLogs::create($logs);

        // exit(var_dump($output));

        return $output;
    }

    public function holdTxnSelectRequest($request, $client_id)
    {

        $mtcn = !empty($request['new_mtcn']) ? $request['new_mtcn'] : '';

        $length = strlen($mtcn);

        if ($length == 10)
        {
            $mtcn = sendmoneystoreLogs::where('mtcn', '=', $mtcn)
                        ->pluck('new_mtcn');
            $mtcn = $mtcn[0];
        }

        $params = '
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:hold-txn-search-request>
                    <channel>
                        <type>SFPS</type>
                        <name>IPCV</name>
                        <version>9520</version>
                    </channel>
                    <new_mtcn>' . $mtcn . '</new_mtcn>
                    <search_type>SELECT</search_type>
                    <foreign_remote_system>
                        <identifier>WGPSPH5130T</identifier>
                        <reference_no>115210-000000003</reference_no>
                        <counter_id>PH513PST001D</counter_id>
                    </foreign_remote_system>
                </xrsi:hold-txn-search-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        // exit(var_dump($params));
        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id, $request);

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;

        $data_inserted = HoldTxnLog::create($logs);

        // exit(var_dump($output));

        return $output;
    }

    public function sendMoneyFulfilmentRequest($request, $client_id)
    {

        $destcountryCode = $request['destinationCountry'];
        $destcountryName = config('country.' . $destcountryCode);

        $countryCode = $request['senderCountryCode'];
        $countryName = config('country.' . $countryCode);

        if (array_key_exists("flagPay", $request)) {
            $flagPay = $request['flagPay'];
        } else {
            $flagPay = "N";
        }

        if (!array_key_exists("stateCode", $request) || $request['stateCode'] == '') {
            $stateCode = "";
        } else {
            $stateCode = $request['stateCode'];
        }
        if (!array_key_exists("receiverCity", $request) || $request['receiverCity'] == '') {
            $city = "";
        } else {
            $city = $request['receiverCity'];
        }

        if (!array_key_exists("myWuNumber", $request)) {
            $myWuNumber = "";
        } else {
            $myWuNumber = $request['myWuNumber'];
        }

        if (!array_key_exists("accountNumber", $request)) {
            $accountNumber = "";
        } else {
            $accountNumber = $request['accountNumber'];
        }

        if (!array_key_exists("bankName", $request)) {
            $bankName = "";
        } else {
            $bankName = $request['bankName'];
        }
        if (!array_key_exists("bic", $request)) {
            $bic = "";
        } else {
            $bic = $request['bic'];
        }
        if (!array_key_exists("accountPrefix", $request)) {
            $accountPrefix = "";
        } else {
            $accountPrefix = $request['accountPrefix'];
        }
        if (!array_key_exists("bankCode", $request)) {
            $bankCode = "";
        } else {
            $bankCode = $request['bankCode'];
        }
        if (!array_key_exists("accountSuffix", $request)) {
            $accountSuffix = "";
        } else {
            $accountSuffix = $request['accountSuffix'];
        }
        if (!array_key_exists("branchNumber", $request)) {
            $branchNumber = "";
        } else {
            $branchNumber = $request['branchNumber'];
        }

        //Bank Details
        $bank_details = '';
        if (!empty($request['accountNumber'])) {
            $bank_details = '<bank_details>';
            $bank_details .= !empty($request['bankName']) ? '<name>' . $request['bankName'] . '</name>' : '';
            $bank_details .= !empty($request['accountNumber']) ? '<account_number>' . $request['accountNumber'] . '</account_number>' : '';
            $bank_details .= !empty($request['branchNumber']) ? '<branch_number>' . $request['branchNumber'] . '</branch_number>' : '';
            $bank_details .= !empty($request['branchLocation']) ? '<bank_location>' . $request['branchLocation'] . '</bank_location>' : '';
            $bank_details .= !empty($request['bic']) ? '<bic>' . $request['bic'] . '</bic>' : '';
            $bank_details .= !empty($request['bankCode']) ? '<bank_code>' . $request['bankCode'] . '</bank_code>' : '';
            $bank_details .= !empty($request['sortCode']) ? '<sort_code>' . $request['sortCode'] . '</sort_code>' : '';
            $bank_details .= !empty($request['accountPrefix']) ? '<account_prefix>' . $request['accountPrefix'] . '</account_prefix>' : '';
            $bank_details .= !empty($request['accountSuffix']) ? '<account_suffix>' . $request['accountSuffix'] . '</account_suffix>' : '';
            $bank_details .= !empty($request['accountName']) ? '<bank_account_holder>' . $request['accountName'] . '</bank_account_holder>' : '';
            $bank_details .= '</bank_details>';
        }

        if (!empty($request['issueDate'])) {
            $request['issueDate'] = str_replace('/', '', $request['issueDate']);
        }
        if (!empty($request['expiration'])) {
            $request['expiration'] = str_replace('/', '', $request['expiration']);
        }
        if (!empty($request['birthDate'])) {
            $request['birthDate'] = str_replace('/', '', $request['birthDate']);
        }

        $id_details = '';
        if (!empty($request['idType']) || !empty($request['idCountryIssued']) || !empty($request['idNum'])) {
            $id_details = '<id_details>';
            $id_details .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
            $id_details .= !empty($request['idCountryIssued']) ? '<id_country_of_issue>' . $request['idCountryIssued'] . '</id_country_of_issue>' : '';
            $id_details .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
            $id_details .= '</id_details>';
        }

        $terminal = '';
        $device = '<device>
                <type>AGENT</type>
            </device>';

        $channel = '<channel>
                <type>SFPS</type>
                <name>IPCV</name>
                <version>9520</version>
            </channel>';

        $foreignRemoteSystem = '<foreign_remote_system>
                <identifier>WGPSPH5130T</identifier>
                <reference_no>115210-000000003</reference_no>
                <counter_id>PH513PST001D</counter_id>
            </foreign_remote_system>';


        $currentAddress = '<Current_address>
                ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                <country>' . $countryName . '</country>
            </Current_address>';

        if (!empty('currentAddress1')) {
            $currentAddress = '<Current_address>
                    ' . (!empty($request['currentAddress1']) ? '<addr_line1>' . $request['currentAddress1'] . '</addr_line1>' : '') . '
                    ' . (!empty($request['currentAddress2']) ? '<addr_line2>' . $request['currentAddress2'] . '</addr_line2>' : '') . '
                    ' . (!empty($request['currentCity']) ? '<city>' . $request['currentCity'] . '</city>' : '') . '
                    ' . (!empty($request['currentProvince']) ? '<state_name>' . $request['currentProvince'] . '</state_name>' : '') . '
                    ' . (!empty($request['currentPostalCode']) ? '<postal_code>' . $request['currentPostalCode'] . '</postal_code>' : '') . '
                    ' . (!empty($request['currentCountry']) ? '<country>' . $request['currentCountry'] . '</country>' : '') . '
                    ' . (empty($request['currentCountry']) ? '<country>' . $countryName . '</country>' : '') . '
                </Current_address>';
        }

        $params = '
        <soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
            <soap:Body>
                <ns2:send-money-store-request xmlns:ns2="http://www.westernunion.com/schema/xrsi">
                    ' . $device . '
                    ' . $channel . '
                    <instant_notification>
                        ' . (!empty($request['addlServiceCharges']) ? '<addl_service_charges>' . $request['addlServiceCharges'] . '</addl_service_charges>' : '') . '
                    </instant_notification>
                    ' . $terminal . '
                    <sender>
                        <name name_type="D">
                            ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['middleName']) ? '<middle_name>' . $request['middleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                        </name>
                        <address>
                            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                            ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . (!empty($request['senderCountryCode']) ? '<country_code>' . $request['senderCountryCode'] . '</country_code>' : '') . '
                                    ' . (!empty($request['senderCountryCurrencyCode']) ? '<currency_code>' . $request['senderCountryCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $countryName . '</country_name>
                            </country_code>
                            ' . (!empty($request['addressType']) ? '<address_type>' . $request['senderCountryCurrencyCode'] . '</address_type>' : '') . '
                        </address>
                        <preferred_customer>
                            ' . (!empty($request['permanentChange']) ? '<permanent_change>' . $request['permanentChange'] . '</permanent_change>' : '') . '
                            ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                        </preferred_customer>
                        <compliance_details>
                            ' . (!empty($request['templateId']) ? '<template_id>' . $request['templateId'] . '</template_id>' : '') . '
                            ' . (!empty($request['version']) ? '<version>' . $request['version'] . '</version>' : '') . '
                            ' . $id_details . '
                            ' . (!empty($request['flagPay']) ? '<third_party_details><flag_pay>' . $request['flagPay'] . '</flag_pay></third_party_details>' : '') . '

                            ' . (!empty($request['complianceFlagBuffer']) ? '<compliance_flags_buffer>' . $request['complianceFlagBuffer'] . '</compliance_flags_buffer>' : '') . '
                            ' . (!empty($request['complianceDataBuffer']) ? '<compliance_data_buffer>' . $request['complianceDataBuffer'] . '</compliance_data_buffer>' : '') . '

                            ' . (!empty($request['issueDate']) ? '<id_issue_date>' . $request['issueDate'] . '</id_issue_date>' : '') . '
                            ' . (!empty($request['expiration']) ? '<id_expiration_date>' . $request['expiration'] . '</id_expiration_date>' : '') . '
                            ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                            ' . (!empty($request['occupation']) ? '<occupation>' . $request['occupation'] . '</occupation>' : '') . '
                            ' . (!empty($request['transactionReason']) ? '<transaction_reason>' . $request['transactionReason'] . '</transaction_reason>' : '') . '

                            ' . $currentAddress . '

                            ' . (!empty($request['countryofBirth']) ? '<Country_of_Birth>' . $request['countryofBirth'] . '</Country_of_Birth>' : '') . '

                            ' . (!empty($request['nationality']) ? '<nationality>' . $request['nationality'] . '</nationality>' : '') . '
                            ' . (!empty($request['gender']) ? '<Gender>' . $request['gender'] . '</Gender>' : '') . '
                            ' . (!empty($request['fundSource']) ? '<Source_of_Funds>' . $request['fundSource'] . '</Source_of_Funds>' : '') . '
                            ' . (!empty($request['relationshiptoReceiver']) ? '<Relationship_to_Receiver_Sender>' . $request['relationshiptoReceiver'] . '</Relationship_to_Receiver_Sender>' : '') . '

                            ' . (!empty($request['ackFlag']) ? '<ack_flag>' . strtoupper($request['ackFlag']) . '</ack_flag>' : '') . '
                            ' . (!empty($request['idDocControlNumber']) ? '<id_doc_control_number>' . $request['idDocControlNumber'] . '</id_doc_control_number>' : '') . '
                            ' . (!empty($request['galacticId']) ? '<galactic_id>' . $request['galacticId'] . '</galactic_id>' : '') . '
                            ' . (!empty($request['multiErrorSupported']) ? '<multi_error_supported>' . $request['multiErrorSupported'] . '</multi_error_supported>' : '') . '
                            ' . (!empty($request['positionLevel']) ? '<employment_position_level>' . $request['positionLevel'] . '</employment_position_level>' : '') . '
                        </compliance_details>
                        ' . (!empty($request['phoneCountryCode']) ? '<phone_country_code>' . $request['phoneCountryCode'] . '</phone_country_code>' : '') . '
                        ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                        ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                    </sender>
                    <receiver>
                        <name name_type="D">
                            ' . (!empty($request['receiverFirstName']) ? '<first_name>' . $request['receiverFirstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['receiverMiddleName']) ? '<middle_name>' . $request['receiverMiddleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['receiverLastName']) ? '<last_name>' . $request['receiverLastName'] . '</last_name>' : '') . '
                        </name>
                        <address>
                            ' . (!empty($request['receiverAddress1']) ? '<addr_line1>' . $request['receiverAddress1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['receiverAddress2']) ? '<addr_line2>' . $request['receiverAddress2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['receiverHomeCity']) ? '<city>' . $request['receiverHomeCity'] . '</city>' : '') . '
                            ' . (!empty($request['receiverState']) ? '<state>' . $request['receiverState'] . '</state>' : '') . '
                            ' . (!empty($request['receiverPostalCode']) ? '<postal_code>' . $request['receiverPostalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                    ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $destcountryName . '</country_name>
                            </country_code>
                            ' . (!empty($request['receiverAddressType']) ? '<address_type>' . $request['receiverAddressType'] . '</address_type>' : '') . '
                        </address>
                    </receiver>
                    <promotions>
                        ' . (!empty($request['promoSequenceNo']) ? '<promo_sequence_no>' . $request['promoSequenceNo'] . '</promo_sequence_no>' : '') . '
                        ' . (!empty($request['promoName']) ? '<promo_name>' . $request['promoName'] . '</promo_name>' : '') . '
                        ' . (!empty($request['promoMessage']) ? '<promo_message>' . $request['promoMessage'] . '</promo_message>' : '') . '
                        ' . (!empty($request['couponCode']) ? '<sender_promo_code>' . $request['senderPromoCode'] . '</sender_promo_code>' : '') . '
                    </promotions>
                    <payment_details>
                        <expected_payout_location>
                            ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                            ' . (!empty($request['receiverCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                        </expected_payout_location>
                        <recording_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </recording_country_currency>
                        <destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </destination_country_currency>
                        <originating_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['currencyCode']) ? '<currency_code>' . $request['currencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </originating_country_currency>

                        ' . (!empty($request['originatingCity']) ? '<originating_city>' . $request['originatingCity'] . '</originating_city>' : '') . '
                        ' . (!empty($request['originatingState']) ? '<originating_state>' . $request['originatingState'] . '</originating_state>' : '') . '
                        ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                        ' . (!empty($request['paymentType']) ? '<payment_type>' . $request['paymentType'] . '</payment_type>' : '') . '
                        ' . (!empty($request['exchangeRate']) ? '<exchange_rate>' . $request['exchangeRate'] . '</exchange_rate>' : '') . '
                        ' . (!empty($request['fixOnSend']) ? '<fix_on_send>' . $request['fixOnSend'] . '</fix_on_send>' : '') . '

                        ' . (!empty($request['duplicateDetectionFlag']) ? '<duplicate_detection_flag>' . $request['duplicateDetectionFlag'] . '</duplicate_detection_flag>' : '') . '
                        ' . (!empty($request['mtRequestedStatus']) ? '<mt_requested_status>' . $request['mtRequestedStatus'] . '</mt_requested_status>' : '') . '
                        <stage_pay_fields>
                            ' . (!empty($request['stagingBuffer']) ? '<staging_buffer>' . $request['stagingBuffer'] . '</staging_buffer>' : '') . '
                        </stage_pay_fields>
                    </payment_details>
                    <financials>
                        <taxes>
                            ' . (!empty($request['municipalTax']) ? '<municipal_tax>' . $request['municipalTax'] . '</municipal_tax>' : '') . '
                            ' . (!empty($request['stateTax']) ? '<state_tax>' . $request['stateTax'] . '</state_tax>' : '') . '
                            ' . (!empty($request['countyTax']) ? '<county_tax>' . $request['countyTax'] . '</county_tax>' : '') . '
                            ' . (!empty($request['taxWorksheet']) ? '<tax_worksheet>' . $request['taxWorksheet'] . '</tax_worksheet>' : '') . '
                        </taxes>
                        ' . (!empty($request['amount']) ? '<originators_principal_amount>' . $request['amount'] . '</originators_principal_amount>' : '') . '
                        ' . (!empty($request['destinationAmount']) ? '<destination_principal_amount>' . $request['destinationAmount'] . '</destination_principal_amount>' : '') . '

                        ' . (!empty($request['grossTotalAmount']) ? '<gross_total_amount>' . $request['grossTotalAmount'] . '</gross_total_amount>' : '') . '
                        ' . (!empty($request['plusChargesAmount']) ? '<plus_charges_amount>' . $request['plusChargesAmount'] . '</plus_charges_amount>' : '') . '

                        ' . (!empty($request['charges']) ? '<charges>' . $request['charges'] . '</charges>' : '') . '
                        ' . (!empty($request['messageCharge']) ? '<message_charge>' . $request['messageCharge'] . '</message_charge>' : '') . '

                        ' . (!empty($request['totalUndiscountedCharges']) ? '<total_undiscounted_charges>' . $request['totalUndiscountedCharges'] . '</total_undiscounted_charges>' : '') . '
                        ' . (!empty($request['totalDiscountedCharges']) ? '<total_discounted_charges>' . $request['totalDiscountedCharges'] . '</total_discounted_charges>' : '') . '
                    </financials>
                    <delivery_services>
                        <code>000</code>
                        <message>
                            <message_details context="4">
                                ' . (!empty($request['message1']) ? '<text>' . $request['message1'] . '</text>' : '') . '
                                ' . (!empty($request['message2']) ? '<text>' . $request['message2'] . '</text>' : '') . '
                                ' . (!empty($request['message3']) ? '<text>' . $request['message3'] . '</text>' : '') . '
                                ' . (!empty($request['message4']) ? '<text>' . $request['message4'] . '</text>' : '') . '
                            </message_details>
                        </message>
                    </delivery_services>
                    ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                    ' . (!empty($request['new_mtcn']) ? '<new_mtcn>' . $request['new_mtcn'] . '</new_mtcn>' : '') . '
                    ' . $foreignRemoteSystem . '
                </ns2:send-money-store-request>
            </soap:Body>
        </soap:Envelope>';

        // exit(var_dump($params));
        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPIMobile($params, $client_id, $request);

//        Debugger::dd($output);
        // return $output;

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;

        $data_inserted = sendmoneystoreLogs::create($logs);


        if (!empty($request['myWuNumber'])) {
            // Send WU Lookup Request Start
            $params = $this->wuLookupXml($request, $client_id);
            $res = $this->requestWUAPIMobile($params, $client_id, $request);
            // Send WU Lookup Request End

            // Extract Total Points Start
            $xml = simplexml_load_string($res);
            $totalPoints = (string)$xml->xpath('//wu_card/total_points_earned')[0];
            // Extract Total Points End

            $wuOutput = $output;
            try {
                // Add Points to XML Start
                $output = simplexml_load_string($output);
                $namespaces = $output->getNamespaces(true);
                $body = $output->children($namespaces['soapenv'])
                    ->Body
                    ->children($namespaces['xrsi'])
                    ->children()
                    ->sender;

            } catch (\Exception $e) {
//                Debugger::dd($wuOutput);
                return $wuOutput;
            }

            $body->addChild("total_points_earned", $totalPoints);
            $output = $output->asXML();
            // Add Points to XML End

            $senderFirstName = !empty($request['firstName']) ? $request['firstName'] : '';
            $senderLastName = !empty($request['lastName']) ? $request['lastName'] : '';
            $senderName = $senderFirstName . " " . $senderLastName;

            $receiverFirstName = !empty($request['receiverFirstName']) ? $request['receiverFirstName'] : '';
            $receiverLastName = !empty($request['receiverLastName']) ? $request['receiverLastName'] : '';
            $receiverName = $receiverFirstName . " " . $receiverLastName;


            // $logs['agentName'] = $agentName;
            $logs['branchLocation'] = !empty($request['branchLocation']) ? $request['branchLocation'] : '';
            // $logs['ftid'] = $ftid;
            
            $logs['mtcn'] = !empty($request['mtcn']) ? $request['mtcn'] : '';
            $logs['agentEmail'] = !empty($request['agentEmail']) ? $request['agentEmail'] : '';
            $logs['client_id'] = $client_id;
            $logs['senderName'] = $senderName;
            $logs['amount'] = !empty($request['amount']) ? $request['amount'] : '';
            $logs['receiverName'] = $receiverName;
            $logs['xml_request'] = $params;
            $logs['request_data'] = json_encode($request);
            $logs['reply_data'] = $output;

            $logs['address1'] = !empty($request['address1']) ? $request['address1'] : '';
            $logs['city'] = !empty($request['city']) ? $request['city'] : '';
            $logs['province'] = !empty($request['province']) ? $request['province'] : '';
            $logs['postalCode'] = !empty($request['postalCode']) ? $request['postalCode'] : '';
            $logs['senderCountryCode'] = !empty($request['senderCountryCode']) ? $request['senderCountryCode'] : '';
            $logs['senderCountryCurrencyCode'] = !empty($request['senderCountryCurrencyCode']) ? $request['senderCountryCurrencyCode'] : '';
            $logs['myWuNumber'] = !empty($request['myWuNumber']) ? $request['myWuNumber'] : '';
            $logs['destinationCountry'] = !empty($request['destinationCountry']) ? $request['destinationCountry'] : '';
            $logs['destinationCurrencyCode'] = !empty($request['destinationCurrencyCode']) ? $request['destinationCurrencyCode'] : '';
            $logs['currencyCode'] = !empty($request['currencyCode']) ? $request['currencyCode'] : '';
            $logs['transactionType'] = !empty($request['transactionType']) ? $request['transactionType'] : '';
            $logs['paymentType'] = !empty($request['paymentType']) ? $request['paymentType'] : '';
            $logs['destinationAmount'] = !empty($request['destinationAmount']) ? $request['destinationAmount'] : '';
            $logs['grossTotalAmount'] = !empty($request['grossTotalAmount']) ? $request['grossTotalAmount'] : '';
            $logs['plusChargesAmount'] = !empty($request['plusChargesAmount']) ? $request['plusChargesAmount'] : '';
            $logs['charges'] = !empty($request['charges']) ? $request['charges'] : '';
            $logs['phoneNum'] = !empty($request['phoneNum']) ? $request['phoneNum'] : '';

            $data_inserted = sendmoneystoreLogs::create($logs);

            return $output;
        }

        return $output;
    }
}
