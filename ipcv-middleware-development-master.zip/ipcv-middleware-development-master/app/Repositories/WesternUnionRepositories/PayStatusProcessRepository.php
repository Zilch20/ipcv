<?php

namespace App\repositories\WesternUnionRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Support\Facades\Cache;
use App\PayStatusInquiryLog;
use App\Traits\WesternUnionCurlRequestTrait;
use App\Traits\SubAgentTraits;

class PayStatusProcessRepository extends Controller
{
    use WesternUnionCurlRequestTrait;
    use SubAgentTraits;

    public function test()
    {
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }

    //Payment Functions

    public function payStatusRequest($request, $client_id)
    {

        $ftid = "PH994AMP001A"; //Staging Credentials
        $fsid = "WGHHPH9940T"; //Staging Credentials
        // $fsid = "WGHHPH5130P"; //Prod Credentials
        // $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }
        $ftid = "PH994AMP001A";

        //Mobile Conditions
        $device = '';
        $foreignRemoteSystem =
        '<foreign_remote_system>
            <identifier>' . $fsid . '</identifier>
            <reference_no>115210-000000003</reference_no>
            <counter_id>' . $ftid . '</counter_id>
        </foreign_remote_system>';
        if(!empty($request['mobileFlag']))
        {
            if($request['mobileFlag'] === true || $request['mobileFlag'] == 'true')
            {
                $device = 
                '<device>
                    <id>WALLET</id>
                    <type>WALLET</type>
                </device>';
    
                $foreignRemoteSystem =
                '<foreign_remote_system>
                    <identifier>WGHHPH5130T</identifier>
                    <reference_no>115210-000000003</reference_no>
                    <counter_id>PH513AMP001D</counter_id>
                </foreign_remote_system>';
            }
        }
        //End Mobile Conditions

        $params = '<S:Envelope xmlns:S="http://schemas.xmlsoap.org/soap/envelope/">
            <S:Header/>
            <S:Body>
            <ns2:pay-status-inquiry-request-data xmlns:ns2="http://www.westernunion.com/schema/xrsi">
                ' . $device . '
                <channel>
                    <type>' . $request['channelType'] . '</type>
                    <name>IPCV</name>
                    <version>' . $request['channelVersion'] . '</version>
                </channel>
                <payment_details>
                    <expected_payout_location/>
                    <recording_country_currency>
                        <iso_code>
                        ' . (!empty($request['recordingCountryCode']) ? '<country_code>' . $request['recordingCountryCode'] . '</country_code>' : '') . '
                        ' . (!empty($request['recordingCountryCurrencyCode']) ? '<currency_code>' . $request['recordingCountryCurrencyCode'] . '</currency_code>' : '') . '
                        </iso_code>
                    </recording_country_currency>
                    <transaction_type/>
                    ' . (!empty($request['payWoIdIndicator']) ? '<pay_wo_id_indicator>' . $request['payWoIdIndicator'] . '</pay_wo_id_indicator>' : '') . '
                </payment_details>
                ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                ' . $foreignRemoteSystem . '
            </ns2:pay-status-inquiry-request-data>
            </S:Body>
        </S:Envelope>';
        // exit(var_dump($params));

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id, $request);

        $logs['clientId'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = PayStatusInquiryLog::create($logs);


        return $output;


    }

}
