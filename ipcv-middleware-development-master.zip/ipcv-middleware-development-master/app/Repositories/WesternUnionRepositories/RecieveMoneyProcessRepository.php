<?php

namespace App\repositories\WesternUnionRepositories;

use App\Http\Controllers\Controller;
use App\RetryMechanismLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Support\Facades\Cache;
use App\ReceiveMoneySearchLog;
use App\ReceiveMoneySelectLog;
use App\ReceiveMoneyPayLog;
use App\Traits\WesternUnionCurlRequestTrait;
use App\Traits\RetryMechanismTrait;
use App\Helpers\Debugger;
use App\Traits\SubAgentTraits;
use App\Traits\GetStatusTraits;

class RecieveMoneyProcessRepository extends Controller
{
    use WesternUnionCurlRequestTrait;
    use RetryMechanismTrait;
    use SubAgentTraits;
    use GetStatusTraits;

    public function test()
    {
        $xml = "Hi";
        return json_decode(json_encode($xml), true);
    }

    //Payment Functions

    public function recieveMoneySearchRequest($request, $client_id)
    {

        $ftid = "PH994AMP001A"; //Staging Credentials
        $fsid = "WGHHPH9940T"; //Staging Credentials
        // $fsid = "WGHHPH5130P"; //Prod Credentials
        // $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }
        $ftid = "PH994AMP001A";

        //Mobile Conditions
        $device = '';
        $receiverDetails = '';
        $foreignRemoteSystem =
        '<foreign_remote_system>
            <identifier>' . $fsid . '</identifier>
            <reference_no>115210-000000003</reference_no>
            <counter_id>' . $ftid . '</counter_id>
        </foreign_remote_system>';
        if(!empty($request['mobileFlag']))
        {
            if($request['mobileFlag'] === true || $request['mobileFlag'] == 'true')
            {
            $device = 
            '<device>
                <id>WALLET</id>
                <type>WALLET</type>
            </device>';

            if (!empty($request['firstName']) || !empty($request['lastName'])) {
                $receiverDetails = '<receiver>';
                $receiverDetails .= '<name name_type="D">';
                $receiverDetails .= !empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '';
                $receiverDetails .= !empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '';
                $receiverDetails .= '</name>';
                $receiverDetails .= '</receiver>';
            }

            $foreignRemoteSystem =
            '<foreign_remote_system>
                <identifier>WGHHPH5130T</identifier>
                <reference_no>115210-000000003</reference_no>
                <counter_id>PH513AMP001D</counter_id>
            </foreign_remote_system>';
            }
        }
        //End Mobile Conditions


        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:receive-money-search-request>
                    ' . $device . '
                    <channel>
                        <type>' . $request['channelType'] . '</type>
                        <name>IPCV</name>
                        <version>' . $request['channelVersion'] . '</version>
                    </channel>

                    ' . $foreignRemoteSystem . '

                    <payment_transaction>
                        ' . $receiverDetails . '
                        <payment_details>
                            <destination_country_currency>
                                <iso_code>
                                    ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '<country_code></country_code>') . '
                                    ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '<currency_code></currency_code>') . '
                                </iso_code>
                            </destination_country_currency>
                        </payment_details>

                        ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                    </payment_transaction>
                </xrsi:receive-money-search-request>
            </soapenv:Body>
        </soapenv:Envelope>';
        // exit(var_dump($params));

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id, $request);

        // exit(var_dump($output));

        $logs['client_id'] = $client_id;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = ReceiveMoneySearchLog::create($logs);

        return $output;


    }

    public function recieveMoneySelectRequest($request, $client_id)
    {
        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:recieve-money-select-request>
                    <channel>
                        <type>H2H</type>
                        <name>IPCV</name>
                        <version>9500</version>
                    </channel>

                    <foreign_remote_system>
                        <identifier>WGHHPH9940T</identifier>
                        <reference_no>115210-000000003</reference_no>
                        <counter_id>PH994AMP001A</counter_id>
                    </foreign_remote_system>

                    <money_transfer_key>' . $request['mtk'] . '</money_transfer_key>
                </xrsi:recieve-money-select-request>
            </soapenv:Body>
        </soapenv:Envelope>';


        $output = $this->requestWUAPI($params, $client_id, $request);

        $logs['client_id'] = $client_id;
        $logs['mtk'] = $request['mtk'];
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;
        $data_inserted = ReceiveMoneySelectLog::create($logs);

        // dd("Passed!");


        return $output;


    }

    public function recieveMoneyPayRequest($request, $client_id)
    {

        $countryCode = $request['receiverCountryCode'];
        $countryName = config('country.' . $countryCode);


        $ftid = "PH994AMP001A"; //Staging Credentials
        $fsid = "WGHHPH9940T"; //Staging Credentials
        // $fsid = "WGHHPH5130P"; //Prod Credentials
        // $ftid = "PH513ARP001A"; //Prod Credentials

        if(empty($request['mobileFlag']))
        {
            $ftid = $this->getFtid($request);
        }
        $ftid = "PH994AMP001A";

        //Mobile Conditions
        $currentAddress = 
        '<Current_address>
            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
            ' . (!empty($request['province']) ? '<state_name>' . $request['province'] . '</state_name>' : '') . '
            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
            ' . (!empty($request['currentCountry']) ? '<country>' . $request['currentCountry'] . '</country>' : '') . '
            ' . (empty($request['currentCountry']) ? '<country>' . $countryName . '</country>' : '') . '
        </Current_address>';
        $device = '';
        $receiverBankDetails = '';
        $foreignRemoteSystem =
        '<foreign_remote_system>
            <identifier>' . $fsid . '</identifier>
            <reference_no>115210-000000003</reference_no>
            <counter_id>' . $ftid . '</counter_id>
        </foreign_remote_system>';
        if(!empty($request['mobileFlag']))
        {
            if($request['mobileFlag'] === true || $request['mobileFlag'] == 'true')
            {
            $device = 
            '<device>
                <id>WALLET</id>
                <type>WALLET</type>
            </device>';

            $currentAddress = '
            <Current_address>
                ' . (!empty($request['currentAddress1']) ? '<addr_line1>' . $request['currentAddress1'] . '</addr_line1>' : '') . '
                ' . (!empty($request['currentAddress2']) ? '<addr_line2>' . $request['currentAddress2'] . '</addr_line2>' : '') . '
                ' . (!empty($request['currentCity']) ? '<city>' . $request['currentCity'] . '</city>' : '') . '
                ' . (!empty($request['currentProvince']) ? '<state_name>' . $request['currentProvince'] . '</state_name>' : '') . '
                ' . (!empty($request['currentPostalCode']) ? '<postal_code>' . $request['currentPostalCode'] . '</postal_code>' : '') . '
                <country>' . $countryName . '</country>
            </Current_address>
            ';

            if (!empty($request['receiverAccountNumber'])) {
                $receiverBankDetails = '<bank_details>';
                $receiverBankDetails .= !empty($request['receiverBankName']) ? '<name>' . $request['receiverBankName'] . '</name>' : '';
                $receiverBankDetails .= !empty($request['receiverAccountNumber']) ? '<account_number>' . $request['receiverAccountNumber'] . '</account_number>' : '';
                $receiverBankDetails .= !empty($request['receiverAccountType']) ? '<account_type>' . $request['receiverAccountType'] . '</account_type>' : '';
                $receiverBankDetails .= '</bank_details>';
            }

            $foreignRemoteSystem =
            '<foreign_remote_system>
                <identifier>WGHHPH5130T</identifier>
                <reference_no>115210-000000003</reference_no>
                <counter_id>PH513AMP001D</counter_id>
            </foreign_remote_system>';
            }
        }
        //End Mobile Conditions

        $request['issueDate'] = !empty($request['issueDate']) ? str_replace('/', '', $request['issueDate']) : '';
        $request['expiration'] = !empty($request['expiration']) ? str_replace('/', '', $request['expiration']) : '';
        $request['birthDate'] = str_replace('/', '', $request['birthDate']);

        if (!empty($request['templateId'])) {
            $request['templateId'] = 'UNI_01_P';
        }

        $id_details = '';
        if (!empty($request['idType']) || !empty($request['idCountryIssued']) || !empty($request['idNum'])) {
            $id_details = '<id_details>';
            $id_details .= !empty($request['idType']) ? '<id_type>' . $request['idType'] . '</id_type>' : '';
            $id_details .= !empty($request['idCountryIssued']) ? '<id_country_of_issue>' . $request['idCountryIssued'] . '</id_country_of_issue>' : '';
            $id_details .= !empty($request['idNum']) ? '<id_number>' . $request['idNum'] . '</id_number>' : '';
            $id_details .= '</id_details>';
        }

        $retryMechanism = RetryMechanismLog::findLog('recieve_money_pay', $request, 'receive')->get();
        if (!empty($retryMechanism[0])) {
            $retryMechanismData = $retryMechanism[0];
            $request['myWuNumber'] = !empty($retryMechanismData['account_nbr']) ? $retryMechanismData['account_nbr'] : $request['myWuNumber'];
            $request['galactic_id'] = !empty($retryMechanismData['galactic_id']) ? $retryMechanismData['galactic_id'] : null;
        }
//        Debugger::dd($request);

        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <soapenv:Header/>
            <soapenv:Body>
                <xrsi:receive-money-pay-request>
                    ' . $device . '
                    <channel>
                        <type>' . $request['channelType'] . '</type>
                        <name>IPCV</name>
                        <version>' . $request['channelVersion'] . '</version>
                    </channel>
                    <receiver>
                        <name name_type="D">
                            ' . (!empty($request['firstName']) ? '<first_name>' . $request['firstName'] . '</first_name>' : '') . '
                            ' . (!empty($request['middleName']) ? '<middle_name>' . $request['middleName'] . '</middle_name>' : '') . '
                            ' . (!empty($request['lastName']) ? '<last_name>' . $request['lastName'] . '</last_name>' : '') . '
                        </name>

                        <address>
                            ' . (!empty($request['address1']) ? '<addr_line1>' . $request['address1'] . '</addr_line1>' : '') . '
                            ' . (!empty($request['address2']) ? '<addr_line2>' . $request['address2'] . '</addr_line2>' : '') . '
                            ' . (!empty($request['city']) ? '<city>' . $request['city'] . '</city>' : '') . '
                            ' . (!empty($request['province']) ? '<state>' . $request['province'] . '</state>' : '') . '
                            ' . (!empty($request['postalCode']) ? '<postal_code>' . $request['postalCode'] . '</postal_code>' : '') . '
                            <country_code>
                                <iso_code>
                                    ' . ($request['receiverCountryCode'] ? '<country_code>' . $request['receiverCountryCode'] . '</country_code>' : '') . '
                                    ' . ($request['receiverCountryCurrencyCode'] ? '<currency_code>' . $request['receiverCountryCurrencyCode'] . '</currency_code>' : '') . '
                                </iso_code>
                                <country_name>' . $countryName . '</country_name>
                            </country_code>
                        </address>

                        <preferred_customer>
                            ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                        </preferred_customer>

                        <compliance_details>
                            ' . (!empty($request['templateId']) ? '<template_id>' . $request['templateId'] . '</template_id>' : '') . '
                            ' . (!empty($request['version']) ? '<version>' . $request['version'] . '</version>' : '') . '

                            ' . $id_details . '

                            ' . (!empty($request['idHasExpiration']) ? '<does_the_id_have_an_expiration_date>' . $request['idHasExpiration'] . '</does_the_id_have_an_expiration_date>' : '') . '
                            ' . (!empty($request['issueDate']) ? '<id_issue_date>' . $request['issueDate'] . '</id_issue_date>' : '') . '
                            ' . (!empty($request['expiration']) ? '<id_expiration_date>' . $request['expiration'] . '</id_expiration_date>' : '') . '
                            ' . (!empty($request['birthDate']) ? '<date_of_birth>' . $request['birthDate'] . '</date_of_birth>' : '') . '
                            ' . (!empty($request['occupation']) ? '<occupation>' . $request['occupation'] . '</occupation>' : '') . '
                            ' . (!empty($request['transactionReason']) ? '<transaction_reason>' . $request['transactionReason'] . '</transaction_reason>' : '') . '

                            ' . $currentAddress . '

                            ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                            ' . (!empty($request['countryofBirth']) ? '<Country_of_Birth>' . $request['countryofBirth'] . '</Country_of_Birth>' : '') . '
                            ' . (!empty($request['nationality']) ? '<nationality>' . $request['nationality'] . '</nationality>' : '') . '
                            ' . (!empty($request['gender']) ? '<Gender>' . $request['gender'] . '</Gender>' : '') . '
                            ' . (!empty($request['relationshiptoSender']) ? '<Relationship_to_Receiver_Sender>' . $request['relationshiptoSender'] . '</Relationship_to_Receiver_Sender>' : '') . '
                            ' . (!empty($request['ackFlag']) ? '<ack_flag>' . strtoupper($request['ackFlag']) . '</ack_flag>' : '') . '
                            ' . (!empty($request['phoneCountryCode']) ? '<Country_Code>' . $request['phoneCountryCode'] . '</Country_Code>' : '') . '
                            ' . (!empty($request['galactic_id']) ? '<galactic_id>' . $request['galactic_id'] . '</galactic_id>' : '') . '
                            ' . (!empty($request['multiErrorSupported']) ? '<multi_error_supported>' . $request['multiErrorSupported'] . '</multi_error_supported>' : '') . '
                            ' . (!empty($request['positionLevel']) ? '<employment_position_level>' . $request['positionLevel'] . '</employment_position_level>' : '') . '
                        </compliance_details>
                        ' . (!empty($request['phoneCountryCode']) ? '<phone_country_code>' . $request['phoneCountryCode'] . '</phone_country_code>' : '') . '
                        ' . (!empty($request['phoneNum']) ? '<contact_phone>' . $request['phoneNum'] . '</contact_phone>' : '') . '
                        <mobile_phone>
                            <phone_number>
                                ' . (!empty($request['phoneCountryCode']) ? '<country_code>' . $request['phoneCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['phoneNum']) ? '<national_number>' . $request['phoneNum'] . '</national_number>' : '') . '
                            </phone_number>
                        </mobile_phone>
                        ' . $receiverBankDetails . '
                    </receiver>

                    <payment_details>
                        <expected_payout_location>
                            ' . (!empty($request['stateCode']) ? '<state_code>' . $request['stateCode'] . '</state_code>' : '') . '
                            ' . (!empty($request['receiverCity']) ? '<city>' . $request['receiverCity'] . '</city>' : '') . '
                        </expected_payout_location>

                        <destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['destinationCountry']) ? '<country_code>' . $request['destinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['destinationCurrencyCode']) ? '<currency_code>' . $request['destinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </destination_country_currency>

                        <originating_country_currency>
                            <iso_code>
                                ' . (!empty($request['originatingCountryCode']) ? '<country_code>' . $request['originatingCountryCode'] . '</country_code>' : '') . '
                                ' . (!empty($request['originatingCurrencyCode']) ? '<currency_code>' . $request['originatingCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </originating_country_currency>

                        ' . (!empty($request['originatingCity']) ? '<originating_city>' . $request['originatingCity'] . '</originating_city>' : '') . '
                        ' . (!empty($request['transactionType']) ? '<transaction_type>' . $request['transactionType'] . '</transaction_type>' : '') . '
                        ' . (!empty($request['exchangeRate']) ? '<exchange_rate>' . $request['exchangeRate'] . '</exchange_rate>' : '') . '
                        <original_destination_country_currency>
                            <iso_code>
                                ' . (!empty($request['ogdestinationCountry']) ? '<country_code>' . $request['ogdestinationCountry'] . '</country_code>' : '') . '
                                ' . (!empty($request['ogdestinationCurrencyCode']) ? '<currency_code>' . $request['ogdestinationCurrencyCode'] . '</currency_code>' : '') . '
                            </iso_code>
                        </original_destination_country_currency>
                    </payment_details>

                    <financials>
                        <taxes>
                            <tax_worksheet/>
                        </taxes>
                        ' . (!empty($request['grossTotalAmount']) ? '<gross_total_amount>' . $request['grossTotalAmount'] . '</gross_total_amount>' : '') . '
                        ' . (!empty($request['payAmount']) ? '<pay_amount>' . $request['payAmount'] . '</pay_amount>' : '') . '

                        ' . (!empty($request['principalAmount']) ? '<principal_amount>' . $request['principalAmount'] . '</principal_amount>' : '') . '
                        ' . (!empty($request['charges']) ? '<charges>' . $request['charges'] . '</charges>' : '') . '
                        ' . (!empty($request['tolls']) ? '<tolls>' . $request['tolls'] . '</tolls>' : '') . '
                    </financials>

                    ' . (!empty($request['mtk']) ? '<money_transfer_key>' . $request['mtk'] . '</money_transfer_key>' : '') . '
                    ' . (!empty($request['new_mtcn']) ? '<new_mtcn>' . $request['new_mtcn'] . '</new_mtcn>' : '') . '
                    ' . (!empty($request['mtcn']) ? '<mtcn>' . $request['mtcn'] . '</mtcn>' : '') . '
                    ' . (!empty($request['payOrDoNot']) ? '<pay_or_do_not_pay_indicator>' . $request['payOrDoNot'] . '</pay_or_do_not_pay_indicator>' : '<pay_or_do_not_pay_indicator>P</pay_or_do_not_pay_indicator>') . '
                    ' . $foreignRemoteSystem . '
                </xrsi:receive-money-pay-request>
            </soapenv:Body>
        </soapenv:Envelope>';

        if (!empty($request['dump'])) {
            exit(var_dump($params));
        }

        $output = $this->requestWUAPI($params, $client_id, $request);

        $this->retryMechanism($output, 'recieve_money_pay', $request, $client_id);

        // exit(var_dump($output));

        //Start Get Agent Name
        // if(empty($request['mobileFlag'])){
        //     // $agentName = $this->getAgentName($request);
        //     // $logs['agentName'] = $agentName;

        //     $branchOwner = $this->getBranchOwner($request);
        //     $logs['branchOwner'] = $branchOwner;
        // }
        //End Get Agent Name

        //Start Get Status
        // $request['transactionStatus'] = $this->getTransactionStatus($output);
        //End Get Status

        $receiverFirstName = !empty($request['firstName']) ? $request['firstName'] : '';
        $receiverLastName = !empty($request['lastName']) ? $request['lastName'] : '';
        $receiverName = $receiverFirstName . " " . $receiverLastName;


        // $logs['agentName'] = $agentName;
        // $logs['transactionStatus'] = !empty($request['transactionStatus']) ? $request['transactionStatus'] : '';
        $logs['branchLocation'] = !empty($request['branchLocation']) ? $request['branchLocation'] : '';
        $logs['ftid'] = $ftid;

        $logs['mtcn'] = !empty($request['mtcn']) ? $request['mtcn'] : '';
        // $logs['agentEmail'] = !empty($request['agentEmail']) ? $request['agentEmail'] : '';
        $logs['client_id'] = $client_id;
        $logs['receiverName'] = $receiverName;
        $logs['xml_request'] = $params;
        $logs['request_data'] = json_encode($request);
        $logs['reply_data'] = $output;

        $logs['idNum'] = !empty($request['idNum']) ? $request['idNum'] : '';
        $logs['address1'] = !empty($request['address1']) ? $request['address1'] : '';
        $logs['city'] = !empty($request['city']) ? $request['city'] : '';
        $logs['province'] = !empty($request['province']) ? $request['province'] : '';
        $logs['postalCode'] = !empty($request['postalCode']) ? $request['postalCode'] : '';
        $logs['receiverCountryCode'] = !empty($request['receiverCountryCode']) ? $request['receiverCountryCode'] : '';
        $logs['receiverCountryCurrencyCode'] = !empty($request['receiverCountryCurrencyCode']) ? $request['receiverCountryCurrencyCode'] : '';
        $logs['birthDate'] = !empty($request['birthDate']) ? $request['birthDate'] : '';
        $logs['occupation'] = !empty($request['occupation']) ? $request['occupation'] : '';
        $logs['transactionReason'] = !empty($request['transactionReason']) ? $request['transactionReason'] : '';
        $logs['gender'] = !empty($request['gender']) ? $request['gender'] : '';
        $logs['relationshiptoSender'] = !empty($request['relationshiptoSender']) ? $request['relationshiptoSender'] : '';
        $logs['originatingCountryCode'] = !empty($request['originatingCountryCode']) ? $request['originatingCountryCode'] : '';
        $logs['originatingCurrencyCode'] = !empty($request['originatingCurrencyCode']) ? $request['originatingCurrencyCode'] : '';

        $logs["grossTotalAmount"] = !empty($request['grossTotalAmount']) ? $request['grossTotalAmount'] : '';
        $logs["payAmount"] = !empty($request['payAmount']) ? $request['payAmount'] : '';
        $logs["principalAmount"] = !empty($request['principalAmount']) ? $request['principalAmount'] : '';

        $logs['issueDate'] = !empty($request['issueDate']) ? $request['issueDate'] : '';
        $logs['birthDate'] = !empty($request['birthDate']) ? $request['birthDate'] : '';
        $logs['occupation'] = !empty($request['occupation']) ? $request['occupation'] : '';
        $logs['relationshiptoSender'] = !empty($request['relationshiptoSender']) ? $request['relationshiptoSender'] : '';
        $logs['phoneNum'] = !empty($request['phoneNum']) ? $request['phoneNum'] : '';

        $data_inserted = ReceiveMoneyPayLog::create($logs);

        return $output;

    }

}
