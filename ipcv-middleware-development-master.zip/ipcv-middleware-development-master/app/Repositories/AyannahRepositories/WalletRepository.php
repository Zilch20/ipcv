<?php

namespace App\Repositories\AyannahRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class WalletRepository extends Controller
{
    public function fundWallet(Request $session, $request)
    {
        //Send Validate Request
        $guzzle = new Client([
            'headers' => [
                'Authorization' => 'Bearer '+ $session->session()->get('tokenA'),
                'Cache-Control' => 'no-cache'
            ]
        ]);

        $params = [
            "reference_num" => $request['referenceId'],
            "user_id" => $request['userId'],
            "amount" => $request['amount'],
            "wallet" => $request['wallet']
        ];

        $res = $guzzle -> post(env('AYANNAH_WALLET_FUND_API_URL'), [
            'json' => $params
        ]);

        //return if no errors
        return json_decode($res->getBody(), true);

    }
    public function fulfillWallet(Request $session, $request)
    {
        //Send Validate Request
        $guzzle = new Client([
            'headers' => [
                'Authorization' => 'Bearer '+ $session->session()->get('tokenA'),
                'Cache-Control' => 'no-cache'
            ]
        ]);

        $url = env('AYANNAH_WALLET_FULFILL_API_URL') + "/"+$request["reference_num"];

        $res = $guzzle -> post($url);
 
        //return if no errors
        return json_decode($res->getBody(), true);

    }
    public function centralizeWallet(Request $session, $request)
    {
        //Send Validate Request
        $guzzle = new Client([
            'headers' => [
                'Authorization' => 'Bearer '+ $session->session()->get('tokenA'),
                'Cache-Control' => 'no-cache'
            ]
        ]);

        $url = env('AYANNAH_WALLET_CENTRALIZE_API_URL') + "/"+$request["user_id"];

        $res = $guzzle -> post($url);
 
        //return if no errors
        return json_decode($res->getBody(), true);

    }
}