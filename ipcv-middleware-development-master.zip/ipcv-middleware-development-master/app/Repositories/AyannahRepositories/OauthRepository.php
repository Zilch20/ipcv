<?php

namespace App\Repositories\AyannahRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;                 
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;

class LoadRepository extends Controller
{
    public function oauthToken($request)
    {
        //Send Validate Request
        $guzzle = new Client();

        $params = [
            "grant_type" => "password",
            "client_id" => "",
            "client_secret" => "",
            "username" => $request['username'],
            "password" => $request['password']
        ];

        $res = $guzzle -> get(env('AYANNAH_OAUTH_TOKEN_API_URL'), [
            'json' => $params
        ]);

        $arr = json_decode($res->getBody(), true);
        $tokenA = $arr['access_token'];
        $request->session()->put('tokenA', $tokenA);
        $refreshTokenA = $arr['refresh_token'];
        $request->session()->put('refreshTokenA', $refreshTokenA);

        //return if no errors
        return json_decode($res->getBody(), true);

    }
    public function refreshToken($request)
    {
        //Send Validate Request
        $guzzle = new Client();

        $params = [
            "grant_type" => "refresh_token",
            "refresh_token" => $request->session()->get('refreshTokenA'),
            "client_id" => "",
            "client_secret" => "",
        ];

        $res = $guzzle -> get(env('AYANNAH_OAUTH_TOKEN_API_URL'), [
            'json' => $params
        ]);

        $arr = json_decode($res->getBody(), true);
        $tokenA = $arr['access_token'];
        $request->session()->put('tokenA', $tokenA);
        $refreshtokenA = $arr['refresh_token'];
        $request->session()->put('refreshtokenA', $refreshtokenA);

        //return if no errors
        return json_decode($res->getBody(), true);

    }
}