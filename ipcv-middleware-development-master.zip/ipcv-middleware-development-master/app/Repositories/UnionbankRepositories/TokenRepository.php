<?php

namespace App\Repositories\UnionbankRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Support\Facades\Cache;

class TokenRepository extends Controller
{

    public function generateToken($details)
    {

        try{
            $guzzle = new Client([
                'headers' => [
                    'accept' => 'application/json',
                    'Content-Type' => 'application/json'
                ]
            ]);
    
            $params = [
                'username' => $details['username'],
                'password' => $details['password'],
            ];
    
            $res = $guzzle -> post("https://api.stg.i2i.ph/api-apic/auth/token", [
                'json' => $params
            ]);
    
            return json_decode($res->getBody(), true);
        }

        catch (\GuzzleHttp\Exception\ClientException $e) {
            $response = $e->getResponse();
            $res = json_decode($response->getBody(), true);
            return $res;
            
        }
    }

    // public function generatePesonetToken($details)
    // {

    //     $guzzle = new Client([
    //         'headers' => [
    //             'accept' => 'application/json',
    //             'Content-Type' => 'application/x-www-form-urlencoded'
    //         ]
    //     ]);

    //     $params = [
    //         'grant_type' => 'password',
    //         'client_id' => env('UNIONBANK_CLIENT_ID'),
    //         'username' => $details['username'],
    //         'password' => $details['password'],
    //         'scope' => 'transfers_pesonet',
    //     ];

    //     $res = $guzzle -> post(env('UNIONBANK_PARTNER_ACCESS_TOKEN_URL'), [
    //         'form_params' => $params
    //     ]);

    //     $arr = json_decode($res->getBody(), true);
    //     $arr = $arr["access_token"];

    //     Cache::put('UnionBankToken', $arr);

    //     return json_decode($res->getBody(), true);
    // }

}