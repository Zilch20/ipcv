<?php

namespace App\Repositories\InstapayRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Validator;

class PartnerToPartnerRepository extends Controller
{
    public function partnerTransfer($request)
    {

        $date = date("Y-m-d\TH:i:s.u");

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => env("INSTAPAY_CLIENT_ID"),
                "x-ibm-client-secret" => env("INSTAPAY_CLIENT_SECRET"),
                "authorization" => "Bearer ". $request['token'],
                "x-partner-id" => env("INSTAPAY_PARTNER_ID")
            ]
        ]);

        $params = [
            "senderRefId"=> 321,
            "tranRequestDate"=> $date,
            "accountNo" => $request["accountNo"],
            "amount" => [
                "currency" => "PHP",
                "value" => $request['amount']
            ],
            "remarks" => $request['remarks'],
            "particulars" => $request['particulars'],
            "info" => [
                ["index" => 1,
                "name" => "Recipient",
                "value" => $request['receiverName']
                ],
                ["index" => 2,
                "name" => "Message",
                "value" => $request['message']
                ]
            ]
        ];

        $res = $guzzle -> post(env("UNIONBANK_PARTNER_FUND_TRANSFER_URL"), [
            "json" => $params
        ]);

        return json_decode($res->getBody(), true);
    }

    public function transferStatus($request)
    {

        $date = date("Y-m-d\TH:i:s.u");

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "Content-Type" => "application/json",
                "x-ibm-client-id" => env("INSTAPAY_CLIENT_ID"),
                "x-ibm-client-secret" => env("INSTAPAY_CLIENT_SECRET"),
                "x-partner-id" => env("INSTAPAY_PARTNER_ID")
            ]
        ]);
        
        $url = env("UNIONBANK_PARTNER_TRANSFER_STATUS_URL").$request['senderRefId'];

        $res = $guzzle -> get($url);

        return json_decode($res->getBody(), true);
    }


}