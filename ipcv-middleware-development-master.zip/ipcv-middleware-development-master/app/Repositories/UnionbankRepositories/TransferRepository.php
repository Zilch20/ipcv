<?php

namespace App\Repositories\UnionbankRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use GuzzleHttp\Client;
use Validator;
use App\InstapayTransferMoneyLog;
use Illuminate\Support\Facades\Cache;
use App\Traits\GetStatusTraits;

class TransferRepository extends Controller
{
    use GetStatusTraits;

    public function transferStatus($request)
    {
        // $token = Cache::get('UnionBankToken');

        try{
            $guzzle = new Client([
                "headers" => [
                    "accept" => "application/json",
                    "authorization" => "Bearer ". $request["token"]
                ]
            ]);
            
            $url = "https://api.stg.i2i.ph/api-apic/instapay?senderReference=".$request['senderReference'];
            $res = $guzzle -> get($url);

            $code = $res->getStatusCode();
            $status = $this->responseStatus($code);
            if($status !== true){
                return response($status,$code)->header('Content-Type', 'application/json');
            }

            return json_decode($res->getBody(), true);
        }
        catch (\GuzzleHttp\Exception\ClientException $e) {
            $response = $e->getResponse();
            $res = json_decode($response->getBody(), true);
            return $res;
            
        }
    }

    public function generateReport($request)
    {
        // $token = Cache::get('UnionBankToken');

        $guzzle = new Client([
            "headers" => [
                "accept" => "application/json",
                "authorization" => "Bearer ". $request["token"]
            ]
        ]);
        
        $url = "https://api.stg.i2i.ph/api-apic/instapay/report";

        if(!empty($request["startDate"]) || !empty($request["endDate"]) || !empty($request["search"]))
        {
            $url .= "?";

            if(!empty($request["startDate"]))
            {
                $url .= "startDate=".$request["startDate"];
            }
            if(!empty($request["endDate"]))
            {
                if(!empty($request["startDate"]))
                {
                    $url .= "&endDate=".$request["endDate"];
                }
                else {
                    $url .= "endDate=".$request["endDate"];
                }
            }
            if(!empty($request["search"]))
            {
                if(!empty($request["endDate"]))
                {
                    $url .= "&search=".$request["search"];
                }
                else {
                    $url .= "search=".$request["search"];
                }
            }
        }
        if(!empty($request['page']))
        {
            $url .= "&page=".$request["page"];
        }
        if(!empty($request['limit']))
        {
            $url .= "&limit=".$request["limit"];
        }

        if (!empty($request['dump'])) {
            exit(var_dump($url));
        }

        $res = $guzzle -> get($url);

        $code = $res->getStatusCode();
            $status = $this->responseStatus($code);
            if($status !== true){
                return response($status,$code)->header('Content-Type', 'application/json');
            }

        return json_decode($res->getBody(), true);
    }

    public function validateFields($request, $client_id)
    {
        $checkCount = InstapayTransferMoneyLog::where('senderReference', '=', $request['transaction']['senderReference'])
                        ->get()
                        ->count();
        if($checkCount > 0)
        {
            return response()->json(['Transaction already Processed'], 400);
        }
        
        try{
            $guzzle = new Client([
                "headers" => [
                    "accept" => "application/json",
                    "Content-Type" => "application/json",
                    "authorization" => "Bearer ". $request['token']
                ]
            ]);

            $params = [
                "transaction" => [
                    "senderReference" => !empty($request['transaction']['senderReference']) ? $request['transaction']['senderReference'] : "",
                    "amount" => !empty($request['transaction']['amount']) ? $request['transaction']['amount'] : "",
                    "purpose" => !empty($request['transaction']['purpose']) ? $request['transaction']['purpose'] : "",
                    // "fundSource" => $request['transaction']['fundSource'],
                    // "senderType" => $request['transaction']['senderType'],
                    "receiverType" => !empty($request['transaction']['receiverType']) ? $request['transaction']['receiverType'] : "",
                    "callbackURL" => !empty($request['transaction']['callbackURL']) ? $request['transaction']['callbackURL'] : "http://3.1.170.158/mw-development/public/transfer/1",
                ],

                "sender" => [
                    "accountName" => !empty($request['sender']['accountName']) ? $request['sender']['accountName'] : "",
                    "accountNumber" => !empty($request['sender']['accountNumber']) ? $request['sender']['accountNumber'] : "",
                    "mobileNumber" => !empty($request['sender']['mobileNumber']) ? $request['sender']['mobileNumber'] : "",
                    "email" => !empty($request['sender']['email']) ? $request['sender']['email'] : "",
                    "address" => !empty($request['sender']['address']) ? $request['sender']['address'] : "",
                    "barangay" => !empty($request['sender']['barangay']) ? $request['sender']['barangay'] : "",
                    "city" => !empty($request['sender']['city']) ? $request['sender']['city'] : "",
                    "zipCode" => !empty($request['sender']['zipCode']) ? $request['sender']['zipCode'] : "",
                    // "gender" => $request['sender']['gender'],
                    // "birthDate" => $request['sender']['birthDate'],
                ],

                "receiver" => [
                    "accountName" => !empty($request['receiver']['accountName']) ? $request['receiver']['accountName'] : "",
                    "accountNumber" => !empty($request['receiver']['accountNumber']) ? $request['receiver']['accountNumber'] : "",
                    "mobileNumber" => !empty($request['receiver']['mobileNumber']) ? $request['receiver']['mobileNumber'] : "",
                    "email" => !empty($request['receiver']['email']) ? $request['receiver']['email'] : "",
                    "address" => !empty($request['receiver']['address']) ? $request['receiver']['address'] : "",
                    "barangay" => !empty($request['receiver']['barangay']) ? $request['receiver']['barangay'] : "",
                    "city" => !empty($request['receiver']['city']) ? $request['receiver']['city'] : "",
                    "zipCode" => !empty($request['receiver']['zipCode']) ? $request['receiver']['zipCode'] : "",
                    "bank" => [
                        "name" => !empty($request['receiver']['bank']['name']) ? $request['receiver']['bank']['name'] : "",
                        "code" => !empty($request['receiver']['bank']['code']) ? $request['receiver']['bank']['code'] : "",
                    ],
                    "gender" => !empty($request['receiver']['gender']) ? $request['receiver']['gender'] : "",
                    "birthDate" => !empty($request['receiver']['birthDate']) ? $request['receiver']['birthDate'] : "",
                ],
                
                "representative" => [
                    "firstName" => !empty($request['representative']['firstName']) ? $request['representative']['firstName'] : "null",
                    "middleName" => !empty($request['representative']['middleName']) ? $request['representative']['middleName'] : "null",
                    "lastName" => !empty($request['representative']['lastName']) ? $request['representative']['lastName'] : "null",
                    "suffix" => !empty($request['representative']['suffix']) ? $request['representative']['suffix'] : "null",
                ]
            ];

            $res = $guzzle -> post("https://api.stg.i2i.ph/api-apic/instapay/validate", [
                "json" => $params
            ]);

            $code = $res->getStatusCode();
            $status = $this->responseStatus($code);
            if($status !== true){
                return response($status,$code)->header('Content-Type', 'application/json');
            }

            return json_decode($res->getBody(), true);
        }catch (\GuzzleHttp\Exception\ClientException $e) {
            $response = $e->getResponse();
            $res = json_decode($response->getBody(), true);
            return $res;
            
        }

        
    }

    public function processTransactions($request, $client_id)
    {
        // $token = Cache::get('UnionBankToken');

        // $date = substr(date("Y-m-d\TH:i:s.u"), 0, -3);
        try{
            $guzzle = new Client([
                "headers" => [
                    "accept" => "application/json",
                    "authorization" => "Bearer ". $request['token']
                ]
            ]);

            $params = [
                "transaction" => [
                    "senderReference" => !empty($request['transaction']['senderReference']) ? $request['transaction']['senderReference'] : "",
                    "amount" => !empty($request['transaction']['amount']) ? $request['transaction']['amount'] : "",
                    "purpose" => !empty($request['transaction']['purpose']) ? $request['transaction']['purpose'] : "",
                    // "fundSource" => $request['transaction']['fundSource'],
                    // "senderType" => $request['transaction']['senderType'],
                    "receiverType" => !empty($request['transaction']['receiverType']) ? $request['transaction']['receiverType'] : "",
                    "callbackURL" => !empty($request['transaction']['callbackURL']) ? $request['transaction']['callbackURL'] : "http://3.1.170.158/mw-development/public/transfer/1",
                ],
                
                "sender" => [
                    "accountName" => !empty($request['sender']['accountName']) ? $request['sender']['accountName'] : "",
                    "accountNumber" => !empty($request['sender']['accountNumber']) ? $request['sender']['accountNumber'] : "",
                    "mobileNumber" => !empty($request['sender']['mobileNumber']) ? $request['sender']['mobileNumber'] : "",
                    "email" => !empty($request['sender']['email']) ? $request['sender']['email'] : "",
                    "address" => !empty($request['sender']['address']) ? $request['sender']['address'] : "",
                    "barangay" => !empty($request['sender']['barangay']) ? $request['sender']['barangay'] : "",
                    "city" => !empty($request['sender']['city']) ? $request['sender']['city'] : "",
                    "zipCode" => !empty($request['sender']['zipCode']) ? $request['sender']['zipCode'] : "",
                    // "gender" => $request['sender']['gender'],
                    // "birthDate" => $request['sender']['birthDate'],
                ],

                "receiver" => [
                    "accountName" => !empty($request['receiver']['accountName']) ? $request['receiver']['accountName'] : "",
                    "accountNumber" => !empty($request['receiver']['accountNumber']) ? $request['receiver']['accountNumber'] : "",
                    "mobileNumber" => !empty($request['receiver']['mobileNumber']) ? $request['receiver']['mobileNumber'] : "",
                    "email" => !empty($request['receiver']['email']) ? $request['receiver']['email'] : "",
                    "address" => !empty($request['receiver']['address']) ? $request['receiver']['address'] : "",
                    "barangay" => !empty($request['receiver']['barangay']) ? $request['receiver']['barangay'] : "",
                    "city" => !empty($request['receiver']['city']) ? $request['receiver']['city'] : "",
                    "zipCode" => !empty($request['receiver']['zipCode']) ? $request['receiver']['zipCode'] : "",
                    "bank" => [
                        "name" => !empty($request['receiver']['bank']['name']) ? $request['receiver']['bank']['name'] : "",
                        "code" => !empty($request['receiver']['bank']['code']) ? $request['receiver']['bank']['code'] : "",
                    ],
                    "gender" => !empty($request['receiver']['gender']) ? $request['receiver']['gender'] : "",
                    "birthDate" => !empty($request['receiver']['birthDate']) ? $request['receiver']['birthDate'] : "",
                ],

                "representative" => [
                    "firstName" => !empty($request['representative']['firstName']) ? $request['representative']['firstName'] : "null",
                    "middleName" => !empty($request['representative']['middleName']) ? $request['representative']['middleName'] : "null",
                    "lastName" => !empty($request['representative']['lastName']) ? $request['representative']['lastName'] : "null",
                    "suffix" => !empty($request['representative']['suffix']) ? $request['representative']['suffix'] : "null",
                ]
            ];

            $res = $guzzle -> post("https://api.stg.i2i.ph/api-apic/instapay/process", [
                "json" => $params
            ]);

            $logs['client_id'] = $client_id;
            $logs['senderReference'] = !empty($request['transaction']['senderReference']) ? $request['transaction']['senderReference'] : "";
            $logs['amount'] = !empty($request['transaction']['amount']) ? $request['transaction']['amount'] : "";
            $logs['purpose'] = !empty($request['transaction']['purpose']) ? $request['transaction']['purpose'] : "";
            $logs['receiverType'] = !empty($request['transaction']['receiverType']) ? $request['transaction']['receiverType'] : "";

            $logs['senderAccountName'] = !empty($request['sender']['accountName']) ? $request['sender']['accountName'] : "";
            $logs['senderAccountNumber'] = !empty($request['sender']['accountNumber']) ? $request['sender']['accountNumber'] : "";
            $logs['senderMobileNumber'] = !empty($request['sender']['mobileNumber']) ? $request['sender']['mobileNumber'] : "";
            $logs['senderEmail'] = !empty($request['sender']['email']) ? $request['sender']['email'] : "";
            $logs['senderAddress'] = !empty($request['sender']['address']) ? $request['sender']['address'] : "";
            $logs['senderBarangay'] = !empty($request['sender']['barangay']) ? $request['sender']['barangay'] : "";
            $logs['senderCity'] = !empty($request['sender']['city']) ? $request['sender']['city'] : "";
            $logs['senderZipCode'] = !empty($request['sender']['zipCode']) ? $request['sender']['zipCode'] : "";

            $logs['receiverAccountName'] = !empty($request['receiver']['accountName']) ? $request['receiver']['accountName'] : "";
            $logs['receiverAccountNumber'] = !empty($request['receiver']['accountNumber']) ? $request['receiver']['accountNumber'] : "";
            $logs['receiverMobileNumber'] = !empty($request['receiver']['mobileNumber']) ? $request['receiver']['mobileNumber'] : "";
            $logs['receiverEmail'] = !empty($request['receiver']['email']) ? $request['receiver']['email'] : "";
            $logs['receiverAddress'] = !empty($request['receiver']['address']) ? $request['receiver']['address'] : "";
            $logs['receiverBarangay'] = !empty($request['receiver']['barangay']) ? $request['receiver']['barangay'] : "";
            $logs['receiverCity'] = !empty($request['receiver']['city']) ? $request['receiver']['city'] : "";
            $logs['receiverZipCode'] = !empty($request['receiver']['zipCode']) ? $request['receiver']['zipCode'] : "";
            $logs['receiverBankName'] = !empty($request['receiver']['bank']['name']) ? $request['receiver']['bank']['name'] : "";
            $logs['receverBankCode'] = !empty($request['receiver']['bank']['code']) ? $request['receiver']['bank']['code'] : "";
            $logs['receiverGender'] = !empty($request['receiver']['gender']) ? $request['receiver']['gender'] : "";
            $logs['receiverBirthDate'] = !empty($request['receiver']['birthDate']) ? $request['receiver']['birthDate'] : "";

            $logs['representativeFirstName'] = !empty($request['representative']['firstName']) ? $request['representative']['firstName'] : "null";
            $logs['representativeMiddleName'] = !empty($request['representative']['middleName']) ? $request['representative']['middleName'] : "null";
            $logs['representativeLastName'] = !empty($request['representative']['lastName']) ? $request['representative']['lastName'] : "null";
            $logs['representativeSuffix'] = !empty($request['representative']['suffix']) ? $request['representative']['suffix'] : "null";

            $logs['request_data'] = json_encode($params);
            // exit(var_dump($logs['request_data']));
            $logs['reply_data'] = json_encode($res->getBody()->getContents(), true);
            // exit(var_dump($logs['reply_data']));

            $data_inserted = InstapayTransferMoneyLog::create($logs);

            $code = $res->getStatusCode();
            $status = $this->responseStatus($code);
            if($status !== true){
                return response($status,$code)->header('Content-Type', 'application/json');
            }
            
            return json_decode($res->getBody(), true);
            
        }catch (\GuzzleHttp\Exception\ClientException $e) {
            $response = $e->getResponse();
            $res = json_decode($response->getBody(), true);
            return $res;
            
        }
    }
    
    public function transactionPurpose($request, $client_id)
    {
        //test

        try{
            $guzzle = new Client([
                "headers" => [
                    "accept" => "application/json",
                    "authorization" => "Bearer ". $request["token"]
                ]
            ]);
            
            $url = "https://api.stg.i2i.ph/api-apic/instapay/purpose";
            $res = $guzzle -> get($url);

            $code = $res->getStatusCode();
            $status = $this->responseStatus($code);
            if($status !== true){
                return response($status,$code)->header('Content-Type', 'application/json');
            }

            return json_decode($res->getBody(), true);
        }
        catch (\GuzzleHttp\Exception\ClientException $e) {
            $response = $e->getResponse();
            $res = json_decode($response->getBody(), true);
            return $res;
            
        }
    }

    public function bankList($request, $client_id)
    {
        //test

        try{
            $guzzle = new Client([
                "headers" => [
                    "accept" => "application/json",
                    "authorization" => "Bearer ". $request["token"]
                ]
            ]);
            
            $url = "https://api.stg.i2i.ph/api-apic/instapay/banks";
            $res = $guzzle -> get($url);

            $code = $res->getStatusCode();
            $status = $this->responseStatus($code);
            if($status !== true){
                return response($status,$code)->header('Content-Type', 'application/json');
            }

            return json_decode($res->getBody(), true);
        }
        catch (\GuzzleHttp\Exception\ClientException $e) {
            $response = $e->getResponse();
            $res = json_decode($response->getBody(), true);
            return $res;
            
        }
    }

}