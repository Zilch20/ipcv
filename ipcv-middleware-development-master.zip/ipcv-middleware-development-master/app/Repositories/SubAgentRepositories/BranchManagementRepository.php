<?php

namespace App\repositories\SubAgentRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Support\Facades\Cache;
use Illuminate\Database\Eloquent\Model;
use App\Helpers\Debugger;
use App\Helpers\JSONSOAPConvert;
use App\BranchManagementTable;
use Illuminate\Database\QueryException;
use App\SubAgentFuntionAccess;

class BranchManagementRepository extends Controller
{
    public function GetBranch()
    {
        $GetBranches = BranchManagementTable::get();
        return $GetBranches->toJson();
    }
    
    public function RegisterBranch($request)
    {
        $ipcvAccess = SubAgentFuntionAccess::where('branchOwner', 'IPCV')->first();
        $bocAccess = SubAgentFuntionAccess::where('branchOwner', 'BOC')->first();
        $pisopayAccess = SubAgentFuntionAccess::where('branchOwner', 'PISOPAY')->first();
        $gprsAccess = SubAgentFuntionAccess::where('branchOwner', 'GPRS')->first();
        $expresspayAccess = SubAgentFuntionAccess::where('branchOwner', 'EXPRESSPAY')->first();


        $branchName = $request['branchName'];
        $branchExists = BranchManagementTable::where('branchName', '=', $branchName) 
                        ->get()
                        ->count();
        if($branchName > 0)
        {
            return response()->json(['Branch Already Exists'],200);
        }
        //Inserts into Sub-Agent DB
        $branches = new BranchManagementTable();
        $data['branchName'] = $request['branchName'];
        $data['branchOwner'] = $request['branchOwner'];
        $data['branchEmail'] = $request['branchEmail'];
        $data['branchAddress'] = $request['branchAddress'];
        $data['branchContact'] = $request['branchContact'];
        $data['branchTerminalId'] = $request['branchTerminalId'];
        $data['ftid'] = $request['ftid'];
        $data_inserted = BranchManagementTable::create($data);

        if(strtoupper($request['branchOwner']) == 'BOC')
        {
            $branches->access()->attach($bocAccess);
        }
        if(strtoupper($request['branchOwner']) == 'PISOPAY')
        {
            $branches->access()->attach($pisopayAccess);
        }
        if(strtoupper($request['branchOwner']) == 'GPRS')
        {
            $branches->access()->attach($gprsAccess);
        }
        if(strtoupper($request['branchOwner']) == 'EXPRESSPAY')
        {
            $branches->access()->attach($expresspayAccess);
        }
        if(strtoupper($request['branchOwner']) == 'IPCV')
        {
            $branches->access()->attach($ipcvAccess);
        }
        
        //Convert Response to SOAP
        return response()->json(['Branch Registered'],200);

    }

    public function UpdateBranch($request)
    {

        $branchId = $request['branchId'];
        $branchName = !empty($request['branchName']) ? $request['branchName'] : '';
        $branchOwner = !empty($request['branchOwner']) ? $request['branchOwner'] : '';
        $branchEmail = !empty($request['branchEmail']) ? $request['branchEmail'] : '';
        $branchAddress = !empty($request['branchAddress']) ? $request['branchAddress'] : '';
        $branchContact = !empty($request['branchContact']) ? $request['branchContact'] : '';
        $branchTerminalId = !empty($request['branchTerminalId']) ? $request['branchTerminalId'] : '';
        $ftid = !empty($request['ftid']) ? $request['ftid'] : '';

        //Checks if Branch Exists
        $emailExists = BranchManagementTable::where('id', '=', $branchId) 
                        ->get()
                        ->count();
        // dd($emailExists);
        if($emailExists == 0)
        {
            return response()->json(['Branch is not Registered'],400);
        }

        //Updates Sub-agent Status
        if(!empty($request['branchName']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchName' => $branchName]);
        }
        if(!empty($request['branchOwner']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchOwner' => $branchOwner]);
        }
        if(!empty($request['branchEmail']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchEmail' => $branchEmail]);
        }
        if(!empty($request['branchAddress']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchAddress' => $branchAddress]);
        }
        if(!empty($request['branchContact']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchContact' => $branchContact]);
        }
        if(!empty($request['branchTerminalId']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['branchTerminalId' => $branchTerminalId]);
        }
        if(!empty($request['ftid']))
        {
            $data_updated = BranchManagementTable::where('id', '=', $branchId)
            ->update(['ftid' => $ftid]);
        }


        return response()->json(['Branch Information has Updated'],200);

    }

    public function DeleteBranch($request)
    {
        $branchName = $request['branchName'];

        //Checks if Branch Exists
        $emailExists = BranchManagementTable::where('branchName', '=', $branchName) 
                        ->get()
                        ->count();
        // dd($emailExists);
        if($emailExists == 0)
        {
            return response()->json(['Branch is not Registered'],400);
        }

        //Deletes Record From Sub-Agent DB
        $data_inserted = BranchManagementTable::where('branchName', '=', $branchName)->delete();
        
        //Convert Response to SOAP
        return response()->json(['Branch '. $branchName .' Has Been Deleted'],200);

    }

    public function searchBranch($request)
    {
        $branchName = $request['branchName'];

        $branchDetails = BranchManagementTable::where('branchName', '=', $branchName) 
                        ->get();

        return $branchDetails->toJson();
    }

    public function GetBranchByOwner($request)
    {
        $branchOwner = $request['branchOwner'];
        $branchOwner = strtoupper($branchOwner);
        
        $branchOwnerExists = BranchManagementTable::where('branchOwner', '=', $branchOwner)
                        ->get()
                        ->count();
        if($branchOwnerExists == 0)
        {
            return response()->json(['No Branches'],400);
        }

        $GetBranches = BranchManagementTable::select('id', 'branchName', 'branchOwner')
                        ->where('branchOwner', '=', $branchOwner)
                        ->get();
        return $GetBranches->toJson();
    }
}
