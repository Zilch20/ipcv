<?php

namespace App\repositories\SubAgentRepositories;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use GuzzleHttp\Client;
use Validator;
use Illuminate\Support\Facades\Cache;
use Illuminate\Database\Eloquent\Model;
use App\Helpers\Debugger;
use App\Helpers\JSONSOAPConvert;
use App\SubAgentManagementTable;
use Illuminate\Database\QueryException;

class SubAgentProcessRepository extends Controller
{
    public function RegisterSubAgent($request, $client_id)
    {
        //Checks if Agent Email has been used
        $emailExists = SubAgentManagementTable::where('agentEmail', '=', $request['agentEmail']) 
                        ->get()
                        ->count();
        if($emailExists >= 1)
        {
            $errorMessage = 'Email already exists';
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            return $soapResponse;
        }

        //Inserts into Sub-Agent DB
        $data['firstName'] = $request['firstName'];
        $data['lastName'] = $request['lastName'];
        $data['agentEmail'] = $request['agentEmail'];
        $data['branchLocation'] = $request['branchLocation'];
        $data['accountType'] = $request['accountType'];
        $data['accountStatus'] = $request['accountStatus'];
        $data_inserted = SubAgentManagementTable::create($data);
        
        //Convert Response to SOAP
        $soapResponse = JSONSOAPConvert::subAgentRegisterSuccess($request);
        return $soapResponse;

    }

    public function UpdateSubAgent($request, $client_id)
    {

        $email = $request['agentEmail'];
        $updateStatus = $request['accountStatus'];

        //Checks if Sub-agent Email Exists
        $emailExists = SubAgentManagementTable::where('agentEmail', '=', $email) 
                        ->get()
                        ->count();
        // dd($emailExists);
        if($emailExists == 0)
        {
            $errorMessage = 'Email does not exist';
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            return $soapResponse;
        }
    
        //Get Sub-agent Name
        $firstName = SubAgentManagementTable::select('firstName') 
        ->where('agentEmail', '=', $email)
        ->pluck('firstName');
        $lastName = SubAgentManagementTable::select('lastName') 
                ->where('agentEmail', '=', $email)
                ->pluck('lastName');
        $name = $firstName[0].' '.$lastName[0];

        //Updates Sub-agent Status
        $data_updated = SubAgentManagementTable::where('agentEmail', '=', $email) 
                        ->update(['accountStatus' => $updateStatus]);

        //Past Tense Disable
        if($updateStatus == 'Disable' || $updateStatus == 'disable')
        {
            $updateStatus = 'Disabled';
        }
        //Convert Response to SOAP
        $soapResponse = JSONSOAPConvert::subAgentUpdateSuccess($updateStatus, $name);
        return $soapResponse;

    }

    public function GetSubAgent($request, $client_id)
    {
        $records = SubAgentManagementTable::get();
        dd($records);
        return $records->toJson();
    }
}
