<?php

namespace App\Helpers;

class JSONSOAPConvert
{
    public static function toSoap($errorMessage)
    {
        $apiEnv = ApiEnvironment::get();
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:date="http://exslt.org/dates-and-times">
    <soapenv:Body>
        <soapenv:Fault xmlns:xrsi="' . $apiEnv['api_url'] . '/schema/xrsi">
            <faultcode>xrsi:error-reply</faultcode>
            <faultstring>business exception</faultstring>
            <faultactor>cx-fault-actor</faultactor>
            <detail>
                <xrsi:error-reply>
                    <error>'. $errorMessage .'</error>
                </xrsi:error-reply>
            </detail>
        </soapenv:Fault>
    </soapenv:Body>
</soapenv:Envelope>';

        return $xml;
    }

    public static function subAgentRegisterSuccess($request)
    {
        $apiEnv = ApiEnvironment::get();
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
        <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:date="http://exslt.org/dates-and-times">
            <soapenv:Body>
                <xrsi:sub-agent-register-success xmlns:xrsi="' . $apiEnv['api_url'] . '/schema/xrsi">
                    <code>SUCCESS<code>
                    <agent_details>
                        <first_name>'. $request['firstName'] .'</first_name>
                        <last_name>'. $request['lastName'] .'</last_name>
                        <agent_email>'. $request['agentEmail'] .'</agent_email>
                        <branch_location>'. $request['branchLocation'] .'</branch_location>
                    </agent_details>
                </xrsi:sub-agent-register-success>
            </soapenv:Body>
        </soapenv:Envelope>';

        return $xml;
    }

    public static function subAgentUpdateSuccess($status, $name)
    {
        $apiEnv = ApiEnvironment::get();
        $xml = '<?xml version="1.0" encoding="UTF-8"?>
        <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:date="http://exslt.org/dates-and-times">
            <soapenv:Body>
                <xrsi:sub-agent-update-success xmlns:xrsi="' . $apiEnv['api_url'] . '/schema/xrsi">
                    <code>SUCCESS<code>
                    <message>'. $name."'s account is now ". $status .'</message>
                </xrsi:sub-agent-update-success>
            </soapenv:Body>
        </soapenv:Envelope>';

        return $xml;
    }

}
