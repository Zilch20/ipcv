<?php

namespace App\Helpers;

use App\Helpers\JSONSOAPConvert;

class SpecialCharacters
{
    public static function checkCharacter($request)
    {
        $containsSpecialChar = false;
        foreach ($request as $value)
        {
            $pattern = "/ñ|ń|ç|ć|č|à|á|â|ä|æ|ã|å|ā/i";
            if(preg_match($pattern, $value)) {
                $containsSpecialChar = true;
                break;
            }
        }
        return $containsSpecialChar;
    }

    public static function encodeAmpersand($request)
    {
        foreach ($request as $key => $string)
        {
            $pattern = "/&(?!#?[a-zA-Z0-9]+;)/";
            if(preg_match($pattern, $string)) {
                $string = preg_replace('/&/','&amp;', $string);
                $request[$key] = $string;
            }
        }
        return $request;
    }

    public function checkBranchNAID($naid)
    {
        $fsid = "PH513";
        if($naid == "PH994") {
            $fsid = "PH994";
        }

        return $fsid;
    }

    public static function checkFTID($ftid)
    {
        $fsid = "PH513";
        $pattern = "/PH513|A3UC/";
        if(!preg_match($pattern, $ftid)) {
            $fsid = "PH994";
        }

        return $fsid;
    }

    public static function checkNameXmlTag($output){

        // $pattern = "/given_name/";
        // if(preg_match($pattern, $output)) {
        //     $output = preg_replace('/given_name/','first_name', $output);
        // }

        // $pattern = "/maternal_name/";
        // if(preg_match($pattern, $output)) {
        //     $output = preg_replace('/maternal_name/','middle_name', $output);
        // }

        // $pattern = "/paternal_name/";
        // if(preg_match($pattern, $output)) {
        //     $output = preg_replace('/paternal_name/','last_name', $output);
        // }

        // exit(var_dump($output));
        $pattern = "/first_name/";
        if(preg_match($pattern, $output)) {
            $output = preg_replace('/first_name/','given_name', $output);
        }

        return $output;
    }

}
