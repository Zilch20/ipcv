<?php

namespace App\Traits;

use App\Helpers\Debugger;
use App\Helpers\SoapParser;
use App\RetryMechanismLog;
use App\SubAgentManagementTable;
use App\BranchManagementTable;
use App\Helpers\JSONSOAPConvert;

trait SubAgentTraits
{
    public function getAgentName($request)
    {
        $email = $request['agentEmail'];
        $agentFirstName = SubAgentManagementTable::where('agentEmail', '=', $email)
                            ->pluck('firstName');
        $agentFirstName = $agentFirstName[0];
        
        $agentLastName = SubAgentManagementTable::where('agentEmail', '=', $email)
                            ->pluck('lastName');
        $agentLastName = $agentLastName[0];

        $agentName = $agentFirstName . " " . $agentLastName;

        return $agentName;
    }

    public function getBranchLocation($request)
    {
        // if(!empty($request['agentEmail']))
        // {
        //     $email = $request['agentEmail'];
        //     $branchLocation = SubAgentManagementTable::where('agentEmail', '=', $email)
        //                         ->pluck('branchLocation');
        //     $branchLocation = $branchLocation[0];

        //     return $branchLocation;
        // }

        // if(!empty($request['branchLocation']))
        // {
        //     $location = $request['branchLocation'];
        //     $branchLocation = BranchManagementTable::where('branchName', '=', $location)
        //                         ->pluck('branchName');
        //     $branchLocation = $branchLocation[0];

        //     return $branchLocation;
        // }

        $email = $request['agentEmail'];
        $branchLocation = SubAgentManagementTable::where('agentEmail', '=', $email)
                            ->pluck('branchLocation');
        $branchLocation = $branchLocation[0];

        return $branchLocation;
    }
    public function getBranchOwner($request)
    {
        $branchOwner = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
                        ->pluck('branchOwner');
        $branchOwner = $branchOwner[0];

        return $branchOwner;
    }
    public function checkSuspended($request)
    {
        $ftid = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
                ->pluck('ftid');
        $ftid = $ftid[0];
        // dd($ftid);

        $suspended = false;
        if($ftid == 'suspended' || $ftid == 'Suspended')
        {
            $suspended = true;

            return $suspended;
        }

        // dd("Not Suspended");
        return $suspended;
    }

    public function getFtid($request)
    {
        $checkBranch = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
                        ->get()
                        ->count();
        if($checkBranch == 0)
        {
            $errorMessage = 'Branch is not Registered';
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            return $soapResponse;
        }

        // $ftid = BranchManagementTable::where('branchName', '=', $request['branchLocation'])
        //                                 ->pluck('ftid');
        // $ftid = $ftid[0];

        // return $ftid;
    }

}
