<?php

namespace App\Traits;

use App\Helpers\JSONSOAPConvert;
use App\WesternUnionConnectionErrorLog;

trait WuLookupXmlTrait{
    public function wuLookupXml($request = [], $client_id){
        $ftid = "PH994AMP001A"; //Staging Credentials
        $fsid = "WGHHPH9940T"; //Staging Credentials
        // $fsid = "WGHHPH5130P"; //Prod Credentials
        // $ftid = "PH513AMP001B"; //Prod Credentials
        
        $params = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xrsi="http://www.westernunion.com/schema/xrsi" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
            <soapenv:Header/>
            <soapenv:Body>
               <xrsi:wu-card-lookup-request>
                <channel>
                    <type>H2H</type>
                    <name>IPCV</name>
                    <version>9500</version>
                </channel>
                  <operator>
                     <id/>
                     <password/>
                     <alias/>
                     <network_id/>
                  </operator>
                  <terminal>
                     <id/>
                     <alias/>
                     <model_id/>
                  </terminal>
                  <sender>
                     <name/>
                     <address>
                        <country_code>
                            <iso_code>
                            ' . (!empty($request['senderCountryCode']) ? '<country_code>' . $request['senderCountryCode'] . '</country_code>' : '') . '
                            </iso_code>
                        </country_code>
                    </address>
                     <preferred_customer>
                        ' . (!empty($request['loyaltyCardUpdateIndicator']) ? '<loyalty_card_update_indicator>' . $request['loyaltyCardUpdateIndicator'] . '</loyalty_card_update_indicator>' : '') . '
                        ' . (!empty($request['permanentChange']) ? '<permanent_change>' . $request['permanentChange'] . '</permanent_change>' : '') . '
                        ' . (!empty($request['myWuNumber']) ? '<account_nbr>' . $request['myWuNumber'] . '</account_nbr>' : '') . '
                        ' . (!empty($request['myWuNumber']) ? '<mywu_number>' . $request['myWuNumber'] . '</mywu_number>' : '') . '
                     </preferred_customer>
                  </sender>
                  <foreign_remote_system>
                     <identifier>' . $fsid . '</identifier>
                     <reference_no>115210-000000003</reference_no>
                     <counter_id>' . $ftid . '</counter_id>
                  </foreign_remote_system>
                  <card_lookup_search_type>S</card_lookup_search_type>
               </xrsi:wu-card-lookup-request>
            </soapenv:Body>
         </soapenv:Envelope>';

         return $params;
    }
}