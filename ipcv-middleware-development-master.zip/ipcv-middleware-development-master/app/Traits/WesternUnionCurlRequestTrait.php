<?php

namespace App\Traits;

use App\Helpers\JSONSOAPConvert;
use App\WesternUnionConnectionErrorLog;

trait WesternUnionCurlRequestTrait
{
    public function requestWUAPI($params, $client_id, $request_data = [])
    {
        $ch = curl_init('https://66.218.162.7');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/xml',
            'Content-Length: ' . strlen($params)
        ]);

        $certFolder = 'pi-cert-key-in-pem-format';
        $dirCertFolder = base_path($certFolder);

        $cert = $dirCertFolder . '/WesternUnionPartnerIntegration-Client.crt.pem';
        $key = $dirCertFolder . '/WesternUnionPartnerIntegration-Client.key.pem';

        $pass = 'BAS$!@S87';

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
        curl_setopt($ch, CURLOPT_POST, 1);

        $pem = realpath($cert);
        if (!$pem || !is_readable($pem)) {
            die("error: .pem is not readable! realpath: \"{$pem}\" - working dir: \"" . getcwd() . "\" effective user: " . print_r(posix_getpwuid(posix_geteuid()), true));
        }

        curl_setopt($ch, CURLOPT_SSLCERT, $cert);
        curl_setopt($ch, CURLOPT_SSLCERTTYPE, "PEM");
        curl_setopt($ch, CURLOPT_SSLKEY, $key);
        curl_setopt($ch, CURLOPT_SSLKEYTYPE, "PEM");
        curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $pass);

        curl_setopt($ch, CURLOPT_POSTFIELDS, "$params");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        if ($output === false) {
            $errorMessage = 'Internal error - ' . curl_error($ch);
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['request_data'] = json_encode($request_data);
            $logs['xml_request'] = $params;
            $logs['reply_data'] = $soapResponse;

            WesternUnionConnectionErrorLog::create($logs);

            return $soapResponse;
//            exit('curl error is -' . curl_error($ch));
        }

        curl_close($ch);

        return $output;
    }

    public function requestWUAPIMobile($params, $client_id, $request_data = [])
    {
        $ch = curl_init('https://66.218.162.7');
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/xml',
            'Content-Length: ' . strlen($params),
            'Credential: WGsfssPL513T',
            'User_id: WUGateway!!',
            'Auth_token: d8ae4a93d52cfe047f5e217a3b42bbf11fdd7f7a3950a3405711b2a0e5d22d9170354ba956ee21a6cba1ee2d5d4d20ac61e807ee556b9f801d87e9b1dd9b5d97'
        ]);

        $certFolder = 'pi-cert-key-in-pem-format';
        $dirCertFolder = base_path($certFolder);

        $cert = $dirCertFolder . '/WesternUnionPartnerIntegration-Client.crt.pem';
        $key = $dirCertFolder . '/WesternUnionPartnerIntegration-Client.key.pem';

        $pass = 'BAS$!@S87';

        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, TRUE);
        curl_setopt($ch, CURLOPT_POST, 1);

        $pem = realpath($cert);
        if (!$pem || !is_readable($pem)) {
            die("error: .pem is not readable! realpath: \"{$pem}\" - working dir: \"" . getcwd() . "\" effective user: " . print_r(posix_getpwuid(posix_geteuid()), true));
        }

        curl_setopt($ch, CURLOPT_SSLCERT, $cert);
        curl_setopt($ch, CURLOPT_SSLCERTTYPE, "PEM");
        curl_setopt($ch, CURLOPT_SSLKEY, $key);
        curl_setopt($ch, CURLOPT_SSLKEYTYPE, "PEM");
        curl_setopt($ch, CURLOPT_SSLCERTPASSWD, $pass);

        curl_setopt($ch, CURLOPT_POSTFIELDS, "$params");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        if ($output === false) {
            $errorMessage = 'Internal error (Mobile) - ' . curl_error($ch);
            $soapResponse = JSONSOAPConvert::toSoap($errorMessage);

            $logs['client_id'] = $client_id;
            $logs['request_data'] = json_encode($request_data);
            $logs['xml_request'] = $params;
            $logs['reply_data'] = $soapResponse;

            WesternUnionConnectionErrorLog::create($logs);

            return $soapResponse;
//            exit('curl error is -' . curl_error($ch));
        }

        curl_close($ch);

        return $output;
    }
}
