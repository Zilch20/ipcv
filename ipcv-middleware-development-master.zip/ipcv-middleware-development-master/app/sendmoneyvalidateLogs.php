<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class sendmoneyvalidatelogs extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;
    protected $table = 'send_money_validate_logs';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'agentEmail','xml_request','client_id','senderName','address','city','province','postalCode','idNum','issueDate','expiration','birthDate','occupation','transactionReason','gender','fundSource','relationshiptoReceiver','positionLevel','phoneNum','receiverName','currencyCode','destinationCountry','destinationCurrencyCode','amount','request_data','reply_data','countryName','senderCountryCode','senderCountryCurrencyCode','idCountryIssued','countryofBirth','transactionType','paymentType'
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];
}
