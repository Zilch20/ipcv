<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Laravel\Lumen\Auth\Authorizable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Laravel\Passport\HasApiTokens;

class BranchManagementTable extends Model implements AuthenticatableContract, AuthorizableContract
{
    use Authenticatable, Authorizable, HasApiTokens;
    protected $table = 'branch_management_table';
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        "branchName",
        "branchOwner",
        "branchEmail",
        "branchAddress",
        "branchContact",
        "branchTerminalId",
        "ftid"
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password',
    ];

    // public function access()
    // {
    //     return $this->belongsToMany('App\SubAgentFuntionAccess', 'branch_access', 'branchOwner', 'id');
    // }

    // public function hasAnyBranchOwner($accesses)
    // {
    //     if(is_array($accesses))
    //     {
    //         foreach($accesses as $access)
    //         {
    //             if($this->hasAccess($access))
    //             {
    //                 return true;
    //             }
    //         }
    //     } else {
    //         if($this->hasAccess($accesses))
    //         {
    //             return true;
    //         }
    //     }
    //     return false;
    // }

    // public function hasAccess($access)
    // {
    //     if($this->access()->where('branchOwner', $access)->first())
    //     {
    //         return true;
    //     }
    //     return false;
    // }
}
