<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class BranchManagementTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('branch_management_table', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('branchName')->nullable();
            $table->string('branchOwner')->nullable();
            $table->string('branchEmail')->nullable();
            $table->string('branchAddress')->nullable();
            $table->string('branchContact')->nullable();
            $table->string('branchTerminalId')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('branch_management_table');
    }
}
