<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        $this->call('UsersTableSeeder');
        // $this->call('OauthClientSeeder');
        $this->call('branch_management_table_seeder');
    }
}
