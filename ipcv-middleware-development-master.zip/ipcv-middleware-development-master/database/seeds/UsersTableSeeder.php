<?php

use App\User;

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new User();
        $user->name = 'Dave';
        $user->email = 'dave@test.com';
        $user->password = app('hash')->make('password123');
        $user->phone_number = '+639171234567';
        $user->save();
    }
}
