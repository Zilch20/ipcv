<?php

use App\oauth_clients;

use Illuminate\Database\Seeder;

class OauthClientSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {


        $oauth = new oauth_clients();
        $oauth->id = '17';
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'iiarGSPvNCduTcBsmDN1O5mlCrskSClcnyZ7QIPX';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = '18';
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'vYJ921ZR6ysgpQXEJTblMwOQYuj4mfij1GSZwO1O';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = '19';
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'ye2iEUOqemK7hPFH6QqcowToqFh6sVlaWI1FK1Dm';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = '20';
        $oauth->name = 'Password Grant Client';
        $oauth->secret = '1GKgqyY5tSGWHSIz8XrABXsiSJZipd6L7yImbnR2';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = '21';
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'KWdrJ0x1wVNIhckRGHhBaAyO37NLTcYydnss1vEI';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();

        $oauth = new oauth_clients();
        $oauth->id = '22';
        $oauth->name = 'Password Grant Client';
        $oauth->secret = 'KD0oYPac3VkBef4Px1nfxdWlBdc3MP0FnNsmsCYg';
        $oauth->redirect = 'http://3.1.170.158';
        $oauth->personal_access_client = '0';
        $oauth->password_client = '1';
        $oauth->revoked = '0';
        $oauth->save();
    }
}
