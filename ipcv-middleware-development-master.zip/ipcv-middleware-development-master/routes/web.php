<?php
use Illuminate\Http\Request;

$router->get('/', function () use ($router) {
    return view('landing_page');
});

$router->post('/register?admin=ipay-admin', 'UserController@register');

//$router->get('/home', function () use ($router) {
//
//    return $router->app->version();
//
//});

$router->post('/test3', 'Test@test_write');
$router->post('/test2', 'Test@testtwo');
$router->post('/test-debug', 'Test@test_debug');
$router->post('/register', 'UserController@register');


$router->group(['middleware' => 'client'], function () use ($router) {
    
    $router->post('/login', 'UserController@UserDetails');
    $router->post('/db-syncing/get-logs', 'DbSyncingController@getlogs' );
    $router->post('/db-syncing/view-logs', 'DbSyncingController@viewlogs' );
    $router->post('/db-syncing/branch-logs', 'DbSyncingController@getLogsForBranches' );
    $router->post('/db-syncing/agent-logs', 'DbSyncingController@getLogsForSubAgent' );
    $router->post('/db-syncing/transaction-logs', 'AgentPortalDbSyncingController@getTransaction' );

    //User Details
    $router->post('/user', 'UserController@UserDetails');
    // Services
    $router->group(['prefix'=>'service'], function() use ($router){
        //Wavecell
        // $router->post('1', 'OtpProcessController@otpProcess');
        //Test Wavecell
        $router->group(['prefix'=>'1'], function() use ($router){
            $router->get('{id}', 'WavecellController@OneTimePin');
            $router->post('validate', 'WavecellController@ValidateOtp');
        });
    });

    $router->group(['prefix'=>'agent'], function() use ($router){
        $router->post('manage', 'SubAgentControllers\SubAgentProcessController@SubAgentProcess');
        $router->post('branch', 'SubAgentControllers\BranchManagementController@BranchProcess');
    });
    //Billers
    $router->group(['prefix'=>'billers'], function() use ($router){
        //ecPAYbills payment
        $router->post('1', 'ECPayControllers\BillsPaymentControllers\TransactProcessController@transactProcess');
        //Ayannah
        // $router->post('2', 'AyannahControllers\BillsPaymentControllers\TransactProcessController@transactProcess');
    });
    //Transfer
    $router->group(['prefix'=>'transfer'], function() use ($router){
        //Instapay & UnionBank
        $router->post('1', 'UnionbankControllers\InstapayControllers\TransferProcessController@transferProcess');
        $router->post('2','UnionbankControllers\PesonetControllers\SingleTransferProcess@transferProcess');
        //Instapay & UnionBank Tokens
        $router->post('token', 'UnionbankControllers\TokenControllers\TokenProcessController@partnerToken');
    });
    //Topup
    $router->group(['prefix'=>'topup'], function() use ($router){
        //ecPAYbills payment
        $router->post('1', 'ECPayControllers\TopupControllers\TopupProcessController@topupProcess');
    });
    //Remittance
    $router->group(['prefix'=>'remittance'], function() use ($router){
        //Western Union
        $router->get('connect', 'WesternUnionControllers\HeartbeatController@heartbeatProcess');
        $router->post('send', 'WesternUnionControllers\SendMoneyProcessController@SendMoneyStoreProcess');
        $router->post('receive', 'WesternUnionControllers\ReceiveMoneyProcessController@ReceiveMoneyProcess');
        $router->post('status', 'WesternUnionControllers\PayStatusProcessController@payStatusProcess');
        $router->post('mywu', 'WesternUnionControllers\MyWuProcessController@MyWuLookupProcess');
        $router->post('kyc', 'WesternUnionControllers\KycProcessController@kycProcess');

        $router->group(['prefix'=>'mobile'], function() use ($router){
            $router->post('send', 'WesternUnionControllers\MobileSendMoneyProcessController@MobileSendMoneyStoreProcess');
            $router->post('receive', 'WesternUnionControllers\MobileReceiveMoneyProcessController@MobileReceiveMoneyProcess');
        });
    });

});
