# IPCV API

![Tests](https://github.com/IPCVI/ipcv-api/actions/workflows/main.yaml/badge.svg)
