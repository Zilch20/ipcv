<?php

declare(strict_types=1);

namespace IPCV\API\Integrators\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Client extends Model
{
    /**
     * @var string
     */
    protected $table = 'client';

    /**
     * @var string[]
     */
    protected $fillable = [
        'name',
        'username',
        'password',
        'description',
        'is_active',
        'fsid',
        'ftid',
    ];

    public function receiveMoneyTransactions(): HasMany
    {
        return $this->hasMany(related: ClientReceiveMoneyTransaction::class, foreignKey: 'client_id');
    }

    public function sendMoneyTransactions(): HasMany
    {
        return $this->hasMany(related: ClientSendMoneyTransaction::class, foreignKey: 'client_id');
    }
}
