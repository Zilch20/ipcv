<?php

declare(strict_types=1);

namespace IPCV\API\Integrators\Models;

use Illuminate\Database\Eloquent\Model;

class ClientSendMoneyTransaction extends Model
{
    /**
     * @var string
     */
    protected $table = 'client_send_money_transactions';

    /**
     * @var string[]
     */
    protected $fillable = [
        ''
    ];
}
