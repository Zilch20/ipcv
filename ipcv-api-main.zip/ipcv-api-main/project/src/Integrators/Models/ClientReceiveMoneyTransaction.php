<?php

declare(strict_types=1);

namespace IPCV\API\Integrators\Models;

use Illuminate\Database\Eloquent\Model;

class ClientReceiveMoneyTransaction extends Model
{
    /**
     * @var string
     */
    protected $table = 'client_receive_money_transactions';

    /**
     * @var string[]
     */
    protected $fillable = [
        'receiver_first_name',
        'receiver_middle_name',
        'receiver_last_name',
        'receiver_address_line_1',
        'receiver_address_line_2',
        'receiver_city',
        'receiver_state',
        'receiver_postal_code',
        'receiver_country',
        'receiver_country_code',
        'receiver_currency_code',
        'receiver_email',
        'receiver_date_of_birth',
        'receiver_nationality',
        'receiver_occupation',
        'receiver_employment_position_level',
        'receiver_gender',
        'receiver_source_of_funds',
        'receiver_country_of_birth',
        'receiver_phone_country_code',
        'receiver_phone_number',
        'receiver_my_wu_number',
        'receiver_id_type',
        'receiver_id_number',
        'receiver_id_country_issued',
        'receiver_id_issue_date',
        'receiver_id_expiry_date',
        'mtcn',
        'new_mtcn',
        'money_transfer_key',
        'new_points_earned',
        'total_points_earned',
        'gross_total_amount',
        'pay_amount',
        'principal_amount',
        'charges',
        'tolls',
        'exchange_rate',
        'originating_currency_code',
        'originating_country_code',
        'destination_country_code',
        'destination_currency_code',
        'transaction_type',
        'purpose',
        'source_of_funds',
        'relationship_to_sender',
        'sender_first_name',
        'sender_middle_name',
        'sender_last_name',
        'messages',
        'status',
        'timestamp',
        'client_id',
    ];
}
