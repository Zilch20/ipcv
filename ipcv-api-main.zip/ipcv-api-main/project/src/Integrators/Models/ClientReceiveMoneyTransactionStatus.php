<?php

declare(strict_types=1);

namespace IPCV\API\Integrators\Models;

enum ClientReceiveMoneyTransactionStatus: int
{
    case CLAIMED = 0;
    case AVAILABLE = 1;
    case FAILED = 2;
}
