<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Events;

use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\WesternUnion\SendMoneyValidation\Request;
use Psr\Http\Message\ResponseInterface;

class FailedSendMoneyValidationEvent implements SendMoneyValidationEvent
{
    public function __construct(
        private readonly GovernmentIdentification $governmentIdentification,
        private readonly Branch $branch,
        private readonly Request $request,
        private readonly ResponseInterface $response,
    ) {
    }

    public function request(): Request
    {
        return $this->request;
    }

    public function response(): ResponseInterface
    {
        return $this->response;
    }

    public function isSuccessful(): bool
    {
        return false;
    }

    public function governmentIdentification(): GovernmentIdentification
    {
        return $this->governmentIdentification;
    }

    public function branch(): Branch
    {
        return $this->branch;
    }
}
