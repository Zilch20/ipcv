<?php

namespace IPCV\API\Portal\Events;

use Illuminate\Support\Carbon;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\WesternUnion\ReceiveMoneyPay\Request;
use Psr\Http\Message\ResponseInterface;

interface ReceiveMoneyPayEvent
{
    public function governmentIdentification(): GovernmentIdentification;

    public function branch(): Branch;

    public function request(): Request;

    public function response(): ResponseInterface;

    public function timestamp(): Carbon;

    public function isSuccessful(): bool;
}
