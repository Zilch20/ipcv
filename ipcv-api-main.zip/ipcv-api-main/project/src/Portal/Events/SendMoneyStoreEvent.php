<?php

namespace IPCV\API\Portal\Events;

use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\WesternUnion\SendMoneyStore\Request;
use Psr\Http\Message\ResponseInterface;

interface SendMoneyStoreEvent
{
    public function governmentIdentification(): GovernmentIdentification;

    public function branch(): Branch;

    public function request(): Request;

    public function response(): ResponseInterface;

    public function isSuccessful(): bool;
}
