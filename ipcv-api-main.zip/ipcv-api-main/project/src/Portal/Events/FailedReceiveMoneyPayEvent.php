<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Carbon;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\WesternUnion\ReceiveMoneyPay\Request as ReceiveMoneyPayRequest;
use Psr\Http\Message\ResponseInterface;

class FailedReceiveMoneyPayEvent implements ReceiveMoneyPayEvent
{
    use Dispatchable;
    use SerializesModels;

    public Carbon $timestamp;

    public function __construct(
        private readonly GovernmentIdentification $governmentIdentification,
        private readonly Branch $branch,
        private readonly ReceiveMoneyPayRequest $request,
        private readonly ResponseInterface $response,
    ) {
        $this->timestamp = Carbon::now();
    }

    public function governmentIdentification(): GovernmentIdentification
    {
        return $this->governmentIdentification;
    }

    public function branch(): Branch
    {
        return $this->branch;
    }

    public function request(): ReceiveMoneyPayRequest
    {
        return $this->request;
    }

    public function response(): ResponseInterface
    {
        return $this->response;
    }

    public function timestamp(): Carbon
    {
        return $this->timestamp;
    }

    public function isSuccessful(): bool
    {
        return false;
    }
}
