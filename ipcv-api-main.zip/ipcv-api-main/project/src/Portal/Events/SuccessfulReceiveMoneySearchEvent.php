<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Events;

use DateTimeImmutable;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use IPCV\API\Portal\Models\Branch;
use IPCV\WesternUnion\ReceiveMoneySearch\Request;
use Psr\Http\Message\ResponseInterface;

class SuccessfulReceiveMoneySearchEvent
{
    use Dispatchable;
    use SerializesModels;

    private DateTimeImmutable $timestamp;
    public function __construct(
        private readonly Branch $branch,
        private readonly Request $request,
        private readonly ResponseInterface $response,
    ) {
        $this->timestamp = new DateTimeImmutable();
    }

    public function branch(): Branch
    {
        return $this->branch;
    }

    public function request(): Request
    {
        return $this->request;
    }

    public function response(): ResponseInterface
    {
        return $this->response;
    }

    public function timestamp(): DateTimeImmutable
    {
        return $this->timestamp;
    }
}
