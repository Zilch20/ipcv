<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\WesternUnion\SendMoneyStore\Request as SendMoneyStoreRequest;
use Psr\Http\Message\ResponseInterface;

class FailedSendMoneyStoreEvent implements SendMoneyStoreEvent
{
    use Dispatchable;
    use SerializesModels;

    public function __construct(
        private readonly GovernmentIdentification $governmentIdentification,
        private readonly Branch $branch,
        private readonly SendMoneyStoreRequest $request,
        private readonly ResponseInterface $response,
    ) {
    }

    public function isSuccessful(): bool
    {
        return false;
    }

    public function governmentIdentification(): GovernmentIdentification
    {
        return $this->governmentIdentification;
    }

    public function branch(): Branch
    {
        return $this->branch;
    }

    public function request(): SendMoneyStoreRequest
    {
        return $this->request;
    }

    public function response(): ResponseInterface
    {
        return $this->response;
    }
}
