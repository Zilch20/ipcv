<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Console\Command;

use Illuminate\Console\Command;
use IPCV\API\Portal\Factories\ForeignRemoteSystemFactory;
use IPCV\API\Portal\Models\CountryCurrency;
use IPCV\API\Portal\Repositories\BranchRepository;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DataAccessServer\Client;
use IPCV\WesternUnion\DataAccessServer\Request;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Filters;
use IPCV\WesternUnion\ForeignRemoteSystem;
use RuntimeException;
use SimpleXMLElement;

class FetchUpdatedCountryCurrencyList extends Command
{
    private const HALF_A_SECOND = 500_000;

    public function __construct(
        private readonly Client $client,
        private readonly BranchRepository $branchRepository,
    ) {
        parent::__construct();
    }

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wu:update-country-currency {originating country=Philippines}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Get updated country currency list from Western Union DAS (Data Access Server).';


    /**
     * @throws InvalidArgumentException
     */
    public function handle(): int
    {
        $filter = new Filters();
        $filter
            ->addFilter('en')
            ->addFilter($this->argument('originating country'))
        ;

        $request = $this->createRequest();
        $request->setFilters($filter);

        do {
            $response = $this->client->send($request);
            $xmlResponse = new SimpleXMLElement($response->getBody()->__toString());

            $thereIsMoreData = self::checkIfThereIsMoreData($xmlResponse);
            $countries = self::extractCountriesFromResponse($xmlResponse);

            foreach ($countries as $country) {
                CountryCurrency::query()
                    ->updateOrCreate(
                        attributes: [
                            'country_name' => $country['country_name'],
                            'iso_currency_number_code' => $country['iso_currency_number_code'],
                        ],
                        values: [
                            'iso_country_number_code' => $country['iso_country_number_code'],
                            'iso_country_code' => $country['iso_country_code'],
                            'currency_code' => $country['currency_code'],
                            'currency_name' => $country['currency_name'],
                        ]
                    );
            }

            if ($thereIsMoreData) {
                $lastCountry = \end($countries);

                $filter = (new Filters())
                    ->addFilter('en')
                    ->addFilter('Philippines')
                    ->addFilter($lastCountry['country_name'])
                    ->addFilter($lastCountry['currency_name'])
                ;
            }

            \usleep(self::HALF_A_SECOND);
        } while ($thereIsMoreData);

        return self::SUCCESS;
    }

    private static function checkIfThereIsMoreData(SimpleXMLElement $xmlResponse): bool
    {
        $dataMore = (string)$xmlResponse
            ->children('soapenv', true)
            ?->Body
            ?->children('xrsi', true)
            ?->children()
            ?->MTML
            ?->REPLY
            ?->DATA_CONTEXT
            ?->HEADER
            ?->DATA_MORE
        ;

        return $dataMore === "Y";
    }

    /**
     * @return array<int, array{
     *     country_name: string,
     *     iso_country_number_code: int,
     *     iso_country_code: string,
     *     currency_code: string,
     *     iso_currency_number_code: int,
     *     currency_name: string,
     * }>
     */
    private static function extractCountriesFromResponse(SimpleXMLElement $xmlResponse): array
    {
        $countries = $xmlResponse
            ->children('soapenv', true)
            ?->Body
            ?->children('xrsi', true)
            ?->children()
            ?->MTML
            ?->REPLY
            ?->DATA_CONTEXT
            ?->RECORDSET
            ?->GETCOUNTRIESCURRENCIES
            ?? []
        ;

        $countriesArray = [];
        foreach ($countries as $country) {
            $countriesArray[] = [
                'country_name' => (string)$country->COUNTRY_LONG,
                'iso_country_number_code' => (int)$country->ISO_COUNTRY_NUM_CD,
                'iso_country_code' => (string)$country->ISO_COUNTRY_CD,
                'currency_code' => (string)$country->CURRENCY_CD,
                'iso_currency_number_code' => (int)$country->ISO_CURRENCY_NUM_CD,
                'currency_name' => (string)$country->CURRENCY_NAME,
            ];
        }

        return $countriesArray;
    }

    /**
     * @throws InvalidArgumentException
     */
    private function createRequest(): Request
    {
        $branch = $this->branchRepository->findByName($branchName = 'IPCV HEAD OFFICE');

        if ($branch === null) {
            throw new RuntimeException(\sprintf('Branch %s not found.', $branchName));
        }

        $foreignRemoteSystem = ForeignRemoteSystemFactory::create($branch, config('western_union.identifier'));

        $request = new Request();
        $request
            ->setChannel(new Channel('H2H', 'IPCV', '9500'))
            ->setForeignRemoteSystem(new ForeignRemoteSystem('WGHHPH5130T', '115210-000000003', 'PH513AMP001C'))
            ->setClientId('H2H')
            ->setName('GetCountriesCurrencies')
        ;

        return $request;
    }
}
