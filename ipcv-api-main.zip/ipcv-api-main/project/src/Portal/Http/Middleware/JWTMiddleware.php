<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use IPCV\API\Portal\Exceptions\NoBearerToken;
use Lcobucci\JWT\Configuration;

class JWTMiddleware
{
    public function __construct(private readonly Configuration $configuration)
    {
    }

    public function handle(Request $request, Closure $next)
    {
        if (false === $request->hasHeader('Authorization')) {
            throw new NoBearerToken(401, __('errors.no_bearer_token'));
        }

        $parser = $this->configuration->parser();
        $validator = $this->configuration->validator();

        $token = $parser->parse(self::extractTokenFromRequest($request));
        $validator->assert($token, ...$this->configuration->validationConstraints());

        $user_id = $token->claims()->get('user_id');
        $request->merge(compact('user_id'));

        return $next($request);
    }

    private static function extractTokenFromRequest(Request $request): string
    {
        return explode(" ", $request->header('Authorization', ''), limit: 2)[1] ?? '';
    }
}
