<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\Customer;

use Illuminate\Validation\Rule;
use IPCV\API\BaseFormRequest;
use IPCV\API\Portal\Models\Customer;
use IPCV\WesternUnion\Gender;

class UpdateCustomerRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'first_name' => ['string'],
            'middle_name' => ['string'],
            'last_name' => ['string'],

            'address_line_1' => ['string'],
            'address_line_2' => ['string'],
            'city' => ['string'],
            'state' => ['string'],
            'postal_code' => ['string'],
            'country_code' => ['string'],
            'currency_code' => ['string'],

            'email' => ['email', 'unique:' . Customer::class],
            'date_of_birth' => ['date_format:Y-m-d'],
            'nationality' => ['string'],
            'occupation' => ['string', Rule::in(config('western_union.transaction.occupations'))],
            'occupation_position_level' => ['string', Rule::in(config('western_union.transaction.position_levels'))],
            'gender' => [Rule::in(Gender::values())],
            'source_of_funds' => ['string', Rule::in(config('western_union.transaction.fund_sources'))],
            'country_of_birth' => ['string'],
            'phone_country_code' => ['string'],
            'phone_number' => ['string'],
        ];
    }
}
