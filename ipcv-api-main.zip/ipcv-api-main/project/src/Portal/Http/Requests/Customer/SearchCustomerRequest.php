<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\Customer;

use Illuminate\Validation\Rule;
use IPCV\API\BaseFormRequest;
use IPCV\WesternUnion\IdType;

class SearchCustomerRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'first_name' => ['string'],
            'middle_name' => ['string'],
            'last_name' => ['string'],
            'phone_number' => ['string'],
            'my_wu_number' => ['string'],

            'government_identification_type' => [
                'string',
                Rule::in(IdType::values()),
                'required_with:government_identification_number'
            ],
            'government_identification_number' => ['string', 'required_with:government_identification_type'],
        ];
    }
}
