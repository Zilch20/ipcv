<?php

namespace IPCV\API\Portal\Http\Requests\Customer;

use Illuminate\Validation\Rule;
use IPCV\API\BaseFormRequest;
use IPCV\API\Portal\Models\Customer;
use IPCV\WesternUnion\Gender;

class CreateCustomerRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'first_name' => ['required', 'string'],
            'middle_name' => ['string'],
            'last_name' => ['required', 'string'],

            'address_line_1' => ['required', 'string'],
            'address_line_2' => ['string'],
            'city' => ['required', 'string'],
            'state' => ['required', 'string'],
            'postal_code' => ['required', 'string'],
            'country' => ['required', 'string'],
            'country_code' => ['required', 'string'],
            'currency_code' => ['required', 'string'],

            'email' => ['required', 'email', 'unique:' . Customer::class],
            'date_of_birth' => ['required', 'date_format:Y-m-d'],
            'nationality' => ['required', 'string'],
            'occupation' => ['required', 'string', Rule::in(config('western_union.transaction.occupations'))],
            'employment_position_level' => [
                'required',
                'string',
                Rule::in(config('western_union.transaction.position_levels'))
            ],
            'gender' => ['required', Rule::in(Gender::values())],
            'source_of_funds' => ['required', 'string', Rule::in(config('western_union.transaction.fund_sources'))],
            'country_of_birth' => ['required', 'string'],
            'phone_country_code' => ['required', 'string'],
            'phone_number' => ['required', 'string'],
        ];
    }
}
