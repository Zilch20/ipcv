<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\TwoFactor;

use Illuminate\Foundation\Http\FormRequest;

class DisableTwoFactorRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'password' => ['string', 'required'],
        ];
    }
}
