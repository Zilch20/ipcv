<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests;

use Illuminate\Validation\Rule;
use IPCV\API\BaseFormRequest;
use IPCV\WesternUnion\ServiceType;
use IPCV\WesternUnion\TransactionType;

class FeeInquiryRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'financials.originators_principal_amount' => [
                'required',
                'integer',
                'numeric'
            ],
            'financials.destination_principal_amount' => [
                'required',
                'integer',
                'numeric'
            ],

            'payment_details.expected_payout_location.state_code' => ['required'],
            'payment_details.expected_payout_location.city' => ['required'],

            'payment_details.recording_country_currency.currency_code' => ['required'],
            'payment_details.recording_country_currency.country_code' => ['required'],

            'payment_details.destination_country_currency.currency_code' => ['required'],
            'payment_details.destination_country_currency.country_code' => ['required'],

            'payment_details.originating_country_currency.currency_code' => ['required'],
            'payment_details.originating_country_currency.country_code' => ['required'],

            'payment_details.originating_state' => ['required'],
            'payment_details.transaction_type' => ['required', Rule::in(TransactionType::values())],
            'payment_details.payment_type' => ['required', Rule::in(config('western_union.transaction.payment_types'))],
        ]
            + self::deliveryServicesValidation()
        ;
    }

    private static function deliveryServicesValidation(): array
    {
        return [
            'delivery_services.code' => ['required', Rule::in(ServiceType::values())],
            'delivery_services.routing_code' => ['string'],
            'delivery_services.message' => ['max:4'],
            'delivery_services.message.*' => ['max:69', 'string'],
        ];
    }

    public function messages(): array
    {
        return [
            'delivery_services.message.max' => 'Maximum message count is :max.',
            'delivery_services.message.*.max' => 'Maximum character count per message is :max',
            'delivery_services.message.*.string' => 'Message should be of type string datatype.',
        ];
    }
}
