<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests;

use Illuminate\Validation\Rule;
use IPCV\API\BaseFormRequest;

class SendMoneyValidationFormRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'customer_id' => ['required', 'string'],
            'government_identification_id' => ['required', 'string'],
            'bank_information_id' => ['string'],
            'relationship_to_receiver' => ['string', Rule::in(config('western_union.transaction.relationships'))],
            'transaction_reason' => ['string', Rule::in(config('western_union.transaction.reasons'))]
        ]
            + config('validation_rules.receiver')
            + config('validation_rules.payment_details')
            + config('validation_rules.financials')
            + config('validation_rules.delivery_services')
        ;
    }

    public function messages(): array
    {
        return config('validation_messages');
    }
}
