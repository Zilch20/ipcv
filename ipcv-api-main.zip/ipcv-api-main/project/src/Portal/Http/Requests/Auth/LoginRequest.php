<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\Auth;

use IPCV\API\BaseFormRequest;

class LoginRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'email' => ['required', 'email'],
            'password' => ['string', 'required'],
        ];
    }
}
