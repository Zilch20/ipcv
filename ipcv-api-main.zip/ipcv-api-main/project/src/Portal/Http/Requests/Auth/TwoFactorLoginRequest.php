<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\Auth;

use IPCV\API\BaseFormRequest;

class TwoFactorLoginRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'code' => ['nullable', 'string'],
            'recovery_code' => ['nullable', 'string'],
            'two_factor_key' => ['required', 'string'],
        ];
    }
}
