<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\BankInformation;

use IPCV\API\BaseFormRequest;

class UpdateBankInformationRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'bank_name' => ['string'],
            'account_number' => ['string'],
            'account_type' => ['string'],
            'routing_number' => ['string'],
            'branch_number' => ['string'],
            'bank_location' => ['string'],
            'bic' => ['string'],
            'bank_code' => ['string'],
            'sort_code' => ['string'],
            'account_prefix' => ['string'],
            'account_suffix' => ['string'],
            'bank_account_holder' => ['string'],
        ];
    }
}
