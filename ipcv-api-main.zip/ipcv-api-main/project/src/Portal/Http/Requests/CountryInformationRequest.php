<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests;

use IPCV\API\BaseFormRequest;

class CountryInformationRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'country_code' => ['required', 'string'],
            'currency_code' => ['required', 'string'],
        ];
    }
}
