<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\GovernmentIdentification;

use Illuminate\Validation\Rule;
use IPCV\API\BaseFormRequest;
use IPCV\WesternUnion\IdType;

class CreateGovernmentIdentificationRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'type' => ['required', Rule::in(IdType::values())],
            'number' => ['required', 'string'],
            'country_issued' => ['required', 'string'],
            'issue_date' => ['required', 'date_format:Y-m-d'],
            'expiry_date' => ['date_format:Y-m-d'],
        ];
    }
}
