<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\GovernmentIdentification;

use IPCV\API\BaseFormRequest;

class UpdateGovernmentIdentificationRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'type' => ['string'],
            'number' => ['string'],
            'country_issued' => ['string'],
            'issue_date' => ['date_format:Y-m-d'],
            'expiry_date' => ['date_format:Y-m-d'],
        ];
    }
}
