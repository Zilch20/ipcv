<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests;

use IPCV\API\BaseFormRequest;

class SendMoneyStoreFormRequest extends BaseFormRequest
{
    public function rules(): array
    {
        return [
            'customer_id' => ['required', 'string'],
            'government_identification_id' => ['required', 'string'],
            'bank_information_id' => ['string'],
            'compliance_data_buffer' =>  ['required', 'string'],
            'mtcn' => ['required', 'max:10'],
            'new_mtcn' => ['required', 'max:16'],
        ]
            + config('validation_rules.receiver')
            + config('validation_rules.payment_details')
            + config('validation_rules.financials')
            + config('validation_rules.delivery_services')
        ;
    }

    public function messages(): array
    {
        return config('validation_messages');
    }
}
