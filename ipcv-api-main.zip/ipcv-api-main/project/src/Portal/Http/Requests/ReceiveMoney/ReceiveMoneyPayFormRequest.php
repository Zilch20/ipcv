<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\ReceiveMoney;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ReceiveMoneyPayFormRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'customer_id' => ['required', 'string'],
            'government_identification_id' => ['required', 'string'],
            'bank_information_id' => ['string'],
            'mtcn' => ['required', 'max:10'],
            'new_mtcn' => ['required', 'max:16'],
            'money_transfer_key' => ['required'],
            'relationship_to_receiver' => ['string', Rule::in(config('western_union.transaction.relationships'))],
            'transaction_reason' => ['string', Rule::in(config('western_union.transaction.reasons'))],
        ]
            + config('validation_rules.receive_money.payment_details')
            + config('validation_rules.receive_money.financials')
        ;
    }
}
