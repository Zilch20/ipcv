<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Requests\ReceiveMoney;

use Illuminate\Foundation\Http\FormRequest;

class ReceiveMoneySearchFormRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'mtcn' => ['required', 'max:10'],
            'payment_details.destination_country_currency.currency_code' => ['required'],
            'payment_details.destination_country_currency.country_code' => ['required'],
        ];
    }
}
