<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class CountryCurrencyResource extends JsonResource
{
    /**
     * @param Request $request
     */
    public function toArray($request): array
    {
        return [
            'id' => $this->id,
            'country_name' => $this->country_name,
            'iso_country_number_code' => $this->iso_country_number_code,
            'iso_country_code' => $this->iso_country_code,
            'currency_code' => $this->currency_code,
            'iso_currency_number_code' => $this->iso_currency_number_code,
            'currency_name' => $this->currency_name,
        ];
    }
}
