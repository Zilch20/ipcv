<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\TwoFactor;

use Illuminate\Http\Request;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Actions\TwoFactor\GenerateTwoFactorRecoveryCodes;
use Symfony\Component\HttpFoundation\Response;

class RegenerateRecoveryCodesController extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly GenerateTwoFactorRecoveryCodes $generateTwoFactorRecoveryCodes,
    ) {
    }

    /**
     * @throws \JsonException
     */
    public function __invoke(Request $request): Response
    {
        ($this->resolveUserFromUserId)($request);
        ($this->generateTwoFactorRecoveryCodes)($request->user());

        return new Response();
    }
}
