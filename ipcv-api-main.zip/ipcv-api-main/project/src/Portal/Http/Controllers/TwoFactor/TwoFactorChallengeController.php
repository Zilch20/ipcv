<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\TwoFactor;

use Illuminate\Http\Request;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Actions\TwoFactor\TwoFactorChallenge;
use IPCV\API\Portal\Actions\TwoFactor\TwoFactorRecoveryCodeChallenge;
use Symfony\Component\HttpFoundation\Response;

class TwoFactorChallengeController
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly TwoFactorRecoveryCodeChallenge $twoFactorRecoveryCodeChallenge,
        private readonly TwoFactorChallenge $twoFactorChallenge,
    ) {
    }

    public function __invoke(Request $request): Response
    {
        ($this->resolveUserFromUserId)($request);

        if ($request->has('recovery_code')) {
            ($this->twoFactorRecoveryCodeChallenge)($request->user(), $request->input('recovery_code'));

            return new Response();
        }

        ($this->twoFactorChallenge)($request->user(), $request->input('code'));

        return new Response();
    }
}
