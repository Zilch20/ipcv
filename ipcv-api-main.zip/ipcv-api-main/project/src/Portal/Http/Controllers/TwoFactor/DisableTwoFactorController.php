<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\TwoFactor;

use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Actions\TwoFactor\DisableTwoFactor;
use IPCV\API\Portal\Actions\UserPasswordChallenge;
use IPCV\API\Portal\Http\Requests\TwoFactor\DisableTwoFactorRequest;
use Symfony\Component\HttpFoundation\Response;

class DisableTwoFactorController extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly UserPasswordChallenge $userPasswordChallenge,
        private readonly DisableTwoFactor $disableTwoFactor
    ) {
    }

    public function __invoke(DisableTwoFactorRequest $request): Response
    {
        ($this->resolveUserFromUserId)($request);
        ($this->userPasswordChallenge)($request->user(), $request->input('password'));
        ($this->disableTwoFactor)($request->user());

        return new Response();
    }
}
