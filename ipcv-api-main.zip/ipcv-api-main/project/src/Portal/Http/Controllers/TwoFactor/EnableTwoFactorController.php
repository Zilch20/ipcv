<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\TwoFactor;

use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Actions\TwoFactor\EnableTwoFactorAuth;
use IPCV\API\Portal\Actions\UserPasswordChallenge;
use IPCV\API\Portal\Http\Requests\TwoFactor\EnableTwoFactorRequest;
use Symfony\Component\HttpFoundation\Response;

class EnableTwoFactorController extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly UserPasswordChallenge $userPasswordChallenge,
        private readonly EnableTwoFactorAuth $enableTwoFactorAuth,
    ) {
    }

    /**
     * @throws \JsonException
     */
    public function __invoke(EnableTwoFactorRequest $request): Response
    {
        ($this->resolveUserFromUserId)($request);
        ($this->userPasswordChallenge)($request->user(), $request->input('password'));
        ($this->enableTwoFactorAuth)($request->user());

        return new Response();
    }
}
