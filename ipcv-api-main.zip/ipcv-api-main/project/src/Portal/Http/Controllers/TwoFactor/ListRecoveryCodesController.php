<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\TwoFactor;

use Illuminate\Contracts\Encryption\Encrypter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use Symfony\Component\HttpFoundation\Response;

class ListRecoveryCodesController extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly Encrypter $encrypter
    ) {
    }

    public function __invoke(Request $request): Response
    {
        ($this->resolveUserFromUserId)($request);

        if (
            ! $request->user()->two_factor_secret ||
            ! $request->user()->two_factor_recovery_codes
        ) {
            return new JsonResponse([]);
        }

        $recoveryCodesAsString = $this->encrypter->decrypt($request->user()->two_factor_recovery_codes);
        return new JsonResponse(\json_decode($recoveryCodesAsString, true, 512, JSON_THROW_ON_ERROR));
    }
}
