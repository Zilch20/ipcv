<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\Customers;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Repositories\CustomerRepository;
use Symfony\Component\HttpFoundation\Response;

class ShowCustomer extends Controller
{
    public function __construct(private readonly CustomerRepository $repository)
    {
    }

    public function __invoke($id): Response
    {
        if ($customer = $this->repository->find($id)) {
            return new JsonResponse($customer);
        }

        return new Response(status: Response::HTTP_NOT_FOUND);
    }
}
