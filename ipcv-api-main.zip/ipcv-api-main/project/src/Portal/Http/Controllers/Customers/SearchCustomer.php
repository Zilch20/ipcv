<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\Customers;

use Illuminate\Http\JsonResponse;
use IPCV\API\Portal\Actions\Customers\SearchCustomerByGovernmentIdentification;
use IPCV\API\Portal\Actions\Customers\SearchCustomerByMyWuNumber;
use IPCV\API\Portal\Actions\Customers\SearchCustomerByPhoneNumber;
use IPCV\API\Portal\Http\Requests\Customer\SearchCustomerRequest;
use Symfony\Component\HttpFoundation\Response;

class SearchCustomer
{
    public function __construct(
        private readonly SearchCustomerByGovernmentIdentification $searchCustomerByGovernmentIdentification,
        private readonly SearchCustomerByPhoneNumber $searchCustomerByPhoneNumber,
        private readonly SearchCustomerByMyWuNumber $searchCustomerByMyWuNumber,
    ) {
    }
    public function __invoke(SearchCustomerRequest $request): Response
    {
        if (
            $request->has('government_identification_type')
            && $request->has('government_identification_number')
        ) {
            $customer = ($this->searchCustomerByGovernmentIdentification)($request);

            return new JsonResponse($customer);
        }

        if ($request->has('phone_number')) {
            $customer = ($this->searchCustomerByPhoneNumber)($request);

            return new JsonResponse($customer);
        }

        if ($request->has('my_wu_number')) {
            $customer = ($this->searchCustomerByMyWuNumber)($request);

            return new JsonResponse($customer);
        }

        return new Response('', 400);
    }
}
