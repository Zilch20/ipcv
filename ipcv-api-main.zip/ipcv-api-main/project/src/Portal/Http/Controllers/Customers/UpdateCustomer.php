<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\Customers;

use IPCV\API\Controller;
use IPCV\API\Portal\Http\Requests\Customer\UpdateCustomerRequest;
use IPCV\API\Portal\Repositories\CustomerRepository;
use Symfony\Component\HttpFoundation\Response;

class UpdateCustomer extends Controller
{
    public function __construct(private readonly CustomerRepository $repository)
    {
    }

    public function __invoke(UpdateCustomerRequest $request, $id): Response
    {
        if (0 === $this->repository->update($id, $request->validated())) {
            return new Response(status: Response::HTTP_NOT_FOUND);
        }

        return new Response(status: Response::HTTP_OK);
    }
}
