<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\Customers;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Http\Requests\Customer\CreateCustomerRequest;
use IPCV\API\Portal\Repositories\CustomerRepository;
use Symfony\Component\HttpFoundation\Response;

class CreateCustomer extends Controller
{
    public function __construct(private readonly CustomerRepository $repository)
    {
    }

    public function __invoke(CreateCustomerRequest $request): Response
    {
        $customer = $this->repository->create($request->validated());

        return new JsonResponse(['id' => $customer->id], status: Response::HTTP_CREATED);
    }
}
