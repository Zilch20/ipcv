<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\SendMoney;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Actions\SendMoneyStore\PerformSendMoneyStoreRequest;
use IPCV\API\Portal\Http\Requests\SendMoneyStoreFormRequest;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Symfony\Component\HttpFoundation\Response as BaseResponse;

class SendMoneyStore extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly PerformSendMoneyStoreRequest $performSendMoneyStoreRequest
    ) {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function __invoke(SendMoneyStoreFormRequest $request): BaseResponse
    {
        ($this->resolveUserFromUserId)($request);
        ($this->performSendMoneyStoreRequest)($request);

        return new JsonResponse("");
    }
}
