<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\SendMoney;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Actions\SendMoneyValidate\ConvertToArraySendMoneyValidationResponse;
use IPCV\API\Portal\Actions\SendMoneyValidate\PerformSendMoneyValidationRequest;
use IPCV\API\Portal\Http\Requests\SendMoneyValidationFormRequest;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Symfony\Component\HttpFoundation\Response as BaseResponse;

class SendMoneyValidation extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly PerformSendMoneyValidationRequest $performSendMoneyValidationRequest,
        private readonly ConvertToArraySendMoneyValidationResponse $convertToArraySendMoneyValidationResponse,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function __invoke(SendMoneyValidationFormRequest $request): BaseResponse
    {
        ($this->resolveUserFromUserId)($request);
        $response = ($this->performSendMoneyValidationRequest)($request);
        $responseAsArray = ($this->convertToArraySendMoneyValidationResponse)($response);

        return new JsonResponse($responseAsArray);
    }
}
