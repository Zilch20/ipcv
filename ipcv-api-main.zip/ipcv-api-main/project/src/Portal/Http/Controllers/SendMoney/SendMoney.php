<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\SendMoney;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Actions\SendMoneyStore\PerformSendMoneyStoreRequest;
use IPCV\API\Portal\Actions\SendMoneyValidate\ConvertToArraySendMoneyValidationResponse;
use IPCV\API\Portal\Actions\SendMoneyValidate\PerformSendMoneyValidationRequest;
use IPCV\API\Portal\Http\Requests\SendMoneyRequest;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Symfony\Component\HttpFoundation\Response;

class SendMoney extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $userFromUserId,
        private readonly PerformSendMoneyValidationRequest $performSendMoneyValidationRequest,
        private readonly ConvertToArraySendMoneyValidationResponse $convertToArraySendMoneyValidationResponse,
        private readonly PerformSendMoneyStoreRequest $performSendMoneyStoreRequest,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function __invoke(SendMoneyRequest $request): Response
    {
        ($this->userFromUserId)($request);

        $sendMoneyValidationResponse = ($this->performSendMoneyValidationRequest)($request);
        $responseAsArray = ($this->convertToArraySendMoneyValidationResponse)($sendMoneyValidationResponse);

        ($this->performSendMoneyStoreRequest)($request, $responseAsArray);

        return new JsonResponse([
            'mtcn' => $responseAsArray['mtcn'],
            'customer_id' => $request->input('customer_id')
        ]);
    }
}
