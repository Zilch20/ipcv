<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\SendMoney;

use Illuminate\Http\Response;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\GenerateSendMoneyPreACR;
use IPCV\API\Portal\Actions\SendMoneyStore\GetSuccessfulSendMoneyTransactionByCustomerIdAndMtcn;

class PrintSendMoneyPreACR extends Controller
{
    public function __construct(
        private readonly GetSuccessfulSendMoneyTransactionByCustomerIdAndMtcn $action,
        private readonly GenerateSendMoneyPreACR $generateSendMoneyPreACR,
    ) {
    }

    public function __invoke($customerId, $mtcn): Response
    {
        $transaction = ($this->action)($customerId, $mtcn);

        return new Response(($this->generateSendMoneyPreACR)($transaction));
    }
}
