<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\FeeInquiry;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\FeeInquiry\ConvertToArrayFeeInquiryResponse;
use IPCV\API\Portal\Actions\FeeInquiry\PerformFeeInquiryRequest;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Http\Requests\FeeInquiryRequest;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Symfony\Component\HttpFoundation\Response as BaseResponse;

class FeeInquiry extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly PerformFeeInquiryRequest $performFeeInquiryRequest,
        private readonly ConvertToArrayFeeInquiryResponse $convertToArrayFeeInquiryResponse,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function __invoke(FeeInquiryRequest $request): BaseResponse
    {
        ($this->resolveUserFromUserId)($request);
        $response = ($this->performFeeInquiryRequest)($request);
        $array = ($this->convertToArrayFeeInquiryResponse)($response);

        return new JsonResponse($array);
    }
}
