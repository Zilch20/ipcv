<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\CountryCurrencies;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use IPCV\API\Controller;
use IPCV\API\Portal\Http\Resources\CountryCurrencyResource;
use IPCV\API\Portal\Models\CountryCurrency;

class ListCountryCurrencies extends Controller
{
    public function __construct()
    {
    }

    public function __invoke(Request $request): AnonymousResourceCollection
    {
        $results = CountryCurrency::query()
            ->cursorPaginate(
                perPage: $request->input('per_page', 25),
                cursor: $request->input('cursor')
            );

        return CountryCurrencyResource::collection($results);
    }
}
