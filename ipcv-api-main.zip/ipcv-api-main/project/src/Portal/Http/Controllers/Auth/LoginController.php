<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\Auth;

use Illuminate\Validation\ValidationException;
use IPCV\API\Portal\Actions\Auth\AuthenticateWithDefaultCredentials;
use IPCV\API\Portal\Actions\Auth\ReturnAppropriateLoginResponse;
use IPCV\API\Portal\Http\Requests\Auth\LoginRequest;
use Symfony\Component\HttpFoundation\Response;

class LoginController
{
    public function __construct(
        private readonly AuthenticateWithDefaultCredentials $authenticateWithDefaultCredentials,
        private readonly ReturnAppropriateLoginResponse $returnAppropriateResponseToken
    ) {
    }

    /**
     * @throws ValidationException
     */
    public function __invoke(LoginRequest $request): Response
    {
        ($this->authenticateWithDefaultCredentials)($request);

        return ($this->returnAppropriateResponseToken)($request);
    }
}
