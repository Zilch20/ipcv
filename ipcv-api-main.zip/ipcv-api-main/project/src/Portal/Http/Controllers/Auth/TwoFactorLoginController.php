<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\Auth;

use Illuminate\Http\JsonResponse;
use IPCV\API\Portal\Actions\Auth\AuthenticateUserUsingTwoFactorCode;
use IPCV\API\Portal\Actions\Auth\AuthenticateUserUsingTwoFactorRecoveryCode;
use IPCV\API\Portal\Actions\Auth\GetChallengedUserByTwoFactorKey;
use IPCV\API\Portal\Http\Requests\Auth\TwoFactorLoginRequest;
use Symfony\Component\HttpFoundation\Response;

class TwoFactorLoginController
{
    public function __construct(
        private readonly GetChallengedUserByTwoFactorKey $getChallengedUserByTwoFactorKey,
        private readonly AuthenticateUserUsingTwoFactorCode $authenticateUserUsingTwoFactorCode,
        private readonly AuthenticateUserUsingTwoFactorRecoveryCode $authenticateUserUsingTwoFactorRecoveryCode,
    ) {
    }

    public function __invoke(TwoFactorLoginRequest $request): Response
    {
        ($this->getChallengedUserByTwoFactorKey)($request);

        if ($request->has('recovery_code')) {
            $token = ($this->authenticateUserUsingTwoFactorRecoveryCode)($request);

            return new JsonResponse(['bearer_token' => $token->toString()]);
        }

        $token = ($this->authenticateUserUsingTwoFactorCode)($request);

        return new JsonResponse(['bearer_token' => $token->toString()]);
    }
}
