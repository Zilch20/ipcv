<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPCV\API\Controller;
use IPCV\API\Portal\Models\CountryCurrency;

class CountryCurrencyController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $paginated = CountryCurrency::query()
            ->cursorPaginate(
                perPage: $request->input('per_page', 25),
                cursor: $request->input('cursor')
            );

        return new JsonResponse($paginated);
    }
}
