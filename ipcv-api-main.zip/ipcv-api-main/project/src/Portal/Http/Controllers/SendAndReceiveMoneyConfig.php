<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPCV\API\Controller;
use Symfony\Component\HttpFoundation\Response;

class SendAndReceiveMoneyConfig extends Controller
{
    public function __invoke(Request $request): Response
    {
        $value = match ($request->input('type')) {
            'payment_types' => config('western_union.transaction.payment_types'),
            'relationships' => config('western_union.transaction.relationships'),
            'reasons' => config('western_union.transaction.reasons'),
            'fund_sources' => config('western_union.transaction.fund_sources'),
            'occupations' => config('western_union.transaction.occupations'),
            'position_levels' => config('western_union.transaction.position_levels'),
            'id_types' => config('western_union.transaction.id_types'),
            'delivery_codes' => config('western_union.transaction.delivery_codes'),
            default => config('western_union.transaction'),
        };

        return new JsonResponse($value);
    }
}
