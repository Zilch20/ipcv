<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\GovernmentIdentifications;

use IPCV\API\Controller;
use IPCV\API\Portal\Http\Requests\GovernmentIdentification\UpdateGovernmentIdentificationRequest;
use IPCV\API\Portal\Repositories\GovernmentIdentificationRepository;
use Symfony\Component\HttpFoundation\Response;

class UpdateGovernmentIdentification extends Controller
{
    public function __construct(private readonly GovernmentIdentificationRepository $repository)
    {
    }

    public function __invoke(UpdateGovernmentIdentificationRequest $request, $id): Response
    {
        $updateResult = $this->repository->update($id, $request->validated());

        if (0 === $updateResult) {
            return new Response(status: Response::HTTP_NOT_FOUND);
        }

        return new Response(status: Response::HTTP_OK);
    }
}
