<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\GovernmentIdentifications;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Http\Requests\GovernmentIdentification\CreateGovernmentIdentificationRequest;
use IPCV\API\Portal\Repositories\CustomerRepository;
use IPCV\API\Portal\Repositories\GovernmentIdentificationRepository;
use Symfony\Component\HttpFoundation\Response;

class CreateGovernmentIdentification extends Controller
{
    public function __construct(
        private readonly GovernmentIdentificationRepository $governmentIdentificationRepository,
        private readonly CustomerRepository $customerRepository
    ) {
    }

    public function __invoke(CreateGovernmentIdentificationRequest $request, $customerId): Response
    {
        $customer = $this->customerRepository->find($customerId);

        if (null === $customer) {
            return new Response(status: Response::HTTP_NOT_FOUND);
        }

        $governmentIdentification = $this->governmentIdentificationRepository->create($customer, $request->validated());

        return new JsonResponse(['id' => $governmentIdentification->id], status: Response::HTTP_CREATED);
    }
}
