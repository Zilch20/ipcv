<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\GovernmentIdentifications;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\GovernmentIdentifications\ListGovernmentIdentificationByCustomerId;
use Symfony\Component\HttpFoundation\Response;

class ListGovernmentIdentification extends Controller
{
    public function __construct(
        private readonly ListGovernmentIdentificationByCustomerId $listGovernmentIdentificationByCustomerId,
    ) {
    }

    public function __invoke($customerId, Request $request): Response
    {
        $data = ($this->listGovernmentIdentificationByCustomerId)($customerId, $request);

        return new JsonResponse($data);
    }
}
