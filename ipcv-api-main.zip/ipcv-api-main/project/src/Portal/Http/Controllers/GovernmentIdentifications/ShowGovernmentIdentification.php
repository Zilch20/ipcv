<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\GovernmentIdentifications;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Repositories\GovernmentIdentificationRepository;
use Symfony\Component\HttpFoundation\Response;

class ShowGovernmentIdentification extends Controller
{
    public function __construct(
        private readonly GovernmentIdentificationRepository $governmentIdentificationRepository,
    ) {
    }

    public function __invoke($id): Response
    {
        $results = $this->governmentIdentificationRepository->find($id);

        return new JsonResponse($results);
    }
}
