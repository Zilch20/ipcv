<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Http\Resources\BranchUserResource;

class ProfileController extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
    ) {
    }

    public function __invoke(Request $request): JsonResource
    {
        ($this->resolveUserFromUserId)($request);

        return new BranchUserResource($request->user());
    }
}
