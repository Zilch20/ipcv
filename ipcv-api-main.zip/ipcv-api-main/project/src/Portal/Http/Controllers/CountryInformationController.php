<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\DataAccessServer\ParseGetCountryInformationResponse;
use IPCV\API\Portal\Actions\DataAccessServer\PerformGetCountryInformationRequest;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Http\Requests\CountryInformationRequest;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Models\CountryInformation;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Symfony\Component\HttpFoundation\Response;

class CountryInformationController extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly PerformGetCountryInformationRequest $performGetCountryInformationRequest,
        private readonly ParseGetCountryInformationResponse $parseGetCountryInformationResponse,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function __invoke(CountryInformationRequest $request): Response
    {
        ($this->resolveUserFromUserId)($request);
        $branch = $this->getBranchOfLoggedInUser($request->user());

        /**
         * @var CountryInformation|null $countryInformation
         */
        $countryInformation = CountryInformation::query()
            ->where('country_code', $request->input('country_code'))
            ->where('currency_code', $request->input('currency_code'))
            ->first()
        ;

        if ($countryInformation && $countryInformation->isUpdatedToday()) {
            return new JsonResponse($countryInformation);
        }

        $response = ($this->performGetCountryInformationRequest)(
            $branch,
            $request->input('country_code'),
            $request->input('currency_code'),
        );

        $responseAsArray = ($this->parseGetCountryInformationResponse)($response);
        $countryInformation = CountryInformation::query()
            ->updateOrCreate(
                attributes: [
                    'country_code' => $request->input('country_code'),
                    'currency_code' => $request->input('currency_code'),
                ],
                values: [
                    'information' => $responseAsArray
                ]
            );

        return new JsonResponse($countryInformation);
    }

    private function getBranchOfLoggedInUser(BranchUser $branchUser): Branch
    {
        return $branchUser->branch()->first();
    }
}
