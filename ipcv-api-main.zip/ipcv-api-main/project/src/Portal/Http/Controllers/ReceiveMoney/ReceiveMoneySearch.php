<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\ReceiveMoney;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ReceiveMoneySearch\ConvertToArrayReceiveMoneySearchResponse;
use IPCV\API\Portal\Actions\ReceiveMoneySearch\PerformReceiveMoneySearchRequest;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Http\Requests\ReceiveMoney\ReceiveMoneySearchFormRequest;
use Symfony\Component\HttpFoundation\Response;

class ReceiveMoneySearch extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly PerformReceiveMoneySearchRequest $performReceiveMoneySearchRequest,
        private readonly ConvertToArrayReceiveMoneySearchResponse $convertToArrayReceiveMoneySearchResponse,
    ) {
    }

    /**
     * @throws \Exception
     */
    public function __invoke(ReceiveMoneySearchFormRequest $request): Response
    {
        ($this->resolveUserFromUserId)($request);
        $response = ($this->performReceiveMoneySearchRequest)($request);

        if ($response === null) {
            return new Response(status: 404);
        }

        $responseAsArray = ($this->convertToArrayReceiveMoneySearchResponse)($response);

        return new JsonResponse($responseAsArray);
    }
}
