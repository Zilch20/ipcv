<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\ReceiveMoney;

use IPCV\API\Controller;
use IPCV\API\Portal\Actions\GenerateReceiveMoneyPreACR;
use IPCV\API\Portal\Actions\ReceiveMoneyPay\GetSuccessfulReceiveMoneyPayTransaction;
use Symfony\Component\HttpFoundation\Response;

class PrintReceiveMoneyPreACR extends Controller
{
    public function __construct(
        private readonly GetSuccessfulReceiveMoneyPayTransaction $getSuccessfulReceiveMoneyPayTransaction,
        private readonly GenerateReceiveMoneyPreACR $generateReceiveMoneyPreACR,
    ) {
    }

    public function __invoke($customerId, $mtcn): Response
    {
        $transaction = ($this->getSuccessfulReceiveMoneyPayTransaction)($customerId, $mtcn);

        return new Response(($this->generateReceiveMoneyPreACR)($transaction));
    }
}
