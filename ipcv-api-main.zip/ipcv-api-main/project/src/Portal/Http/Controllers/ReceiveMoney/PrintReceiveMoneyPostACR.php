<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\ReceiveMoney;

use IPCV\API\Controller;
use IPCV\API\Portal\Actions\GenerateReceiveMoneyPostACR;
use IPCV\API\Portal\Actions\ReceiveMoneyPay\GetSuccessfulReceiveMoneyPayTransaction;
use Symfony\Component\HttpFoundation\Response;

class PrintReceiveMoneyPostACR extends Controller
{
    public function __construct(
        private readonly GetSuccessfulReceiveMoneyPayTransaction $getSuccessfulReceiveMoneyPayTransaction,
        private readonly GenerateReceiveMoneyPostACR $generatePDF,
    ) {
    }

    public function __invoke($customerId, $mtcn): Response
    {
        $transaction = ($this->getSuccessfulReceiveMoneyPayTransaction)($customerId, $mtcn);

        return new Response(($this->generatePDF)($transaction));
    }
}
