<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\ReceiveMoney;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ReceiveMoneyPay\PerformReceiveMoneyPayRequest;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use IPCV\API\Portal\Http\Requests\ReceiveMoney\ReceiveMoneyPayFormRequest;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Symfony\Component\HttpFoundation\Response;

class ReceiveMoneyPay extends Controller
{
    public function __construct(
        private readonly ResolveUserFromUserId $resolveUserFromUserId,
        private readonly PerformReceiveMoneyPayRequest $performReceiveMoneyPayRequest,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     * @throws \Exception
     */
    public function __invoke(ReceiveMoneyPayFormRequest $request): Response
    {
        ($this->resolveUserFromUserId)($request);
        ($this->performReceiveMoneyPayRequest)($request);

        return new JsonResponse();
    }
}
