<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\BankInformation;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Repositories\BankInformationRepository;
use Symfony\Component\HttpFoundation\Response;

class ShowBankInformation extends Controller
{
    public function __construct(private readonly BankInformationRepository $repository)
    {
    }

    public function __invoke($id): Response
    {
        $bankInformation = $this->repository->find($id);

        if (null === $bankInformation) {
            return new Response(status: Response::HTTP_NOT_FOUND);
        }

        return new JsonResponse($bankInformation);
    }
}
