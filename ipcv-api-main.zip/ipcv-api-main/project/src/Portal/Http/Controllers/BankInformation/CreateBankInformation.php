<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\BankInformation;

use Illuminate\Http\JsonResponse;
use IPCV\API\Controller;
use IPCV\API\Portal\Http\Requests\BankInformation\CreateBankInformationRequest;
use IPCV\API\Portal\Repositories\BankInformationRepository;
use IPCV\API\Portal\Repositories\CustomerRepository;
use Symfony\Component\HttpFoundation\Response;

class CreateBankInformation extends Controller
{
    public function __construct(
        private readonly CustomerRepository $customerRepository,
        private readonly BankInformationRepository $bankInformationRepository
    ) {
    }

    public function __invoke(CreateBankInformationRequest $request, $customerId): Response
    {
        $customer = $this->customerRepository->find($customerId);

        if (null === $customer) {
            return new Response(status: Response::HTTP_NOT_FOUND);
        }

        $bankInformation = $this->bankInformationRepository->create($customer, $request->validated());

        return new JsonResponse(['id' => $bankInformation->id]);
    }
}
