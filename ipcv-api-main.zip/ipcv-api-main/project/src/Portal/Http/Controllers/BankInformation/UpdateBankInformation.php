<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Http\Controllers\BankInformation;

use IPCV\API\Controller;
use IPCV\API\Portal\Http\Requests\BankInformation\UpdateBankInformationRequest;
use IPCV\API\Portal\Repositories\BankInformationRepository;
use Symfony\Component\HttpFoundation\Response;

class UpdateBankInformation extends Controller
{
    public function __construct(private readonly BankInformationRepository $repository)
    {
    }

    public function __invoke(UpdateBankInformationRequest $request, $id): Response
    {
        $updateResult = $this->repository->update($id, $request->validated());

        if (0 === $updateResult) {
            return new Response(status: Response::HTTP_NOT_FOUND);
        }

        return new Response(status: Response::HTTP_OK);
    }
}
