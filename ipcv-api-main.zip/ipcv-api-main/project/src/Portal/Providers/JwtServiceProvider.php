<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Providers;

use DateTimeImmutable;
use Illuminate\Foundation\Application;
use Illuminate\Support\ServiceProvider;
use Lcobucci\Clock\SystemClock;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Decoder;
use Lcobucci\JWT\Encoding\ChainedFormatter;
use Lcobucci\JWT\Encoding\JoseEncoder;
use Lcobucci\JWT\Signer;
use Lcobucci\JWT\Signer\Key;
use Lcobucci\JWT\Signer\Key\InMemory;
use Lcobucci\JWT\Token\Builder;
use Lcobucci\JWT\Token\Parser;
use Lcobucci\JWT\Validation\Constraint\IssuedBy;
use Lcobucci\JWT\Validation\Constraint\PermittedFor;
use Lcobucci\JWT\Validation\Constraint\SignedWith;
use Lcobucci\JWT\Validation\Constraint\StrictValidAt;
use Ramsey\Uuid\Uuid;

class JwtServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(Signer::class, static fn () => new Signer\Hmac\Sha512());
        $this->app->singleton(Key::class, static fn () => InMemory::plainText(config('jwt.secret')));
        $this->app->singleton(Decoder::class, static fn () => new JoseEncoder());

        $this->app->bind(Configuration::class, function (Application $app) {
            $configuration = Configuration::forSymmetricSigner($app->get(Signer::class), $app->get(Key::class));

            $configuration->setBuilderFactory(static fn () => self::createBuilder());
            $configuration->setParser(new Parser(new JoseEncoder()));

            $constraints = [
                new IssuedBy(config('app.name')),
                new SignedWith($this->app->get(Signer::class), $this->app->get(Key::class)),
                new StrictValidAt(SystemClock::fromSystemTimezone()),
                new PermittedFor('ipcv-agent-portal-app-user')
            ];

            $configuration->setValidationConstraints(...$constraints);

            return $configuration;
        });
    }

    private static function createBuilder(): Builder
    {
        $builder = new Builder(new JoseEncoder(), ChainedFormatter::default());
        $builder
            ->issuedBy(config('app.name'))
            ->permittedFor('ipcv-agent-portal-app-user')
            ->issuedAt($now = new DateTimeImmutable())
            ->canOnlyBeUsedAfter($now)
            ->expiresAt($now->modify(sprintf("+%d seconds", config('jwt.expiry_in_seconds'))))
            ->identifiedBy((string)Uuid::uuid4())
        ;

        return $builder;
    }
}
