<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Providers;

use Illuminate\Contracts\Redis\Connection;
use Illuminate\Foundation\Application;
use Illuminate\Support\ServiceProvider;
use IPCV\API\Portal\Services\InMemoryTwoFactorKeyService;
use IPCV\API\Portal\Services\JwtTokenService;
use IPCV\API\Portal\Services\TokenService;
use IPCV\API\Portal\Services\TwoFactorKeyService;
use Lcobucci\JWT\Configuration;

class AuthServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(TokenService::class, function (Application $app) {
            return new JwtTokenService($app->get(Configuration::class));
        });

        $this->app->singleton(TwoFactorKeyService::class, function (Application $app) {
            return new InMemoryTwoFactorKeyService($app->get(Connection::class));
        });
    }
}
