<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use IPCV\API\Portal\Events\FailedReceiveMoneyPayEvent;
use IPCV\API\Portal\Events\FailedReceiveMoneySearchEvent;
use IPCV\API\Portal\Events\FailedSendMoneyStoreEvent;
use IPCV\API\Portal\Events\SuccessfulReceiveMoneyPayEvent;
use IPCV\API\Portal\Events\SuccessfulReceiveMoneySearchEvent;
use IPCV\API\Portal\Events\SuccessfulSendMoneyStoreEvent;
use IPCV\API\Portal\Events\SuccessfulSendMoneyValidationEvent;
use IPCV\API\Portal\Listeners\CreateFailedReceiveMoneyPayTransaction;
use IPCV\API\Portal\Listeners\CreateFailedReceiveMoneySearchTransaction;
use IPCV\API\Portal\Listeners\CreateSuccessfulReceiveMoneyPayTransaction;
use IPCV\API\Portal\Listeners\CreateSuccessfulReceiveMoneySearchTransaction;
use IPCV\API\Portal\Listeners\CreateVerifiedSendMoneyTransaction;
use IPCV\API\Portal\Listeners\UpdateSendMoneyTransactionToFailed;
use IPCV\API\Portal\Listeners\UpdateSendMoneyTransactionToSuccessful;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event to listener mappings for the application.
     *
     * @var array<class-string, array<class-string>>
     */
    protected $listen = [
        /**
         * Send Money Events
         */
        SuccessfulSendMoneyValidationEvent::class => [
            CreateVerifiedSendMoneyTransaction::class,
        ],
        SuccessfulSendMoneyStoreEvent::class => [
            UpdateSendMoneyTransactionToSuccessful::class,
        ],
        FailedSendMoneyStoreEvent::class => [
            UpdateSendMoneyTransactionToFailed::class,
        ],

        /**
         * Receive Money Search Events
         */
        SuccessfulReceiveMoneySearchEvent::class => [
            CreateSuccessfulReceiveMoneySearchTransaction::class,
        ],
        FailedReceiveMoneySearchEvent::class => [
            CreateFailedReceiveMoneySearchTransaction::class,
        ],

        /**
         * Receive Money Pay Events
         */
        SuccessfulReceiveMoneyPayEvent::class => [
            CreateSuccessfulReceiveMoneyPayTransaction::class,
        ],
        FailedReceiveMoneyPayEvent::class => [
            CreateFailedReceiveMoneyPayTransaction::class,
        ],
    ];

    /**
     * Register any events for your application.
     */
    public function boot(): void
    {
    }
}
