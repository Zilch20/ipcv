<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Providers;

use GuzzleHttp\Client;
use Illuminate\Support\ServiceProvider;
use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Models\CountryCurrency;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;
use IPCV\API\Portal\Models\SendMoneyTransaction;
use IPCV\API\Portal\Repositories\BankInformationRepository;
use IPCV\API\Portal\Repositories\BaseBankInformationRepository;
use IPCV\API\Portal\Repositories\BaseBranchRepository;
use IPCV\API\Portal\Repositories\BaseBranchUserRepository;
use IPCV\API\Portal\Repositories\BaseCountryCurrencyRepository;
use IPCV\API\Portal\Repositories\BaseCustomerRepository;
use IPCV\API\Portal\Repositories\BaseGovernmentIdentificationRepository;
use IPCV\API\Portal\Repositories\BaseReceiveMoneyPayTransactionRepository;
use IPCV\API\Portal\Repositories\BaseSendMoneyTransactionRepository;
use IPCV\API\Portal\Repositories\BranchRepository;
use IPCV\API\Portal\Repositories\BranchUserRepository;
use IPCV\API\Portal\Repositories\CountryCurrencyRepository;
use IPCV\API\Portal\Repositories\CustomerRepository;
use IPCV\API\Portal\Repositories\GovernmentIdentificationRepository;
use IPCV\API\Portal\Repositories\ReceiveMoneyTransactionRepository;
use IPCV\API\Portal\Repositories\SendMoneyTransactionRepository;
use IPCV\WesternUnion\Client as WesternUnionClient;
use IPCV\WesternUnion\DataAccessServer\HttpClient as DASHttpClient;
use IPCV\WesternUnion\HttpClient;

class WesternUnionServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->singleton(
            CustomerRepository::class,
            static fn () => new BaseCustomerRepository(new Customer())
        );

        $this->app->singleton(
            GovernmentIdentificationRepository::class,
            static fn () => new BaseGovernmentIdentificationRepository(new GovernmentIdentification())
        );

        $this->app->singleton(
            BankInformationRepository::class,
            static fn () => new BaseBankInformationRepository(new BankInformation())
        );

        $this->app->singleton(
            WesternUnionClient::class,
            static fn () => new HttpClient(new Client(config('western_union.client')))
        );

        $this->app->singleton(
            \IPCV\WesternUnion\DataAccessServer\Client::class,
            static fn () => new DASHttpClient(new Client(config('western_union.das_client')))
        );

        $this->app->singleton(
            SendMoneyTransactionRepository::class,
            static fn () => new BaseSendMoneyTransactionRepository(new SendMoneyTransaction())
        );

        $this->app->singleton(
            ReceiveMoneyTransactionRepository::class,
            static fn () => new BaseReceiveMoneyPayTransactionRepository(new ReceiveMoneyPayTransaction())
        );

        $this->app->singleton(
            BranchUserRepository::class,
            static fn () => new BaseBranchUserRepository(new BranchUser())
        );

        $this->app->singleton(
            BranchRepository::class,
            static fn () => new BaseBranchRepository(new Branch())
        );

        $this->app->singleton(
            CountryCurrencyRepository::class,
            static fn () => new BaseCountryCurrencyRepository(new CountryCurrency())
        );
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
    }
}
