<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Providers;

use Illuminate\Support\ServiceProvider;
use IPCV\API\Portal\Actions\GenerateReceiveMoneyPostACR;
use IPCV\API\Portal\Actions\GenerateReceiveMoneyPreACR;
use IPCV\API\Portal\Actions\GenerateSendMoneyPostACR;
use IPCV\API\Portal\Actions\GenerateSendMoneyPreACR;
use setasign\Fpdi\Fpdi;

class TransactionToPDFServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(GenerateSendMoneyPreACR::class, function () {

            $PDF = new Fpdi();
            $PDF->AddPage();
            $PDF->setSourceFile(\resource_path('pdf/send_money_pre.pdf'));
            $page = $PDF->importPage(pageNumber: 1);
            $PDF->useTemplate($page);
            $PDF->SetFont(family: 'Helvetica', style: 'B', size: 8);
            $PDF->SetTextColor(0, 0, 0);

            return new GenerateSendMoneyPreACR($PDF);
        });

        $this->app->singleton(GenerateSendMoneyPostACR::class, function () {
            $PDF = new Fpdi();

            $PDF->AddPage();
            $PDF->setSourceFile(\resource_path('pdf/send_money_post.pdf'));
            $page = $PDF->importPage(pageNumber: 1);
            $PDF->useTemplate($page);
            $PDF->SetFont(family: 'Helvetica', style: 'B', size: 8);
            $PDF->SetTextColor(0, 0, 0);

            return new GenerateSendMoneyPostACR($PDF);
        });

        $this->app->singleton(GenerateReceiveMoneyPreACR::class, function () {
            $PDF = new Fpdi();

            $PDF->AddPage();
            $PDF->setSourceFile(\resource_path('pdf/receive_money_pre.pdf'));
            $page = $PDF->importPage(pageNumber: 1);
            $PDF->useTemplate($page);
            $PDF->SetFont(family: 'Helvetica', style: 'B', size: 8);
            $PDF->SetTextColor(0, 0, 0);

            return new GenerateReceiveMoneyPreACR($PDF);
        });

        $this->app->singleton(GenerateReceiveMoneyPostACR::class, function () {
            $PDF = new Fpdi();

            $PDF->AddPage();
            $PDF->setSourceFile(\resource_path('pdf/receive_money_post.pdf'));
            $page = $PDF->importPage(pageNumber: 1);
            $PDF->useTemplate($page);
            $PDF->SetFont(family: 'Helvetica', style: 'B', size: 8);
            $PDF->SetTextColor(0, 0, 0);

            return new GenerateReceiveMoneyPostACR($PDF);
        });
    }
}
