<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\BranchUserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Laravel\Fortify\TwoFactorAuthenticatable;
use Ramsey\Uuid\Uuid;

class BranchUser extends Authenticatable
{
    use HasFactory;
    use TwoFactorAuthenticatable;

    /**
     * @var bool
     */
    public $incrementing = false;

    /**
     * @var array<int, string>
     */
    protected $fillable = [
        'first_name',
        'middle_name',
        'last_name',
        'email',
        'is_active',
        'password',
    ];

    /**
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public static function newFactory(): BranchUserFactory
    {
        return new BranchUserFactory();
    }

    protected static function boot(): void
    {
        parent::boot();

        static::creating(self::generateUUID());
    }

    private static function generateUUID(): callable
    {
        return static fn (BranchUser $user): string => $user->id = (string)Uuid::uuid4();
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }
}
