<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\CustomerFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Customer extends Model
{
    use HasFactory;
    use UUID4AsPrimaryKey;

    /**
     * @var string[]
     */
    protected $fillable = [
        'first_name',
        'middle_name',
        'last_name',

        'address_line_1',
        'address_line_2',
        'city',
        'state',
        'postal_code',
        'country',
        'country_code',
        'currency_code',

        'email',
        'date_of_birth',
        'nationality',
        'occupation',
        'employment_position_level',
        'gender',
        'source_of_funds',
        'country_of_birth',
        'phone_country_code',
        'phone_number',
        'my_wu_number',
    ];

    /**
     * @var string[]
     */
    protected $casts = [
        'date_of_birth' => 'immutable_datetime:Y-m-d',
    ];

    public static function newFactory(): CustomerFactory
    {
        return new CustomerFactory();
    }

    public function fullName(): string
    {
        if (!$this->middle_name) {
            return \sprintf("%s %s", $this->first_name, $this->last_name);
        }

        return \sprintf("%s %s %s", $this->first_name, $this->middle_name, $this->last_name);
    }

    public function governmentIdentifications(): HasMany
    {
        return $this->hasMany(GovernmentIdentification::class);
    }

    public function bankInformation(): HasMany
    {
        return $this->hasMany(BankInformation::class);
    }

    public function sendMoneyTransactions(): HasMany
    {
        return $this->hasMany(SendMoneyTransaction::class);
    }
}
