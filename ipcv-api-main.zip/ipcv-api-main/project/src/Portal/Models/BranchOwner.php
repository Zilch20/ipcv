<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\BranchOwnerFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BranchOwner extends Model
{
    use HasFactory;
    use UUID4AsPrimaryKey;

    protected $fillable = [
        'name'
    ];

    public static function newFactory(): BranchOwnerFactory
    {
        return new BranchOwnerFactory();
    }

    public function branches(): HasMany
    {
        return $this->hasMany(Branch::class);
    }
}
