<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Illuminate\Database\Eloquent\Model;

class CountryInformation extends Model
{
    protected $fillable = [
        'country_code',
        'currency_code',
        'information',
        'created_at',
    ];

    protected $casts = [
        'information' => 'array'
    ];

    public function isUpdatedToday(): bool
    {
        return $this->updated_at->isToday();
    }
}
