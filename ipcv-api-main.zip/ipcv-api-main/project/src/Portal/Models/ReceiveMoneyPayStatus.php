<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

enum ReceiveMoneyPayStatus: int
{
    case SUCCESSFUL = 1;
    case FAILED = 0;
}
