<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

enum SendMoneyTransactionStatus: int
{
    case SUCCESSFUL = 2;
    case VERIFIED = 1;
    case FAILED = 0;
}
