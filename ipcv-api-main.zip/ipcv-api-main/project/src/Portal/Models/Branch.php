<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\BranchFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Branch extends Model
{
    use HasFactory;
    use UUID4AsPrimaryKey;

    /**
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'description',
        'address',
        'contact_number',
        'terminal_id',
        'ftid',
        'naid',
        'is_active',
    ];

    public static function newFactory(): BranchFactory
    {
        return new BranchFactory();
    }

    public function branchOwner(): BelongsTo
    {
        return $this->belongsTo(BranchOwner::class);
    }

    public function branchUsers(): HasMany
    {
        return $this->hasMany(BranchUser::class);
    }

    public function sendMoneyTransactions(): HasMany
    {
        return $this->hasMany(SendMoneyTransaction::class);
    }
}
