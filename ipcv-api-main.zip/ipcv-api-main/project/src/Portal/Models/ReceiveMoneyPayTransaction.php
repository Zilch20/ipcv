<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\ReceiveMoneyPayTransactionFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ReceiveMoneyPayTransaction extends Model
{
    use HasFactory;
    use UUID4AsPrimaryKey;

    protected $casts = [
        'status' => ReceiveMoneyPayStatus::class,
    ];

    protected $fillable = [
        'mtcn',
        'new_mtcn',
        'new_points_earned',
        'total_points_earned',
        'money_transfer_key',
        'gross_total_amount',
        'pay_amount',
        'principal_amount',
        'charges',
        'tolls',
        'exchange_rate',
        'originating_currency_code',
        'originating_country_code',
        'destination_country_code',
        'destination_currency_code',
        'transaction_type',
        'purpose',
        'source_of_funds',
        'relationship_to_sender',
        'branch_id',
        'customer_id',
        'government_identification_id',
        'xml_request',
        'wu_response_headers',
        'wu_response_body',
        'status',
        'timestamp',
    ];

    public function payAmount(): string
    {
        return \sprintf(
            '%s %s',
            $this->destination_currency_code,
            \sprintf("%.2f", $this->pay_amount / 100)
        );
    }

    public function exchangeRate(): string
    {
        return sprintf(
            '%s to %s: %s',
            $this->originating_currency_code,
            $this->destination_currency_code,
            $this->exchange_rate
        );
    }

    public static function newFactory(): ReceiveMoneyPayTransactionFactory
    {
        return new ReceiveMoneyPayTransactionFactory();
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function governmentIdentification(): BelongsTo
    {
        return $this->belongsTo(GovernmentIdentification::class);
    }
}
