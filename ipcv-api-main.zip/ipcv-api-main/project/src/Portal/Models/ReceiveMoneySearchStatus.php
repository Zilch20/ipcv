<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

enum ReceiveMoneySearchStatus: int
{
    case OK = 1;
    case FAILED = 0;
}
