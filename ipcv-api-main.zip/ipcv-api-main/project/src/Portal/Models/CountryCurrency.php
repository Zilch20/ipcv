<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Illuminate\Database\Eloquent\Model;

class CountryCurrency extends Model
{
    protected $fillable = [
        'country_name',
        'iso_country_number_code',
        'iso_country_code',
        'currency_code',
        'iso_currency_number_code',
        'currency_name',
    ];
}
