<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\BankInformationFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BankInformation extends Model
{
    use HasFactory;
    use UUID4AsPrimaryKey;

    /**
     * @var string[]
     */
    protected $fillable = [
        'bank_name',
        'account_number',
        'account_type',
        'routing_number',
        'branch_number',
        'bank_location',
        'bic',
        'bank_code',
        'sort_code',
        'account_prefix',
        'account_suffix',
        'bank_account_holder',
    ];

    public static function newFactory(): BankInformationFactory
    {
        return new BankInformationFactory();
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }
}
