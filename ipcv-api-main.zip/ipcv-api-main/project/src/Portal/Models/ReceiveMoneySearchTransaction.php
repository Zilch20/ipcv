<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;

class ReceiveMoneySearchTransaction extends Model
{
    /**
     * @var string[]
     */
    protected $casts = [
        'status' => ReceiveMoneySearchStatus::class,
    ];

    /**
     * @var string[]
     */
    protected $fillable = [
        'status',
        'timestamp',
        'mtcn',
        'new_mtcn',
        'money_transfer_key',
        'sender_first_name',
        'sender_middle_name',
        'sender_last_name',
        'messages',
        'xml_request',
        'wu_response_headers',
        'wu_response_body',
        'branch_id',
    ];

    public function messages(): Attribute
    {
        return Attribute::make(
            get: static fn ($value): array => $value
                ? \json_decode($value, true, 512, JSON_THROW_ON_ERROR)
                : [],
            set: static fn ($value): string => \json_encode($value, JSON_THROW_ON_ERROR)
        );
    }

    public function senderFullName(): string
    {
        if (!$this->sender_middle_name) {
            return \sprintf('%s %s', $this->sender_first_name, $this->sender_last_name);
        }

        return \sprintf(
            '%s %s %s',
            $this->sender_first_name,
            $this->sender_middle_name,
            $this->sender_last_name
        );
    }
}
