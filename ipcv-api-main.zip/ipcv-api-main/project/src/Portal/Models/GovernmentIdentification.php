<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\GovernmentIdentificationFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class GovernmentIdentification extends Model
{
    use HasFactory;
    use UUID4AsPrimaryKey;

    /**
     * @var array<int, string>
     */
    protected $fillable = [
        'type',
        'number',
        'country_issued',
        'issue_date',
        'expiry_date',
        'url'
    ];

    protected $casts = [
        'issue_date' => 'immutable_datetime:Y-m-d',
        'expiry_date' => 'immutable_datetime:Y-m-d',
    ];

    /**
     * @var array<string, string>
     */
    private static array $typeMap = [
        'A' => 'Passport',
        'C' => "Driver's license",
        '5' => 'PRC ID',
        '7' => 'NBI Clearance',
        'D' => 'Police Clearance',
        '1' => 'Postal ID',
        'M' => "Voter's ID",
        '3' => 'Barangay Certification',
        'E' => 'Government Service Insurance System (GSIS) e-Card',
        'N' => 'Social Security System (SSS) Card',
        'B' => 'Government issued national identification card',
        'W' => 'Senior Citizen ID',
        'V' => 'Overseas Workers Welfare Administration (OWWA) ID',
        '6' => 'OFW ID',
        'R' => "Seaman's Book",
        '8' => 'Alien/Immigrant Certificate of Registration',
        'H' => 'PWD/NCWDP ID',
        '9' => 'DSWD Certificate',
        'U' => 'IBP ID',
        'X' => 'Student ID',
        '2' => 'Unified Multi Purpose ID (UMID)',
        '4' => 'Taxpayer’s ID (TIN)',
        'I' => 'Other government issued IDs',
    ];

    public function type(): string
    {
        return self::$typeMap[$this->type] ?? $this->type;
    }

    public static function newFactory(): GovernmentIdentificationFactory
    {
        return new GovernmentIdentificationFactory();
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function sendMoneyTransactions(): HasMany
    {
        return $this->hasMany(SendMoneyTransaction::class);
    }
}
