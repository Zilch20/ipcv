<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Database\Factories\SendMoneyTransactionFactory;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SendMoneyTransaction extends Model
{
    use HasFactory;
    use UUID4AsPrimaryKey;

    protected $casts = [
        'status' => SendMoneyTransactionStatus::class,
    ];

    protected $fillable = [
        'mtcn',
        'new_mtcn',
        'new_points_earned',
        'total_points_earned',
        'originators_principal_amount',
        'destination_principal_amount',
        'gross_total_amount',
        'exchange_rate',
        'charges',
        'message_charge',
        'originating_currency_code',
        'originating_country_code',
        'destination_country_code',
        'destination_currency_code',
        'transaction_type',
        'purpose',
        'source_of_funds',
        'relationship_to_receiver',
        'compliance_data_buffer',
        'branch_id',
        'customer_id',
        'government_identification_id',
        'receiver_first_name',
        'receiver_middle_name',
        'receiver_last_name',
        'xml_request',
        'wu_response_headers',
        'wu_response_body',
        'messages',
        'status',
    ];

    public function messages(): Attribute
    {
        return Attribute::make(
            get: static fn ($value): array => $value
                ? \json_decode($value, true, 512, JSON_THROW_ON_ERROR)
                : [],
            set: static fn ($value): string => \json_encode($value, JSON_THROW_ON_ERROR)
        );
    }

    public function amountSent(): string
    {
        return \sprintf(
            '%s %s',
            $this->originating_currency_code,
            \sprintf("%.2f", $this->originators_principal_amount / 100)
        );
    }

    public function deliveryCharge(): string
    {
        return \sprintf('%s %s', $this->originating_currency_code, \sprintf("%.2f", $this->charges / 100));
    }

    public function messageCharge(): string
    {
        return \sprintf('%s %s', $this->originating_currency_code, \sprintf("%.2f", $this->message_charge / 100));
    }

    public function exchangeRate(): string
    {
        return \sprintf(
            '%s to %s: %s',
            $this->originating_currency_code,
            $this->destination_currency_code,
            $this->exchange_rate
        );
    }

    public function receiverFullName(): string
    {
        if (!$this->receiver_middle_name) {
            return \sprintf('%s %s', $this->receiver_first_name, $this->receiver_last_name);
        }

        return \sprintf(
            '%s %s %s',
            $this->receiver_first_name,
            $this->receiver_middle_name,
            $this->receiver_last_name
        );
    }

    public function payoutAmount(): string
    {
        return \sprintf(
            '%s %s',
            $this->destination_currency_code,
            \sprintf("%.2f", $this->destination_principal_amount / 100)
        );
    }

    public function grossTotalAmount(): string
    {
        return \sprintf(
            '%s %s',
            $this->destination_currency_code,
            \sprintf("%.2f", $this->gross_total_amount / 100)
        );
    }

    public static function newFactory(): SendMoneyTransactionFactory
    {
        return new SendMoneyTransactionFactory();
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function governmentIdentification(): BelongsTo
    {
        return $this->belongsTo(GovernmentIdentification::class);
    }
}
