<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Models;

use Illuminate\Database\Eloquent\Model;
use Ramsey\Uuid\Uuid;

trait UUID4AsPrimaryKey
{
    public static function booted(): void
    {
        static::creating(static fn (Model $model) => $model->setAttribute($model->getKeyName(), (string)Uuid::uuid4()));
    }

    public function getIncrementing(): bool
    {
        return false;
    }

    public function getKeyType(): string
    {
        return 'string';
    }
}
