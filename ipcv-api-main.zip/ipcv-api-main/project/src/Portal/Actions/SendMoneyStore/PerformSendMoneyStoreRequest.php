<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\SendMoneyStore;

use Exception;
use GuzzleHttp\Exception\ServerException;
use Illuminate\Contracts\Events\Dispatcher;
use IPCV\API\Portal\Actions\HandleWesternUnionErrorResponse;
use IPCV\API\Portal\Events\FailedSendMoneyStoreEvent;
use IPCV\API\Portal\Events\SuccessfulSendMoneyStoreEvent;
use IPCV\API\Portal\Exceptions\CustomerNotFound;
use IPCV\API\Portal\Exceptions\GovernmentIdentificationNotFound;
use IPCV\API\Portal\Factories\SendMoney\SendMoneyStoreRequestFactory;
use IPCV\API\Portal\Http\Requests\SendMoneyRequest;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Repositories\CustomerRepository;
use IPCV\WesternUnion\Client;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Psr\Http\Message\ResponseInterface;

class PerformSendMoneyStoreRequest
{
    public function __construct(
        private readonly CustomerRepository $customerRepository,
        private readonly Client $client,
        private readonly HandleWesternUnionErrorResponse $handleWesternUnionErrorResponse,
        private readonly Dispatcher $eventDispatcher,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     * @throws Exception
     */
    public function __invoke(
        SendMoneyRequest $request,
        array $sendMoneyValidationResponse,
    ): ?ResponseInterface {
        $customer = $this->customerRepository->find($request->input('customer_id'));

        if (null === $customer) {
            throw new CustomerNotFound(404, 'Customer not found.');
        }

        $governmentId = $customer
            ->governmentIdentifications()
            ->find($request->input('government_identification_id'))
        ;

        if (null === $governmentId) {
            throw new GovernmentIdentificationNotFound(404, 'Government Identification not found.');
        }

        $branch = $this->getBranchOfLoggedInUser($request);
        $factory = new SendMoneyStoreRequestFactory(
            $request,
            $branch,
            $customer,
            config('western_union.identifier')
        );

        $sendMoneyRequest = $factory
            ->setMtcn($sendMoneyValidationResponse['mtcn'])
            ->setNewMtcn($sendMoneyValidationResponse['new_mtcn'])
            ->setComplianceDataBuffer($sendMoneyValidationResponse['compliance_data_buffer'])
            ->build()
        ;

        try {
            $response = $this->client->send($sendMoneyRequest);
        } catch (ServerException $e) {
            $this->eventDispatcher->dispatch(
                new FailedSendMoneyStoreEvent($governmentId, $branch, $sendMoneyRequest, $e->getResponse())
            );
            return ($this->handleWesternUnionErrorResponse)($e->getResponse()->getBody()->getContents());
        }

        $this->eventDispatcher->dispatch(
            new SuccessfulSendMoneyStoreEvent($governmentId, $branch, $sendMoneyRequest, $response)
        );

        return $response;
    }

    private function getBranchOfLoggedInUser(SendMoneyRequest $request): Branch
    {
        return $request->user()->branch()->first();
    }
}
