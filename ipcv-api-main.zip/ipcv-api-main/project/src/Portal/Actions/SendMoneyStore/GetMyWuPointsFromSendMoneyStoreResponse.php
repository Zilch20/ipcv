<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\SendMoneyStore;

use function json_decode;
use function json_encode;
use function preg_replace;
use function simplexml_load_string;

class GetMyWuPointsFromSendMoneyStoreResponse
{
    private function __construct(
        public readonly string $totalMyWuPointsEarned,
        public readonly string $newMyWuPointsEarned,
    ) {
    }

    /**
     * @throws \JsonException
     */
    public static function create(string $response): self
    {
        $xml = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $response);
        $xml = simplexml_load_string($xml);
        $json = json_encode($xml, JSON_THROW_ON_ERROR);
        $responseAsArray = json_decode($json, associative: true);

        return new GetMyWuPointsFromSendMoneyStoreResponse(
            $responseAsArray['soapenvBody']['xrsisend-money-store-reply']['sender']['total_points_earned'] ?? '',
            $responseAsArray['soapenvBody']['xrsisend-money-store-reply']['new_points_earned'] ?? ''
        );
    }
}
