<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\SendMoneyStore;

use IPCV\API\Portal\Exceptions\TransactionNotFound;
use IPCV\API\Portal\Models\SendMoneyTransaction;
use IPCV\API\Portal\Models\SendMoneyTransactionStatus;

class GetSuccessfulSendMoneyTransactionByCustomerIdAndMtcn
{
    /**
     * @throws TransactionNotFound
     */
    public function __invoke(string $customerId, string $mtcn): SendMoneyTransaction
    {
        /** @var ?SendMoneyTransaction $transaction */
        $transaction = SendMoneyTransaction::query()
            ->where('customer_id', '=', $customerId)
            ->where('mtcn', '=', $mtcn)
            ->where('status', '=', SendMoneyTransactionStatus::SUCCESSFUL)
            ->first()
        ;

        if ($transaction === null) {
            throw new TransactionNotFound(404, 'Transaction not found.');
        }

        return $transaction;
    }
}
