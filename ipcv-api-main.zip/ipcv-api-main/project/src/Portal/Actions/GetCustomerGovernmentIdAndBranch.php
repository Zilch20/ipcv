<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use Illuminate\Http\Request;
use IPCV\API\Portal\Exceptions\CustomerNotFound;
use IPCV\API\Portal\Exceptions\GovernmentIdentificationNotFound;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Repositories\CustomerRepository;

class GetCustomerGovernmentIdAndBranch
{
    private Branch $branch;

    private Customer $customer;

    private GovernmentIdentification $governmentIdentification;

    public function __construct(
        private readonly CustomerRepository $customerRepository,
    ) {
    }

    public function __invoke(Request $request): void
    {
        $customer = $this->customerRepository->find($request->input('customer_id'));

        if (null === $customer) {
            throw new CustomerNotFound(404, 'Customer not found.');
        }

        $this->customer = $customer;

        $governmentId = $customer
            ->governmentIdentifications()
            ->find($request->input('government_identification_id'))
        ;

        if (null === $governmentId) {
            throw new GovernmentIdentificationNotFound(404, 'Government Identification not found.');
        }

        $this->governmentIdentification = $governmentId;
        $this->branch = $request->user()->branch()->first();
    }

    public function branch(): Branch
    {
        return $this->branch;
    }

    public function customer(): Customer
    {
        return $this->customer;
    }

    public function governmentIdentification(): GovernmentIdentification
    {
        return $this->governmentIdentification;
    }
}
