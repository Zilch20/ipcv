<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use Exception;
use IPCV\API\Portal\Exceptions\WesternUnionGatewayException;
use SimpleXMLElement;

class HandleWesternUnionErrorResponse
{
    /**
     * @throws Exception
     */
    public function __invoke(string $responseBody): void
    {
        $xml = new SimpleXMLElement($responseBody);
        $soapenv = $xml->children('soapenv', true);
        $errorMessage = (string)$soapenv
            ?->Body
            ?->Fault
            ?->children()
            ?->detail
            ?->children('xrsi', true)
            ?->{'error-reply'}
            ?->children()
            ?->error
        ;

        if ('' === $errorMessage) {
            throw new WesternUnionGatewayException(
                500,
                'An unknown error was returned from Western Union service. Check the logs for details.'
            );
        }

        throw new WesternUnionGatewayException(
            400,
            \sprintf("Western Union Error Response: %s", $errorMessage)
        );
    }
}
