<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\TwoFactor;

use Illuminate\Contracts\Encryption\Encrypter;
use IPCV\API\Portal\Exceptions\InvalidTwoFactorCode;
use IPCV\API\Portal\Models\BranchUser;
use Laravel\Fortify\Contracts\TwoFactorAuthenticationProvider;

class TwoFactorChallenge
{
    public function __construct(
        private readonly TwoFactorAuthenticationProvider $twoFactorAuthenticationProvider,
        private readonly Encrypter $encrypter,
    ) {
    }

    public function __invoke(BranchUser $user, string $code): void
    {
        $secret = $this->encrypter->decrypt($user->two_factor_secret);

        if (false === $this->twoFactorAuthenticationProvider->verify($secret, $code)) {
            throw new InvalidTwoFactorCode(422, __('errors.auth.invalid_two_factor_code'));
        }
    }
}
