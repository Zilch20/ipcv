<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\TwoFactor;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use IPCV\API\Controller;
use IPCV\API\Portal\Actions\ResolveUserFromUserId;
use Symfony\Component\HttpFoundation\Response;

class TwoFactorQrCodeController extends Controller
{
    public function __construct(private readonly ResolveUserFromUserId $resolveUserFromUserId)
    {
    }

    public function json(Request $request): Response
    {
        ($this->resolveUserFromUserId)($request);

        if (\is_null($request->user()->two_factor_secret)) {
            return new JsonResponse([]);
        }

        return new JsonResponse([
            'svg' => $request->user()->twoFactorQrCodeSvg(),
        ]);
    }

    public function html(Request $request): View
    {
        ($this->resolveUserFromUserId)($request);

        if (\is_null($request->user()->two_factor_secret)) {
            return \view('twofactorqr', ['svg' => '']);
        }

        return \view('twofactorqr', ['svg' => $request->user()->twoFactorQrCodeSvg()]);
    }
}
