<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\TwoFactor;

use Illuminate\Contracts\Encryption\Encrypter;
use IPCV\API\Portal\Models\BranchUser;
use Laravel\Fortify\RecoveryCode;

class GenerateTwoFactorRecoveryCodes
{
    public function __construct(private readonly Encrypter $encrypter)
    {
    }

    public function __invoke(BranchUser $user): void
    {
        $user->forceFill([
            'two_factor_recovery_codes' => $this->encrypter->encrypt(
                \json_encode(self::generateTwoFactorRecoveryCodes(), JSON_THROW_ON_ERROR)
            ),
        ])->save();
    }

    private static function generateTwoFactorRecoveryCodes(): array
    {
        for ($i = 0; $i <= 8; $i++) {
            $recoveryCodes[] = RecoveryCode::generate();
        }

        return $recoveryCodes;
    }
}
