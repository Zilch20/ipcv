<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\TwoFactor;

use IPCV\API\Portal\Models\BranchUser;
use Laravel\Fortify\Fortify;

class DisableTwoFactor
{
    public function __invoke(BranchUser $user): void
    {
        if (
            ! is_null($user->two_factor_secret) ||
            ! is_null($user->two_factor_recovery_codes) ||
            ! is_null($user->two_factor_confirmed_at)
        ) {
            $user->forceFill([
                    'two_factor_secret' => null,
                    'two_factor_recovery_codes' => null,
                ] + (Fortify::confirmsTwoFactorAuthentication() ? [
                    'two_factor_confirmed_at' => null,
                ] : []))
                ->save();
        }
    }
}
