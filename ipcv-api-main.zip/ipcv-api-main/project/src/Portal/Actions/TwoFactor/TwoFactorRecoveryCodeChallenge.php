<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\TwoFactor;

use IPCV\API\Portal\Exceptions\InvalidTwoFactorRecoveryCode;
use IPCV\API\Portal\Models\BranchUser;

class TwoFactorRecoveryCodeChallenge
{
    public function __invoke(BranchUser $user, string $inputRecoveryCode): void
    {
        $matchingRecoveryCode = null;

        foreach ($user->recoveryCodes() as $recoveryCode) {
            if (\hash_equals($recoveryCode, $inputRecoveryCode)) {
                $matchingRecoveryCode = $recoveryCode;
            }
        }

        if (null === $matchingRecoveryCode) {
            throw new InvalidTwoFactorRecoveryCode(422, __('errors.auth.invalid_two_factor_code'));
        }

        $user->replaceRecoveryCode($matchingRecoveryCode);
    }
}
