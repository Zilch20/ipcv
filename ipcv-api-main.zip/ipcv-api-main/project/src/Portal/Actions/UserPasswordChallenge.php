<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use Illuminate\Contracts\Hashing\Hasher;
use IPCV\API\Portal\Exceptions\InvalidPassword;
use IPCV\API\Portal\Models\BranchUser;

class UserPasswordChallenge
{
    public function __construct(private readonly Hasher $hasher)
    {
    }

    public function __invoke(BranchUser $user, string $password): void
    {
        if (false === $this->hasher->check($password, $user->password)) {
            throw new InvalidPassword(422, __('errors.invalid_password'));
        }
    }
}
