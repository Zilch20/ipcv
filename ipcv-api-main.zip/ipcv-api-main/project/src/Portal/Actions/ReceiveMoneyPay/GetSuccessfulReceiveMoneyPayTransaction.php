<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\ReceiveMoneyPay;

use IPCV\API\Portal\Exceptions\TransactionNotFound;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;

class GetSuccessfulReceiveMoneyPayTransaction
{
    public function __invoke(string $customerId, string $mtcn): ReceiveMoneyPayTransaction
    {
        /** @var ?ReceiveMoneyPayTransaction $transaction */
        $transaction = ReceiveMoneyPayTransaction::query()
            ->where('customer_id', '=', $customerId)
            ->where('mtcn', '=', $mtcn)
            ->where('status', '=', ReceiveMoneyPayTransaction::SUCCESSFUL)
            ->first()
        ;

        if ($transaction === null) {
            throw new TransactionNotFound(404, 'Transaction not found.');
        }

        return $transaction;
    }
}
