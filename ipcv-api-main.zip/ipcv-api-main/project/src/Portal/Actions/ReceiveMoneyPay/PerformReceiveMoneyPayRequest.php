<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\ReceiveMoneyPay;

use GuzzleHttp\Exception\ServerException;
use Illuminate\Contracts\Events\Dispatcher;
use IPCV\API\Portal\Actions\GetCustomerGovernmentIdAndBranch;
use IPCV\API\Portal\Actions\HandleWesternUnionErrorResponse;
use IPCV\API\Portal\Events\FailedReceiveMoneyPayEvent;
use IPCV\API\Portal\Events\SuccessfulReceiveMoneyPayEvent;
use IPCV\API\Portal\Factories\ComplianceDetailsFactory;
use IPCV\API\Portal\Factories\ForeignRemoteSystemFactory;
use IPCV\API\Portal\Factories\ReceiveMoney\ReceiveMoneyPayFactory;
use IPCV\API\Portal\Factories\ReceiveMoneyReceiverFactory;
use IPCV\API\Portal\Http\Requests\ReceiveMoney\ReceiveMoneyPayFormRequest;
use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Repositories\BankInformationRepository;
use IPCV\WesternUnion\Client;
use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\ReceiveMoneyReceiver;
use Psr\Http\Message\ResponseInterface;

class PerformReceiveMoneyPayRequest
{
    public function __construct(
        private readonly GetCustomerGovernmentIdAndBranch $getCustomerGovernmentIdAndBranch,
        private readonly BankInformationRepository $bankInformationRepository,
        private readonly Client $client,
        private readonly HandleWesternUnionErrorResponse $handleWesternUnionErrorResponse,
        private readonly Dispatcher $eventDispatcher,
    ) {
    }

    /**
     * @return ResponseInterface
     * @throws InvalidArgumentException
     * @throws \Exception
     */
    public function __invoke(ReceiveMoneyPayFormRequest $request): ResponseInterface
    {
        ($this->getCustomerGovernmentIdAndBranch)($request);

        $bankInformation = $this->bankInformationRepository->find($request->input('bank_information_id', ''));
        $governmentId = $this->getCustomerGovernmentIdAndBranch->governmentIdentification();

        $complianceDetails = $this->createComplianceDetails(
            $request->input('transaction_reason'),
            $request->input('relationship_to_sender'),
            $governmentId
        );

        $branch = $request->user()->branch;

        $receiver = $this->createReceiver($complianceDetails, $bankInformation);
        $foreignRemoteSystem = $this->createForeignRemoteSystem();

        $receiveMoneyPay = ReceiveMoneyPayFactory::create($request, $receiver, $foreignRemoteSystem);

        try {
            $response =  $this->client->send($receiveMoneyPay);
        } catch (ServerException $e) {
            $error = $e->getResponse()->getBody()->getContents();
            $this->eventDispatcher->dispatch(
                new FailedReceiveMoneyPayEvent($governmentId, $branch, $receiveMoneyPay, $e->getResponse())
            );
            return ($this->handleWesternUnionErrorResponse)($error);
        }

        $this->eventDispatcher->dispatch(
            new SuccessfulReceiveMoneyPayEvent($governmentId, $branch, $receiveMoneyPay, $response)
        );

        return $response;
    }

    private function createComplianceDetails(
        string $transactionReason,
        string $relationshipToReceiverSender,
        GovernmentIdentification $governmentId
    ): ComplianceDetails {
        $customer = $this->getCustomerGovernmentIdAndBranch->customer();

        return ComplianceDetailsFactory::create(
            $customer,
            $governmentId,
            $transactionReason,
            $relationshipToReceiverSender
        );
    }

    private function createReceiver(
        ComplianceDetails $complianceDetails,
        BankInformation $bankInformation = null
    ): ReceiveMoneyReceiver {
        $customer = $this->getCustomerGovernmentIdAndBranch->customer();

        return ReceiveMoneyReceiverFactory::create($customer, $complianceDetails, $bankInformation);
    }

    public function createForeignRemoteSystem(): ForeignRemoteSystem
    {
        return ForeignRemoteSystemFactory::create(
            $this->getCustomerGovernmentIdAndBranch->branch(),
            config('western_union.identifier')
        );
    }
}
