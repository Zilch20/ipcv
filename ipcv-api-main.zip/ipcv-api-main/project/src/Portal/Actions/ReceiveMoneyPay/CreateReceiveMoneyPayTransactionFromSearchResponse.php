<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\ReceiveMoneyPay;

use IPCV\API\Portal\Repositories\ReceiveMoneyTransactionRepository;

class CreateReceiveMoneyPayTransactionFromSearchResponse
{
    public function __construct(private readonly ReceiveMoneyTransactionRepository $repository)
    {
    }

    public function __invoke(array $responseArray): void
    {
        $this->repository->create([
            'mtcn' => $responseArray['mtcn'],
            'new_mtcn' => $responseArray['new_mtcn'],
            'sender_first_name' => $responseArray['sender']['first_name'] ?? '',
            'sender_middle_name' => $responseArray['sender']['middle_name'] ?? '',
            'sender_last_name' => $responseArray['sender']['last_name'] ?? '',
            'messages' => $responseArray['delivery_services']['message'] ?? []
        ]);
    }
}
