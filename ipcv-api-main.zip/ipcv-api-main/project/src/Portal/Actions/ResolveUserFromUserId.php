<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use Illuminate\Http\Request;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Repositories\BranchUserRepository;

class ResolveUserFromUserId
{
    public function __construct(private readonly BranchUserRepository $repository)
    {
    }

    public function __invoke(Request $request): void
    {
        $user = $this->repository->find($request->user_id);

        if (null === $user) {
            return;
        }

        $request->setUserResolver(static fn (): BranchUser => $user);
    }
}
