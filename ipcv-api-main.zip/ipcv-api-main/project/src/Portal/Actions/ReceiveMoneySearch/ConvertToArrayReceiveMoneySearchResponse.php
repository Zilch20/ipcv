<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\ReceiveMoneySearch;

use Psr\Http\Message\ResponseInterface;

class ConvertToArrayReceiveMoneySearchResponse
{
    /**
     * @throws \Exception
     */
    public function __invoke(ResponseInterface $response): array
    {
        $xml = new \SimpleXMLElement((string)$response->getBody());
        $soapenv = $xml->children('soapenv', true);
        $body = $soapenv
            ?->Body
            ?->children('xrsi', true)
            ?->{'receive-money-search-reply'}
            ?->children()
            ?->payment_transactions
            ?->children()
            ?->payment_transaction
        ;

        $deliveryServices = $soapenv
            ?->Body
            ?->children('xrsi', true)
            ?->{'receive-money-search-reply'}
            ?->children()
            ?->delivery_services
        ;

        $messages = [];
        foreach ($deliveryServices?->message?->message_details?->text ?? [] as $message) {
            $messages[] = \trim((string)$message);
        }

        $senderName = $body?->sender?->name;
        $senderAddress = $body?->sender?->address;

        $receiverName = $body?->receiver?->name;
        $receiverAddress = $body?->receiver?->address;

        $financials = $body?->financials;
        $paymentDetails = $body?->payment_details;

        $destinationCountryCurrency = $paymentDetails?->destination_country_currency?->iso_code;
        $originatingCountryCurrency = $paymentDetails?->originating_country_currency?->iso_code;
        $originalDestinationCountryCurrency = $paymentDetails?->original_destination_country_currency?->iso_code;

        return [
            'sender' => [
                'name' => [
                    'first_name' => (string)$senderName?->first_name,
                    'middle_name' => (string)$senderName?->middle_name,
                    'last_name' => (string)$senderName?->last_name,
                ],
                'address' => [
                    'city' => (string)$senderAddress?->city,
                    'state' => (string)$senderAddress?->state,
                    'country_code' => (string)$senderAddress?->country_code?->iso_code?->country_code,
                    'currency_code' => (string)$senderAddress?->country_code?->iso_code?->currency_code,
                    'postal_code' => (string)$senderAddress?->state_zip,
                    'street' => (string)$senderAddress?->street,
                ],
                'contact_phone' => (string)$body?->sender->contact_phone,
                'mobile_phone' => [
                    'country_code' => (string)$body?->sender?->mobile_phone?->phone_number?->country_code,
                    'number' => (string)$body?->sender?->mobile_phone?->phone_number?->national_number,
                ]
            ],
            'receiver' => [
                'name' => [
                    'first_name' => (string)$receiverName?->first_name,
                    'middle_name' => (string)$receiverName?->middle_name,
                    'last_name' => (string)$receiverName?->last_name,
                ],
                'address' => [
                    'addr_line2' => (string)$receiverAddress?->addr_line2,
                    'state' => (string)$receiverAddress?->state,
                    'country_code' => (string)$receiverAddress?->country_code?->iso_code?->country_code,
                    'currency_code' => (string)$receiverAddress?->country_code?->iso_code?->currency_code,
                    'postal_code' => (string)$receiverAddress?->state_zip,
                    'street' => (string)$receiverAddress?->street,
                ],
                'mobile_phone' => [
                    'country_code' => (string)$body?->receiver?->mobile_phone?->phone_number?->country_code,
                    'number' => (string)$body?->receiver?->mobile_phone?->phone_number?->national_number,
                ]
            ],
            'financials' => [
                'gross_total_amount' => (int)$financials?->gross_total_amount,
                'pay_amount' => (int)$financials?->pay_amount,
                'principal_amount' => (int)$financials?->principal_amount,
                'charges' => (int)$financials?->charges,
                'tolls' => (int)$financials?->tolls,
            ],
            'payment_details' => [
                'expected_payout_location' => [
                    'state_code' => (string)$paymentDetails?->expected_payout_location?->state_code,
                    'city' => (string)$paymentDetails?->expected_payout_location?->city
                ],
                'destination_country_currency' => [
                    'country_code' => (string)$destinationCountryCurrency?->country_code,
                    'currency_code' => (string)$destinationCountryCurrency?->currency_code,
                ],
                'originating_country_currency' => [
                    'country_code' => (string)$originatingCountryCurrency?->country_code,
                    'currency_code' => (string)$originatingCountryCurrency?->currency_code,
                ],
                'original_destination_country_currency' => [
                    'country_code' => (string)$originalDestinationCountryCurrency?->country_code,
                    'currency_code' => (string)$originalDestinationCountryCurrency?->currency_code,
                ],
                'originating_state' => (string)$paymentDetails?->originating_city,
                'transaction_type' => (string)$paymentDetails?->transaction_type,
                'exchange_rate' => (string)$paymentDetails?->exchange_rate,
            ],
            'delivery_services' => [
                'message' => $messages
            ],
            'filing_date' => (string)$body?->filing_date,
            'filing_time' => (string)$body?->filing_time,
            'money_transfer_key' => (string)$body?->money_transfer_key,
            'pay_status_description' => (string)$body?->pay_status_description,
            'mtcn' => (string)$body?->mtcn,
            'new_mtcn' => (string)$body?->new_mtcn
        ];
    }
}
