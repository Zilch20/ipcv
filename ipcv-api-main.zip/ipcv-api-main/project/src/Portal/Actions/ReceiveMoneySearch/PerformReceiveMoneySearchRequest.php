<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\ReceiveMoneySearch;

use GuzzleHttp\Exception\ServerException;
use Illuminate\Contracts\Events\Dispatcher;
use Illuminate\Http\Request;
use IPCV\API\Portal\Actions\HandleWesternUnionErrorResponse;
use IPCV\API\Portal\Events\FailedReceiveMoneySearchEvent;
use IPCV\API\Portal\Events\SuccessfulReceiveMoneySearchEvent;
use IPCV\API\Portal\Factories\ReceiveMoney\ReceiveMoneySearchFactory;
use IPCV\WesternUnion\Client;
use Psr\Http\Message\ResponseInterface;

class PerformReceiveMoneySearchRequest
{
    public function __construct(
        private readonly Client $client,
        private readonly HandleWesternUnionErrorResponse $handleWesternUnionErrorResponse,
        private readonly Dispatcher $eventDispatcher,
    ) {
    }

    /**
     * @throws \Exception
     */
    public function __invoke(Request $request): ResponseInterface
    {
        $branch = $request->user()->branch;

        $receiveMoneySearch = ReceiveMoneySearchFactory::create(
            $request,
            $branch,
            config('western_union.identifier')
        );
        try {
            $response = $this->client->send($receiveMoneySearch);
        } catch (ServerException $e) {
            $this->eventDispatcher->dispatch(
                new FailedReceiveMoneySearchEvent($branch, $receiveMoneySearch, $e->getResponse())
            );

            $error = (string)$e->getResponse()->getBody();
            return ($this->handleWesternUnionErrorResponse)($error);
        }

        $this->eventDispatcher->dispatch(
            new SuccessfulReceiveMoneySearchEvent($branch, $receiveMoneySearch, $response)
        );

        return $response;
    }
}
