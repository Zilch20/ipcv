<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\SendMoneyTransaction;
use setasign\Fpdi\Fpdi;

class GenerateSendMoneyPostACR
{
    public function __construct(private readonly Fpdi $pdf)
    {
    }

    public function __invoke(SendMoneyTransaction $transaction): string
    {
        /**
         * @var Customer $customer;
         */
        $customer = $transaction->customer;

        /**
         * @var GovernmentIdentification $govId
         */
        $govId = $transaction->governmentIdentification;

        $this->customerCopy($customer, $govId, $transaction);
        $this->agentCopy($customer, $govId, $transaction);

        return $this->pdf->Output();
    }

    private function customerCopy(
        Customer $customer,
        GovernmentIdentification $govId,
        SendMoneyTransaction $transaction
    ): void {
        /**
         * Sender Name
         */
        $this->pdf->Text(29, 24, $customer->fullName());

        /**
         * Sender My WU Number
         */
        $this->pdf->Text(40.5, 29, $customer->my_wu_number);

        /**
         * Total Points Earned
         */
        $this->pdf->Text(39.5, 35.5, $transaction->total_points_earned);

        /**
         * New Points Earned
         */
        $this->pdf->Text(42.5, 39, $transaction->new_points_earned);

        /**
         * Present Address
         */
        $this->pdf->SetFontSize(6);
        $this->pdf->Text(16.1, 47.5, $customer->address_line_1);
        $this->pdf->Text(16.1, 50, $customer->address_line_2);
        $this->pdf->SetFontSize(7);

        /**
         * ID Type
         */
        $this->pdf->Text(16.1, 56, \sprintf('Type: %s', $govId->type()));

        /**
         * ID Number
         */
        $this->pdf->Text(16.1, 59, \sprintf('Number: %s', $govId->number));

        /**
         * ID Expiry Date
         */
        $this->pdf->Text(16.1, 62, \sprintf('Expiry Date: %s', $govId->expiry_date->format('F j, Y')));

        /**
         * Message
         */
        $this->pdf->SetFont('Helvetica', 'B', 5);
        $this->pdf->Text(60, 77.5, $transaction->messages[0] ?? '');
        $this->pdf->Text(60, 79.5, $transaction->messages[1] ?? '');
        $this->pdf->Text(60, 81.5, $transaction->messages[2] ?? '');
        $this->pdf->Text(60, 83.5, $transaction->messages[3] ?? '');

        /**
         * Receiver Full Name
         */
        $this->pdf->SetFont('Helvetica', 'B', 8);
        $this->pdf->Text(95, 24, $transaction->receiverFullName());
        $this->pdf->SetFont('Helvetica', 'B', 8);

        /**
         * Destination Country
         */
        $this->pdf->Text(106, 29, $transaction->destination_country_code);

        /**
         * MTCN
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 11);
        $this->pdf->Text(157.5, 21.5, $transaction->mtcn);
        $this->pdf->SetFont('Helvetica', style: 'B', size: 8);

        /**
         * Date and Time
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 7);
        $this->pdf->Text(157.5, 27, $transaction->created_at->format('F j, Y h:i:s A T'));

        /**
         * Purpose
         */
        $this->pdf->Text(163.5, 36.5, $transaction->purpose);

        /**
         * Amount Sent
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 7);
        $this->pdf->Text(155, 45.8, $transaction->amountSent());

        /**
         * Delivery Fee
         */
        $this->pdf->Text(157, 55, $transaction->deliveryCharge());

        /**
         * Message Charge Label
         */
        $this->pdf->SetFont('Helvetica', size: 6);
        $this->pdf->Text(173, 55, 'Message Charge:');

        /**
         * Message Charge
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 7);
        $this->pdf->Text(190, 55, $transaction->messageCharge());

        /**
         * Total
         */
        $this->pdf->Text(151, 65.7, $transaction->grossTotalAmount());

        /**
         * Exchange Rate
         */
        $this->pdf->Text(157, 72.3, $transaction->exchangeRate());

        /**
         * Payout Amount
         */
        $this->pdf->Text(157, 79.5, $transaction->payoutAmount());
    }

    private function agentCopy(
        Customer $customer,
        GovernmentIdentification $govId,
        SendMoneyTransaction $transaction
    ): void {
        /**
         * Sender Name
         */
        $this->pdf->Text(30, 163.5, $customer->fullName());

        /**
         * Sender My WU Number
         */
        $this->pdf->Text(40.3, 168.5, $customer->my_wu_number);

        /**
         * Total Points Earned
         */
        $this->pdf->Text(39.5, 175.5, $transaction->total_points_earned);

        /**
         * New Points Earned
         */
        $this->pdf->Text(41.5, 178.5, $transaction->new_points_earned);

        /**
         * Present Address
         */
        $this->pdf->SetFontSize(6);
        $this->pdf->Text(16.6, 187, $customer->address_line_1);
        $this->pdf->Text(16.6, 189.5, $customer->address_line_2);
        $this->pdf->SetFontSize(7);

        /**
         * ID Type
         */
        $this->pdf->Text(16.6, 195, \sprintf('Type: %s', $govId->type()));

        /**
         * ID Number
         */
        $this->pdf->Text(16.6, 198, \sprintf('Number: %s', $govId->number));

        /**
         * ID Expiry Date
         */
        $this->pdf->Text(16.6, 201, \sprintf('Expiry Date: %s', $govId->expiry_date->format('F j, Y')));

        /**
         * Message
         */
        $this->pdf->SetFont('Helvetica', 'B', 5);
        $this->pdf->Text(60, 217, $transaction->messages[0] ?? '');
        $this->pdf->Text(60, 219, $transaction->messages[1] ?? '');
        $this->pdf->Text(60, 221, $transaction->messages[2] ?? '');
        $this->pdf->Text(60, 223, $transaction->messages[3] ?? '');

        /**
         * Receiver Full Name
         */
        $this->pdf->SetFont('Helvetica', 'B', 8);
        $this->pdf->Text(95, 163.5, $transaction->receiverFullName());
        $this->pdf->SetFont('Helvetica', 'B', 8);

        /**
         * Destination Country
         */
        $this->pdf->Text(106, 168.5, $transaction->destination_country_code);

        /**
         * MTCN
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 11);
        $this->pdf->Text(157.5, 160.5, $transaction->mtcn);
        $this->pdf->SetFont('Helvetica', style: 'B', size: 8);

        /**
         * Date and Time
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 7);
        $this->pdf->Text(157.5, 165.8, $transaction->created_at->format('F j, Y h:i:s A T'));

        /**
         * Purpose
         */
        $this->pdf->Text(163.5, 177.8, $transaction->purpose);

        /**
         * Amount Sent
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 7);
        $this->pdf->Text(156, 189.6, $transaction->amountSent());

        /**
         * Delivery Fee
         */
        $this->pdf->Text(158, 199, $transaction->deliveryCharge());

        /**
         * Message Charge Label
         */
        $this->pdf->SetFont('Helvetica', size: 6);
        $this->pdf->Text(173, 199, 'Message Charge:');

        /**
         * Message Charge
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 7);
        $this->pdf->Text(190, 199, $transaction->messageCharge());

        /**
         * Total
         */
        $this->pdf->Text(152, 210.8, $transaction->grossTotalAmount());

        /**
         * Exchange Rate
         */
        $this->pdf->Text(157, 216.6, $transaction->exchangeRate());

        /**
         * Payout Amount
         */
        $this->pdf->Text(157, 221.2, $transaction->payoutAmount());
    }
}
