<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\Auth;

use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use IPCV\API\Portal\Http\Requests\Auth\LoginRequest;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Repositories\BranchUserRepository;
use Laravel\Fortify\Fortify;
use Laravel\Fortify\LoginRateLimiter;

class AuthenticateWithDefaultCredentials
{
    public function __construct(
        private readonly BranchUserRepository $repository,
        private readonly LoginRateLimiter $limiter
    ) {
    }

    /**
     * @throws ValidationException
     */
    public function __invoke(LoginRequest $request): void
    {
        $user = $this->repository->findByEmail($request->input('email'));

        if (null === $user) {
            $this->throwFailedAuthenticationException($request);
        }

        if (false === Hash::check($request->input('password'), $user->password)) {
            $this->throwFailedAuthenticationException($request);
        }

        $user->hasEnabledTwoFactorAuthentication();

        $request->setUserResolver(fn (): BranchUser => $user);
    }

    /**
     * @throws ValidationException
     */
    private function throwFailedAuthenticationException($request): void
    {
        $this->limiter->increment($request);

        throw ValidationException::withMessages([
            Fortify::username() => [trans('auth.failed')],
        ]);
    }
}
