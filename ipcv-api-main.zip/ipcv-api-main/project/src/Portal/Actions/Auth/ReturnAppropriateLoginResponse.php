<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\Auth;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Services\TokenService;
use IPCV\API\Portal\Services\TwoFactorKeyService;
use Laravel\Fortify\LoginRateLimiter;
use Symfony\Component\HttpFoundation\Response;

class ReturnAppropriateLoginResponse
{
    public function __construct(
        private readonly LoginRateLimiter $limiter,
        private readonly TwoFactorKeyService $twoFactorKeyService,
        private readonly TokenService $tokenService,
    ) {
    }

    public function __invoke(Request $request): Response
    {
        $this->limiter->clear($request);

        /** @var BranchUser $user */
        $user = $request->user();

        if ($user->hasEnabledTwoFactorAuthentication()) {
            $key = $this->twoFactorKeyService->generate($user);
            return new JsonResponse(['two_factor_key' => $key]);
        }

        $token = $this->tokenService->generate($user);

        return new JsonResponse(['bearer_token' => $token->toString()]);
    }
}
