<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\Auth;

use IPCV\API\Portal\Exceptions\InvalidTwoFactorKey;
use IPCV\API\Portal\Exceptions\UserNotFound;
use IPCV\API\Portal\Http\Requests\Auth\TwoFactorLoginRequest;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Repositories\BranchUserRepository;
use IPCV\API\Portal\Services\TwoFactorKeyService;

class GetChallengedUserByTwoFactorKey
{
    public function __construct(
        private readonly TwoFactorKeyService $twoFactorKeyService,
        private readonly BranchUserRepository $branchUserRepository,
    ) {
    }

    public function __invoke(TwoFactorLoginRequest $request): void
    {
        $userId = $this->twoFactorKeyService->get($request->input('two_factor_key'));

        if (false === $userId) {
            throw new InvalidTwoFactorKey(422, __('errors.auth.invalid_two_factor_key'));
        }

        $user = $this->branchUserRepository->find($userId);

        if (null === $user) {
            throw new UserNotFound(404, __('errors.branch_user.not_found'));
        }

        $request->setUserResolver(fn (): BranchUser => $user);
    }
}
