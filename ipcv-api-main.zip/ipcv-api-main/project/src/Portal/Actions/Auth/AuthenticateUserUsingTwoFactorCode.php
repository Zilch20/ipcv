<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\Auth;

use IPCV\API\Portal\Actions\TwoFactor\TwoFactorChallenge;
use IPCV\API\Portal\Http\Requests\Auth\TwoFactorLoginRequest;
use IPCV\API\Portal\Services\TokenService;
use Lcobucci\JWT\Token;

class AuthenticateUserUsingTwoFactorCode
{
    public function __construct(
        private readonly TwoFactorChallenge $twoFactorChallenge,
        private readonly TokenService $tokenService,
    ) {
    }

    public function __invoke(TwoFactorLoginRequest $request): Token
    {
        ($this->twoFactorChallenge)($request->user(), $request->input('code'));

        return $this->tokenService->generate($request->user());
    }
}
