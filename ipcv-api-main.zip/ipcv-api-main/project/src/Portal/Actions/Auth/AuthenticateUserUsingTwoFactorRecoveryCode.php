<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\Auth;

use IPCV\API\Portal\Actions\TwoFactor\TwoFactorRecoveryCodeChallenge;
use IPCV\API\Portal\Http\Requests\Auth\TwoFactorLoginRequest;
use IPCV\API\Portal\Services\TokenService;
use Lcobucci\JWT\Token;

class AuthenticateUserUsingTwoFactorRecoveryCode
{
    public function __construct(
        private readonly TwoFactorRecoveryCodeChallenge $twoFactorRecoveryCodeChallenge,
        private readonly TokenService $tokenService,
    ) {
    }

    public function __invoke(TwoFactorLoginRequest $request): Token
    {
        ($this->twoFactorRecoveryCodeChallenge)($request->user(), $request->input('recovery_code'));

        return $this->tokenService->generate($request->user());
    }
}
