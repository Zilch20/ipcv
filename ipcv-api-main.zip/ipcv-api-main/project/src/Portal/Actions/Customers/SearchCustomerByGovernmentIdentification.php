<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\Customers;

use IPCV\API\Portal\Exceptions\CustomerNotFound;
use IPCV\API\Portal\Exceptions\GovernmentIdentificationNotFound;
use IPCV\API\Portal\Http\Requests\Customer\SearchCustomerRequest;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;

class SearchCustomerByGovernmentIdentification
{
    public function __invoke(SearchCustomerRequest $request): Customer
    {
        $q = GovernmentIdentification::query();

        $q
            ->where('type', $request->input('government_identification_type'))
            ->where('number', $request->input('government_identification_number'))
        ;

        $govId = $q->first();

        if ($govId === null) {
            throw new GovernmentIdentificationNotFound(404, __('errors.government_identification.not_found'));
        }

        $q = Customer::query();

        $q->where('id', '=', $govId->customer_id);

        if ($firstName = $request->input('first_name')) {
            $q->where('first_name', '=', $firstName);
        }

        if ($middleName = $request->input('middle_name')) {
            $q->where('middle_name', '=', $middleName);
        }

        if ($lastName = $request->input('last_name')) {
            $q->where('last_name', '=', $lastName);
        }

        /** @var ?Customer $customer */
        $customer = $q->first();

        if ($customer === null) {
            throw new CustomerNotFound(404, __('errors.customer.not_found'));
        }

        return $customer;
    }
}
