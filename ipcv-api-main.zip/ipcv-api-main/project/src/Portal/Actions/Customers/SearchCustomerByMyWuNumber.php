<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\Customers;

use IPCV\API\Portal\Exceptions\CustomerNotFound;
use IPCV\API\Portal\Http\Requests\Customer\SearchCustomerRequest;
use IPCV\API\Portal\Models\Customer;

class SearchCustomerByMyWuNumber
{
    /**
     * @throws CustomerNotFound
     */
    public function __invoke(SearchCustomerRequest $request): Customer
    {
        /** @var ?Customer $customer */
        $customer = Customer::query()
            ->where('my_wu_number', '=', $request->input('my_wu_number'))
            ->first()
        ;

        if ($customer === null) {
            throw new CustomerNotFound(404, __('errors.customer.not_found'));
        }

        return $customer;
    }
}
