<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\GovernmentIdentifications;

use Illuminate\Http\Request;
use Illuminate\Pagination\CursorPaginator;
use IPCV\API\Portal\Models\GovernmentIdentification;

class ListGovernmentIdentificationByCustomerId
{
    public function __invoke(string $customerId, Request $request): CursorPaginator
    {
        return GovernmentIdentification::query()
            ->where('customer_id', '=', $customerId)
            ->cursorPaginate(
                perPage: $request->input('per_page', 25),
                cursor: $request->input('cursor')
            );
    }
}
