<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\SendMoneyTransaction;
use setasign\Fpdi\Fpdi;

class GenerateSendMoneyPreACR
{
    public function __construct(private readonly Fpdi $pdf)
    {
    }

    public function __invoke(SendMoneyTransaction $transaction): string
    {
        /**
         * @var Customer $customer;
         */
        $customer = $transaction->customer;

        /**
         * @var GovernmentIdentification $govId
         */
        $govId = $transaction->governmentIdentification;

        $this->pdf->Text(48, 38, $customer->fullName());
        $this->pdf->Text(40, 47.2, $customer->my_wu_number);
        $this->pdf->Text(107, 47.2, $transaction->new_points_earned);
        $this->pdf->Text(104, 55.5, $transaction->total_points_earned);
        $this->pdf->Text(29, 75.1, $govId->type());
        $this->pdf->Text(33, 79.7, $govId->number);
        $this->pdf->Text(43, 84.3, $govId->expiry_date->format('F j, Y'));

        $this->pdf->Text(34, 95.2, $customer->occupation);
        $this->pdf->Text(35.3, 110.7, $customer->date_of_birth->format('F, j, Y'));
        $this->pdf->Text(40, 115.3, $customer->country);
        $this->pdf->Text(33, 119.8, $customer->nationality);

        $this->pdf->Text(108, 110.7, $transaction->purpose);
        $this->pdf->Text(99, 115.3, $transaction->source_of_funds);
        $this->pdf->Text(110, 119.8, $transaction->relationship_to_receiver);

        /**
         * Present Address
         */
        $this->pdf->Text(16.3, 133, $customer->address_line_1);
        $this->pdf->Text(16.3, 136, $customer->address_line_2);

        /**
         * Permanent Address
         */
        $this->pdf->Text(75.5, 133, $customer->address_line_1);
        $this->pdf->Text(75.5, 136, $customer->address_line_2);

        /**
         * Mobile Number
         */
        $this->pdf->Text(92, 143, $customer->phone_number);

        /**
         * MTCN
         */
        $this->pdf->SetFont('Helvetica', style: 'B', size: 11);
        $this->pdf->Text(152, 30.3, $transaction->mtcn);
        $this->pdf->SetFont('Helvetica', style: 'B', size: 8);

        /**
         * Date and Time
         */
        $this->pdf->Text(139, 44, $transaction->created_at->format('F j, Y h:i:s A T'));

        /**
         * Destination Country
         */
        $this->pdf->Text(168, 68.8, $transaction->destination_country_code);

        /**
         * Amount Sent
         */
        $this->pdf->Text(158.3, 91.1, $transaction->amountSent());

        /**
         * Message Charge Label
         */
        $this->pdf->SetFont('Helvetica', size: 8);
        $this->pdf->Text(138.7, 95.3, 'Message Charge:');
        $this->pdf->SetFont('Helvetica', style: 'B', size: 8);

        /**
         * Message Charge
         */
        $this->pdf->Text(162, 95.3, $transaction->messageCharge());

        /**
         * Delivery Charge
         */
        $this->pdf->Text(162, 99.5, $transaction->deliveryCharge());

        /**
         * Total
         */
        $this->pdf->Text(150, 120.6, $transaction->grossTotalAmount());

        /**
         * Exchange Rate
         */
        $this->pdf->Text(160, 132.5, $transaction->exchangeRate());

        /**
         * Payout Amount
         */
        $this->pdf->Text(162, 140.5, $transaction->payoutAmount());

        /**
         * Receiver Name
         */
        $this->pdf->Text(45.5, 170.9, $transaction->receiverFullName());

        /**
         * Message
         */
        $this->pdf->SetFont('Helvetica', 'B', 8);
        $this->pdf->Text(16, 185.5, $transaction->messages[0] ?? '');
        $this->pdf->Text(16, 188.6, $transaction->messages[1] ?? '');
        $this->pdf->Text(16, 191.4, $transaction->messages[2] ?? '');
        $this->pdf->Text(16, 194.6, $transaction->messages[3] ?? '');

        return $this->pdf->Output();
    }
}
