<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\SendMoneyValidate;

use Psr\Http\Message\ResponseInterface;

class ConvertToArraySendMoneyValidationResponse
{
    public function __invoke(ResponseInterface $response): array
    {
        $xml = new \SimpleXMLElement($response->getBody()->__toString());
        $soapenv = $xml->children('soapenv', true);
        $sendMoneyValidationReply = $soapenv
            ?->Body
            ?->children('xrsi', true)
            ?->{'send-money-validation-reply'}
            ?->children()
        ;

        $complianceDataBuffer = (string)$sendMoneyValidationReply
            ?->sender
            ?->compliance_details
            ?->compliance_data_buffer
        ;

        $financials = $sendMoneyValidationReply
            ?->financials
        ;

        $paymentDetails = $sendMoneyValidationReply
            ?->payment_details
        ;

        $mtcn = (string)$sendMoneyValidationReply
            ?->mtcn
        ;

        $newMtcn = (string)$sendMoneyValidationReply
            ?->new_mtcn
        ;

        $receiver = $sendMoneyValidationReply
            ?->receiver
            ?->name
        ;

        return [
            'mtcn' => $mtcn,
            'new_mtcn' => $newMtcn,
            'compliance_data_buffer' => $complianceDataBuffer,
            'sender' => [
                'compliance_details' => [
                    'compliance_data_buffer' => $complianceDataBuffer,
                ],
            ],
            'receiver' => [
                'name' => [
                    'first_name' => (string)$receiver?->first_name,
                    'middle_name' => (string)$receiver?->middle_name,
                    'last_name' => (string)$receiver?->last_name,
                ],
            ],
            'financials' => [
                'originators_principal_amount' => (string)$financials?->originators_principal_amount,
                'destination_principal_amount' => (string)$financials?->destination_principal_amount,
                'gross_total_amount' => (string)$financials?->gross_total_amount,
                'plus_charges_amount' => (string)$financials?->plus_charges_amount,
                'charges' => (string)$financials?->charges,
                'message_charge' => (string)$financials?->message_charge,
            ],
            'payment_details' => [
                'expected_payout_location' => [
                    'state_code' => (string)$paymentDetails?->expected_payout_location?->state_code,
                    'city' => (string)$paymentDetails?->expected_payout_location?->city,
                ],
                'recording_country_currency' => [
                    'country_code' => (string)$paymentDetails?->recording_country_currency?->iso_code?->country_code,
                    'currency_code' => (string)$paymentDetails?->recording_country_currency?->iso_code?->currency_code,
                ],
                'destination_country_currency' => [
                    'country_code' => (string)$paymentDetails?->destination_country_currency?->iso_code?->country_code,
                    'currency_code' =>
                        (string)$paymentDetails?->destination_country_currency?->iso_code?->currency_code,
                ],
                'originating_country_currency' => [
                    'country_code' => (string)$paymentDetails?->originating_country_currency?->iso_code?->country_code,
                    'currency_code' =>
                        (string)$paymentDetails?->originating_country_currency?->iso_code?->currency_code,
                ],
                'originating_city' => (string)$paymentDetails?->originating_city,
                'originating_state' => (string)$paymentDetails?->originating_state,
                'transaction_type' => (string)$paymentDetails?->transaction_type,
                'payment_type' => (string)$paymentDetails?->payment_type,
                'exchange_rate' => (string)$paymentDetails?->exchange_rate,
                'fix_on_send' => (string)$paymentDetails?->fix_on_send,
                'pay_wo_id_indicator' => (string)$paymentDetails?->pay_wo_id_indicator,
                'duplicate_detection_flag' => (string)$paymentDetails?->duplicate_detection_flag,
            ],
        ];
    }
}
