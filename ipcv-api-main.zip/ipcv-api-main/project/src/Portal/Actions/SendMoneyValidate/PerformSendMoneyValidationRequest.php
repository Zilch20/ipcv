<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\SendMoneyValidate;

use GuzzleHttp\Exception\ServerException;
use Illuminate\Contracts\Events\Dispatcher;
use IPCV\API\Portal\Actions\HandleWesternUnionErrorResponse;
use IPCV\API\Portal\Events\FailedSendMoneyValidationEvent;
use IPCV\API\Portal\Events\SuccessfulSendMoneyValidationEvent;
use IPCV\API\Portal\Exceptions\BankInformationNotFound;
use IPCV\API\Portal\Exceptions\CustomerNotFound;
use IPCV\API\Portal\Exceptions\GovernmentIdentificationNotFound;
use IPCV\API\Portal\Factories\SendMoney\SendMoneyValidationRequestFactory;
use IPCV\API\Portal\Http\Requests\SendMoneyRequest;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Repositories\BankInformationRepository;
use IPCV\API\Portal\Repositories\CustomerRepository;
use IPCV\WesternUnion\Client;
use Psr\Http\Message\ResponseInterface;

class PerformSendMoneyValidationRequest
{
    public function __construct(
        private readonly CustomerRepository $customerRepository,
        private readonly BankInformationRepository $bankInformationRepository,
        private readonly Client $client,
        private readonly Dispatcher $eventDispatcher,
        private readonly HandleWesternUnionErrorResponse $handleWesternUnionErrorResponse,
    ) {
    }

    public function __invoke(SendMoneyRequest $request): ResponseInterface
    {
        $customer = $this->customerRepository->find($request->input('customer_id'));

        if (null === $customer) {
            throw new CustomerNotFound(404, 'Customer not found.');
        }

        $governmentId = $customer
            ->governmentIdentifications()
            ->find($request->input('government_identification_id'))
        ;

        if (null === $governmentId) {
            throw new GovernmentIdentificationNotFound(404, 'Government Identification not found.');
        }

        $branch = $this->getBranchOfLoggedInUser($request->user());
        $sendMoneyValidationFactory = new SendMoneyValidationRequestFactory(
            $request,
            config('western_union.identifier')
        );
        $sendMoneyValidationFactory
            ->setBranch($branch)
            ->setCustomer($customer)
            ->setGovernmentIdentification($governmentId)
        ;

        if ($request->has('bank_information_id')) {
            $bankInformation = $this->bankInformationRepository->find($request->input('bank_information_id'));

            if (null === $bankInformation) {
                throw new BankInformationNotFound(404, 'Bank information not found.');
            }

            $sendMoneyValidationFactory->setBankInformation($bankInformation);
        }

        $sendMoneyValidationRequest = $sendMoneyValidationFactory->build();
        try {
            $response =  $this->client->send($sendMoneyValidationRequest);

            $this->eventDispatcher->dispatch(
                new SuccessfulSendMoneyValidationEvent($governmentId, $branch, $sendMoneyValidationRequest, $response)
            );

            return $response;
        } catch (ServerException $e) {
            $responseBody = $e->getResponse()->getBody()->getContents();
            $this->eventDispatcher->dispatch(
                new FailedSendMoneyValidationEvent(
                    $governmentId,
                    $branch,
                    $sendMoneyValidationRequest,
                    $e->getResponse()
                )
            );

            return ($this->handleWesternUnionErrorResponse)($responseBody);
        }
    }

    private function getBranchOfLoggedInUser(BranchUser $branchUser): Branch
    {
        return $branchUser->branch()->first();
    }
}
