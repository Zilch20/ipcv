<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\FeeInquiry;

use Psr\Http\Message\ResponseInterface;

class ConvertToArrayFeeInquiryResponse
{
    public function __invoke(ResponseInterface $response): array
    {
        $xml = new \SimpleXMLElement($response->getBody()->getContents());
        $soapenv = $xml->children('soapenv', true);
        $feeInquiryReply = $soapenv
            ?->Body
            ?->children('xrsi', true)
            ?->{'fee-inquiry-reply'}
            ?->children()
        ;

        $originatorsPrincipalAmount = (int)$feeInquiryReply?->financials?->originators_principal_amount;
        $destinationPrincipalAmount = (int)$feeInquiryReply?->financials?->destination_principal_amount;
        $grossTotalAmount = (int)$feeInquiryReply?->financials?->gross_total_amount;
        $plusChargesAmount = (int)$feeInquiryReply?->financials?->plus_charges_amount;
        $charges = (int)$feeInquiryReply?->financials?->charges;
        $messageCharge = (int)$feeInquiryReply?->financials?->message_charge;

        $exchangeRate = (float)$feeInquiryReply?->payment_details?->exchange_rate;

        return [
            'financials' => [
                'originators_principal_amount' => $originatorsPrincipalAmount,
                'destination_principal_amount' => $destinationPrincipalAmount,
                'gross_total_amount' => $grossTotalAmount,
                'plus_charges_amount' => $plusChargesAmount,
                'charges' => $charges,
                'message_charge' => $messageCharge,
            ],
            'payment_details' => [
                'exchange_rate' => $exchangeRate
            ]
        ];
    }
}
