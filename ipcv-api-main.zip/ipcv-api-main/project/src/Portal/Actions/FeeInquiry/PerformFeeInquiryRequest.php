<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\FeeInquiry;

use GuzzleHttp\Exception\ServerException;
use IPCV\API\Portal\Actions\HandleWesternUnionErrorResponse;
use IPCV\API\Portal\Factories\FeeInquiry\FeeInquiryRequestFactory;
use IPCV\API\Portal\Http\Requests\FeeInquiryRequest;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\WesternUnion\Client;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use Psr\Http\Message\ResponseInterface;

class PerformFeeInquiryRequest
{
    public function __construct(
        private readonly Client $client,
        private readonly HandleWesternUnionErrorResponse $handleWesternUnionErrorResponse,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     * @throws \Exception
     */
    public function __invoke(FeeInquiryRequest $request): ?ResponseInterface
    {
        $branch = $this->getBranchOfLoggedInUser($request->user());
        $feeInquiryRequest = FeeInquiryRequestFactory::create($request, $branch);
        try {
            $response = $this->client->send($feeInquiryRequest);
        } catch (ServerException $e) {
            $error = $e->getResponse()->getBody()->getContents();
            return ($this->handleWesternUnionErrorResponse)($error);
        }

        return $response;
    }

    private function getBranchOfLoggedInUser(BranchUser $branchUser): Branch
    {
        return $branchUser->branch()->first();
    }
}
