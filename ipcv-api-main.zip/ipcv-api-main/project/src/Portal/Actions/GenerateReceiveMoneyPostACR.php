<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;
use setasign\Fpdi\Fpdi;

class GenerateReceiveMoneyPostACR
{
    public function __construct(private readonly Fpdi $pdf)
    {
    }

    public function __invoke(ReceiveMoneyPayTransaction $transaction): string
    {
        /**
         * @var Customer $receiver;
         */
        $receiver = $transaction->customer;
        /**
         * @var GovernmentIdentification $govId
         */
        $govId = $transaction->governmentIdentification;

        /**
         * Receiver Full Name
         */
        $this->pdf->Text(32, 24, $receiver->fullName());

        /*
         * Sender Full Name
         */
        $this->pdf->Text(92, 24, $transaction->senderFullName());

        /**
         * My WU Number
         */
        $this->pdf->Text(41, 29, $receiver->my_wu_number);

        /**
         * Total MyWU Points
         */
        $this->pdf->Text(37, 35, $transaction->total_points_earned);

        /**
         * MyWU Points Earned
         */
        $this->pdf->Text(39, 38, $transaction->new_points_earned);

        /**
         * Address Line 1
         */
        $this->pdf->SetFont("helvetica", "B", 8);
        $this->pdf->Text(16, 51, $receiver->address_line_1);

        /**
         * Address Line 2
         */
        $this->pdf->Text(16, 54, $receiver->address_line_2);

        /**
         * ID Type
         */
        $this->pdf->Text(34, 61, $govId->type());

        /**
         * ID Number
         */
        $this->pdf->Text(34, 64, $govId->number);

        /**
         * Messages
         */
        $this->pdf->SetFont('Helvetica', 'B', 6);
        $this->pdf->Text(60, 81, $transaction->messages[0] ?? '');
        $this->pdf->Text(60, 83, $transaction->messages[1] ?? '');
        $this->pdf->Text(60, 85, $transaction->messages[2] ?? '');
        $this->pdf->Text(60, 87.2, $transaction->messages[3] ?? '');

        /**
         * MTCN
         */
        $this->pdf->SetFont('helvetica', 'B', 10);
        $this->pdf->Text(172, 21, $transaction->mtcn);
        $this->pdf->SetFont('helvetica', 'B', 6);
        $this->pdf->Text(155.5, 26.6, $transaction->created_at->format('F j, Y h:i:s A'));

        /**
         * Transaction Reason
         */
        $this->pdf->Text(166, 36, $transaction->purpose);

        /**
         * Originating Country
         */
        $this->pdf->Text(166, 39, $transaction->originating_country_code);

        /**
         * Amount Received
         */
        $this->pdf->Text(160, 47, $transaction->payAmount());

        /**
         * Total
         */
        $this->pdf->Text(160, 53, $transaction->payAmount());

        /**
         * Exchange Rate
         */
        $this->pdf->Text(156, 58, $transaction->exchangeRate());

        /**
         * Receiver Name
         */
        $this->pdf->SetFont('Helvetica', 'B', 8);
        $this->pdf->Text(32, 161.5, $receiver->fullName());

        /**
         * Sender Name
         */
        $this->pdf->Text(92, 161.5, $transaction->senderFullName());

        /**
         * MyWU Number
         */
        $this->pdf->Text(41, 166.8, $receiver->my_wu_number);

        /**
         * Total MyWU Points Earned
         */
        $this->pdf->Text(37, 172.5, $transaction->total_points_earned);
        /**
         * New MyWU Points Earned
         */
        $this->pdf->Text(37.2, 175.8, $transaction->new_points_earned);

        /**
         * Address Line 1
         */
        $this->pdf->Text(16, 188.5, $receiver->address_line_1);

        /**
         * Address Line 2
         */
        $this->pdf->Text(16, 191.5, $receiver->address_line_2);

        /**
         * ID Type
         */
        $this->pdf->Text(34, 199.5, $govId->type());

        /**
         * ID Number
         */
        $this->pdf->Text(34, 202.5, $govId->number);

        /**
         * Messages
         */
        $this->pdf->SetFont('Helvetica', 'B', 6);
        $this->pdf->Text(60, 219.5, $transaction->messages[0] ?? '');
        $this->pdf->Text(60, 222, $transaction->messages[1] ?? '');
        $this->pdf->Text(60, 224, $transaction->messages[2] ?? '');
        $this->pdf->Text(60, 226, $transaction->messages[3] ?? '');

        /**
         * Created At
         */
        $this->pdf->SetFont('Helvetica', 'B', 10);
        $this->pdf->Text(172, 161, $transaction->mtcn);


        $this->pdf->SetFont('Helvetica', 'B', 6);
        $this->pdf->Text(156, 167, $transaction->created_at->format('F j, Y h:i:s A'));

        /**
         * Transaction Reason
         */
        $this->pdf->Text(164, 177.3, $transaction->purpose);

        /**
         * Originating Country
         */
        $this->pdf->Text(164, 179.5, $transaction->originating_country_code);

        /**
         * Amount Received
         */
        $this->pdf->Text(160, 188, $transaction->payAmount());

        /**
         * Total
         */
        $this->pdf->Text(160, 193.4, $transaction->payAmount());

        /**
         * Exchange Rate
         */
        $this->pdf->Text(156, 199.5, $transaction->exchangeRate());


        return $this->pdf->Output();
    }
}
