<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions;

use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;
use setasign\Fpdi\Fpdi;

class GenerateReceiveMoneyPreACR
{
    public function __construct(private readonly Fpdi $pdf)
    {
    }

    public function __invoke(ReceiveMoneyPayTransaction $transaction): string
    {
        /**
         * @var Customer $receiver;
         */
        $receiver = $transaction->customer;

        /**
         * @var GovernmentIdentification $govId
         */
        $govId = $transaction->governmentIdentification;

        /**
         * Receiver Name
         */
        $this->pdf->Text(48, 38, $receiver->fullName());

        /**
         * My WU Number
         */
        $this->pdf->Text(40, 46.5, $receiver->my_wu_number);

        /**
         * New Points Earned
         */
        $this->pdf->Text(107, 46.2, $transaction->new_points_earned);

        /**
         * Total My WU Points
         */
        $this->pdf->Text(104, 54.6, $transaction->total_points_earned);

        /**
         * ID Type
         */
        $this->pdf->Text(48, 73, $govId->type());

        /**
         * ID Number
         */
        $this->pdf->Text(48, 78, $govId->number);

        /**
         * ID Expiration
         */
        $this->pdf->Text(48, 83, $govId->expiry_date->format('F j Y'));

        /**
         * Occupation
         */
        $this->pdf->Text(48, 93, $receiver->occupation);

        /**
         * Date of Birth
         */
        $this->pdf->Text(48, 109, $receiver->date_of_birth->format('F j, Y'));

        /**
         * Country of Birth
         */
        $this->pdf->Text(48, 114, $receiver->country_of_birth);

        /**
         * Nationality
         */
        $this->pdf->Text(48, 118, $receiver->nationality);

        /**
         * Present Address
         */
        $this->pdf->Text(16.3, 132, $receiver->address_line_1);
        $this->pdf->Text(16.3, 136, $receiver->address_line_2);

        /**
         * Permanent Address
         */
        $this->pdf->Text(75.3, 132, $receiver->address_line_1);
        $this->pdf->Text(75.3, 136, $receiver->address_line_2);

        /**
         * Purpose of Transaction
         */
        $this->pdf->SetFont(family: 'Helvetica', style: 'B', size: 6);
        $this->pdf->Text(108, 109, $transaction->purpose);

        /**
         * Source of Funds
         */
        $this->pdf->SetFont(family: 'Helvetica', style: 'B', size: 8);
        $this->pdf->Text(99, 113.7, $receiver->source_of_funds);

        /**
         * Relationship with Sender
         */
        $this->pdf->SetFont(family: 'Helvetica', style: 'B', size: 6);
        $this->pdf->Text(111, 118.3, $transaction->relationship_to_sender);

        /**
         * Mobile Number
         */
        $this->pdf->SetFont(family: 'Helvetica', style: 'B', size: 8);
        $this->pdf->Text(92, 141.3, $receiver->phone_number);

        /**
         * Sender Name
         */
        $this->pdf->Text(47, 170.8, $transaction->senderFullName());

        /**
         * Messages
         */
        $this->pdf->Text(16, 186, $transaction->messages[0] ?? '');
        $this->pdf->Text(16, 189, $transaction->messages[1] ?? '');
        $this->pdf->Text(16, 192, $transaction->messages[2] ?? '');
        $this->pdf->Text(16, 195, $transaction->messages[3] ?? '');

        /**
         * MTCN
         */
        $this->pdf->SetFont(family: 'Helvetica', style: 'B', size: 11);
        $this->pdf->Text(152, 30.4, $transaction->mtcn);

        /**
         * Date and Time
         */
        $this->pdf->SetFont(family: 'Helvetica', style: 'B', size: 11);
        $this->pdf->Text(139, 44.5, $transaction->created_at);

        /**
         * Originating Country
         */
        $this->pdf->SetFont(family: 'Helvetica', style: 'B', size: 8);
        $this->pdf->Text(168, 64.6, $transaction->originating_country_code);

        /**
         * Destination Amount
         */
        $this->pdf->Text(165, 85, $transaction->payAmount());

        /**
         * Total
         */
        $this->pdf->Text(150, 96.2, $transaction->payAmount());

        /**
         * Exchange Rate
         */
        $this->pdf->Text(160.5, 106.2, $transaction->exchangeRate());

        return $this->pdf->Output();
    }
}
