<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\DataAccessServer;

use IPCV\API\Portal\Factories\ForeignRemoteSystemFactory;
use IPCV\API\Portal\Models\Branch;
use IPCV\WesternUnion\DataAccessServer\Client;
use IPCV\WesternUnion\DataAccessServer\Request;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Filters;
use SimpleXMLElement;

class PerformGetCountryInformationRequest
{
    public function __construct(
        private readonly Client $client,
    ) {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function __invoke(Branch $branch, string $countryCode, string $currencyCode): SimpleXMLElement
    {
        $request = new Request();
        $request
            ->setName('GetCountryInfo')
            ->setClientId('H2H')
            ->setForeignRemoteSystem(
                ForeignRemoteSystemFactory::create($branch, config('western_union.identifier'))
            )
            ->setFilters(
                (new Filters())
                    ->addFilter('en')
                    ->addFilter("$countryCode $currencyCode")
            )
        ;

        $this->client->send($request);
    }
}
