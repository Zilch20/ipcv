<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Actions\DataAccessServer;

use SimpleXMLElement;

class ParseGetCountryInformationResponse
{
    private static array $categories = [
        'MAXIMUM SEND AMOUNT',
        'MAXIMUM PAYOUT AMOUNT',
        'MINIMUM MT PAYOUT AGE',
        'COUNTRY GENERAL RESTRICTIONS',
        'SEND RESTRICTIONS',
        'PAYOUT RESTRICTIONS',
        'ACCEPTABLE FORMS OF IDENTIFICATION',
        'ADDITIONAL RESTRICTIONS AND INFORMATION',
        'SERVICES OFFERED',
    ];

    public function __invoke(SimpleXMLElement $response): array
    {
        $category = '';
        $results = [];

        $responseData = $response
            ->children('soapenv', true)
            ?->Body
            ?->children('xrsi', true)
            ?->children()
            ?->MTML
            ?->REPLY
            ?->DATA_CONTEXT
            ?->RECORDSET
            ?->GETCOUNTRYINFO
        ;

        foreach ($responseData as $data) {
            $data = (string)$data->INFO;

            if ($data === '') {
                continue;
            }

            if (self::isPayoutCurrency($data)) {
                $results['PAYOUT CURRENCY'][] = \trim(\explode(separator: ':', string: $data)[1]);
                continue;
            }

            if (self::isSendCurrency($data)) {
                $results['SEND CURRENCY'][] = \trim(\explode(separator: ':', string: $data)[1]);
                continue;
            }

            if (self::isCategory($data)) {
                $category = $data;
                continue;
            }

            if (self::startsWithSpaces($data)) {
                $lastElement = \array_pop($results[$category]);
                $combined = $lastElement . $data;
                $results[$category][] = $combined;
                continue;
            }

            $results[$category][] = $data;
        }


        return $results;
    }

    private static function isPayoutCurrency(string $str): bool
    {
        return \str_starts_with(haystack: $str, needle: 'Payout Currency:');
    }

    private static function isSendCurrency(string $str): bool
    {
        return \str_starts_with(haystack: $str, needle: 'Send Currency:');
    }

    private static function isCategory(string $str): bool
    {
        return \in_array($str, self::$categories, strict: true);
    }

    private static function startsWithSpaces(string $str): bool
    {
        return \str_starts_with(haystack: $str, needle: ' ');
    }
}
