<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Services;

use Illuminate\Contracts\Auth\Authenticatable;

interface TwoFactorKeyService
{
    public function generate(Authenticatable $user): string;

    public function get(string $key): string|false;

    public function delete(string $key): void;
}
