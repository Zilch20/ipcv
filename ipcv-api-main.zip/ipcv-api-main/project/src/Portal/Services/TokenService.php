<?php

namespace IPCV\API\Portal\Services;

use Illuminate\Contracts\Auth\Authenticatable;
use Lcobucci\JWT\Token;

interface TokenService
{
    public function generate(Authenticatable $user): Token;
}
