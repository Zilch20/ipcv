<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Services;

use Illuminate\Contracts\Auth\Authenticatable;
use Lcobucci\JWT\Configuration;
use Lcobucci\JWT\Token;

class JwtTokenService implements TokenService
{
    public function __construct(
        private readonly Configuration $configuration
    ) {
    }

    public function generate(Authenticatable $user): Token
    {
        return $this
            ->configuration
            ->builder()
            ->withClaim('user_id', $user->id)
            ->getToken($this->configuration->signer(), $this->configuration->signingKey())
        ;
    }
}
