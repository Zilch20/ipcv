<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Services;

use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Contracts\Redis\Connection;
use Illuminate\Support\Str;

class InMemoryTwoFactorKeyService implements TwoFactorKeyService
{
    public function __construct(private readonly Connection $connection)
    {
    }

    public function generate(Authenticatable $user): string
    {
        $this->connection->command('SET', [$str = Str::random(64), $user->id, 120]);

        return $str;
    }

    public function get(string $key): string|false
    {
        return $this->connection->command('GET', [$key]);
    }

    public function delete(string $key): void
    {
        $this->connection->command('DEL', [$key]);
    }
}
