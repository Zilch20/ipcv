<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use IPCV\API\Portal\Models\Customer;

interface CustomerRepository
{
    public function find(string $id): ?Customer;

    public function create(array $attributes): Customer;

    public function update(string $id, array $attributes): int;
}
