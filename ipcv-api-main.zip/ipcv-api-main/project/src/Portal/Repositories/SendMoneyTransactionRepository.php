<?php

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\SendMoneyTransaction;

interface SendMoneyTransactionRepository
{
    public function create(
        GovernmentIdentification $governmentIdentification,
        Branch $branch,
        array $attributes
    ): SendMoneyTransaction;

    public function find(string $id): ?SendMoneyTransaction;

    public function findOneBy(array $filters): ?SendMoneyTransaction;

    public function getByMtcn(string $mtcn): Collection;

    public function getByBranch(Branch $branch): Collection;

    public function getByCustomer(Customer $customer): Collection;
}
