<?php

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchOwner;

class BaseBranchRepository implements BranchRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly Branch $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function update(string $id, array $attributes): int
    {
        return $this->builder->where('id', '=', $id)->update($attributes);
    }

    public function createIndependent(array $attributes): Branch
    {
        return $this->builder->create($attributes);
    }

    public function create(BranchOwner $branchOwner, array $attributes): Branch
    {
        return $branchOwner->branches()->create($attributes);
    }

    public function findByName(string $name): ?Branch
    {
        return $this->builder->where('name', '=', $name)->first();
    }

    public function find(string $id): ?Branch
    {
        return $this->builder->find($id);
    }

    public function getBranchUsers(): Collection
    {
        return $this->model->branchUsers()->get();
    }
}
