<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchUser;

class BaseBranchUserRepository implements BranchUserRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly BranchUser $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function create(Branch $branch, array $attributes): BranchUser
    {
        return $branch->branchUsers()->create($attributes);
    }

    public function update(string $id, array $attributes): int
    {
        return $this->builder->where('id', '=', $id)->update($attributes);
    }

    public function find(string $id): ?BranchUser
    {
        return $this->builder->find($id);
    }

    public function findByEmail(string $email): ?BranchUser
    {
        return $this->builder->where('email', '=', $email)->first();
    }
}
