<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchUser;

interface BranchUserRepository
{
    public function create(Branch $branch, array $attributes): BranchUser;

    public function update(string $id, array $attributes): int;

    public function find(string $id): ?BranchUser;

    public function findByEmail(string $email): ?BranchUser;
}
