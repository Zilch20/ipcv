<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\Customer;

class BaseBankInformationRepository implements BankInformationRepository
{
    private readonly Builder $query;

    public function __construct(private readonly BankInformation $model)
    {
        $this->query = $this->model->newQuery();
    }

    public function create(Customer $customer, array $attributes): BankInformation
    {
        return $customer->bankInformation()->create($attributes);
    }

    public function update(string $id, array $attributes): int
    {
        return $this->query->where('id', '=', $id)->update($attributes);
    }

    public function findBy(string $accountNumber, string $bankName, string $customerId): ?BankInformation
    {
        return $this->query
            ->where('account_number', '=', $accountNumber)
            ->where('bank_name', '=', $bankName)
            ->where('customer_id', '=', $customerId)
            ->first()
        ;
    }

    public function find(string $id): ?BankInformation
    {
        return $this->query->find($id);
    }
}
