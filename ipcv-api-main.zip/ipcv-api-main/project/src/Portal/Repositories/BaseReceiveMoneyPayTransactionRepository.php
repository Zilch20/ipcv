<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;

class BaseReceiveMoneyPayTransactionRepository implements ReceiveMoneyTransactionRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly ReceiveMoneyPayTransaction $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function create(array $attributes): ReceiveMoneyPayTransaction
    {
        return $this->builder->create($attributes);
    }

    public function find(string $id): ?ReceiveMoneyPayTransaction
    {
        return $this->builder->find($id);
    }

    public function findBy(array $filters): ?ReceiveMoneyPayTransaction
    {
        foreach ($filters as $field => $value) {
            $this->builder->where($field, '=', $value);
        }

        return $this->builder->first();
    }

    public function getByMtcn(string $mtcn): Collection
    {
        return $this->builder->where('mtcn', '=', $mtcn)->get();
    }

    public function getByBranch(Branch $branch): Collection
    {
        return $this->builder->where('branch_id', '=', $branch->id)->get();
    }

    public function getByCustomer(Customer $customer): Collection
    {
        return $this->builder->where('customer_id', '=', $customer->id)->get();
    }

    public function update(array $attributes): bool
    {
        return $this->model->update($attributes);
    }
}
