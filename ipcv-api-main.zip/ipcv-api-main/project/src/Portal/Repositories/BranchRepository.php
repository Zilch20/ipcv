<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchOwner;

interface BranchRepository
{
    public function createIndependent(array $attributes): Branch;

    public function create(BranchOwner $branchOwner, array $attributes);

    public function update(string $id, array $attributes): int;

    public function findByName(string $name): ?Branch;

    public function find(string $id): ?Branch;
}
