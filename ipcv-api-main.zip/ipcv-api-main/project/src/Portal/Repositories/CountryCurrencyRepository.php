<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use IPCV\API\Portal\Models\CountryCurrency;

interface CountryCurrencyRepository
{
    public function create(array $attributes): CountryCurrency;

    public function find(int $id);

    public function findOneBy(array $filter): ?CountryCurrency;
}
