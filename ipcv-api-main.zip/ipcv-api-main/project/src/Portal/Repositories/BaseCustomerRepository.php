<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use IPCV\API\Portal\Models\Customer;

class BaseCustomerRepository implements CustomerRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly Customer $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function find(string $id): ?Customer
    {
        return $this->builder->find($id);
    }

    public function create(array $attributes): Customer
    {
        return $this->builder->create($attributes);
    }

    public function update(string $id, array $attributes): int
    {
        return $this->builder->where('id', '=', $id)->update($attributes);
    }
}
