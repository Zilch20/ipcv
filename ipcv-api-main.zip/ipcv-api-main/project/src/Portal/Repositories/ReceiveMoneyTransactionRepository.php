<?php

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;

interface ReceiveMoneyTransactionRepository
{
    public function create(array $attributes): ReceiveMoneyPayTransaction;

    public function update(array $attributes): bool;

    public function findBy(array $filters): ?ReceiveMoneyPayTransaction;

    public function find(string $id): ?ReceiveMoneyPayTransaction;

    public function getByMtcn(string $mtcn): Collection;

    public function getByBranch(Branch $branch): Collection;

    public function getByCustomer(Customer $customer): Collection;
}
