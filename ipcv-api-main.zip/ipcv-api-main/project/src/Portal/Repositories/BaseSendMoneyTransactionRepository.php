<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\SendMoneyTransaction;

class BaseSendMoneyTransactionRepository implements SendMoneyTransactionRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly SendMoneyTransaction $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function create(
        GovernmentIdentification $governmentIdentification,
        Branch $branch,
        array $attributes
    ): SendMoneyTransaction {
        $data = [
            'government_identification_id' => $governmentIdentification->id,
            'branch_id' => $branch->id,
            'customer_id' => $governmentIdentification->customer_id,
            ...$attributes,
        ];

        return $this->builder->create($data);
    }

    public function find(string $id): ?SendMoneyTransaction
    {
        return $this->builder->find($id);
    }

    public function findOneBy(array $filters): ?SendMoneyTransaction
    {
        foreach ($filters as $field => $value) {
            $this->builder->where($field, '=', $value);
        }

        return $this->builder->first();
    }

    public function getByMtcn(string $mtcn): Collection
    {
        return $this->builder->where('mtcn', '=', $mtcn)->get();
    }

    public function getByBranch(Branch $branch): Collection
    {
        return $this->builder->where('branch_id', '=', $branch->id)->get();
    }

    public function getByCustomer(Customer $customer): Collection
    {
        return $this->builder->where('customer_id', '=', $customer->id)->get();
    }
}
