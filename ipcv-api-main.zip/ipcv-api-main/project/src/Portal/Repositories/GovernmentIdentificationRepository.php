<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;

interface GovernmentIdentificationRepository
{
    public function create(Customer $customer, array $attributes): GovernmentIdentification;

    public function update(string $id, array $attributes): int;

    public function find(string $id): ?GovernmentIdentification;

    public function findByNumberAndType(string $number, string $type): ?GovernmentIdentification;

    public function findByCustomerId(string $customerId): Collection;
}
