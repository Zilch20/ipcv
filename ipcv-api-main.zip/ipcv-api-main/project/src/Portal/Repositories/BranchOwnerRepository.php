<?php

namespace IPCV\API\Portal\Repositories;

use IPCV\API\Portal\Models\BranchOwner;

interface BranchOwnerRepository
{
    public function create(array $attributes): BranchOwner;

    public function update(string $id, array $attributes): int;

    public function find(string $id): ?BranchOwner;

    public function findByName(string $name): ?BranchOwner;
}
