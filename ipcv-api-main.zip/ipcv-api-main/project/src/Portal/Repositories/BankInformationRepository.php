<?php

namespace IPCV\API\Portal\Repositories;

use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\Customer;

interface BankInformationRepository
{
    public function create(Customer $customer, array $attributes): BankInformation;

    public function update(string $id, array $attributes): int;

    public function findBy(string $accountNumber, string $bankName, string $customerId): ?BankInformation;

    public function find(string $id): ?BankInformation;
}
