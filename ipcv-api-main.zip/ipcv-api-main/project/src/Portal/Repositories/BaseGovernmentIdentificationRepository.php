<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;

class BaseGovernmentIdentificationRepository implements GovernmentIdentificationRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly GovernmentIdentification $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function find(string $id): ?GovernmentIdentification
    {
        return $this->builder->find($id);
    }

    public function create(Customer $customer, array $attributes): GovernmentIdentification
    {
        return $customer->governmentIdentifications()->create($attributes);
    }

    public function update(string $id, array $attributes): int
    {
        return $this->builder->where('id', '=', $id)->update($attributes);
    }

    public function findByNumberAndType(string $number, string $type): ?GovernmentIdentification
    {
        return $this
            ->builder
            ->where('type', '=', $type)
            ->where('number', '=', $number)
            ->first()
        ;
    }

    public function findByCustomerId(string $customerId): Collection
    {
        return $this
            ->builder
            ->where('customer_id', '=', $customerId)
            ->get()
        ;
    }
}
