<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use IPCV\API\Portal\Models\CountryCurrency;

class BaseCountryCurrencyRepository implements CountryCurrencyRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly CountryCurrency $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function create(array $attributes): CountryCurrency
    {
        return $this->builder->create($attributes);
    }

    public function find(int $id): ?CountryCurrency
    {
        return $this->builder->find($id);
    }

    public function findOneBy(array $filter): ?CountryCurrency
    {
        foreach ($filter as $field => $value) {
            $this->builder->where($field, '=', $value);
        }

        return $this->builder->first();
    }
}
