<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Repositories;

use Illuminate\Database\Eloquent\Builder;
use IPCV\API\Portal\Models\BranchOwner;

class BaseBranchOwnerRepository implements BranchOwnerRepository
{
    private readonly Builder $builder;

    public function __construct(private readonly BranchOwner $model)
    {
        $this->builder = $this->model->newQuery();
    }

    public function create(array $attributes): BranchOwner
    {
        return $this->builder->create($attributes);
    }

    public function update(string $id, array $attributes): int
    {
        return $this->builder->where('id', '=', $id)->update($attributes);
    }

    public function find(string $id): ?BranchOwner
    {
        return $this->builder->find($id);
    }

    public function findByName(string $name): ?BranchOwner
    {
        return $this->builder->where('name', '=', $name)->first();
    }
}
