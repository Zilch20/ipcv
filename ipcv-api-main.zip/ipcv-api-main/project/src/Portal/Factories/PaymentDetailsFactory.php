<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use Illuminate\Http\Request;
use IPCV\WesternUnion\DestinationCountryCurrency;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\ExpectedPayoutLocation;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\Option;
use IPCV\WesternUnion\OriginalDestinationCountryCurrency;
use IPCV\WesternUnion\OriginatingCountryCurrency;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\PaymentType;
use IPCV\WesternUnion\RecordingCountryCurrency;
use IPCV\WesternUnion\TransactionType;

final class PaymentDetailsFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(Request $request): PaymentDetails
    {
        $paymentDetails = new PaymentDetails();

        $expectedPayoutLocation = (new ExpectedPayoutLocation())
            ->setStateCode($request->input('payment_details.expected_payout_location.state_code'))
            ->setCity($request->input('payment_details.expected_payout_location.city'))
        ;

        if ($request->has('payment_details.recording_country_currency')) {
            $recordingCountry = new RecordingCountryCurrency(
                new IsoCode(
                    $request->input('payment_details.recording_country_currency.country_code'),
                    $request->input('payment_details.recording_country_currency.currency_code'),
                )
            );

            $paymentDetails->setRecordingCountryCurrency($recordingCountry);
        }

        $originatingCountry = new OriginatingCountryCurrency(
            new IsoCode(
                $request->input('payment_details.originating_country_currency.country_code'),
                $request->input('payment_details.originating_country_currency.currency_code'),
            )
        );

        $destinationCountry = new DestinationCountryCurrency(
            new IsoCode(
                $request->input('payment_details.destination_country_currency.country_code'),
                $request->input('payment_details.destination_country_currency.currency_code'),
            )
        );

        if ($request->has('payment_details.original_destination_country_currency')) {
            $originalDestinationCountryCurrency = new OriginalDestinationCountryCurrency(
                new IsoCode(
                    $request->input('payment_details.original_destination_country_currency.country_code'),
                    $request->input('payment_details.original_destination_country_currency.currency_code'),
                )
            );

            $paymentDetails->setOriginalDestinationCountryCurrency($originalDestinationCountryCurrency);
        }

        $paymentDetails
            ->setTransactionType(TransactionType::from($request->input('payment_details.transaction_type')))
            ->setPaymentType(PaymentType::from($request->input('payment_details.payment_type')))
            ->setExpectedPayoutLocation($expectedPayoutLocation)
            ->setOriginatingCountryCurrency($originatingCountry)
            ->setDestinationCountryCurrency($destinationCountry)
            ->setPayWoIdIndicator(Option::N)
            ->setDuplicateDetectionFlag('D')
        ;

        if ($request->has('payment_details.exchange_rate')) {
            $paymentDetails->setExchangeRate($request->input('payment_details.exchange_rate'));
        }

        return $paymentDetails;
    }
}
