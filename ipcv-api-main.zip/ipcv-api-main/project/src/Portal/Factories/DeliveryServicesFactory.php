<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use Illuminate\Http\Request;
use IPCV\WesternUnion\DeliveryServices;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Message;
use IPCV\WesternUnion\ServiceType;

final class DeliveryServicesFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(Request $request): DeliveryServices
    {
        $message = new Message();

        foreach ($request->input('delivery_services.message') as $msg) {
            $message->add($msg);
        }

        return (new DeliveryServices())
            ->setCode(ServiceType::from($request->input('delivery_services.code')))
            ->setMessage($message)
            ->setRoutingCode($request->input('delivery_services.routing_code', ''))
        ;
    }
}
