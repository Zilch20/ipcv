<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\Customer;
use IPCV\WesternUnion\Address;
use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\MobilePhone;
use IPCV\WesternUnion\Name;
use IPCV\WesternUnion\PhoneNumber;
use IPCV\WesternUnion\ReceiveMoneyReceiver;

class ReceiveMoneyReceiverFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(
        Customer $customer,
        ComplianceDetails $complianceDetails,
        BankInformation $bankInformation = null
    ): ReceiveMoneyReceiver {
        $name = Name::createTypeD(
            $customer->first_name,
            $customer->middle_name ?? '',
            $customer->last_name,
        );

        $customerCountryCode = new CountryCode(
            new IsoCode(
                $customer->country_code,
                $customer->currency_code
            ),
            $customer->country
        );

        $address = new Address(
            $customer->address_line_1,
            $customer->state,
            $customer->postal_code,
            $customerCountryCode
        );

        $address->setAddressLine2($customer->address_line_2 ?? '');

        $mobilePhone = new MobilePhone(
            new PhoneNumber(
                $customer->phone_country_code,
                $customer->phone_number,
            )
        );

        $receiver = new ReceiveMoneyReceiver();
        $receiver
            ->setName($name)
            ->setAddress($address)
            ->setComplianceDetails($complianceDetails)
            ->setEmail($customer->email)
            ->setPhoneCountryCode($customer->phone_country_code)
            ->setContactPhone($customer->phone_number)
            ->setMobilePhone($mobilePhone)
        ;

        if ($bankInformation !== null) {
            $receiver->setBankDetails(BankDetailsFactory::create($bankInformation));
        }

        return $receiver;
    }
}
