<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use Illuminate\Http\Request;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\DeviceType;
use IPCV\WesternUnion\Exception\InvalidArgumentException;

final class DeviceFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(Request $request): Device
    {
        $device = new Device();

        if ($request->has('device.id')) {
            $device->setId($request->input('device.id'));
        }

        if ($request->has('device.type')) {
            $device->setType(DeviceType::from($request->input('device.type')));
        }

        return $device;
    }
}
