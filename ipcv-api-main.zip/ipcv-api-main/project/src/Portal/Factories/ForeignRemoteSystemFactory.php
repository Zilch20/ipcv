<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use Illuminate\Support\Str;
use IPCV\API\Portal\Models\Branch;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\ForeignRemoteSystem;

final class ForeignRemoteSystemFactory
{
    private const PH994_FSID = 'WGHHPH9940P';

    private const DEFAULT_FTID = 'PH513ARP001A';

    /**
     * @throws InvalidArgumentException
     */
    public static function create(Branch $branch, string $identifier): ForeignRemoteSystem
    {
        $naid = $branch->naid;
        $ftid = $branch->ftid;

        if ($naid === 'PH994') {
            $identifier = self::PH994_FSID;
        }

        return new ForeignRemoteSystem($identifier, Str::random(), $ftid);
    }
}
