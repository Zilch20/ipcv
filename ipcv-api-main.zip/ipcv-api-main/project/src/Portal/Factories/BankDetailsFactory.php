<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use IPCV\API\Portal\Models\BankInformation;
use IPCV\WesternUnion\BankDetails;
use IPCV\WesternUnion\Exception\InvalidArgumentException;

final class BankDetailsFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(BankInformation $bankInformation): BankDetails
    {
        return (new BankDetails())
            ->setName($bankInformation->bank_name)
            ->setAccountNumber($bankInformation->account_number)
            ->setAccountType($bankInformation->account_type)
        ;
    }
}
