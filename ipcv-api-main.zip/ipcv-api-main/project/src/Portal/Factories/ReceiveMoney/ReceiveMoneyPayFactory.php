<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories\ReceiveMoney;

use IPCV\API\Portal\Factories\FinancialsFactory;
use IPCV\API\Portal\Factories\PaymentDetailsFactory;
use IPCV\API\Portal\Http\Requests\ReceiveMoney\ReceiveMoneyPayFormRequest;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\DeviceType;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\ReceiveMoneyPay\Request as ReceiveMoneyPayRequest;
use IPCV\WesternUnion\ReceiveMoneyReceiver;

class ReceiveMoneyPayFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(
        ReceiveMoneyPayFormRequest $request,
        ReceiveMoneyReceiver $receiveMoneyReceiver,
        ForeignRemoteSystem $foreignRemoteSystem,
    ): ReceiveMoneyPayRequest {
        $device = (new Device())
            ->setId('IPCV')
            ->setType(DeviceType::WEB)
        ;

        $r = new ReceiveMoneyPayRequest();
        $r
            ->setDevice($device)
            ->setChannel(new Channel('H2H', 'IPCV', '9500'))
            ->setReceiver($receiveMoneyReceiver)
            ->setPaymentDetails(PaymentDetailsFactory::create($request))
            ->setFinancials(FinancialsFactory::create($request))
            ->setMoneyTransferKey($request->input('money_transfer_key'))
            ->setNewMtcn($request->input('new_mtcn'))
            ->setMtcn($request->input('mtcn'))
            ->setPayOrDoNotPayIndicator('P')
            ->setForeignRemoteSystem($foreignRemoteSystem)
        ;

        return $r;
    }
}
