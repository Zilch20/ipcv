<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories\ReceiveMoney;

use Illuminate\Http\Request;
use IPCV\API\Portal\Factories\ForeignRemoteSystemFactory;
use IPCV\API\Portal\Models\Branch;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DestinationCountryCurrency;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\DeviceType;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\PaymentTransaction;
use IPCV\WesternUnion\ReceiveMoneySearch\Request as ReceiveMoneySearchRequest;

final class ReceiveMoneySearchFactory
{
    public static function create(
        Request $request,
        Branch $branch,
        string $identifier
    ): ReceiveMoneySearchRequest {
        $device = (new Device())
            ->setId('IPCV')
            ->setType(DeviceType::WEB)
        ;

        $isoCode = new IsoCode(
            $request->input('payment_details.destination_country_currency.country_code'),
            $request->input('payment_details.destination_country_currency.currency_code'),
        );

        $paymentDetails = (new PaymentDetails())
            ->setDestinationCountryCurrency(new DestinationCountryCurrency($isoCode))
            ->setDuplicateDetectionFlag('D')
        ;
        $paymentTransaction = (new PaymentTransaction())
            ->setPaymentDetails($paymentDetails)
            ->setMtcn($request->input('mtcn'))
        ;

        return (new ReceiveMoneySearchRequest())
            ->setDevice($device)
            ->setChannel(new Channel('H2H', 'IPCV', '9500'))
            ->setPaymentTransaction($paymentTransaction)
            ->setForeignRemoteSystem(ForeignRemoteSystemFactory::create($branch, $identifier));
    }
}
