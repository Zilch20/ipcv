<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use Illuminate\Http\Request;
use IPCV\API\Portal\Models\Customer;
use IPCV\WesternUnion\Address;
use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\MobilePhone;
use IPCV\WesternUnion\Name;
use IPCV\WesternUnion\PhoneNumber;
use IPCV\WesternUnion\Receiver;

class ReceiverFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(Request $request): Receiver
    {
        $receiver = new Receiver();

        $name = Name::createTypeD(
            $request->input('receiver.name.first_name'),
            $request->input('receiver.name.middle_name'),
            $request->input('receiver.name.last_name'),
        );

        $countryCode = new CountryCode(
            new IsoCode(
                $request->input('receiver.address.country_code'),
                $request->input('receiver.address.currency_code')
            ),
            $request->input('receiver.address.country_name')
        );

        $address = new Address(
            $request->input('receiver.address.line_1'),
            $request->input('receiver.address.state'),
            $request->input('receiver.address.postal_code'),
            $countryCode
        );

        $address->setAddressLine2($request->input('receiver.address.line_2', ''));

        $mobilePhone = new MobilePhone(
            new PhoneNumber(
                $request->input('receiver.phone.phone_country_code'),
                $request->input('receiver.phone.number'),
            )
        );

        $receiver
            ->setName($name)
            ->setAddress($address)
            ->setPhoneCountryCode($request->input('receiver.phone.phone_country_code'))
            ->setMobilePhone($mobilePhone)
        ;

        return $receiver;
    }

    public static function createFromCustomer(Customer $customer): Receiver
    {
        $receiver = new Receiver();

        $name = Name::createTypeD(
            $customer->first_name,
            $customer->middle_name,
            $customer->last_name,
        );

        $countryCode = new CountryCode(
            new IsoCode(
                $customer->country_code,
                $customer->currency_code
            ),
            $customer->country
        );

        $address = new Address(
            $customer->address_line_1,
            $customer->state,
            $customer->postal_code,
            $countryCode
        );

        $address->setAddressLine2($customer->address_line_2 ?? '');

        $mobilePhone = new MobilePhone(
            new PhoneNumber(
                $customer->phone_country_code,
                $customer->phone_number,
            )
        );

        $receiver
            ->setName($name)
            ->setAddress($address)
            ->setPhoneCountryCode($customer->phone_country_code)
            ->setMobilePhone($mobilePhone)
        ;

        return $receiver;
    }
}
