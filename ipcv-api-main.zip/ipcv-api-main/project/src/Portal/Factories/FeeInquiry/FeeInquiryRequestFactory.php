<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories\FeeInquiry;

use Illuminate\Http\Request;
use IPCV\API\Portal\Factories\DeliveryServicesFactory;
use IPCV\API\Portal\Factories\DeviceFactory;
use IPCV\API\Portal\Factories\FinancialsFactory;
use IPCV\API\Portal\Factories\ForeignRemoteSystemFactory;
use IPCV\API\Portal\Factories\PaymentDetailsFactory;
use IPCV\API\Portal\Factories\PromotionsFactory;
use IPCV\API\Portal\Models\Branch;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\FeeInquiry\Request as FeeInquiryRequest;

class FeeInquiryRequestFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(Request $request, Branch $branch): FeeInquiryRequest
    {
        return (new FeeInquiryRequest())
            ->setDevice(DeviceFactory::create($request))
            ->setChannel(new Channel('H2H', 'IPCV', '9500'))
            ->setFinancials(FinancialsFactory::create($request))
            ->setPaymentDetails(PaymentDetailsFactory::create($request))
            ->setPromotions(PromotionsFactory::create($request))
            ->setDeliveryServices(DeliveryServicesFactory::create($request))
            ->setForeignRemoteSystem(ForeignRemoteSystemFactory::create($branch, config('western_union.identifier')))
        ;
    }
}
