<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use Illuminate\Http\Request;
use IPCV\WesternUnion\Financials;

final class FinancialsFactory
{
    public static function create(Request $request): Financials
    {
        $financials = new Financials();

        if ($request->has('financials.originators_principal_amount')) {
            $financials->setOriginatorsPrinicpalAmount($request->input('financials.originators_principal_amount'));
        }

        if ($request->has('financials.destination_principal_amount')) {
            $financials->setDestinationPrinicipalAmount($request->input('financials.destination_principal_amount'));
        }

        if ($request->has('financials.gross_total_amount')) {
            $financials->setGrossTotalAmount($request->input('financials.gross_total_amount'));
        }

        if ($request->has('financials.pay_amount')) {
            $financials->setPayAmount($request->input('financials.pay_amount'));
        }

        if ($request->has('financials.principal_amount')) {
            $financials->setPrincipalAmount($request->input('financials.principal_amount'));
        }

        if ($request->has('financials.charges')) {
            $financials->setCharges($request->input('financials.charges'));
        }

        if ($request->has('financials.tolls')) {
            $financials->setTolls($request->input('financials.tolls'));
        }

        if ($request->has('financials.plus_charges_amount')) {
            $financials->setPlusChargesAmount($request->input('financials.plus_charges_amount'));
        }

        if ($request->has('financials.message_charge')) {
            $financials->setMessageCharge($request->input('financials.message_charge'));
        }

        return $financials;
    }
}
