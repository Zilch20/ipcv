<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use Illuminate\Http\Request;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Promotions;

final class PromotionsFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(Request $request): Promotions
    {
        return (new Promotions())
            ->setCouponsPromotions($request->input('coupons_promotions', ''))
            ->setSenderPromoCode($request->input('sender_promo_code', ''))
        ;
    }
}
