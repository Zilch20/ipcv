<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use IPCV\API\Portal\Models\Customer;
use IPCV\WesternUnion\Address;
use IPCV\WesternUnion\BankDetails;
use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\MobilePhone;
use IPCV\WesternUnion\Name;
use IPCV\WesternUnion\PermanentChange;
use IPCV\WesternUnion\PhoneNumber;
use IPCV\WesternUnion\PreferredCustomer;
use IPCV\WesternUnion\Sender;

final class SenderFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function createFromCustomer(
        Customer $customer,
        ComplianceDetails $complianceDetails,
        BankDetails $bankDetails = null
    ): Sender {
        $name = Name::createTypeD(
            $customer->first_name,
            $customer->middle_name ?? '',
            $customer->last_name,
        );

        $countryCode = new CountryCode(
            new IsoCode(
                $customer->country_code,
                $customer->currency_code
            ),
            $customer->country
        );

        $address = new Address(
            $customer->address_line_1,
            $customer->state,
            $customer->postal_code,
            $countryCode
        );
        $address
            ->setCity($customer->city)
            ->setAddressLine2($customer->address_line_2 ?? '')
        ;

        $preferredCustomer = new PreferredCustomer(
            PermanentChange::None,
            $customer->mywu_number ?? ''
        );

        $mobilePhone = new MobilePhone(
            new PhoneNumber(
                $customer->phone_country_code,
                $customer->phone_number
            )
        );

        $sender = (new Sender())
            ->setName($name)
            ->setAddress($address)
            ->setPreferredCustomer($preferredCustomer)
            ->setComplianceDetails($complianceDetails)
            ->setEmail($customer->email)
            ->setPhoneCountryCode($customer->phone_country_code)
            ->setContactPhone($customer->phone_number)
            ->setMobilePhone($mobilePhone)
        ;

        if (null !== $bankDetails) {
            $sender->setBankDetails($bankDetails);
        }

        return $sender;
    }
}
