<?php

namespace IPCV\API\Portal\Factories\SendMoney;

use Illuminate\Http\Request as HttpRequest;
use IPCV\API\Portal\Factories\BankDetailsFactory;
use IPCV\API\Portal\Factories\ComplianceDetailsFactory;
use IPCV\API\Portal\Factories\DeliveryServicesFactory;
use IPCV\API\Portal\Factories\FinancialsFactory;
use IPCV\API\Portal\Factories\ForeignRemoteSystemFactory;
use IPCV\API\Portal\Factories\PaymentDetailsFactory;
use IPCV\API\Portal\Factories\PromotionsFactory;
use IPCV\API\Portal\Factories\ReceiverFactory;
use IPCV\API\Portal\Factories\SenderFactory;
use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Sender;
use IPCV\WesternUnion\SendMoneyValidation\Request as SendMoneyValidationRequest;

final class SendMoneyValidationRequestFactory
{
    private Branch $branch;

    private Customer $customer;

    private GovernmentIdentification $governmentIdentification;

    private BankInformation|null $bankInformation = null;

    public function __construct(private readonly HttpRequest $request, private readonly string $identifier)
    {
    }

    public function setBranch(Branch $branch): self
    {
        $this->branch = $branch;

        return $this;
    }

    public function setCustomer(Customer $customer): self
    {
        $this->customer = $customer;

        return $this;
    }

    public function setGovernmentIdentification(GovernmentIdentification $governmentIdentification): self
    {
        $this->governmentIdentification = $governmentIdentification;

        return $this;
    }

    public function setBankInformation(?BankInformation $bankInformation): self
    {
        $this->bankInformation = $bankInformation;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function build(): SendMoneyValidationRequest
    {
        $request = new SendMoneyValidationRequest();

        $request
            ->setChannel(new Channel('H2H', 'IPCV', '9500'))
            ->setSender($this->createSender())
            ->setReciver(ReceiverFactory::create($this->request))
            ->setPromotions(PromotionsFactory::create($this->request))
            ->setPaymentDetails(PaymentDetailsFactory::create($this->request))
            ->setFinancials(FinancialsFactory::create($this->request))
            ->setDeliveryServices(DeliveryServicesFactory::create($this->request))
            ->setForeignRemoteSystem(ForeignRemoteSystemFactory::create($this->branch, $this->identifier))
        ;

        return $request;
    }

    /**
     * @throws InvalidArgumentException
     */
    private function createSender(): Sender
    {
        if (null !== $this->bankInformation) {
            return SenderFactory::createFromCustomer(
                $this->customer,
                $this->createComplianceDetails(),
                BankDetailsFactory::create($this->bankInformation)
            );
        }

        return SenderFactory::createFromCustomer($this->customer, $this->createComplianceDetails());
    }

    /**
     * @throws InvalidArgumentException
     */
    private function createComplianceDetails(): ComplianceDetails
    {
        return ComplianceDetailsFactory::create(
            $this->customer,
            $this->governmentIdentification,
            $this->request->input('transaction_reason'),
            $this->request->input('relationship_to_receiver'),
        );
    }
}
