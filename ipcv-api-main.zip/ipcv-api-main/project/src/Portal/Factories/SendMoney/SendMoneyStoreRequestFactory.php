<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories\SendMoney;

use Illuminate\Http\Request as HttpRequest;
use IPCV\API\Portal\Factories\BankDetailsFactory;
use IPCV\API\Portal\Factories\ComplianceDetailsFactory;
use IPCV\API\Portal\Factories\DeliveryServicesFactory;
use IPCV\API\Portal\Factories\FinancialsFactory;
use IPCV\API\Portal\Factories\ForeignRemoteSystemFactory;
use IPCV\API\Portal\Factories\PaymentDetailsFactory;
use IPCV\API\Portal\Factories\PromotionsFactory;
use IPCV\API\Portal\Factories\ReceiverFactory;
use IPCV\API\Portal\Factories\SenderFactory;
use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Sender;
use IPCV\WesternUnion\SendMoneyStore\Request as SendMoneyStoreRequest;

final class SendMoneyStoreRequestFactory
{
    private BankInformation|null $bankInformation = null;

    private string $mtcn = '';

    private string $newMtcn = '';

    private string $complianceDataBuffer = '';

    public function __construct(
        private readonly HttpRequest $request,
        private readonly Branch $branch,
        private readonly Customer $customer,
        private readonly string $identifier,
    ) {
    }

    public function setBankInformation(BankInformation $bankInformation): self
    {
        $this->bankInformation = $bankInformation;

        return $this;
    }

    public function setMtcn(string $mtcn): self
    {
        $this->mtcn = $mtcn;

        return $this;
    }

    public function setNewMtcn(string $newMtcn): self
    {
        $this->newMtcn = $newMtcn;

        return $this;
    }

    public function setComplianceDataBuffer(string $complianceDataBuffer): self
    {
        $this->complianceDataBuffer = $complianceDataBuffer;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function build(): SendMoneyStoreRequest
    {
        return (new SendMoneyStoreRequest())
            ->setChannel(new Channel('H2H', 'IPCV', '9500'))
            ->setMtcn($this->mtcn)
            ->setNewMtcn($this->newMtcn)
            ->setSender($this->createSender())
            ->setReceiver(ReceiverFactory::create($this->request))
            ->setPromotions(PromotionsFactory::create($this->request))
            ->setPaymentDetails(PaymentDetailsFactory::create($this->request))
            ->setFinancials(FinancialsFactory::create($this->request))
            ->setDeliveryServices(DeliveryServicesFactory::create($this->request))
            ->setForeignRemoteSystem(ForeignRemoteSystemFactory::create($this->branch, $this->identifier))
        ;
    }

    /**
     * @throws InvalidArgumentException
     */
    private function createSender(): Sender
    {
        if (null !== $this->bankInformation) {
            return SenderFactory::createFromCustomer(
                $this->customer,
                ComplianceDetailsFactory::createOnlyWithBuffer($this->complianceDataBuffer),
                BankDetailsFactory::create($this->bankInformation)
            );
        }

        return SenderFactory::createFromCustomer(
            $this->customer,
            ComplianceDetailsFactory::createOnlyWithBuffer($this->complianceDataBuffer)
        );
    }
}
