<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Factories;

use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\CurrentAddress;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Gender;
use IPCV\WesternUnion\IdDetails;
use IPCV\WesternUnion\IdType;
use IPCV\WesternUnion\Option;
use IPCV\WesternUnion\ThirdPartyDetails;

final class ComplianceDetailsFactory
{
    /**
     * @throws InvalidArgumentException
     */
    public static function create(
        Customer $customer,
        GovernmentIdentification $governmentIdentification,
        string $transactionReason,
        string $relationshipToReceiver,
    ): ComplianceDetails {
        $complianceDetails = (new ComplianceDetails())
            ->setTemplateId('UNI_01_S')
            ->setVersion('PH_1.1')
            ->setIdDetails(self::createIdDetails($governmentIdentification))
            ->setThirdPartyDetails(new ThirdPartyDetails(Option::N))
            ->setIdIssueDate($governmentIdentification->issue_date)
        ;

        if (null !== $governmentIdentification->expiry_date) {
            $complianceDetails->setIdExpirationDate($governmentIdentification->expiry_date);
        }

        $complianceDetails
            ->setDateOfBirth($customer->date_of_birth)
            ->setOccupation($customer->occupation)
            ->setTransactionReason($transactionReason)
            ->setCurrentAddress(self::createCurrentAddress($customer))
            ->setContactPhone($customer->phone_number)
            ->setCountryCode($customer->phone_country_code)
            ->setCountryOfBirth($customer->country_of_birth)
            ->setNationality($customer->nationality)
            ->setGender(Gender::fromString($customer->gender))
            ->setSourceOfFunds($customer->source_of_funds)
            ->setRelationshipToReceiverSender($relationshipToReceiver)
            ->setAckFlag('X')
            ->setMultiErrorSupported(Option::Y)
            ->setEmploymentPositionLevel($customer->employment_position_level)
        ;

        return $complianceDetails;
    }

    /**
     * @throws InvalidArgumentException
     */
    public static function createOnlyWithBuffer(string $complianceDataBuffer): ComplianceDetails
    {
        return (new ComplianceDetails())->setComplianceDataBuffer($complianceDataBuffer);
    }

    private static function createIdDetails(GovernmentIdentification $governmentIdentification): IdDetails
    {
        return new IdDetails(
            IdType::from($governmentIdentification->type),
            $governmentIdentification->country_issued,
            $governmentIdentification->number,
        );
    }

    /**
     * @throws InvalidArgumentException
     */
    private static function createCurrentAddress(Customer $customer): CurrentAddress
    {
        return (new CurrentAddress())
            ->setAddrLine1($customer->address_line_1)
            ->setAddrLine2($customer->address_line_2 ?? '')
            ->setCity($customer->city)
            ->setStateName($customer->state)
            ->setPostalCode($customer->postal_code)
            ->setCountry($customer->country)
        ;
    }
}
