<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Listeners;

use IPCV\API\Portal\Actions\ReceiveMoneySearch\ConvertToArrayReceiveMoneySearchResponse;
use IPCV\API\Portal\Events\FailedReceiveMoneySearchEvent;
use IPCV\API\Portal\Models\ReceiveMoneyPayStatus;
use IPCV\API\Portal\Models\ReceiveMoneySearchTransaction;

class CreateFailedReceiveMoneySearchTransaction
{
    public function __construct(
        private readonly ConvertToArrayReceiveMoneySearchResponse $convertToArrayReceiveMoneySearchResponse,
    ) {
    }

    /**
     * @throws \Exception
     */
    public function handle(FailedReceiveMoneySearchEvent $event): void
    {
        $responseAsArray = ($this->convertToArrayReceiveMoneySearchResponse)($event->response());

        ReceiveMoneySearchTransaction::query()->create([
                'status' => ReceiveMoneyPayStatus::FAILED,
                'timestamp' => $event->timestamp(),
                'xml_request' => $event->request()->toSimpleXML()->asXML(),
                'wu_response_headers' => \json_encode($event->response()->getHeaders()),
                'wu_response_body' => (string)$event->response()->getBody(),
                'branch_id' => $event->branch()->id,
            ]);
    }
}
