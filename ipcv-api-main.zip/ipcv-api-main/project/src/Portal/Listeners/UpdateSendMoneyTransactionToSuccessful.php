<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Listeners;

use IPCV\API\Portal\Actions\SendMoneyStore\GetMyWuPointsFromSendMoneyStoreResponse;
use IPCV\API\Portal\Events\SuccessfulSendMoneyStoreEvent;
use IPCV\API\Portal\Models\SendMoneyTransactionStatus;
use IPCV\API\Portal\Repositories\SendMoneyTransactionRepository;

class UpdateSendMoneyTransactionToSuccessful
{
    public function __construct(
        private readonly SendMoneyTransactionRepository $repository,
    ) {
    }

    public function handle(SuccessfulSendMoneyStoreEvent $event): void
    {
        $transaction  = $this->repository->findOneBy([
            'mtcn' => $event->request()->mtcn,
            'new_mtcn' => $event->request()->new_mtcn,
        ]);

        if ($transaction === null) {
            return;
        }

        $wuPoints = GetMyWuPointsFromSendMoneyStoreResponse::create($event->response()->getBody()->getContents());

        $transaction->update([
            'xml_request' => $event->request()->toSimpleXML()->asXML() ?? '',
            'wu_response_headers' => \json_encode($event->response()->getHeaders()) ?? '',
            'wu_response_body' => $event->response()->getBody()->__toString(),
            'new_points_earned' => $wuPoints->newMyWuPointsEarned,
            'total_points_earned' => $wuPoints->totalMyWuPointsEarned,
            'status' => SendMoneyTransactionStatus::SUCCESSFUL,
        ]);
    }
}
