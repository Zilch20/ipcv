<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Listeners;

use IPCV\API\Portal\Actions\SendMoneyStore\GetMyWuPointsFromSendMoneyStoreResponse;
use IPCV\API\Portal\Events\SuccessfulReceiveMoneyPayEvent;
use IPCV\API\Portal\Models\ReceiveMoneyPayStatus;
use IPCV\API\Portal\Repositories\ReceiveMoneyTransactionRepository;

class CreateSuccessfulReceiveMoneyPayTransaction
{
    public function __construct(
        private readonly ReceiveMoneyTransactionRepository $repository,
    ) {
    }

    public function handle(SuccessfulReceiveMoneyPayEvent $event): void
    {
        $request = $event->request();
        $response = $event->response();

        $wuPoints = GetMyWuPointsFromSendMoneyStoreResponse::create((string)$response->getBody());

        $this->repository->create([
            'mtcn' => $request->mtcn,
            'new_mtcn' => $request->new_mtcn,
            'money_transfer_key' => $request->money_transfer_key,
            'status' => ReceiveMoneyPayStatus::SUCCESSFUL,
            'timestamp' => $event->timestamp(),
            'new_points_earned' => $wuPoints->newMyWuPointsEarned,
            'total_points_earned' => $wuPoints->totalMyWuPointsEarned,
            'gross_total_amount' => $request->financials->gross_total_amount,
            'pay_amount' => $request->financials->pay_amount,
            'principal_amount' => $request->financials->principal_amount,
            'charges' => $request->financials->charges,
            'tolls' => $request->financials->tolls,
            'exchange_rate' => $request->payment_details->exchange_rate,
            'originating_currency_code' =>
                $request->payment_details->originating_country_currency->iso_code->currency_code,
            'originating_country_code' =>
                $request->payment_details->originating_country_currency->iso_code->country_code,
            'destination_country_code' =>
                $request->payment_details->destination_country_currency->iso_code->country_code,
            'destination_currency_code' =>
                $request->payment_details->destination_country_currency->iso_code->currency_code,
            'transaction_type' => $request->payment_details->transaction_type->value,
            'purpose' => $request->receiver->complianceDetails->transaction_reason,
            'source_of_funds' => $request->receiver->complianceDetails->Source_of_Funds,
            'relationship_to_sender' => $request->receiver->complianceDetails->Relationship_to_Receiver_Sender,
            'xml_request' => $event->request()->toSimpleXML()->asXML(),
            'wu_response_headers' => \json_encode($event->response()->getHeaders()),
            'wu_response_body' => (string)$event->response()->getBody(),

            'branch_id' => $event->branch()->id,
            'customer_id' => $event->governmentIdentification()->customer_id,
            'government_identification_id' => $event->governmentIdentification()->id,
        ]);
    }
}
