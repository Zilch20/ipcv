<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Listeners;

use IPCV\API\Portal\Actions\ReceiveMoneySearch\ConvertToArrayReceiveMoneySearchResponse;
use IPCV\API\Portal\Events\SuccessfulReceiveMoneySearchEvent;
use IPCV\API\Portal\Models\ReceiveMoneyPayStatus;
use IPCV\API\Portal\Models\ReceiveMoneySearchTransaction;

class CreateSuccessfulReceiveMoneySearchTransaction
{
    public function __construct(
        private readonly ConvertToArrayReceiveMoneySearchResponse $convertToArrayReceiveMoneySearchResponse,
    ) {
    }

    /**
     * @throws \Exception
     */
    public function handle(SuccessfulReceiveMoneySearchEvent $event): void
    {
        $responseAsArray = ($this->convertToArrayReceiveMoneySearchResponse)($event->response());

        ReceiveMoneySearchTransaction::query()->create([
                'status' => ReceiveMoneyPayStatus::SUCCESSFUL,
                'timestamp' => $event->timestamp(),
                'mtcn' => $responseAsArray['mtcn'],
                'new_mtcn' => $responseAsArray['new_mtcn'],
                'money_transfer_key' => $responseAsArray['money_transfer_key'],
                'sender_first_name' => $responseAsArray['sender']['name']['first_name'],
                'sender_middle_name' => $responseAsArray['sender']['name']['middle_name'],
                'sender_last_name' => $responseAsArray['sender']['name']['last_name'],
                'messages' => $responseAsArray['delivery_services']['message'],
                'xml_request' => $event->request()->toSimpleXML()->asXML(),
                'wu_response_headers' => \json_encode($event->response()->getHeaders()),
                'wu_response_body' => (string)$event->response()->getBody(),
                'branch_id' => $event->branch()->id,
            ]);
    }
}
