<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Listeners;

use IPCV\API\Portal\Events\FailedSendMoneyStoreEvent;
use IPCV\API\Portal\Models\SendMoneyTransactionStatus;
use IPCV\API\Portal\Repositories\SendMoneyTransactionRepository;

class UpdateSendMoneyTransactionToFailed
{
    public function __construct(
        private readonly SendMoneyTransactionRepository $repository,
    ) {
    }

    public function handle(FailedSendMoneyStoreEvent $event): void
    {
        $transaction = $this->repository->findOneBy([
            'mtcn' => $event->request()->mtcn,
            'new_mtcn' => $event->request()->new_mtcn
        ]);

        if ($transaction === null) {
            return;
        }

        $transaction->update([
            'xml_request' => $event->request()->toSimpleXML()->asXML() ?? '',
            'wu_response_headers' => \json_encode($event->response()->getHeaders()) ?? '',
            'wu_response_body' => $event->response()->getBody()->__toString(),
            'status' => SendMoneyTransactionStatus::FAILED,
        ]);
    }
}
