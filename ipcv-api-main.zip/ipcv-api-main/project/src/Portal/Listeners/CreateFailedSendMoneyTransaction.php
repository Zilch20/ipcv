<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Listeners;

use IPCV\API\Portal\Events\FailedSendMoneyStoreEvent;
use IPCV\API\Portal\Events\SuccessfulSendMoneyStoreEvent;
use IPCV\API\Portal\Models\SendMoneyTransaction;
use IPCV\API\Portal\Repositories\SendMoneyTransactionRepository;

class CreateFailedSendMoneyTransaction
{
    public function __construct(
        private readonly SendMoneyTransactionRepository $repository,
    ) {
    }

    public function handle(FailedSendMoneyStoreEvent $event): void
    {
        $this->repository->create(
            $event->governmentIdentification(),
            $event->branch(),
            $this->createAttributes($event)
        );
    }

    private function createAttributes(SuccessfulSendMoneyStoreEvent $event): array
    {
        $request = $event->request();
        $responseHeaders = $event->response()->getHeaders();
        $responseBody = $event->response()->getBody()->__toString();
        $branch = $event->branch();
        $governmentIdentification = $event->governmentIdentification();

        return [
            'mtcn' => $request->mtcn,
            'new_mtcn' => $request->new_mtcn,
            'originators_principal_amount' => $request->financials->originators_principal_amount ?? '',
            'destination_principal_amount' => $request->financials->destination_principal_amount ?? '',
            'gross_total_amount' => $request->financials->gross_total_amount,
            'exchange_rate' => $request->payment_details->exchange_rate,
            'originating_currency_code' =>
                $request->payment_details->originating_country_currency->iso_code->currency_code,
            'originating_country_code' =>
                $request->payment_details->originating_country_currency->iso_code->country_code,
            'destination_country_code' =>
                $request->payment_details->destination_country_currency->iso_code->country_code,
            'destination_currency_code' =>
                $request->payment_details->destination_country_currency->iso_code->currency_code,
            'transaction_type' => $request->payment_details->transaction_type,
            'purpose' => $request->sender->compliance_details->transaction_reason,
            'source_of_funds' => $request->sender->compliance_details->Source_of_Funds,
            'relationship_to_receiver' => $request->sender->compliance_details->Relationship_to_Receiver_Sender,
            'compliance_data_buffer' => $request->sender->compliance_details->compliance_data_buffer,
            'branch_id' => $branch->id,
            'customer_id' => $governmentIdentification->customer_id,
            'government_identification_id' => $governmentIdentification->id,
            'receiver_first_name' => $request->receiver->name->first_name,
            'receiver_middle_name' => $request->receiver->name->middle_name,
            'receiver_last_name' => $request->receiver->name->last_name,
            'messages' => $request->delivery_services->message->messages(),
            'xml_request' => $request->toSimpleXML()->asXML() ?? '',
            'wu_response_headers' => \json_encode($responseHeaders) ?? '',
            'wu_response_body' => $responseBody,
            'status' => SendMoneyTransaction::FAILED,
        ];
    }
}
