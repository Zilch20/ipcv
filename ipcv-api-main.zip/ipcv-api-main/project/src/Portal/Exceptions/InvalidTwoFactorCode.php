<?php

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class InvalidTwoFactorCode extends HttpException implements WesternUnionException
{
}
