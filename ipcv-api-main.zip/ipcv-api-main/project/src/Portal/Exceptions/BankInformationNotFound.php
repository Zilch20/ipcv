<?php

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class BankInformationNotFound extends HttpException implements WesternUnionException
{
}
