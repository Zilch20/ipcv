<?php

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class GovernmentIdentificationNotFound extends HttpException implements WesternUnionException
{
}
