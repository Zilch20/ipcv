<?php

namespace IPCV\API\Portal\Exceptions;

interface WesternUnionException
{
    public function getStatusCode(): int;

    public function getMessage(): string;
}
