<?php

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class InvalidTwoFactorRecoveryCode extends HttpException implements WesternUnionException
{
}
