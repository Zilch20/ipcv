<?php

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class InvalidPassword extends HttpException implements WesternUnionException
{
}
