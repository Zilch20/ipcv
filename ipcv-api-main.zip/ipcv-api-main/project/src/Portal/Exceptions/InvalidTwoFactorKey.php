<?php

declare(strict_types=1);

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class InvalidTwoFactorKey extends HttpException implements WesternUnionException
{
}
