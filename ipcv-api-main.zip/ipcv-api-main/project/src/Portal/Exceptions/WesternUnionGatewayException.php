<?php

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class WesternUnionGatewayException extends HttpException implements WesternUnionException
{
}
