<?php

namespace IPCV\API\Portal\Exceptions;

use Symfony\Component\HttpKernel\Exception\HttpException;

class CustomerNotFound extends HttpException implements WesternUnionException
{
}
