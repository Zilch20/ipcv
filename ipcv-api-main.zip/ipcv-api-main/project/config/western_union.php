<?php

return [
    'identifier' => env('WU_GATEWAY_IDENTIFIER', 'WGHHPH5130T'),
    'client' => [
        'base_uri' => env('WU_GATEWAY_BASE_URI', ''),
        'headers' => [
            'User-Agent' => 'ipcv-api/1.0',
            'Content-Type' => 'text/xml',
        ],
        'cert' => env('WU_GATEWAY_SSL_CERT'),
        'ssl_key' => [
            env('WU_GATEWAY_SSL_KEY'),
            env('WU_GATEWAY_SSL_KEY_PASSPHRASE'),
        ],
    ],
    'das_client' => [
        'base_uri' => env('DAS_BASE_URI', ''),
        'headers' => [
            'User-Agent' => 'ipcv-api/1.0',
            'Content-Type' => 'text/xml',
        ],
        'cert' => env('DAS_SSL_CERT'),
        'ssl_key' => [
            env('DAS_SSL_KEY'),
            env('DAS_SSL_KEY_PASSPHRASE'),
        ],
    ],

    'transaction' => [
        'payment_types' => [
            'Cash',
            'ACH',
            'DebitCardIntercahnge',
            'Adjustment',
            'Reinstate',
            'Refund',
            'Cancel',
            'Retailmoney',
        ],
        'relationships' => [
            'Family',
            'Friend',
            'Trade/BusinesPartner',
            'Employee/Employer',
            'Donor/Receiver of Ch',
            'Purchaser/Seller',
        ],
        'reasons' => [
            'Family Support/Living Expenses',
            'Saving/Investments',
            'Gift',
            'Goods & Services Payment',
            'Travel Expenses',
            'Education/School Fee',
            'Rent/Mortgage',
            'Emergency/Medical Aid',
            'Charity/Aid Payment',
            'Employee Payroll/Employee Expense',
        ],
        'fund_sources' => [
            'Cash Tips',
            'Sale of Goods/Property/Services',
            'Investment Income',
            'Salary',
            'Savings',
            'Borrowed Funds/Loan',
            'Gift',
            'Pension/Government/Welfare',
            'Inheritance',
            'Charitable Donations',
        ],
        'occupations' => [
            'Airline/Maritime Employee',
            'Art/Entertainment/Media/Sports',
            'Civil/Government Employee',
            'Domestic Helper',
            'Driver',
            'Teacher/Educator',
            'Hotel/Restaurant/Leisure',
            'Housewife/Child Care',
            'IT and Tech Professional',
            'Laborer-Agriculture',
            'Laborer-Construction',
            'Laborer-Manufacturing',
            'Laborer- Oil/Gas/Mining',
            'Medical/Health Care',
            'Non-profit/Volunteer',
            'Cosmetic/Personal Care',
            'Law Enforcement/Military',
            'Office Professional',
            'Prof Svc Practitioner',
            'Religious/Church Servant',
            'Retail Sales',
            'Retired',
            'Sales/Insurance/Real Estate',
            'Science/Research Professional',
            'Security Guard',
            'Self-Employed',
            'Skilled Trade/Specialist',
            'Student',
            'Unemployed',
        ],
        'position_levels' => [
            'Entry Level',
            'Mid-Level/Supervisory/Management',
            'Senior Level/Executive',
            'Owner',
        ],
        'id_types' => [
            [
                'label' => 'Passport',
                'value' => 'A',
                'has_expiry' => true,
            ],
            [
                'label' => "Driver's license",
                'value' => 'C',
                'has_expiry' => true,
            ],
            [
                'label' => 'PRC ID',
                'value' => '5',
                'has_expiry' => true,
            ],
            [
                'label' => 'NBI Clearance',
                'value' => '7',
                'has_expiry' => true,
            ],
            [
                'label' => 'Police Clearance',
                'value' => 'D',
                'has_expiry' => true,
            ],
            [
                'label' => 'Postal ID',
                'value' => '1',
                'has_expiry' => true,
            ],
            [
                'label' => "Voter's ID",
                'value' => 'M',
                'has_expiry' => true,
            ],
            [
                'label' => 'Barangay Certification',
                'value' => '3',
                'has_expiry' => true,
            ],
            [
                'label' => 'Government Service Insurance System (GSIS) e-Card',
                'value' => 'E',
                'has_expiry' => true,
            ],
            [
                'label' => 'Social Security System (SSS) Card',
                'value' => 'N',
                'has_expiry' => true,
            ],
            [
                'label' => 'Government issued national identification card',
                'value' => 'B',
                'has_expiry' => true,
            ],
            [
                'label' => 'Senior Citizen ID',
                'value' => 'W',
                'has_expiry' => true,
            ],
            [
                'label' => 'Overseas Workers Welfare Administration (OWWA) ID',
                'value' => 'V',
                'has_expiry' => true,
            ],
            [
                'label' => 'OFW ID',
                'value' => '6',
                'has_expiry' => true,
            ],
            [
                'label' => "Seaman's Book",
                'value' => 'R',
                'has_expiry' => true,
            ],
            [
                'label' => 'Alien/Immigrant Certificate of Registration',
                'value' => '8',
                'has_expiry' => true,
            ],
            [
                'label' => 'PWD/NCWDP ID',
                'value' => 'H',
                'has_expiry' => true,
            ],
            [
                'label' => 'DSWD Certificate',
                'value' => '9',
                'has_expiry' => true,
            ],
            [
                'label' => 'IBP ID',
                'value' => 'U',
                'has_expiry' => true,
            ],
            [
                'label' => 'Student ID',
                'value' => 'X',
                'has_expiry' => true,
            ],
            [
                'label' => 'Unified Multi Purpose ID (UMID)',
                'value' => '2',
                'has_expiry' => true,
            ],
            [
                'label' => 'Taxpayer’s ID (TIN)',
                'value' => '4',
                'has_expiry' => true,
            ],
            [
                'label' => 'Other government issued IDs',
                'value' => 'I',
                'has_expiry' => true,
            ],
        ],
        'delivery_codes' => [
            [
                'label' => 'Money in Minutes',
                'value' => '000'
            ],
            [
                'label' => 'Direct To Bank service',
                'value' => '500'
            ],
        ],
    ]
];
