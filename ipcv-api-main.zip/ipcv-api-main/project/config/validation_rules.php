<?php

use Illuminate\Validation\Rule;
use IPCV\WesternUnion\ServiceType;
use IPCV\WesternUnion\TransactionType;

return [
    'receive_money' => [
        'payment_details' => [
            'payment_details.expected_payout_location.state_code' => ['required'],
            'payment_details.expected_payout_location.city' => ['required'],

            'payment_details.destination_country_currency.currency_code' => ['required'],
            'payment_details.destination_country_currency.country_code' => ['required'],

            'payment_details.originating_country_currency.currency_code' => ['required'],
            'payment_details.originating_country_currency.country_code' => ['required'],

            'payment_details.originating_state' => ['required'],
            'payment_details.transaction_type' => ['required', Rule::in(TransactionType::values())],
            'payment_details.payment_type' => ['required'],
            'payment_details.exchange_rate' => ['required'],
        ],
        'financials' => [
            'financials.gross_total_amount' => ['required', 'integer', 'numeric'],
            'financials.pay_amount' => ['required', 'integer', 'numeric'],
            'financials.principal_amount' => ['required', 'integer', 'numeric'],
            'financials.charges' => ['required', 'integer', 'numeric'],
            'financials.tolls' => ['required', 'integer', 'numeric'],
        ],
    ],
    'receiver' => [
        'receiver.name.first_name' => ['required', 'string'],
        'receiver.name.middle_name' => ['string', 'string'],
        'receiver.name.last_name' => ['required', 'string'],

        'receiver.address.line_1' => ['required', 'string'],
        'receiver.address.line_2' => ['string'],
        'receiver.address.city' => ['required', 'string'],
        'receiver.address.state' => ['required', 'string'],
        'receiver.address.postal_code' => ['required', 'string'],
        'receiver.address.country_name' => ['required', 'string'],
        'receiver.address.country_code' => ['required', 'string'],
        'receiver.address.currency_code' => ['required', 'string'],

        'receiver.phone.phone_country_code' => ['required', 'string'],
        'receiver.phone.number' => ['required', 'string'],
    ],
    'payment_details' => [
        'payment_details.expected_payout_location.state_code' => ['required'],
        'payment_details.expected_payout_location.city' => ['required'],

        'payment_details.recording_country_currency.currency_code' => ['required'],
        'payment_details.recording_country_currency.country_code' => ['required'],

        'payment_details.destination_country_currency.currency_code' => ['required'],
        'payment_details.destination_country_currency.country_code' => ['required'],

        'payment_details.originating_country_currency.currency_code' => ['required'],
        'payment_details.originating_country_currency.country_code' => ['required'],

        'payment_details.originating_state' => ['required'],
        'payment_details.transaction_type' => ['required', Rule::in(TransactionType::values())],
        'payment_details.payment_type' => ['required'],
        'payment_details.exchange_rate' => ['required'],
    ],
    'financials' => [
        'financials.originators_principal_amount' => [
            'required',
            'integer',
            'numeric',
        ],
        'financials.destination_principal_amount' => [
            'required',
            'integer',
            'numeric',
        ],
        'financials.gross_total_amount' => ['required', 'integer', 'numeric'],
        'financials.plus_charges_amount' => ['required', 'integer', 'numeric'],
        'financials.charges' => ['required', 'integer', 'numeric'],
        'financials.message_charge' => ['required', 'integer', 'numeric'],
    ],
    'delivery_services' => [
        'delivery_services.code' => ['required', Rule::in(ServiceType::values())],
        'delivery_services.routing_code' => ['string'],
        'delivery_services.message' => ['max:4'],
        'delivery_services.message.*' => ['max:69', 'string'],

    ],
];
