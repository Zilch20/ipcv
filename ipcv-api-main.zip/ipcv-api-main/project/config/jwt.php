<?php

return [
    'secret' => env('JWT_SECRET', 'n3AqHvaQXRJOIDVvZ7sLPtlV3V1qcZ3GB7D4JjcUCpW9euhGpUlB9d0zvvFLXsy8'),
    'expiry_in_seconds' => env('JWT_EXPIRY_IN_SECONDS', 3600),
];
