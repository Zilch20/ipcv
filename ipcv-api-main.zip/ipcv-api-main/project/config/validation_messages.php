<?php

return [
    'delivery_services.message.max' => 'Maximum message count is :max.',
    'delivery_services.message.*.max' => 'Maximum character count per message is :max',
    'delivery_services.message.*.string' => 'Message should be of type string datatype.',
];
