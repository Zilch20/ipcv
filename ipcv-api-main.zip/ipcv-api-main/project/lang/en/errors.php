<?php

return [
    'auth' => [
        'invalid_two_factor_key' => 'Invalid Two-Factor key.',
        'invalid_two_factor_code' => 'Invalid Two-Factor code.',
    ],
    'branch_user' => [
        'not_found' => 'User not found.'
    ],
    'invalid_password' => 'Invalid password.',
    'no_bearer_token' => 'No bearer token.',
    'government_identification' => [
        'not_found' => 'Government identification not found.'
    ],
    'customer' => [
        'not_found' => 'Customer not found.'
    ]
];
