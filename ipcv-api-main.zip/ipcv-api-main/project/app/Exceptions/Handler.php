<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Http\JsonResponse;
use Illuminate\Validation\ValidationException;
use IPCV\API\Portal\Exceptions\WesternUnionException;
use Lcobucci\JWT\Exception as JwtLibraryException;
use Psr\Log\LogLevel;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\MethodNotAllowedHttpException;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * A list of exception types with their corresponding custom log levels.
     *
     * @var array<class-string<Throwable>, LogLevel::*>
     */
    protected $levels = [
        //
    ];

    /**
     * A list of the exception types that are not reported.
     *
     * @var array<int, class-string<Throwable>>
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed to the session on validation exceptions.
     *
     * @var array<int, string>
     */
    protected $dontFlash = [
        'current_password',
        'password',
        'password_confirmation',
    ];

    /**
     * Register the exception handling callbacks for the application.
     */
    public function register(): void
    {
    }

    public function render($request, Throwable $e)
    {
        if ($e instanceof ValidationException) {
            return $this->invalidJson($request, $e);
        }

        if  ($e instanceof MethodNotAllowedHttpException) {
            return new Response(status: $e->getStatusCode(), headers:  $e->getHeaders());
        }

        if ($e instanceof NotFoundHttpException) {
            return new Response(status: Response::HTTP_NOT_FOUND);
        }

        if ($e instanceof WesternUnionException) {
            return new JsonResponse(['message' => $e->getMessage()], $e->getStatusCode());
        }

        if ($e instanceof JwtLibraryException) {
            return new JsonResponse(['message' => $e->getMessage()], 400);
        }

        return parent::render($request, $e);
    }
}
