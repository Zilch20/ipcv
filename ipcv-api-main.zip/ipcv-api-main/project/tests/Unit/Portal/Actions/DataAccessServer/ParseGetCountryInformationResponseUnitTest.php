<?php

namespace Tests\Unit\WesternUnion\Actions\DataAccessServer;

use IPCV\API\Portal\Actions\DataAccessServer\ParseGetCountryInformationResponse;
use SimpleXMLElement;
use Tests\TestCase;

class ParseGetCountryInformationResponseUnitTest extends TestCase
{
    /**
     * @test
     */
    public function it_should_handle_xml_response(): void
    {
        $result = (new ParseGetCountryInformationResponse())(self::response());
        $this->assertEquals(expected: self::expectedResponse(), actual: $result);
    }

    private static function expectedResponse(): array
    {
        return [
            "PAYOUT CURRENCY" => [
                "Philippine Peso, US Dollar"
            ],
            "SEND CURRENCY" => [
                "Philippine Peso"
            ],
            "MAXIMUM SEND AMOUNT" => [
                "* N/A"
            ],
            "MAXIMUM PAYOUT AMOUNT" => [
                "* Maximum principal payout amount per person,per transaction,  per day, per week, per month and/or per calendar year"
            ],
            "MINIMUM MT PAYOUT AGE" => [
                "* 16 Years old"
            ],
            "COUNTRY GENERAL RESTRICTIONS" => [
                "Government restriction:",
                "* Student ID and Company ID or Employee ID issued by Private Entities are not  accepted in the Provinces of Tawi-Tawi, Basilan, Maguindanao and Sulu."
            ],
            "SEND RESTRICTIONS" => [
                "Government restrictions:",
                "* Senders must present valid photo identification document (among the list of  valid IDs below and if ID has expiry date, ID must not be expired).",
                "* Minors (below 18) cannot send money-they can only receive money transfer.",
                "Agent restrictions:",
                "* For Send Money Transfers, senders should contact the Philippine WU Customer  Hotline for particulars of each country.",
            ],
            "PAYOUT RESTRICTIONS" => [
                "* Payee must present correct Money Transfer Control Number (MTCN).",
                "* Large payouts of more than P500,000 (or its foreign currency equivalent), in  any single transaction with customers, shall only be made via check payment or  deposit to accounts. Payout in CASH is no longer allowed in this case, per BSP  Circular 942 released in February 2017. Please call the Western Union  Customer Service hotline for assistance.",
                "* For US Outbound transactions to Philippines, this will not be applicable. The  limit of sending to the Philippines from the US is set to USD9,500. This may  change depending on the current prevailing foreign exchange rate in the  market.",
                "* Payees must present valid photo identification document (among the list of  valid IDs below and if ID has expiry date, ID must not be expired).",
                "* Test Question is not allowed.",
                "Agent restrictions:and if ID has expiry date, ID must not be expired).",
                "* Minors (below 18) cannot send money-they can only receive money transfer.",
                "Agent restrictions:",
                "* For Send Money Transfers, senders should contact the Philippine WU Customer  Hotline for particulars of each country.",
                "* Payee must present correct Money Transfer Control Number (MTCN).",
                "* Large payouts of more than P500,000 (or its foreign currency equivalent), in  any single transaction with customers, shall only be made via check payment or  deposit to accounts. Payout in CASH is no longer allowed in this case, per BSP  Circular 942 released in February 2017. Please call the Western Union  Customer Service hotline for assistance.",
                "* For US Outbound transactions to Philippines, this will not be applicable. The  limit of sending to the Philippines from the US is set to USD9,500. This may  change depending on the current prevailing foreign exchange rate in the  market.",
                "* Payees must present valid photo identification document (among the list of  valid IDs below and if ID has expiry date, ID must not be expired).",
                "* Test Question is not allowed.",
                "Agent restrictions:",
                "* For US Dollar Payouts locations, payees should call the Philippine Customer  Hotline for the nearest location.",
            ],
            "ACCEPTABLE FORMS OF IDENTIFICATION" => [
                "Resident and Non-Resident:",
                "-Philsys/Phil ID/Nacional ID",
                "-Passport",
                "-Govt Office/ GOCC ID.",
                "-Driver's License.",
                "-Professional Regulation Commission (PRC) ID.",
                "-National Bureau of Investigation (NBI) Clearance.",
                "-Postal ID.",
                "-Voter's ID.",
                "-Government Service Insurance System (GSIS) E Card.",
                "-Employment ID.",
                "-Overseas Workers Welfare Association (OWWA) ID.",
                "-Overseas Filipino Workers (OFW) ID.",
                "-Seaman's Book.",
                "-Social Security System (SSS) ID.",
                "-Student ID (for students 16 - 21 years old).",
                "-In",
                "* For US Dollar Payouts locations, payees should call the Philippine Customer  Hotline for the nearest location.",
                "Resident and Non-Resident:",
                "-Philsys/Phil ID/Nacional ID",
                "-Passport",
                "-Govt Office/ GOCC ID.",
                "-Driver's License.",
                "-Professional Regulation Commission (PRC) ID.",
                "-National Bureau of Investigation (NBI) Clearance.",
                "-Postal ID.",
                "-Voter's ID.",
                "-Government Service Insurance System (GSIS) E Card.",
                "-Employment ID.",
                "-Overseas Workers Welfare Association (OWWA) ID.",
                "-Overseas Filipino Workers (OFW) ID.",
                "-Seaman's Book.",
                "-Social Security System (SSS) ID.",
                "-Student ID (for students 16 - 21 years old).",
                "-Integrated Bar (IBP) ID.",
                "-Senior Citizen Card.",
                "-Unified Multi-Purpose ID (UMID).",
                "-Police Clearance Certificate.",
                "-Alien Certificate of Registration.",
                "-Disabled Person Cert/ID NCWDP.",
                "-DSWD Certificate.",
                "-Tax Payers ID (TIN ID).",
                "-Barangay Certification.",
            ],
            "ADDITIONAL RESTRICTIONS AND INFORMATION" => [
                "* N/A"
            ],
            "SERVICES OFFERED" => [
                "* D2B: Dirct to Bank",
                "* QC:Quick Cash",
                "* QP: Quick Pay",
                "r.07152022.jpr.",
            ]
        ];
    }

    /**
     * @throws \Exception
     */
    private static function response(): SimpleXMLElement
    {
        $xml = <<<XML
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <soapenv:Body>
        <xrsi:h2h-das-reply xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <MTML>
                <REPLY HOST="AUHOST" CLIENT="WUCLIENT" TYPE="">
                    <DATA_CONTEXT>
                        <HEADER>
                            <ACCOUNT_NUM>APZ560113</ACCOUNT_NUM>
                            <DATA_MORE>N</DATA_MORE>
                            <DATA_NUM_RECS>126</DATA_NUM_RECS>
                            <NAME>GetCountryInfo</NAME>
                            <FSID>WGHHPH9940P</FSID>
                            <COUNTER_ID>PH994Y490</COUNTER_ID>
                            <TERM_ID>gGgO</TERM_ID>
                        </HEADER>
                        <RECORDSET>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>001</REC_NUMBER>
                                <INFO>Payout Currency: Philippine Peso, US Dollar</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>002</REC_NUMBER>
                                <INFO>Send Currency: Philippine Peso</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>003</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>004</REC_NUMBER>
                                <INFO>MAXIMUM SEND AMOUNT</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>005</REC_NUMBER>
                                <INFO>* N/A</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>006</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>007</REC_NUMBER>
                                <INFO>MAXIMUM PAYOUT AMOUNT</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>008</REC_NUMBER>
                                <INFO>* Maximum principal payout amount per person,per transaction,</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>009</REC_NUMBER>
                                <INFO>  per day, per week, per month and/or per calendar year</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>010</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>011</REC_NUMBER>
                                <INFO>MINIMUM MT PAYOUT AGE</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>012</REC_NUMBER>
                                <INFO>* 16 Years old</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>013</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>014</REC_NUMBER>
                                <INFO>COUNTRY GENERAL RESTRICTIONS</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>015</REC_NUMBER>
                                <INFO>Government restriction:</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>016</REC_NUMBER>
                                <INFO>* Student ID and Company ID or Employee ID issued by Private Entities are not</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>017</REC_NUMBER>
                                <INFO>  accepted in the Provinces of Tawi-Tawi, Basilan, Maguindanao and Sulu.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>018</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>019</REC_NUMBER>
                                <INFO>SEND RESTRICTIONS</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>020</REC_NUMBER>
                                <INFO>Government restrictions:</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>021</REC_NUMBER>
                                <INFO>* Senders must present valid photo identification document (among the list of</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>022</REC_NUMBER>
                                <INFO>  valid IDs below and if ID has expiry date, ID must not be expired).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>023</REC_NUMBER>
                                <INFO>* Minors (below 18) cannot send money-they can only receive money transfer.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>024</REC_NUMBER>
                                <INFO>Agent restrictions:</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>025</REC_NUMBER>
                                <INFO>* For Send Money Transfers, senders should contact the Philippine WU Customer</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>026</REC_NUMBER>
                                <INFO>  Hotline for particulars of each country.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>027</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>028</REC_NUMBER>
                                <INFO>PAYOUT RESTRICTIONS</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>029</REC_NUMBER>
                                <INFO>* Payee must present correct Money Transfer Control Number (MTCN).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>030</REC_NUMBER>
                                <INFO>* Large payouts of more than P500,000 (or its foreign currency equivalent), in</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>031</REC_NUMBER>
                                <INFO>  any single transaction with customers, shall only be made via check payment or</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>032</REC_NUMBER>
                                <INFO>  deposit to accounts. Payout in CASH is no longer allowed in this case, per BSP</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>033</REC_NUMBER>
                                <INFO>  Circular 942 released in February 2017. Please call the Western Union</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>034</REC_NUMBER>
                                <INFO>  Customer Service hotline for assistance.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>035</REC_NUMBER>
                                <INFO>* For US Outbound transactions to Philippines, this will not be applicable. The</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>036</REC_NUMBER>
                                <INFO>  limit of sending to the Philippines from the US is set to USD9,500. This may</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>037</REC_NUMBER>
                                <INFO>  change depending on the current prevailing foreign exchange rate in the</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>038</REC_NUMBER>
                                <INFO>  market.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>039</REC_NUMBER>
                                <INFO>* Payees must present valid photo identification document (among the list of</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>040</REC_NUMBER>
                                <INFO>  valid IDs below and if ID has expiry date, ID must not be expired).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>041</REC_NUMBER>
                                <INFO>* Test Question is not allowed.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>042</REC_NUMBER>
                                <INFO>Agent restrictions:and if ID has expiry date, ID must not be expired).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>043</REC_NUMBER>
                                <INFO>* Minors (below 18) cannot send money-they can only receive money transfer.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>044</REC_NUMBER>
                                <INFO>Agent restrictions:</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>045</REC_NUMBER>
                                <INFO>* For Send Money Transfers, senders should contact the Philippine WU Customer</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>046</REC_NUMBER>
                                <INFO>  Hotline for particulars of each country.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>047</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>048</REC_NUMBER>
                                <INFO>PAYOUT RESTRICTIONS</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>049</REC_NUMBER>
                                <INFO>* Payee must present correct Money Transfer Control Number (MTCN).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>050</REC_NUMBER>
                                <INFO>* Large payouts of more than P500,000 (or its foreign currency equivalent), in</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>051</REC_NUMBER>
                                <INFO>  any single transaction with customers, shall only be made via check payment or</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>052</REC_NUMBER>
                                <INFO>  deposit to accounts. Payout in CASH is no longer allowed in this case, per BSP</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>053</REC_NUMBER>
                                <INFO>  Circular 942 released in February 2017. Please call the Western Union</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>054</REC_NUMBER>
                                <INFO>  Customer Service hotline for assistance.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>055</REC_NUMBER>
                                <INFO>* For US Outbound transactions to Philippines, this will not be applicable. The</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>056</REC_NUMBER>
                                <INFO>  limit of sending to the Philippines from the US is set to USD9,500. This may</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>057</REC_NUMBER>
                                <INFO>  change depending on the current prevailing foreign exchange rate in the</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>058</REC_NUMBER>
                                <INFO>  market.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>059</REC_NUMBER>
                                <INFO>* Payees must present valid photo identification document (among the list of</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>060</REC_NUMBER>
                                <INFO>  valid IDs below and if ID has expiry date, ID must not be expired).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>061</REC_NUMBER>
                                <INFO>* Test Question is not allowed.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>062</REC_NUMBER>
                                <INFO>Agent restrictions:</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>063</REC_NUMBER>
                                <INFO>* For US Dollar Payouts locations, payees should call the Philippine Customer</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>064</REC_NUMBER>
                                <INFO>  Hotline for the nearest location.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>065</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>066</REC_NUMBER>
                                <INFO>ACCEPTABLE FORMS OF IDENTIFICATION</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>067</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>068</REC_NUMBER>
                                <INFO>Resident and Non-Resident:</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>069</REC_NUMBER>
                                <INFO>-Philsys/Phil ID/Nacional ID</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>070</REC_NUMBER>
                                <INFO>-Passport</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>071</REC_NUMBER>
                                <INFO>-Govt Office/ GOCC ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>072</REC_NUMBER>
                                <INFO>-Driver's License.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>073</REC_NUMBER>
                                <INFO>-Professional Regulation Commission (PRC) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>074</REC_NUMBER>
                                <INFO>-National Bureau of Investigation (NBI) Clearance.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>075</REC_NUMBER>
                                <INFO>-Postal ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>076</REC_NUMBER>
                                <INFO>-Voter's ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>077</REC_NUMBER>
                                <INFO>-Government Service Insurance System (GSIS) E Card.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>078</REC_NUMBER>
                                <INFO>-Employment ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>079</REC_NUMBER>
                                <INFO>-Overseas Workers Welfare Association (OWWA) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>080</REC_NUMBER>
                                <INFO>-Overseas Filipino Workers (OFW) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>081</REC_NUMBER>
                                <INFO>-Seaman's Book.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>082</REC_NUMBER>
                                <INFO>-Social Security System (SSS) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>083</REC_NUMBER>
                                <INFO>-Student ID (for students 16 - 21 years old).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>084</REC_NUMBER>
                                <INFO>-In</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>085</REC_NUMBER>
                                <INFO>* For US Dollar Payouts locations, payees should call the Philippine Customer</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>086</REC_NUMBER>
                                <INFO>  Hotline for the nearest location.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>087</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>088</REC_NUMBER>
                                <INFO>ACCEPTABLE FORMS OF IDENTIFICATION</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>089</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>090</REC_NUMBER>
                                <INFO>Resident and Non-Resident:</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>091</REC_NUMBER>
                                <INFO>-Philsys/Phil ID/Nacional ID</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>092</REC_NUMBER>
                                <INFO>-Passport</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>093</REC_NUMBER>
                                <INFO>-Govt Office/ GOCC ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>094</REC_NUMBER>
                                <INFO>-Driver's License.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>095</REC_NUMBER>
                                <INFO>-Professional Regulation Commission (PRC) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>096</REC_NUMBER>
                                <INFO>-National Bureau of Investigation (NBI) Clearance.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>097</REC_NUMBER>
                                <INFO>-Postal ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>098</REC_NUMBER>
                                <INFO>-Voter's ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>099</REC_NUMBER>
                                <INFO>-Government Service Insurance System (GSIS) E Card.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>100</REC_NUMBER>
                                <INFO>-Employment ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>101</REC_NUMBER>
                                <INFO>-Overseas Workers Welfare Association (OWWA) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>102</REC_NUMBER>
                                <INFO>-Overseas Filipino Workers (OFW) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>103</REC_NUMBER>
                                <INFO>-Seaman's Book.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>104</REC_NUMBER>
                                <INFO>-Social Security System (SSS) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>105</REC_NUMBER>
                                <INFO>-Student ID (for students 16 - 21 years old).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>106</REC_NUMBER>
                                <INFO>-Integrated Bar (IBP) ID.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>107</REC_NUMBER>
                                <INFO>-Senior Citizen Card.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>108</REC_NUMBER>
                                <INFO>-Unified Multi-Purpose ID (UMID).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>109</REC_NUMBER>
                                <INFO>-Police Clearance Certificate.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>110</REC_NUMBER>
                                <INFO>-Alien Certificate of Registration.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>111</REC_NUMBER>
                                <INFO>-Disabled Person Cert/ID NCWDP.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>112</REC_NUMBER>
                                <INFO>-DSWD Certificate.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>113</REC_NUMBER>
                                <INFO>-Tax Payers ID (TIN ID).</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>114</REC_NUMBER>
                                <INFO>-Barangay Certification.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>115</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>116</REC_NUMBER>
                                <INFO>ADDITIONAL RESTRICTIONS AND INFORMATION</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>117</REC_NUMBER>
                                <INFO>* N/A</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>118</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>119</REC_NUMBER>
                                <INFO>SERVICES OFFERED</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>120</REC_NUMBER>
                                <INFO>* D2B: Dirct to Bank</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>121</REC_NUMBER>
                                <INFO>* QC:Quick Cash</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>122</REC_NUMBER>
                                <INFO>* QP: Quick Pay</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>123</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>124</REC_NUMBER>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>125</REC_NUMBER>
                                <INFO>r.07152022.jpr.</INFO>
                            </GETCOUNTRYINFO>
                            <GETCOUNTRYINFO>
                                <REC_NUMBER>126</REC_NUMBER>
                            </GETCOUNTRYINFO>
                        </RECORDSET>
                    </DATA_CONTEXT>
                </REPLY>
            </MTML>
        </xrsi:h2h-das-reply>
    </soapenv:Body>
</soapenv:Envelope>
XML;

        return new SimpleXMLElement($xml);
    }
}
