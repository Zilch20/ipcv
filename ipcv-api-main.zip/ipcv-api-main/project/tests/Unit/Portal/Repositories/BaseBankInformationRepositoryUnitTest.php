<?php

namespace Tests\Unit\WesternUnion\Repositories;

use IPCV\API\Portal\Models\BankInformation;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Repositories\BaseBankInformationRepository;
use Tests\DataProviders\BankInformationDataProvider;
use Tests\TestCase;

class BaseBankInformationRepositoryUnitTest extends TestCase
{
    use BankInformationDataProvider;

    /**
     * @test
     * @dataProvider bankInformationDataProvider
     */
    public function it_should_create_bank_information($data): void
    {
        $customer = Customer::factory()->create();

        $repository = new BaseBankInformationRepository(new BankInformation());

        $bankInformation = $repository->create($customer, $data);

        $this->assertEquals($data['bank_name'], $bankInformation->bank_name);
        $this->assertEquals($data['account_number'], $bankInformation->account_number);
        $this->assertEquals($data['account_type'], $bankInformation->account_type);
        $this->assertEquals($data['routing_number'], $bankInformation->routing_number);
        $this->assertEquals($data['branch_number'], $bankInformation->branch_number);
        $this->assertEquals($data['bank_location'], $bankInformation->bank_location);
        $this->assertEquals($data['bic'], $bankInformation->bic);
        $this->assertEquals($data['bank_code'], $bankInformation->bank_code);
        $this->assertEquals($data['sort_code'], $bankInformation->sort_code);
        $this->assertEquals($data['account_prefix'], $bankInformation->account_prefix);
        $this->assertEquals($data['account_suffix'], $bankInformation->account_suffix);
        $this->assertEquals($data['bank_account_holder'], $bankInformation->bank_account_holder);
    }

    /**
     * @test
     */
    public function it_should_find_bank_information(): void
    {
        $customer = Customer::factory()->create();
        $original = BankInformation::factory()->for($customer)->create();

        $repository = new BaseBankInformationRepository(new BankInformation());

        $found = $repository->find($original->id);

        $this->assertEquals($original->id, $found->id);
        $this->assertEquals($original->bank_name, $found->bank_name);
        $this->assertEquals($original->account_number, $found->account_number);
    }

    /**
     * @test
     */
    public function it_should_update_bank_information(): void
    {
        $customer = Customer::factory()->create();
        $original = BankInformation::factory()->for($customer)->create();

        $repository = new BaseBankInformationRepository(new BankInformation());

        $updateFields = [
            'bank_name' => 'ChinaBank',
            'account_number' => '123-123-123',
        ];

        $updateResult = $repository->update($original->id, $updateFields);
        $updated = $repository->find($original->id);

        $this->assertEquals(1, $updateResult);
        $this->assertEquals($updateFields['bank_name'], $updated->bank_name);
        $this->assertEquals($updateFields['account_number'], $updated->account_number);
    }

    /**
     * @test
     */
    public function it_should_find_bank_information_by_account_number_bank_name_and_customer_id(): void
    {
        $customer = Customer::factory()->create();
        $original = BankInformation::factory()->for($customer)->create();

        $repository = new BaseBankInformationRepository(new BankInformation());

        $found = $repository->findBy(
            accountNumber: $original->account_number,
            bankName: $original->bank_name,
            customerId: $original->customer_id,
        );

        $this->assertEquals($original->id, $found->id);
        $this->assertEquals($original->account_number, $found->account_number);
        $this->assertEquals($original->customer_id, $found->customer_id);
    }
}
