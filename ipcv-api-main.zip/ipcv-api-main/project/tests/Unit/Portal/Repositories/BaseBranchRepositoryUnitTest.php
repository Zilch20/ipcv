<?php

namespace Tests\Unit\WesternUnion\Repositories;

use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchOwner;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Repositories\BaseBranchRepository;
use Tests\DataProviders\BranchDataProvider;
use Tests\TestCase;

class BaseBranchRepositoryUnitTest extends TestCase
{
    use BranchDataProvider;

    /**
     * @dataProvider branchDataProvider
     * @test
     */
    public function it_should_create_independent_branch($data): void
    {
        $repository = new BaseBranchRepository(new Branch());

        $model = $repository->createIndependent($data);

        $this->assertEquals(Branch::class, $model::class);
        $this->assertEquals($data['name'], $model->name);
        $this->assertEquals($data['description'], $model->description);
        $this->assertEquals($data['address'], $model->address);
        $this->assertEquals($data['contact_number'], $model->contact_number);
        $this->assertEquals($data['terminal_id'], $model->terminal_id);
        $this->assertEquals($data['ftid'], $model->ftid);
        $this->assertEquals($data['naid'], $model->naid);
    }

    /**
     * @dataProvider branchDataProvider
     * @test
     */
    public function it_should_create_branch($data): void
    {
        $branchOwner = BranchOwner::factory()->create();

        $repository = new BaseBranchRepository(new Branch());

        $model = $repository->create($branchOwner, $data);

        $this->assertEquals(Branch::class, $model::class);
        $this->assertEquals($branchOwner->id, $model->branch_owner_id);
        $this->assertEquals($data['name'], $model->name);
        $this->assertEquals($data['description'], $model->description);
        $this->assertEquals($data['address'], $model->address);
        $this->assertEquals($data['contact_number'], $model->contact_number);
        $this->assertEquals($data['terminal_id'], $model->terminal_id);
        $this->assertEquals($data['ftid'], $model->ftid);
        $this->assertEquals($data['naid'], $model->naid);
    }

    /**
     * @dataProvider branchDataProvider
     * @test
     */
    public function it_should_find_branch($data): void
    {
        $branch = Branch::factory()->create();

        $repository = new BaseBranchRepository(new Branch());

        $found = $repository->find($branch->id);

        $this->assertEquals($branch->id, $found->id);
        $this->assertEquals($branch->name, $found->name);
        $this->assertEquals($branch->description, $found->description);
        $this->assertEquals($branch->address, $found->address);
        $this->assertEquals($branch->contact_number, $found->contact_number);
        $this->assertEquals($branch->terminal_id, $found->terminal_id);
        $this->assertEquals($branch->ftid, $found->ftid);
        $this->assertEquals($branch->naid, $found->naid);
    }

    /**
     * @dataProvider branchDataProvider
     * @test
     */
    public function it_should_find_branch_by_name($data): void
    {
        $branch = Branch::factory()->create();

        $repository = new BaseBranchRepository(new Branch());

        $found = $repository->findByName($branch->name);

        $this->assertEquals($branch->id, $found->id);
        $this->assertEquals($branch->name, $found->name);
        $this->assertEquals($branch->description, $found->description);
        $this->assertEquals($branch->address, $found->address);
        $this->assertEquals($branch->contact_number, $found->contact_number);
        $this->assertEquals($branch->terminal_id, $found->terminal_id);
        $this->assertEquals($branch->ftid, $found->ftid);
        $this->assertEquals($branch->naid, $found->naid);
    }

    /**
     * @dataProvider branchDataProvider
     * @test
     */
    public function it_should_update_branch($data): void
    {
        $original = Branch::factory()->create();

        $attributes = [
            'name' => $this->faker()->company(),
            'description' => $this->faker()->sentence(),
            'address' => $this->faker()->address(),
            'contact_number' => $this->faker()->phoneNumber(),
            'terminal_id' => $this->faker()->word(),
            'ftid' => $this->faker()->word(),
            'naid' => $this->faker()->word(),
        ];

        $repository = new BaseBranchRepository(new Branch());
        $updateStatus = $repository->update($original->id, $attributes);
        $updated = $repository->find($original->id);

        $this->assertEquals(1, $updateStatus);
        $this->assertEquals(Branch::class, $original::class);

        $this->assertEquals($attributes['name'], $updated->name);
        $this->assertEquals($attributes['description'], $updated->description);
        $this->assertEquals($attributes['address'], $updated->address);
        $this->assertEquals($attributes['contact_number'], $updated->contact_number);
        $this->assertEquals($attributes['terminal_id'], $updated->terminal_id);
        $this->assertEquals($attributes['ftid'], $updated->ftid);
        $this->assertEquals($attributes['naid'], $updated->naid);
    }

    /**
     * @test
     */
    public function it_should_get_branch_users(): void
    {
        $branch = Branch::factory()->create();
        BranchUser::factory()->count($count = 3)->for($branch)->create();

        $repository = new BaseBranchRepository($branch);

        $result = $repository->getBranchUsers();

        $this->assertEquals(Collection::class, $result::class);
        $this->assertCount($count, $result);
        foreach ($result as $branchUser) {
            $this->assertEquals($branch->id, $branchUser->branch_id);
        }
    }
}
