<?php

namespace Tests\Unit\WesternUnion\Repositories;

use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Repositories\BaseGovernmentIdentificationRepository;
use Tests\DataProviders\GovernmentIdentificationDataProvider;
use Tests\TestCase;

class BaseGovernmentIdentificationRepositoryUnitTest extends TestCase
{
    use GovernmentIdentificationDataProvider;

    /**
     * @dataProvider governmentIdentificationDataProvider
     * @test
     */
    public function it_should_create_government_identification($data): void
    {
        $customer = Customer::factory()->create();

        $govIdRepo = new BaseGovernmentIdentificationRepository(new GovernmentIdentification());

        $model = $govIdRepo->create($customer, $data);

        $this->assertEquals(GovernmentIdentification::class, $model::class);
        $this->assertEquals($data['type'], $model->type);
        $this->assertEquals($data['number'], $model->number);
        $this->assertEquals($data['country_issued'], $model->country_issued);
        $this->assertEquals($data['issue_date'], $model->issue_date->format('Y-m-d'));
        $this->assertEquals($data['expiry_date'], $model->expiry_date->format('Y-m-d'));
        $this->assertEquals($data['url'], $model->url);
    }

    /**
     * @dataProvider governmentIdentificationDataProvider
     * @test
     */
    public function it_should_find_government_identification($data): void
    {
        $customer = Customer::factory()->create();
        $govIdRepo = new BaseGovernmentIdentificationRepository(new GovernmentIdentification());

        $created = $govIdRepo->create($customer, $data);
        $found = $govIdRepo->find($created->id);

        $this->assertEquals(GovernmentIdentification::class, $found::class);
        $this->assertEquals($created->id, $found->id);
        $this->assertEquals($created->type, $found->type);
        $this->assertEquals($created->number, $found->number);
        $this->assertEquals($created->country_issued, $found->country_issued);
        $this->assertEquals($created->issue_date, $found->issue_date);
        $this->assertEquals($created->expiry_date, $found->expiry_date);
        $this->assertEquals($created->url, $found->url);
    }

    /**
     * @dataProvider governmentIdentificationDataProvider
     * @test
     */
    public function it_should_update_government_identification($data): void
    {
        $customer = Customer::factory()->create();
        $govIdRepo = new BaseGovernmentIdentificationRepository(new GovernmentIdentification());

        $created = $govIdRepo->create($customer, $data);

        $attributes = [
            'type' => 'Foobar',
            'number' => $this->faker()->phoneNumber(),
            'country_issued' => $this->faker()->country(),
            'issue_date' => $this->faker()->date(),
            'expiry_date' => $this->faker()->date(),
            'url' => $this->faker()->imageUrl(),
        ];

        $updateResult = $govIdRepo->update($created->id, $attributes);
        $updated = $govIdRepo->find($created->id);

        $this->assertEquals(1, $updateResult);
        $this->assertEquals($attributes['type'], $updated->type);
        $this->assertEquals($attributes['number'], $updated->number);
        $this->assertEquals($attributes['country_issued'], $updated->country_issued);
        $this->assertEquals($attributes['issue_date'], $updated->issue_date->format('Y-m-d'));
        $this->assertEquals($attributes['expiry_date'], $updated->expiry_date->format('Y-m-d'));
        $this->assertEquals($attributes['url'], $updated->url);
    }

    /**
     * @test
     */
    public function it_should_not_update_government_identification_when_it_does_not_exist(): void
    {
        $govIdRepo = new BaseGovernmentIdentificationRepository(new GovernmentIdentification());

        $attributes = [
            'type' => 'Foobar',
            'number' => $this->faker()->phoneNumber(),
            'country_issued' => $this->faker()->country(),
            'issue_date' => $this->faker()->date(),
            'expiry_date' => $this->faker()->date(),
            'url' => $this->faker()->imageUrl(),
        ];

        $updateResult = $govIdRepo->update(1, $attributes);

        $this->assertEquals(0, $updateResult);
    }

    /**
     * @dataProvider governmentIdentificationDataProvider
     * @test
     */
    public function it_should_find_government_identification_by_number($data): void
    {
        $customer = Customer::factory()->create();
        $govIdRepo = new BaseGovernmentIdentificationRepository(new GovernmentIdentification());

        $created = $govIdRepo->create($customer, $data);
        $found = $govIdRepo->findByNumberAndType($created->number, $created->type);

        $this->assertEquals(GovernmentIdentification::class, $found::class);
        $this->assertEquals($created->id, $found->id);
        $this->assertEquals($created->type, $found->type);
        $this->assertEquals($created->number, $found->number);
        $this->assertEquals($created->country_issued, $found->country_issued);
        $this->assertEquals($created->issue_date, $found->issue_date);
        $this->assertEquals($created->expiry_date, $found->expiry_date);
        $this->assertEquals($created->url, $found->url);
    }

    /**
     * @dataProvider governmentIdentificationDataProvider
     * @test
     */
    public function it_should_find_government_identifications_by_customer_id($data): void
    {
        $customer = Customer::factory()->create();
        $govIdRepo = new BaseGovernmentIdentificationRepository(new GovernmentIdentification());

        GovernmentIdentification::factory()
            ->count($count = 3)
            ->for($customer)
            ->create()
        ;

        $found = $govIdRepo->findByCustomerId($customer->id);

        $this->assertEquals(Collection::class, $found::class);
        $this->assertEquals($count, $found->count());
        foreach ($found as $model) {
            $this->assertEquals($customer->id, $model->customer_id);
        }
    }
}
