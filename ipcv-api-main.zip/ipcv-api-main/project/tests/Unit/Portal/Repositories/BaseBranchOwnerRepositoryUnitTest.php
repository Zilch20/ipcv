<?php

namespace Tests\Unit\WesternUnion\Repositories;

use IPCV\API\Portal\Models\BranchOwner;
use IPCV\API\Portal\Repositories\BaseBranchOwnerRepository;
use Tests\DataProviders\BranchOwnerDataProvider;
use Tests\TestCase;

class BaseBranchOwnerRepositoryUnitTest extends TestCase
{
    use BranchOwnerDataProvider;

    /**
     * @dataProvider branchOwnerDataProvider
     * @test
     */
    public function it_should_create_branch_owner($data): void
    {
        $repository = new BaseBranchOwnerRepository(new BranchOwner());

        $model = $repository->create($data);

        $this->assertEquals(BranchOwner::class, $model::class);
        $this->assertEquals($data['name'], $model->name);
    }

    /**
     * @test
     */
    public function it_should_find_branch_owner(): void
    {
        $created = BranchOwner::factory()->create();

        $repository = new BaseBranchOwnerRepository(new BranchOwner());
        $found = $repository->find($created->id);

        $this->assertEquals(BranchOwner::class, $found::class);
        $this->assertEquals($created->id, $found->id);
        $this->assertEquals($created->name, $found->name);
    }

    /**
     * @test
     */
    public function it_should_find_branch_owner_by_name(): void
    {
        $created = BranchOwner::factory()->create();

        $repository = new BaseBranchOwnerRepository(new BranchOwner());
        $found = $repository->findByName($created->name);

        $this->assertEquals(BranchOwner::class, $found::class);
        $this->assertEquals($created->id, $found->id);
        $this->assertEquals($created->name, $found->name);
    }

    /**
     * @dataProvider branchOwnerDataProvider
     * @test
     */
    public function it_should_update_branch_owner($data)
    {
        $created = BranchOwner::factory()->create();

        $attributes = [
            'name' => 'E-Corp',
        ];

        $repository = new BaseBranchOwnerRepository(new BranchOwner());

        $updateStatus = $repository->update($created->id, $attributes);
        $updated = $repository->find($created->id);

        $this->assertEquals(1, $updateStatus);
        $this->assertEquals($created->id, $updated->id);
        $this->assertEquals($attributes['name'], $updated->name);
    }


}
