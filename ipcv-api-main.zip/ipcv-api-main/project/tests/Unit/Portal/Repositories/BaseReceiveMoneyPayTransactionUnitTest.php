<?php

namespace Tests\Unit\WesternUnion\Repositories;

use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;
use IPCV\API\Portal\Repositories\BaseReceiveMoneyPayTransactionRepository;
use Tests\DataProviders\ReceiveMoneyPayTransactionDataProvider;
use Tests\TestCase;

class BaseReceiveMoneyPayTransactionUnitTest extends TestCase
{
    use ReceiveMoneyPayTransactionDataProvider;

    /**
     * @dataProvider receiveMoneyTransactionDataProvider
     * @test
     */
    public function it_should_create_receive_money_transaction($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch = Branch::factory()->create();

        $data = [
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch->id,
            ...$data
        ];

        $repository = new BaseReceiveMoneyPayTransactionRepository(new ReceiveMoneyPayTransaction());
        $created = $repository->create($data);

        $this->assertEquals(ReceiveMoneyPayTransaction::class, $created::class);
        $this->assertEquals($created->mtcn, $data['mtcn']);
        $this->assertEquals($created->new_mtcn, $data['new_mtcn']);
        $this->assertEquals($created->new_points_earned, $data['new_points_earned']);
        $this->assertEquals($created->total_points_earned, $data['total_points_earned']);
        $this->assertEquals($created->money_transfer_key, $data['money_transfer_key']);
        $this->assertEquals($created->gross_total_amount, $data['gross_total_amount']);
        $this->assertEquals($created->pay_amount, $data['pay_amount']);
        $this->assertEquals($created->principal_amount, $data['principal_amount']);
        $this->assertEquals($created->charges, $data['charges']);
        $this->assertEquals($created->tolls, $data['tolls']);
        $this->assertEquals($created->exchange_rate, $data['exchange_rate']);
        $this->assertEquals($created->originating_currency_code, $data['originating_currency_code']);
        $this->assertEquals($created->originating_country_code, $data['originating_country_code']);
        $this->assertEquals($created->destination_country_code, $data['destination_country_code']);
        $this->assertEquals($created->destination_currency_code, $data['destination_currency_code']);
        $this->assertEquals($created->transaction_type, $data['transaction_type']);
        $this->assertEquals($created->purpose, $data['purpose']);
        $this->assertEquals($created->source_of_funds, $data['source_of_funds']);
        $this->assertEquals($created->relationship_to_sender, $data['relationship_to_sender']);
        $this->assertEquals($created->branch_id, $data['branch_id']);
        $this->assertEquals($created->customer_id, $data['customer_id']);
        $this->assertEquals($created->government_identification_id, $data['government_identification_id']);
        $this->assertEquals($created->xml_request, $data['xml_request']);
        $this->assertEquals($created->wu_response_headers, $data['wu_response_headers']);
        $this->assertEquals($created->wu_response_body, $data['wu_response_body']);
        $this->assertEquals($created->status, $data['status']);
        $this->assertEquals($created->timestamp, $data['timestamp']);
    }

    /**
     * @test
     * @dataProvider receiveMoneyTransactionDataProvider
     */
    public function it_should_find_receive_money_transaction($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch = Branch::factory()->create();
        $original = ReceiveMoneyPayTransaction::factory()->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch->id,
        ]);

        $repository = new BaseReceiveMoneyPayTransactionRepository(new ReceiveMoneyPayTransaction());

        $found = $repository->find($original->id);

        $this->assertEquals(ReceiveMoneyPayTransaction::class, $found::class);
        $this->assertEquals($original->toArray(), $found->toArray());
    }

    /**
     * @test
     * @dataProvider receiveMoneyTransactionDataProvider
     */
    public function it_should_find_receive_money_transaction_by_mtcn($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch = Branch::factory()->create();
        $original = ReceiveMoneyPayTransaction::factory()->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch->id,
        ]);

        $repository = new BaseReceiveMoneyPayTransactionRepository(new ReceiveMoneyPayTransaction());

        $found = $repository->getByMtcn($original->mtcn);

        $this->assertEquals(Collection::class, $found::class);
        $this->assertEquals($original->toArray(), $found->get(0)->toArray());
    }

    /**
     * @test
     * @dataProvider receiveMoneyTransactionDataProvider
     */
    public function it_should_get_receive_money_transactions_by_branch_id($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch1 = Branch::factory()->create();
        $branch2 = Branch::factory()->create();

        ReceiveMoneyPayTransaction::factory()->count($count = 3)->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch1->id,
        ]);

        ReceiveMoneyPayTransaction::factory()->count(5)->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch2->id,
        ]);

        $repository = new BaseReceiveMoneyPayTransactionRepository(new ReceiveMoneyPayTransaction());

        $results= $repository->getByBranch($branch1);

        $this->assertEquals(Collection::class, $results::class);
        $this->assertCount($count, $results);
        foreach ($results as $transaction) {
            $this->assertEquals($branch1->id, $transaction->branch_id);
        }
    }

    /**
     * @test
     * @dataProvider receiveMoneyTransactionDataProvider
     */
    public function it_should_get_receive_money_transactions_by_customer_id($data): void
    {
        $customer1 = Customer::factory()->create();
        $customer2 = Customer::factory()->create();
        $govId1 = GovernmentIdentification::factory()->for($customer1)->create();
        $govId2 = GovernmentIdentification::factory()->for($customer2)->create();
        $branch = Branch::factory()->create();

        ReceiveMoneyPayTransaction::factory()->count($count = 3)->create([
            'government_identification_id' => $govId1->id,
            'customer_id' => $govId1->customer_id,
            'branch_id' => $branch->id,
        ]);

        ReceiveMoneyPayTransaction::factory()->count(5)->create([
            'government_identification_id' => $govId2->id,
            'customer_id' => $govId2->customer_id,
            'branch_id' => $branch->id,
        ]);

        $repository = new BaseReceiveMoneyPayTransactionRepository(new ReceiveMoneyPayTransaction());

        $results= $repository->getByCustomer($customer1);

        $this->assertEquals(Collection::class, $results::class);
        $this->assertCount($count, $results);
        foreach ($results as $transaction) {
            $this->assertEquals($customer1->id, $transaction->customer_id);
        }
    }
}
