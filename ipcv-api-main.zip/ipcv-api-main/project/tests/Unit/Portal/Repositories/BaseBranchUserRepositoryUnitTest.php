<?php

namespace Tests\Unit\WesternUnion\Repositories;

use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchUser;
use IPCV\API\Portal\Repositories\BaseBranchUserRepository;
use Tests\DataProviders\BranchUserDataProvider;
use Tests\TestCase;

class BaseBranchUserRepositoryUnitTest extends TestCase
{
    use BranchUserDataProvider;

    /**
     * @test
     */
    public function it_should_find_branch_user_by_email(): void
    {
        $repository = new BaseBranchUserRepository(new BranchUser());

        $branch = Branch::factory()->create();
        $branchUser = BranchUser::factory()->for($branch)->create();

        $found = $repository->findByEmail($branchUser->email);

        $this->assertEquals($branchUser->id, $found->id);
        $this->assertEquals($branchUser->first_name, $found->first_name);
        $this->assertEquals($branchUser->middle_name, $found->middle_name);
        $this->assertEquals($branchUser->last_name, $found->last_name);
        $this->assertEquals($branchUser->email, $found->email);
        $this->assertEquals($branchUser->is_active, $found->is_active);
        $this->assertEquals($branchUser->password, $found->password);
    }

    /**
     * @test
     */
    public function it_should_find_branch_user(): void
    {
        $repository = new BaseBranchUserRepository(new BranchUser());

        $branch = Branch::factory()->create();
        $branchUser = BranchUser::factory()->for($branch)->create();

        $found = $repository->find($branchUser->id);

        $this->assertEquals($branchUser->id, $found->id);
        $this->assertEquals($branchUser->first_name, $found->first_name);
        $this->assertEquals($branchUser->middle_name, $found->middle_name);
        $this->assertEquals($branchUser->last_name, $found->last_name);
        $this->assertEquals($branchUser->email, $found->email);
        $this->assertEquals($branchUser->is_active, $found->is_active);
        $this->assertEquals($branchUser->password, $found->password);
    }

    /**
     * @test
     */
    public function it_should_update_branch_user(): void
    {
        $repository = new BaseBranchUserRepository(new BranchUser());

        $branch = Branch::factory()->create();
        $branchUser = BranchUser::factory()->for($branch)->create();

        $updateFields = [
            'first_name' => fake()->firstName(),
            'middle_name' => fake()->firstName(),
            'last_name' => fake()->lastName(),
            'email' => fake()->unique()->safeEmail(),
        ];

        $updateResult = $repository->update($branchUser->id, $updateFields);

        $found = $repository->find($branchUser->id);

        $this->assertEquals(1, $updateResult);
        $this->assertEquals($updateFields['first_name'], $found->first_name);
        $this->assertEquals($updateFields['middle_name'], $found->middle_name);
        $this->assertEquals($updateFields['last_name'], $found->last_name);
        $this->assertEquals($updateFields['email'], $found->email);
    }

    /**
     * @dataProvider branchUserDataProvider
     * @test
     */
    public function it_should_create_branch_user($data): void
    {
        $repository = new BaseBranchUserRepository(new BranchUser());

        $branch = Branch::factory()->create();

        $model = $repository->create($branch, $data);

        $this->assertEquals(BranchUser::class, $model::class);
        $this->assertEquals($data['first_name'], $model->first_name);
        $this->assertEquals($data['middle_name'], $model->middle_name);
        $this->assertEquals($data['last_name'], $model->last_name);
        $this->assertEquals($data['email'], $model->email);
        $this->assertEquals($data['password'], $model->password);
    }
}
