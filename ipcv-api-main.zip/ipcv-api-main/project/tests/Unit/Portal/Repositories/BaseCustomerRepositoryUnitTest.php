<?php

namespace Tests\Unit\WesternUnion\Repositories;

use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Repositories\BaseCustomerRepository;
use Tests\DataProviders\CustomerDataProvider;
use Tests\TestCase;

class BaseCustomerRepositoryUnitTest extends TestCase
{
    use CustomerDataProvider;

    /**
     * @dataProvider customerDataProvider
     * @test
     */
    public function it_should_create_customer($data): void
    {
        $repository = new BaseCustomerRepository(new Customer());

        $model = $repository->create($data);

        $this->assertEquals(Customer::class, $model::class);
        $this->assertEquals($data['first_name'], $model->first_name);
        $this->assertEquals($data['middle_name'], $model->middle_name);
        $this->assertEquals($data['last_name'], $model->last_name);
    }

    /**
     * @test
     * @dataProvider customerDataProvider
     */
    public function it_should_find_customer($data): void
    {
        $repository = new BaseCustomerRepository(new Customer());
        $expected = $repository->create($data);

        $actual = $repository->find($expected->id);

        $this->assertEquals(Customer::class, $actual::class);
        $this->assertEquals($expected->id, $actual->id);
    }

    /**
     * @test
     * @dataProvider customerDataProvider
     */
    public function it_should_update_customer($data): void
    {
        $repository = new BaseCustomerRepository(new Customer());
        $customer = $repository->create($data);

        $input = [
            'first_name' => 'Jojie',
            'middle_name' => 'Pink',
            'last_name' => 'Guy',
        ];

        $updateResult = $repository->update($customer->id, $input);
        $updated = $repository->find($customer->id);

        $this->assertEquals(1, $updateResult);
        $this->assertEquals($input['first_name'], $updated->first_name);
        $this->assertEquals($input['middle_name'], $updated->middle_name);
        $this->assertEquals($input['last_name'], $updated->last_name);
    }

    /**
     * @test
     */
    public function it_should_not_update_when_customer_does_not_exist()
    {
        $repository = new BaseCustomerRepository(new Customer());

        $input = [
            'first_name' => 'Jojie',
            'middle_name' => 'Pink',
            'last_name' => 'Guy',
        ];

        $updateResult = $repository->update(1, $input);
        $this->assertEquals(0, $updateResult);
    }
}
