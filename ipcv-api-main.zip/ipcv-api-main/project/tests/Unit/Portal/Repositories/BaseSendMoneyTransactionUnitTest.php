<?php

namespace Tests\Unit\WesternUnion\Repositories;

use Illuminate\Database\Eloquent\Collection;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;
use IPCV\API\Portal\Models\SendMoneyTransaction;
use IPCV\API\Portal\Repositories\BaseSendMoneyTransactionRepository;
use Tests\DataProviders\SendMoneyTransactionDataProvider;
use Tests\TestCase;

class BaseSendMoneyTransactionUnitTest extends TestCase
{
    use SendMoneyTransactionDataProvider;

    /**
     * @test
     * @dataProvider sendMoneyTransactionDataProvider
     */
    public function it_should_create_send_money_transaction($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch = Branch::factory()->create();

        $repository = new BaseSendMoneyTransactionRepository(new SendMoneyTransaction());

        $created = $repository->create($govId, $branch, $data);

        $actual = [
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch->id,
            ...$data
        ];

        $modelWithoutIdAndTimestamp = collect($created)
            ->except(['id', 'updated_at', 'created_at'])
            ->toArray()
        ;

        $this->assertEquals(SendMoneyTransaction::class, $created::class);
        $this->assertEquals($created->mtcn, $data['mtcn']);
        $this->assertEquals($created->new_mtcn, $data['new_mtcn']);
        $this->assertEquals($created->new_points_earned, $data['new_points_earned']);
        $this->assertEquals($created->total_points_earned, $data['total_points_earned']);
        $this->assertEquals($created->originators_principal_amount, $data['originators_principal_amount']);
        $this->assertEquals($created->destination_principal_amount, $data['destination_principal_amount']);
        $this->assertEquals($created->gross_total_amount, $data['gross_total_amount']);
        $this->assertEquals($created->exchange_rate, $data['exchange_rate']);
        $this->assertEquals($created->charges, $data['charges']);
        $this->assertEquals($created->message_charge, $data['message_charge']);
        $this->assertEquals($created->originating_currency_code, $data['originating_currency_code']);
        $this->assertEquals($created->originating_country_code, $data['originating_country_code']);
        $this->assertEquals($created->destination_country_code, $data['destination_country_code']);
        $this->assertEquals($created->destination_currency_code, $data['destination_currency_code']);
        $this->assertEquals($created->transaction_type, $data['transaction_type']);
        $this->assertEquals($created->purpose, $data['purpose']);
        $this->assertEquals($created->source_of_funds, $data['source_of_funds']);
        $this->assertEquals($created->relationship_to_receiver, $data['relationship_to_receiver']);
        $this->assertEquals($created->compliance_data_buffer, $data['compliance_data_buffer']);
        $this->assertEquals($created->receiver_first_name, $data['receiver_first_name']);
        $this->assertEquals($created->receiver_middle_name, $data['receiver_middle_name']);
        $this->assertEquals($created->receiver_last_name, $data['receiver_last_name']);
        $this->assertEquals($created->xml_request, $data['xml_request']);
        $this->assertEquals($created->wu_response_headers, $data['wu_response_headers']);
        $this->assertEquals($created->wu_response_body, $data['wu_response_body']);
        $this->assertEquals($created->messages, $data['messages']);
        $this->assertEquals($created->status, $data['status']);
    }

    /**
     * @test
     * @dataProvider sendMoneyTransactionDataProvider
     */
    public function it_should_find_send_money_transaction($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch = Branch::factory()->create();
        $original = SendMoneyTransaction::factory()->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch->id,
        ]);

        $repository = new BaseSendMoneyTransactionRepository(new SendMoneyTransaction());

        $found = $repository->find($original->id);

        $this->assertEquals(SendMoneyTransaction::class, $found::class);
        $this->assertEquals($original->toArray(), $found->toArray());
    }

    /**
     * @test
     * @dataProvider sendMoneyTransactionDataProvider
     */
    public function it_should_find_send_money_transaction_by_mtcn($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch = Branch::factory()->create();
        $original = SendMoneyTransaction::factory()->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch->id,
        ]);

        $repository = new BaseSendMoneyTransactionRepository(new SendMoneyTransaction());

        $found = $repository->getByMtcn($original->mtcn);

        $this->assertEquals(Collection::class, $found::class);
        $this->assertEquals($original->toArray(), $found->get(0)->toArray());
    }

    /**
     * @test
     * @dataProvider sendMoneyTransactionDataProvider
     */
    public function it_should_get_send_money_transactions_by_branch_id($data): void
    {
        $customer = Customer::factory()->create();
        $govId = GovernmentIdentification::factory()->for($customer)->create();
        $branch1 = Branch::factory()->create();
        $branch2 = Branch::factory()->create();

        SendMoneyTransaction::factory()->count($count = 3)->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch1->id,
        ]);

        SendMoneyTransaction::factory()->count(5)->create([
            'government_identification_id' => $govId->id,
            'customer_id' => $govId->customer_id,
            'branch_id' => $branch2->id,
        ]);

        $repository = new BaseSendMoneyTransactionRepository(new SendMoneyTransaction());

        $results= $repository->getByBranch($branch1);

        $this->assertEquals(Collection::class, $results::class);
        $this->assertCount($count, $results);
        foreach ($results as $transaction) {
            $this->assertEquals($branch1->id, $transaction->branch_id);
        }
    }

    /**
     * @test
     * @dataProvider sendMoneyTransactionDataProvider
     */
    public function it_should_get_send_money_transactions_by_customer_id($data): void
    {
        $customer1 = Customer::factory()->create();
        $customer2 = Customer::factory()->create();
        $govId1 = GovernmentIdentification::factory()->for($customer1)->create();
        $govId2 = GovernmentIdentification::factory()->for($customer2)->create();
        $branch = Branch::factory()->create();

        SendMoneyTransaction::factory()->count($count = 3)->create([
            'government_identification_id' => $govId1->id,
            'customer_id' => $govId1->customer_id,
            'branch_id' => $branch->id,
        ]);

        SendMoneyTransaction::factory()->count(5)->create([
            'government_identification_id' => $govId2->id,
            'customer_id' => $govId2->customer_id,
            'branch_id' => $branch->id,
        ]);

        $repository = new BaseSendMoneyTransactionRepository(new SendMoneyTransaction());

        $results= $repository->getByCustomer($customer1);

        $this->assertEquals(Collection::class, $results::class);
        $this->assertCount($count, $results);
        foreach ($results as $transaction) {
            $this->assertEquals($customer1->id, $transaction->customer_id);
        }
    }
}
