<?php

declare(strict_types=1);

namespace Tests\DataProviders;

trait BankInformationDataProvider
{
    public function bankInformationDataProvider(): array
    {
        $faker = $this->faker('en_US');

        return [
            [
                [
                    'bank_name' => $faker->company(),
                    'account_number' => $faker->phoneNumber(),
                    'account_type' => 'BL',
                    'routing_number' => $faker->uuid(),
                    'branch_number' => $faker->uuid(),
                    'bank_location' => $faker->address(),
                    'bic' => $faker->uuid(),
                    'bank_code' => $faker->uuid(),
                    'sort_code' => $faker->uuid(),
                    'account_prefix' => $faker->sentence(),
                    'account_suffix' => $faker->sentence(),
                    'bank_account_holder' => $faker->name(),
                ]
            ]
        ];
    }
}
