<?php

declare(strict_types=1);

namespace Tests\DataProviders;

trait GovernmentIdentificationDataProvider
{
    private static array $idTypes = [
        'Passport',
        "Driver's license",
        'PRC ID',
        'NBI CLEARANCE',
        'Police Clearance',
        'POSTAL ID',
        'Voter ID',
        'BARANGAY CERTIFICATION',
        'Government Service Insurance System (GSIS) e-Card',
        'Social Security System (SSS) Card',
        'Government issued national identification card',
        'Senior Citizen ID',
        'Overseas Workers Welfare Administration (OWWA) ID',
        'OFW ID',
        "Seaman's Book",
        'Alien/Immigrant Certificate of Registration',
        'PWD/NCWDP ID',
        'DSWD CERTIFICATE',
        'IBP ID',
        'Student ID',
        'Unified Multi Purpose ID (UMID)',
        'TAXPAYER’S ID (TIN)',
        'Other government issued IDs',
    ];

    public function governmentIdentificationDataProvider(): array
    {
        $faker = $this->faker('en_US');

        return [
            [
                [
                    'type' => $faker->randomElement(self::$idTypes),
                    'number' => $faker->phoneNumber(),
                    'country_issued' => $faker->country(),
                    'issue_date' => $faker->date(),
                    'expiry_date' => $faker->date(),
                    'url' => $faker->imageUrl(),
                ]
            ]
        ];
    }
}
