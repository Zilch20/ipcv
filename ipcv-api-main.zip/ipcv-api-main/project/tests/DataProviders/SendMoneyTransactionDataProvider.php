<?php

declare(strict_types=1);

namespace Tests\DataProviders;

use IPCV\API\Portal\Models\SendMoneyTransactionStatus;

trait SendMoneyTransactionDataProvider
{
    public function sendMoneyTransactionDataProvider(): array
    {
        $faker = $this->faker('en_US');

        $amount = 50000;
        $charges = \random_int(1_000_000, 9_999_999);
        $messageCharge = \random_int(1_000_000, 9_999_999);

        return [
            [
                [
                    'mtcn' => (string)\random_int(1_000_000_000, 9_999_999_999),
                    'new_mtcn' => (string)\random_int(1_000_000_000_000_000, 9_999_999_999_999_999),
                    'originators_principal_amount' => $amount,
                    'destination_principal_amount' => $amount,
                    'gross_total_amount' => $amount + $charges + $messageCharge,
                    'exchange_rate' => '1',
                    'new_points_earned' => (string)\random_int(100, 999),
                    'total_points_earned' => (string)\random_int(1000, 9999),
                    'originating_currency_code' => 'PHP',
                    'originating_country_code' => 'PH',
                    'charges' => (string)$charges,
                    'message_charge' => (string)$messageCharge,
                    'destination_country_code' => 'PH',
                    'destination_currency_code' => 'PHP',
                    'transaction_type' => $faker->randomElement(['WMF', 'WMN']),
                    'purpose' => $faker->randomElement(
                        [
                            'Family Support/Living Expenses',
                            'Saving/Investments',
                            'Gift',
                            'Goods & Services Payment',
                            'Travel Expenses',
                            'Education/School Fee',
                            'Rent/Mortgage',
                            'Emergency/Medical Aid',
                            'Charity/Aid Payment',
                            'Employee Payroll/Employee Expense',
                        ]
                    ),
                    'source_of_funds' => $faker->randomElement(
                        [
                            'Cash Tips',
                            'Sale of Goods/Property/Services',
                            'Investment Income',
                            'Salary',
                            'Savings',
                            'Borrowed Funds/Loan',
                            'Gift',
                            'Pension/Government/Welfare',
                            'Inheritance',
                            'Charitable Donations',
                        ]
                    ),
                    'relationship_to_receiver' =>$faker->randomElement(
                        [
                            'Family',
                            'Friend',
                            'Trade/BusinesPartner',
                            'Employee/Employer',
                            'Donor/Receiver of Ch',
                            'Purchaser/Seller',
                        ]
                    ),
                    'compliance_data_buffer' => $faker->sentence(12),
                    'receiver_first_name' => $faker->firstName(),
                    'receiver_middle_name' => $faker->firstName(),
                    'receiver_last_name' => $faker->lastName(),
                    'xml_request' => fake()->sentence(),
                    'wu_response_headers' => \json_encode(['foo' => 'bar', 'baz' => 'boz']),
                    'wu_response_body' => fake()->sentence(),
                    'messages' => [
                        $faker->word(),
                        $faker->word(),
                        $faker->word(),
                        $faker->word(),
                    ],
                    'status' => $faker->randomElement(SendMoneyTransactionStatus::cases()),
                ],
            ],
        ];
    }
}
