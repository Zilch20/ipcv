<?php

namespace Tests\DataProviders;

trait BranchDataProvider
{
    public function branchDataProvider(): array
    {
        $faker = $this->faker('en_US');

        return [
            [
                [
                    'name' => $faker->company(),
                    'description' => $faker->sentence(),
                    'address' => $faker->address(),
                    'contact_number' => $faker->phoneNumber(),
                    'terminal_id' => $faker->word(),
                    'ftid' => $faker->word(),
                    'naid' => $faker->word(),
                ]
            ]
        ];
    }
}
