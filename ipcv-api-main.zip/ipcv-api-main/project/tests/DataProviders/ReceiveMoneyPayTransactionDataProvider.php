<?php

declare(strict_types=1);

namespace Tests\DataProviders;

use IPCV\API\Portal\Models\ReceiveMoneyPayStatus;

trait ReceiveMoneyPayTransactionDataProvider
{
    public function receiveMoneyTransactionDataProvider(): array
    {
        $faker = $this->faker('en_US');

        return [
            [
                [
                    'mtcn' => (string)\random_int(1_000_000_000, 9_999_999_999),
                    'new_mtcn' => (string)\random_int(1_000_000_000_000_000, 9_999_999_999_999_999),
                    'new_points_earned' => (string)\random_int(100, 999),
                    'total_points_earned' => (string)\random_int(1000, 9999),
                    'money_transfer_key' => (string)\random_int(1_000_000_000, 9_999_999_999),
                    'gross_total_amount' => (string)\random_int(1_000_000_000, 9_999_999_999),
                    'pay_amount' => (string)\random_int(1_000_000_000, 9_999_999_999),
                    'principal_amount' => (string)\random_int(1_000_000_000, 9_999_999_999),
                    'charges' => (string)\random_int(1_000_000, 9_999_999),
                    'tolls' => (string)\random_int(1_000_000, 9_999_999),
                    'exchange_rate' => '1',
                    'originating_currency_code' => 'PHP',
                    'originating_country_code' => 'PH',
                    'destination_country_code' => 'PHP',
                    'destination_currency_code' => 'PH',
                    'transaction_type' => $faker->randomElement(['WMN', 'WMF']),
                    'purpose' => $faker->randomElement(
                        [
                            'Family Support/Living Expenses',
                            'Saving/Investments',
                            'Gift',
                            'Goods & Services Payment',
                            'Travel Expenses',
                            'Education/School Fee',
                            'Rent/Mortgage',
                            'Emergency/Medical Aid',
                            'Charity/Aid Payment',
                            'Employee Payroll/Employee Expense',
                        ]
                    ),
                    'source_of_funds' => $faker->randomElement(
                        [
                            'Cash Tips',
                            'Sale of Goods/Property/Services',
                            'Investment Income',
                            'Salary',
                            'Savings',
                            'Borrowed Funds/Loan',
                            'Gift',
                            'Pension/Government/Welfare',
                            'Inheritance',
                            'Charitable Donations',
                        ]
                    ),
                    'relationship_to_sender' => $faker->randomElement(
                        [
                            'Family',
                            'Friend',
                            'Trade/BusinesPartner',
                            'Employee/Employer',
                            'Donor/Receiver of Ch',
                            'Purchaser/Seller',
                        ]
                    ),
                    'xml_request' => '',
                    'wu_response_headers' => '',
                    'wu_response_body' => '',
                    'status' => $faker->randomElement(ReceiveMoneyPayStatus::cases()),
                    'timestamp' => \now(),
                ],
            ],
        ];
    }
}
