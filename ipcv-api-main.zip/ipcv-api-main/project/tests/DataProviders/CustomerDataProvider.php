<?php

declare(strict_types=1);

namespace Tests\DataProviders;

trait CustomerDataProvider
{
    public function customerDataProvider(): array
    {
        $faker = $this->faker('en_US');

        return [
            [
                [
                    'first_name' => $faker->firstName(),
                    'middle_name' => $faker->firstName(),
                    'last_name' => $faker->lastName(),

                    'address_line_1' => $faker->address(),
                    'address_line_2' => $faker->address(),
                    'city' => $faker->city(),
                    'state' => $faker->city(),
                    'postal_code' => $faker->postcode(),
                    'country' => $faker->country(),
                    'country_code' => $faker->countryCode(),
                    'currency_code' => $faker->currencyCode(),

                    'email' => $faker->safeEmail(),
                    'date_of_birth' => $faker->date(),
                    'nationality' => $faker->country(),
                    'occupation' => $faker->sentence(),
                    'employment_position_level' => $faker->sentence(),
                    'gender' => $faker->randomElement(['M', 'F']),
                    'source_of_funds' => $faker->sentence(),
                    'country_of_birth' => $faker->country(),
                    'phone_country_code' => $faker->countryCode(),
                    'phone_number' => $faker->phoneNumber(),
                ]
            ]
        ];
    }
}
