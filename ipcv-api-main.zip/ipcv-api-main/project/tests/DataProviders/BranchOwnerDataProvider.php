<?php

declare(strict_types=1);

namespace Tests\DataProviders;

trait BranchOwnerDataProvider
{
    public function branchOwnerDataProvider(): array
    {
        $faker = $this->faker('en_US');

        return [
            [
                [
                    'name' => $faker->company(),
                ]
            ]
        ];
    }
}
