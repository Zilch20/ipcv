<?php

namespace Tests\DataProviders;

trait BranchUserDataProvider
{
    public function branchUserDataProvider(): array
    {
        $faker = $this->faker('en_US');

        return [
            [
                [
                    'first_name' => $faker->firstName(),
                    'middle_name' => $faker->firstName(),
                    'last_name' => $faker->lastName(),
                    'email' => $faker->safeEmail(),
                    'is_active' => 1,
                    'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                ]
            ]
        ];
    }
}
