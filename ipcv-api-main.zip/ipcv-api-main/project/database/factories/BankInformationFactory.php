<?php

declare(strict_types=1);

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use IPCV\API\Portal\Models\BankInformation;

class BankInformationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'bank_name' => fake()->company(),
            'account_number' => fake()->phoneNumber(),
            'account_type' => 'BL',
            'routing_number' => fake()->uuid(),
            'branch_number' => fake()->uuid(),
            'bank_location' => fake()->address(),
            'bic' => fake()->uuid(),
            'bank_code' => fake()->uuid(),
            'sort_code' => fake()->uuid(),
            'account_prefix' => fake()->sentence(),
            'account_suffix' => fake()->sentence(),
            'bank_account_holder' => fake()->name(),
        ];
    }

    /**
     * @return class-string<BankInformation>
     */
    public function modelName(): string
    {
        return BankInformation::class;
    }
}
