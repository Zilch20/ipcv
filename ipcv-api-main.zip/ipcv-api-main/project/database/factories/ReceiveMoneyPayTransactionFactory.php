<?php

declare(strict_types=1);

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use IPCV\API\Portal\Models\ReceiveMoneyPayStatus;
use IPCV\API\Portal\Models\ReceiveMoneyPayTransaction;
use function random_int;

class ReceiveMoneyPayTransactionFactory extends Factory
{
    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'mtcn' => random_int(1_000_000_000, 9_999_999_999),
            'new_mtcn' => random_int(1_000_000_000, 9_999_999_999),
            'new_points_earned' => random_int(100, 9999),
            'total_points_earned' => random_int(10_000, 99_999),
            'money_transfer_key' => random_int(1_000_000_000, 9_999_999_999),
            'gross_total_amount' => random_int(1_000_000_000, 9_999_999_999),
            'pay_amount' => random_int(1_000_000_000, 9_999_999_999),
            'principal_amount' => random_int(1_000_000_000, 9_999_999_999),
            'charges' => random_int(100, 999),
            'tolls' => random_int(100, 999),
            'exchange_rate' => 1,
            'originating_currency_code' => 'PHP',
            'originating_country_code' => 'PH',
            'destination_country_code' => 'PH',
            'destination_currency_code' => 'PHP',
            'transaction_type' => fake()->randomElement(['WMN', 'WMF']),
            'purpose' => fake()->randomElement(config('western_union.transaction.reasons')),
            'source_of_funds' => fake()->randomElement(config('western_union.transaction.fund_sources')),
            'relationship_to_sender' => fake()->randomElement(config('western_union.transaction.relationships')),
            'xml_request' => '',
            'wu_response_headers' => '',
            'wu_response_body' => '',
            'status' => fake()->randomElement(ReceiveMoneyPayStatus::cases()),
            'timestamp' => \now()
        ];
    }

    /**
     * @return class-string<ReceiveMoneyPayTransaction>
     */
    public function modelName(): string
    {
        return ReceiveMoneyPayTransaction::class;
    }
}
