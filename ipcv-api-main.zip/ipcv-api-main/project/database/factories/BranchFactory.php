<?php

declare(strict_types=1);

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use IPCV\API\Portal\Models\Branch;

class BranchFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->company(),
            'description' => fake()->sentence(10),
            'address' => fake()->address(),
            'contact_number' => fake()->phoneNumber(),
            'terminal_id' => fake()->uuid(),
            'ftid' => fake()->uuid(),
            'naid' => fake()->uuid(),
            'is_active' => 1,
        ];
    }

    /**
     * @return class-string<Branch>
     */
    public function modelName(): string
    {
        return Branch::class;
    }
}

Branch::create(['name' => fake()->company(),'description' => fake()->sentence(10),'address' => fake()->address(),'contact_number' => fake()->phoneNumber(),'terminal_id' => fake()->uuid(),'ftid' => fake()->uuid(),'naid' => fake()->uuid(),'is_active' => 1]);
