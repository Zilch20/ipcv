<?php

declare(strict_types=1);

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use IPCV\API\Portal\Models\SendMoneyTransaction;
use IPCV\API\Portal\Models\SendMoneyTransactionStatus;

class SendMoneyTransactionFactory extends Factory
{
    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $amount = 50000;
        $charges = 500;
        $messageCharge = 5000;

        return [
            'mtcn' => (string)\random_int(1_000_000_000, 9_999_999_999),
            'new_mtcn' => (string)\random_int(1_000_000_000_000_000, 9_999_999_999_999_999),
            'originators_principal_amount' => (string)$amount,
            'destination_principal_amount' => (string)$amount,
            'gross_total_amount' => (string)($amount + $charges + $messageCharge),
            'exchange_rate' => '1',
            'new_points_earned' => (string)\random_int(100, 999),
            'total_points_earned' => (string)\random_int(1000, 9999),
            'originating_currency_code' => 'PHP',
            'originating_country_code' => 'PH',
            'charges' => (string)$charges,
            'message_charge' => (string)$messageCharge,
            'destination_country_code' => 'PH',
            'destination_currency_code' => 'PHP',
            'transaction_type' => fake()->randomElement(['WMF', 'WMN']),
            'purpose' => fake()->randomElement(
                [
                    'Family Support/Living Expenses',
                    'Saving/Investments',
                    'Gift',
                    'Goods & Services Payment',
                    'Travel Expenses',
                    'Education/School Fee',
                    'Rent/Mortgage',
                    'Emergency/Medical Aid',
                    'Charity/Aid Payment',
                    'Employee Payroll/Employee Expense',
                ]
            ),
            'source_of_funds' => fake()->randomElement(
                [
                    'Cash Tips',
                    'Sale of Goods/Property/Services',
                    'Investment Income',
                    'Salary',
                    'Savings',
                    'Borrowed Funds/Loan',
                    'Gift',
                    'Pension/Government/Welfare',
                    'Inheritance',
                    'Charitable Donations',
                ]
            ),
            'relationship_to_receiver' =>fake()->randomElement(
                [
                    'Family',
                    'Friend',
                    'Trade/BusinesPartner',
                    'Employee/Employer',
                    'Donor/Receiver of Ch',
                    'Purchaser/Seller',
                ]
            ),
            'compliance_data_buffer' => fake()->sentence(12),
            'receiver_first_name' => fake()->firstName(),
            'receiver_middle_name' => fake()->firstName(),
            'receiver_last_name' => fake()->lastName(),
            'messages' => [
                fake()->sentence(),
                fake()->sentence(),
                fake()->sentence(),
                fake()->sentence(),
            ],
            'xml_request' => fake()->sentence(),
            'wu_response_headers' => \json_encode(['foo' => 'bar', 'baz' => 'boz']),
            'wu_response_body' => fake()->sentence(),
            'status' => fake()->randomElement(SendMoneyTransactionStatus::cases()),
        ];
    }

    /**
     * @return class-string<SendMoneyTransaction>
     */
    public function modelName(): string
    {
        return SendMoneyTransaction::class;
    }
}
