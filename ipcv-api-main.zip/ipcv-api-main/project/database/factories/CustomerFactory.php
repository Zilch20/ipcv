<?php

declare(strict_types=1);

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use IPCV\API\Portal\Models\Customer;

class CustomerFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'first_name' => fake()->firstName(),
            'middle_name' => fake()->firstName(),
            'last_name' => fake()->lastName(),

            'address_line_1' => fake()->address(),
            'address_line_2' => fake()->address(),
            'city' => fake()->city(),
            'state' => fake()->city(),
            'postal_code' => fake()->postcode(),
            'country' => fake()->country(),
            'country_code' => fake()->countryCode(),
            'currency_code' => fake()->currencyCode(),

            'email' => fake()->safeEmail(),
            'date_of_birth' => fake()->date(),
            'nationality' => fake()->country(),
            'occupation' => fake()->sentence(),
            'employment_position_level' => fake()->sentence(),
            'gender' => fake()->randomElement(['M', 'F']),
            'source_of_funds' => fake()->sentence(),
            'country_of_birth' => fake()->country(),
            'phone_country_code' => fake()->countryCode(),
            'phone_number' => fake()->phoneNumber(),
        ];
    }

    /**
     * @return class-string<Customer>
     */
    public function modelName(): string
    {
        return Customer::class;
    }
}
