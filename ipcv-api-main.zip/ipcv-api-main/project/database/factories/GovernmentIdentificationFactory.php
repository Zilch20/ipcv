<?php

declare(strict_types=1);

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use IPCV\API\Portal\Models\GovernmentIdentification;

class GovernmentIdentificationFactory extends Factory
{
    private static array $idTypes = [
        'Passport',
        "Driver's license",
        'PRC ID',
        'NBI CLEARANCE',
        'Police Clearance',
        'POSTAL ID',
        'Voter ID',
        'BARANGAY CERTIFICATION',
        'Government Service Insurance System (GSIS) e-Card',
        'Social Security System (SSS) Card',
        'Government issued national identification card',
        'Senior Citizen ID',
        'Overseas Workers Welfare Administration (OWWA) ID',
        'OFW ID',
        "Seaman's Book",
        'Alien/Immigrant Certificate of Registration',
        'PWD/NCWDP ID',
        'DSWD CERTIFICATE',
        'IBP ID',
        'Student ID',
        'Unified Multi Purpose ID (UMID)',
        'TAXPAYER’S ID (TIN)',
        'Other government issued IDs'
    ];

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'type' => fake()->randomElement(self::$idTypes),
            'number' => fake()->phoneNumber(),
            'country_issued' => fake()->country(),
            'issue_date' => fake()->date(),
            'expiry_date' => fake()->date(),
            'url' => fake()->imageUrl(),
        ];
    }

    /**
     * @return class-string<GovernmentIdentification>
     */
    public function modelName(): string
    {
        return GovernmentIdentification::class;
    }
}
