<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use IPCV\API\Portal\Models\Customer;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('bank_information', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('bank_name');
            $table->string('account_number');
            $table->string('account_type')->nullable();
            $table->string('routing_number')->nullable();
            $table->string('branch_number')->nullable();
            $table->string('bank_location')->nullable();
            $table->string('bic')->nullable();
            $table->string('bank_code')->nullable();
            $table->string('sort_code')->nullable();
            $table->string('account_prefix')->nullable();
            $table->string('account_suffix')->nullable();
            $table->string('bank_account_holder')->nullable();
            $table->timestamps();

            $table->index(['account_number', 'bank_name']);
            $table->foreignIdFor(Customer::class)->index();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('bank_information');
    }
};
