<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use IPCV\API\Portal\Models\BranchOwner;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('branches', function (Blueprint $table) {
            $table->uuid('id')->index();
            $table->string('name')->unique();
            $table->string('description')->index();
            $table->string('address');
            $table->string('contact_number');
            $table->string('terminal_id')->index();
            $table->string('ftid')->index();
            $table->string('naid')->index();
            $table->tinyInteger('is_active')->default(1);
            $table->timestamps();

            $table->foreignIdFor(BranchOwner::class)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('branches');
    }
};
