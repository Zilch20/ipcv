<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('customers', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('first_name')->index();
            $table->string('middle_name')->nullable();
            $table->string('last_name')->index();

            $table->string('address_line_1');
            $table->string('address_line_2')->nullable();
            $table->string('city');
            $table->string('state');
            $table->string('postal_code');
            $table->string('country');
            $table->string('country_code');
            $table->string('currency_code');

            $table->string('email')->nullable()->unique();
            $table->date('date_of_birth');
            $table->string('nationality');
            $table->string('occupation');
            $table->string('employment_position_level');
            $table->string('gender');
            $table->string('source_of_funds');
            $table->string('country_of_birth');
            $table->string('phone_country_code');
            $table->string('phone_number')->index();
            $table->string('my_wu_number')->nullable()->index();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('customers');
    }
};
