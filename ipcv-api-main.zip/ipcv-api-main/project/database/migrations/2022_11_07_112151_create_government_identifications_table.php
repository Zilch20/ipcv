<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use IPCV\API\Portal\Models\Customer;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('government_identifications', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('type');
            $table->string('number');
            $table->string('country_issued');
            $table->date('issue_date');
            $table->date('expiry_date')->nullable();
            $table->string('url')->nullable();
            $table->timestamps();

            $table->index(['number', 'type']);
            $table->foreignIdFor(Customer::class)->index();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('government_identifications');
    }
};
