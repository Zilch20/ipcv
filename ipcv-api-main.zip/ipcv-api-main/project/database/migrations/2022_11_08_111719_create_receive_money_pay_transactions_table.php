<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('receive_money_pay_transactions', static function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('mtcn')->index();
            $table->string('new_mtcn')->index();
            $table->string('money_transfer_key')->index();
            $table->string('new_points_earned')->nullable();
            $table->string('total_points_earned')->nullable();
            $table->string('gross_total_amount');
            $table->string('pay_amount');
            $table->string('principal_amount');
            $table->string('charges');
            $table->string('tolls');
            $table->string('exchange_rate');
            $table->string('originating_currency_code');
            $table->string('originating_country_code');
            $table->string('destination_country_code');
            $table->string('destination_currency_code');
            $table->string('transaction_type');
            $table->string('purpose');
            $table->string('source_of_funds');
            $table->string('relationship_to_sender');
            $table->mediumText('xml_request');
            $table->text('wu_response_headers');
            $table->mediumText('wu_response_body');
            $table->tinyInteger('status')->index();
            $table->timestamp('timestamp');
            $table->timestamps();

            $table->foreignIdFor(Branch::class)->type('uuid')->index()->nullable();
            $table->foreignIdFor(Customer::class)->type('uuid')->index()->nullable();
            $table->foreignIdFor(GovernmentIdentification::class)
                ->type('uuid')
                ->index('government_identification_idx')
                ->nullable()
            ;
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('receive_money_transactions');
    }
};
