<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use IPCV\API\Portal\Models\Branch;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('receive_money_search_transactions', static function (Blueprint $table) {
            $table->id();
            $table->tinyInteger('status')->index();
            $table->timestamp('timestamp');
            $table->string('mtcn')->index()->nullable();
            $table->string('new_mtcn')->index()->nullable();
            $table->string('money_transfer_key')->index()->nullable();
            $table->string('sender_first_name')->nullable();
            $table->string('sender_middle_name')->nullable();
            $table->string('sender_last_name')->nullable();
            $table->string('messages')->nullable();
            $table->mediumText('xml_request');
            $table->text('wu_response_headers');
            $table->mediumText('wu_response_body');
            $table->timestamps();

            $table->foreignIdFor(Branch::class)->type('uuid')->index();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('receive_money_search_transaction');
    }
};
