<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\Customer;
use IPCV\API\Portal\Models\GovernmentIdentification;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('send_money_transactions', static function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('mtcn')->index();
            $table->string('new_mtcn');
            $table->string('new_points_earned')->nullable();
            $table->string('total_points_earned')->nullable();
            $table->string('originators_principal_amount')->nullable();
            $table->string('destination_principal_amount')->nullable();
            $table->string('gross_total_amount')->nullable();
            $table->string('exchange_rate')->nullable();
            $table->string('charges')->nullable();
            $table->string('message_charge')->nullable();
            $table->string('originating_currency_code');
            $table->string('originating_country_code');
            $table->string('destination_country_code');
            $table->string('destination_currency_code');
            $table->string('transaction_type');
            $table->string('purpose')->nullable();
            $table->string('source_of_funds')->nullable();
            $table->string('relationship_to_receiver')->nullable();
            $table->text('compliance_data_buffer')->nullable();
            $table->string('receiver_first_name')->index();
            $table->string('receiver_middle_name')->nullable();
            $table->string('receiver_last_name')->index();
            $table->string('messages')->nullable();
            $table->mediumText('xml_request')->nullable();
            $table->text('wu_response_headers')->nullable();
            $table->mediumText('wu_response_body')->nullable();
            $table->tinyInteger('status')->index();
            $table->timestamps();

            $table->foreignIdFor(Branch::class)->index();
            $table->foreignIdFor(Customer::class)->index();
            $table->foreignIdFor(GovernmentIdentification::class)->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('send_money_transactions');
    }
};
