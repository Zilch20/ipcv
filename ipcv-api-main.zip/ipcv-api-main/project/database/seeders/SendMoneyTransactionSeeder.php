<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class SendMoneyTransactionSeeder extends Seeder
{
    public function run(): void
    {

    }
}
