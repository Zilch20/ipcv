<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use IPCV\API\Portal\Models\Branch;
use IPCV\API\Portal\Models\BranchOwner;
use IPCV\API\Portal\Models\BranchUser;

class BranchSeeder extends Seeder
{
    public function run(): void
    {
        $branchOwner = BranchOwner::factory()->create(['name' => 'i-pcv']);
        $branch = Branch::factory()
            ->for($branchOwner)
            ->create([
                'name' => 'Test Branch',
                'description' => 'Test Branch',
                'contact_number' => '+6399999912111',
                'terminal_id' => '123-123-123',
                'ftid' => '123ABC',
                'naid' => '123ABCDE',
                'is_active' => 1,
            ])
        ;
        BranchUser::factory()
            ->for($branch)
            ->create(['email' => 'test@foo.com'])
        ;
    }
}
