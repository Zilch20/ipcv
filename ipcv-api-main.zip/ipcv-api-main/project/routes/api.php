<?php

use Illuminate\Support\Facades\Route;
use IPCV\API\Portal\Http\Controllers\BankInformation\CreateBankInformation;
use IPCV\API\Portal\Http\Controllers\BankInformation\ShowBankInformation;
use IPCV\API\Portal\Http\Controllers\BankInformation\UpdateBankInformation;
use IPCV\API\Portal\Http\Controllers\CountryCurrencies\ListCountryCurrencies;
use IPCV\API\Portal\Http\Controllers\CountryInformationController;
use IPCV\API\Portal\Http\Controllers\Customers\CreateCustomer;
use IPCV\API\Portal\Http\Controllers\Customers\SearchCustomer;
use IPCV\API\Portal\Http\Controllers\Customers\ShowCustomer;
use IPCV\API\Portal\Http\Controllers\Customers\UpdateCustomer;
use IPCV\API\Portal\Http\Controllers\FeeInquiry\FeeInquiry;
use IPCV\API\Portal\Http\Controllers\GovernmentIdentifications\CreateGovernmentIdentification;
use IPCV\API\Portal\Http\Controllers\GovernmentIdentifications\ListGovernmentIdentification;
use IPCV\API\Portal\Http\Controllers\GovernmentIdentifications\ShowGovernmentIdentification;
use IPCV\API\Portal\Http\Controllers\GovernmentIdentifications\UpdateGovernmentIdentification;
use IPCV\API\Portal\Http\Controllers\ProfileController;
use IPCV\API\Portal\Http\Controllers\ReceiveMoney\PrintReceiveMoneyPostACR;
use IPCV\API\Portal\Http\Controllers\ReceiveMoney\PrintReceiveMoneyPreACR;
use IPCV\API\Portal\Http\Controllers\ReceiveMoney\ReceiveMoneyPay;
use IPCV\API\Portal\Http\Controllers\ReceiveMoney\ReceiveMoneySearch;
use IPCV\API\Portal\Http\Controllers\SendAndReceiveMoneyConfig;
use IPCV\API\Portal\Http\Controllers\SendMoney\PrintSendMoneyPostACR;
use IPCV\API\Portal\Http\Controllers\SendMoney\PrintSendMoneyPreACR;
use IPCV\API\Portal\Http\Controllers\SendMoney\SendMoney;
use IPCV\API\Portal\Http\Controllers\SendMoney\SendMoneyStore;
use IPCV\API\Portal\Http\Controllers\SendMoney\SendMoneyValidation;

Route::middleware(['jwt'])->group(static function () {
    Route::get('/profile', ProfileController::class);

    Route::post('/customers', CreateCustomer::class)->name('customers.create');

    Route::patch('/customers/{id}', UpdateCustomer::class)->name('customers.update');
    Route::get('/customers/search', SearchCustomer::class)->name('customers.search');
    Route::get('/customers/{id}', ShowCustomer::class)->name('customers.show');

    Route::post('/customers/{id}/government-identifications', CreateGovernmentIdentification::class)
        ->name('customers.create.government_identification');

    Route::get('/customers/{id}/government-identifications', ListGovernmentIdentification::class)
        ->name('customers.list.government_identifications');

    Route::get('/government-identifications/{id}', ShowGovernmentIdentification::class)
        ->name('government_identification.show');

    Route::patch('/government-identifications/{id}', UpdateGovernmentIdentification::class)
        ->name('government_identification.update');

    Route::post('/customers/{id}/bank-information', CreateBankInformation::class)
        ->name('customers.create.bank_information');

    Route::get('/bank-information/{id}', ShowBankInformation::class)
        ->name('bank_information.show');

    Route::patch('/bank-information/{id}', UpdateBankInformation::class)
        ->name('bank_information.update');

    Route::prefix('western-union')->group(static function () {
        Route::get('/configuration', SendAndReceiveMoneyConfig::class)->name('western_union.config');
        Route::post('/fee-inquiry', FeeInquiry::class)->name('western_union.fee_inquiry');
        Route::post('/send-money', SendMoney::class)->name('western_union.send_money');

        Route::post('/send-money-store', SendMoneyStore::class)->name('western_union.send_money_store');
        Route::post('/send-money-validation', SendMoneyValidation::class)->name('western_union.send_money_validation');

        Route::get('/receive-money-search', ReceiveMoneySearch::class)->name('western_union.receive_money_search');
        Route::post('/receive-money-pay', ReceiveMoneyPay::class)->name('western_union.receive_money_pay');

        Route::get('/send-money-pre-acr/{customerId}/{mtcn}', PrintSendMoneyPreACR::class)->name('western_union.send_money_pre_acr');
        Route::get('/send-money-post-acr/{customerId}/{mtcn}', PrintSendMoneyPostACR::class)->name('western_union.send_money_post_acr');
        Route::get('/receive-money-pre-acr/{customerId}/{mtcn}', PrintReceiveMoneyPreACR::class)->name('western_union.receive_money_pre_acr');
        Route::get('/receive-money-post-acr/{customerId}/{mtcn}', PrintReceiveMoneyPostACR::class)->name('western_union.receive_money_post_acr');
    });

    Route::get('/country-currencies', ListCountryCurrencies::class);
    Route::get('/country-information', CountryInformationController::class);
});
