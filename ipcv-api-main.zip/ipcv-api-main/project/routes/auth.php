<?php

use Illuminate\Routing\Router;
use IPCV\API\Portal\Actions\TwoFactor\TwoFactorQrCodeController;
use IPCV\API\Portal\Http\Controllers\Auth\LoginController;
use IPCV\API\Portal\Http\Controllers\Auth\TwoFactorLoginController;
use IPCV\API\Portal\Http\Controllers\TwoFactor\DisableTwoFactorController;
use IPCV\API\Portal\Http\Controllers\TwoFactor\EnableTwoFactorController;
use IPCV\API\Portal\Http\Controllers\TwoFactor\ListRecoveryCodesController;
use IPCV\API\Portal\Http\Controllers\TwoFactor\RegenerateRecoveryCodesController;
use IPCV\API\Portal\Http\Controllers\TwoFactor\TwoFactorChallengeController;

/**
 * @var Router $router
 */


$router->post('/login', LoginController::class)->name('auth.login');
$router->post('/two-factor-login', TwoFactorLoginController::class)->name('auth.two_factor.login');

$router->middleware('jwt')->group(static function (Router $router) {
    $router->post('/two-factor-challenge', TwoFactorChallengeController::class)->name('auth.two_factor.challenge');
    $router->post('/enable-two-factor-authentication', EnableTwoFactorController::class)->name('auth.two_factor.enable');
    $router->post('/disable-two-factor-authentication', DisableTwoFactorController::class)->name('auth.two_factor.disable');
    $router->get('/two-factor-qr-code', [TwoFactorQrCodeController::class, 'json'])->name('auth.two_factor.qr_code_json');
    $router->get('/two-factor-qr-code/html', [TwoFactorQrCodeController::class, 'html'])->name('auth.two_factor.qr_code_html');
    $router->get('/two-factor-recovery-codes', ListRecoveryCodesController::class)->name('auth.two_factor.list_recovery_codes');
    $router->post('/two-factor-recovery-codes', RegenerateRecoveryCodesController::class)->name('auth.two_factor.regenerate_recovery_codes');
});
