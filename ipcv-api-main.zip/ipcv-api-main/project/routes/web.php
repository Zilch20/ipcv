<?php

//Route::get('/', static fn() => new JsonResponse(['message' => 'I-PCV API']));
