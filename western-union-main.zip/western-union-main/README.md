# western-union
Unofficial Western Union Gateway API Library

![Unit Tests (PHP 8.1)](https://github.com/IPCVI/western-union/workflows/PHP%208.1/badge.svg)

- [Western Union](#western-union)
  - [Installation](#installation)
  - [Usage](#usage)
    - [Creating HTTP Client](#creating-the-http-client)
    - [Fee Inquiry Request](#fee-inquiry-request)
    - [Send Money Validation Request](#send-money-validation-request)
    - [Send Money Store Request](#send-money-store-request)

## Installation
`composer install ipcv/western-union`

## Usage
### Creating the HTTP client
```php
$config = [
    'base_uri' => 'https://western-union.url', // Western Union gateway base url
    'headers' => [
        'User-Agent' => 'ipcv-api/1.0', // This could be your application name
        'Content-Type' => 'text/xml', // Western Union Gateway only accepts content of type text/xml
    ],
    'cert' => '/path/to/ssl/certificate/file', // Western Union Gateway SSL certificate file path
    'ssl_key' => [
        'path/to/ssl/key/file', // Western Union SSL key file path
        'path/to/ssl/key/passphrase', // Western Union SSL key passphrase file path
    ],
]

$guzzleClient = new \GuzzleHttp\Client($config)

// Western Union Gateway Client
$client = new \IPCV\WesternUnion\HttpClient($guzzleClient)
$client->send($request);
```
An `interface` is available so that you can mock the http client or do dependency injection.
#### Laravel Example
In your service provider:
```php
use Illuminate\Support\ServiceProvider;

class MyServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->singleton(
            IPCV\WesternUnion\Client::class,
            static fn () => new IPCV\WesternUnion\HttpClient(new \GuzzleHttp\Client($config))
        )
    }
}
```

In your controller:
```php
class MyController 
{
    public function __construct(private readonly IPCV\WesternUnion\Client $client) 
    {
    }
    
    public function __invoke()
    {
        $this->client->send($request)
    }
}
```

### Sending Western Union Requests

### Important note:
Western Union treats the last 2 digits as decimal places on the financials section. For example, `50000` is actually `500.00`.

### Fee Inquiry Request
This request sends information about the sender's location, currency, amount to be sent, message, and receiver's currency, and location. Western Union then uses this information and returns the calculated amount to be paid, charges, and exchange rate between the sender's currency and receiver's currency.


```php
/** 
 * @var \IPCV\WesternUnion\Client $client 
 */
$client;

$request = (new IPCV\WesternUnion\FeeInquiry\Request())
    ->setDevice(
        (new \IPCV\WesternUnion\Device())
            ->setId('AGENT')
            ->setType('AGENT')
    )
    ->setChannel(new \IPCV\WesternUnion\Channel(type: 'H2H', name: 'IPCV', version: '9500'))
    ->setFinancials(
        (new \IPCV\WesternUnion\Financials())
            ->setOriginatorsPrinicpalAmount('50000')
            ->setDestinationPrinicipalAmount('50000')
    )
    ->setPaymentDetails(
        (new \IPCV\WesternUnion\PaymentDetails())
            ->setExpectedPayoutLocation(
                (new \IPCV\WesternUnion\ExpectedPayoutLocation())
                    ->setStateCode('Laguna')
                    ->setCity('Santa Rosa')
            )
            ->setRecordingCountryCurrency(new \IPCV\WesternUnion\RecordingCountryCurrency(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP')))
            ->setDestinationCountryCurrency(new \IPCV\WesternUnion\DestinationCountryCurrency(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP')))
            ->setOriginatingCountryCurrency(new \IPCV\WesternUnion\OriginatingCountryCurrency(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP')))
            ->setTransactionType(\IPCV\WesternUnion\TransactionType::WMF)
            ->setPaymentType(\IPCV\WesternUnion\PaymentType::CASH)
    )
    ->setDeliveryServices(
        (new \IPCV\WesternUnion\DeliveryServices())
            ->setCode(\IPCV\WesternUnion\ServiceType::WILL_OR_CALL)
            ->setMessage(
                (new \IPCV\WesternUnion\Message())
                    ->add('Message 1 Maximum of 69 (nice) characters each.')
                    ->add('Message 2 Maximum of 4 messages only.')
                    ->add('Message 3')
                    ->add('Message 4')
            )
    )

/**
 * @var \Psr\Http\Message\ResponseInterface $response
 */
$response = $client->send($request);
```
The return type of the `IPCV\WesternUnion\Client::send()` method is of type `Psr\Http\Message\ResponseInterface`. You can get the response body by calling the `ResponseInterface::getBody()` method.
```php
/**
 * @var \Psr\Http\Message\ResponseInterface $response
 */
$response = $client->send($request);
$responseAsString = (string)$response->getBody();
```
Calling `ResponseInterface::getBody()` will return an object that implements the `\Psr\Http\Message\StreamInterface`, which has the `Psr\Http\Message\StreamInterface::__toString()` method, by casting the object to string, this method will be called, which in turn returns the response body as a string.

### Sample Western Union Fee Inquiry Response
```xml
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <soapenv:Body>
        <xrsi:fee-inquiry-reply xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <instant_notification>
                <addl_service_charges>010300002010030100103MSG02045000030450001103FEE12035001303500962101045000020210030350099200101C0211PIL00009699</addl_service_charges>
            </instant_notification>
            <financials>
                <taxes>
                    <tax_rate>0</tax_rate>
                    <municipal_tax>0</municipal_tax>
                    <state_tax>0</state_tax>
                    <county_tax>0</county_tax>
                    <tax_worksheet/>
                </taxes>
                <originators_principal_amount>50000</originators_principal_amount>
                <destination_principal_amount>50000</destination_principal_amount>
                <gross_total_amount>55500</gross_total_amount>
                <plus_charges_amount>0</plus_charges_amount>
                <pay_amount>50000</pay_amount>
                <charges>500</charges>
                <tolls>5000</tolls>
                <originating_currency_principal/>
                <canadian_dollar_exchange_fee>0</canadian_dollar_exchange_fee>
                <message_charge>5000</message_charge>
            </financials>
            <promotions>
                <promo_code_description/>
                <promo_sequence_no/>
                <promo_name/>
                <promo_discount_amount>0</promo_discount_amount>
            </promotions>
            <foreign_remote_system>
                <identifier>WGHHPH5130T</identifier>
                <reference_no>M6PZPDA7PdspLP6c</reference_no>
                <counter_id>PH513AMP001C</counter_id>
            </foreign_remote_system>
            <payment_details>
                <exchange_rate>1.0000000</exchange_rate>
            </payment_details>
            <fee_inquiry_message>
                <base_message_charge>5000</base_message_charge>
                <base_message_limit>10</base_message_limit>
                <incremental_message_charge>500</incremental_message_charge>
                <incremental_message_limit>10</incremental_message_limit>
            </fee_inquiry_message>
        </xrsi:fee-inquiry-reply>
    </soapenv:Body>
</soapenv:Envelope>
```

### Send Money Validation Request
This request sends all transaction data and Western Union validates it, and returns all data along with the `compliance_data_buffer`, `mtcn`, and `new_mtcn`.
```php
/** 
 * @var \IPCV\WesternUnion\Client $client 
 */
$client;

$request = (new \IPCV\WesternUnion\SendMoneyValidation\Request())
    ->setChannel(new \IPCV\WesternUnion\Channel(type: 'H2H', name: 'IPCV', version: '9500'))
    ->setSender(
        (new \IPCV\WesternUnion\Sender())
            ->setName(\IPCV\WesternUnion\Name::createTypeD(firstName: 'John', middleName: 'Joe', lastName: 'Doe'))
            ->setAddress(
                (new \IPCV\WesternUnion\Address(
                    addressLine1: 'Block 1 Lot 10 Phase 3 Foobar Street',
                    state: 'Laguna',
                    postalCode: '4000',
                    countryCode: new \IPCV\WesternUnion\CountryCode(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP'), country_name: 'Philippines'))
                )
                    ->setCity('Ciy of San Pedro')
                    ->setAddressLine2('Sun Subdivision, Barangay FooBar')
            )
            ->setPreferredCustomer(new \IPCV\WesternUnion\PreferredCustomer(\IPCV\WesternUnion\PermanentChange::None, myWuNumber: '123-123-123'))
            ->setComplianceDetails(
                (new \IPCV\WesternUnion\ComplianceDetails())
                    ->setTemplateId('UNI_01_S')
                    ->setVersion('PH_1.1')
                    ->setIdDetails(new \IPCV\WesternUnion\IdDetails(\IPCV\WesternUnion\IdType::NATIONAL_ID, idCountryOfIssue: 'Philippines', idNumber: '123-123-123'))
                    ->setThirdPartyDetails(new \IPCV\WesternUnion\ThirdPartyDetails(\IPCV\WesternUnion\Option::N))
                    ->setIdIssueDate(new \DateTimeImmutable())
                    ->setIdExpirationDate(new \DateTimeImmutable())
                    ->setDateOfBirth(new \DateTimeImmutable())
                    ->setOccupation('Driver')
                    ->setTransactionReason('Gift')
                    ->setCurrentAddress(
                        (new \IPCV\WesternUnion\CurrentAddress())
                            ->setAddrLine1('address line one')
                            ->setAddrLine2('address line two')
                            ->setCity('City of San Pedro')
                            ->setStateName('Laguna')
                            ->setPostalCode('4000')
                            ->setCountry('Philippines')
                    )
                    ->setCountryOfBirth('Philippines')
                    ->setNationality('Philippines')
                    ->setGender(\IPCV\WesternUnion\Gender::M)
                    ->setSourceOfFunds('Cash Tips')
                    ->setRelationshipToReceiverSender('Family')
                    ->setAckFlag('X')
                    ->setMultiErrorSupported(\IPCV\WesternUnion\Option::Y)
                    ->setEmploymentPositionLevel('Entry Level')
            )
            ->setEmail('foobar@email.com')
            ->setPhoneCountryCode('63')
            ->setContactPhone('639123456789')
            ->setMobilePhone(new \IPCV\WesternUnion\MobilePhone(new \IPCV\WesternUnion\PhoneNumber(countryCode: '63', nationalNumber: '639123456789')))
    )
    ->setReciver(
        (new \IPCV\WesternUnion\Receiver())
            ->setName(\IPCV\WesternUnion\Name::createTypeD(firstName: 'Jane', middleName: 'Doe', lastName: 'Doe'))
            ->setAddress(
                (new \IPCV\WesternUnion\Address(addressLine1: 'Foo Bar Street', state: 'Laguna', postalCode: '4000', countryCode: new \IPCV\WesternUnion\CountryCode(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP'), country_name: 'Philippines')))
            )
            ->setPhoneCountryCode('63')
            ->setMobilePhone(new \IPCV\WesternUnion\MobilePhone(new \IPCV\WesternUnion\PhoneNumber(countryCode: '63', nationalNumber: '639123456789')))
    )
    ->setPromotions(
        (new \IPCV\WesternUnion\Promotions())
            ->setCouponsPromotions('')
            ->setSenderPromoCode('')
    )
    ->setPaymentDetails(
        (new \IPCV\WesternUnion\PaymentDetails())
            ->setTransactionType(\IPCV\WesternUnion\TransactionType::WMF)
            ->setPaymentType(\IPCV\WesternUnion\PaymentType::CASH)
            ->setExpectedPayoutLocation(
                (new \IPCV\WesternUnion\ExpectedPayoutLocation())
                    ->setStateCode('Laguna')
                    ->setCity('City of San Pedro')
            )
            ->setOriginatingCountryCurrency(new \IPCV\WesternUnion\OriginatingCountryCurrency(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP')))
            ->setDestinationCountryCurrency(new \IPCV\WesternUnion\DestinationCountryCurrency(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP')))
            ->setPayWoIdIndicator(\IPCV\WesternUnion\Option::N)
            ->setDuplicateDetectionFlag('D')
            ->setExchangeRate(1.0)
    )
    ->setFinancials(
        (new \IPCV\WesternUnion\Financials())
            ->setOriginatorsPrinicpalAmount(50_000)
            ->setDestinationPrinicipalAmount(50_000)
            ->setGrossTotalAmount(50_000)
            ->setPlusChargesAmount(0)
            ->setCharges(100)
            ->setMessageCharge(0)
    )
    ->setDeliveryServices(
        (new \IPCV\WesternUnion\DeliveryServices())
            ->setCode(\IPCV\WesternUnion\ServiceType::WILL_OR_CALL)
            ->setMessage(
                (new \IPCV\WesternUnion\Message())
                    ->add('Message 1 Maximum of 69 (nice) characters each.')
                    ->add('Message 2 Maximum of 4 messages only.')
                    ->add('Message 3')
                    ->add('Message 4')
            )
    )
    ->setForeignRemoteSystem(new \IPCV\WesternUnion\ForeignRemoteSystem(identifier: 'WGHHPH9940P', referenceNumber: '16char-refNo', counterId: 'ABC123'))
;

$response = $client->send($request);

$responseBodyAsString = (string)$response->getBody();
```
### Sample Western Union Send Money Validate Response
```xml
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/">
    <soapenv:Body>
        <xrsi:send-money-validation-reply xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <channel>
                <version>9500</version>
            </channel>
            <instant_notification>
                <addl_service_charges>010300002010030100103MSG02010030101103FEE1204250013042500962101045000020210030350099200101C0211PIL00009698</addl_service_charges>
            </instant_notification>
            <sender>
                <name name_type="D">
                    <first_name>FooTest</first_name>
                    <last_name>BarTest</last_name>
                </name>
                <address>
                    <addr_line1>5578 TEST IPAY API</addr_line1>
                    <city>ST LOUIS</city>
                    <state>Bataan</state>
                    <postal_code>11005</postal_code>
                    <country_code>
                        <iso_code>
                            <country_code>PH</country_code>
                            <currency_code>PHP</currency_code>
                        </iso_code>
                        <country_name>Philippines</country_name>
                    </country_code>
                </address>
                <preferred_customer>
                    <mywu_number>873F70452</mywu_number>
                </preferred_customer>
                <compliance_details>
                    <compliance_data_buffer>0108UNI_01_S0201A0309G527521000613United States0708051020010825Airline/Maritime Employee0908051020111008051020312401N2011Philippines29185578 TEST IPAY API8606Bataan3008ST LOUIS3105110059901X3313United States3413United States3501M4407Savings2118Saving/Investments7006FriendJ6194000000000205808439J701YM711Entry LevelO606PH_1.1</compliance_data_buffer>
                </compliance_details>
                <phone_country_code>1</phone_country_code>
                <contact_phone>2025557021</contact_phone>
                <mobile_phone>
                    <phone_number>
                        <country_code>1</country_code>
                        <national_number>2025557021</national_number>
                    </phone_number>
                </mobile_phone>
                <bank_details>
                    <account_number>7112015063458604</account_number>
                </bank_details>
            </sender>
            <receiver>
                <name name_type="D">
                    <first_name>John</first_name>
                    <last_name>DoeTest</last_name>
                </name>
                <address>
                    <addr_line1>5578 pershing</addr_line1>
                    <city>saint louis</city>
                    <country_code>
                        <iso_code>
                            <country_code>PH</country_code>
                            <currency_code>PHP</currency_code>
                        </iso_code>
                        <country_name>Philippines</country_name>
                    </country_code>
                    <address_type>I</address_type>
                </address>
                <mobile_phone>
                    <phone_number/>
                </mobile_phone>
            </receiver>
            <payment_details>
                <expected_payout_location/>
                <recording_country_currency>
                    <iso_code>
                        <country_code>PH</country_code>
                        <currency_code>PHP</currency_code>
                    </iso_code>
                </recording_country_currency>
                <destination_country_currency>
                    <iso_code>
                        <country_code>PH</country_code>
                        <currency_code>PHP</currency_code>
                    </iso_code>
                </destination_country_currency>
                <originating_country_currency>
                    <iso_code>
                        <country_code>PH</country_code>
                        <currency_code>PHP</currency_code>
                    </iso_code>
                </originating_country_currency>
                <originating_city>MAKATI</originating_city>
                <originating_state>ME</originating_state>
                <transaction_type>WMN</transaction_type>
                <payment_type>Cash</payment_type>
                <exchange_rate>1.0000000</exchange_rate>
                <fix_on_send>Y</fix_on_send>
                <pay_wo_id_indicator>N</pay_wo_id_indicator>
                <credit_debit_card_details>
                    <authorization_code/>
                </credit_debit_card_details>
                <duplicate_detection_flag>D</duplicate_detection_flag>
            </payment_details>
            <financials>
                <taxes>
                    <municipal_tax>0</municipal_tax>
                    <state_tax>0</state_tax>
                    <county_tax>0</county_tax>
                </taxes>
                <originators_principal_amount>150003</originators_principal_amount>
                <destination_principal_amount>150003</destination_principal_amount>
                <gross_total_amount>152503</gross_total_amount>
                <plus_charges_amount>0</plus_charges_amount>
                <charges>2500</charges>
                <message_charge>0</message_charge>
            </financials>
            <promotions>
                <promo_code_description/>
                <promo_message/>
                <sender_promo_code/>
            </promotions>
            <mtcn>8157847209</mtcn>
            <new_mtcn>2226688157847209</new_mtcn>
            <foreign_remote_system>
                <identifier>WGHHPH5131P</identifier>
                <reference_no>115210-000000003</reference_no>
                <counter_id>PH513AMP001E</counter_id>
            </foreign_remote_system>
            <filing_date>09-23</filing_date>
            <filing_time>0314A EDT </filing_time>
            <Is_convenience_search_flag>Y</Is_convenience_search_flag>
            <Is_convenience_suppress_Flag>Y</Is_convenience_suppress_Flag>
        </xrsi:send-money-validation-reply>
    </soapenv:Body>
</soapenv:Envelope>
```
### Important Note:
The fields `mtcn`, `new_mtcn`, and `compliance_data_buffer` are needed from send money validate response in order to perform send money store request.

### Send Money Store Request
Send Money Store request stores the transaction data in Western Union which can be received if successful.
```php
/** 
 * @var \IPCV\WesternUnion\Client $client 
 */
$client;

$request = (new IPCV\WesternUnion\SendMoneyStore\Request())
    ->setChannel(new \IPCV\WesternUnion\Channel(type: 'H2H', name: 'IPCV', version: '9500'))
    ->setMtcn('8157847209')
    ->setNewMtcn('2226688157847209')
    ->setSender(
        (new \IPCV\WesternUnion\Sender())
        ->setName(\IPCV\WesternUnion\Name::createTypeD(firstName: 'John', middleName: 'Joe', lastName: 'Doe'))
        ->setAddress(
            (new \IPCV\WesternUnion\Address(
                addressLine1: 'Block 1 Lot 10 Phase 3 Foobar Street',
                state: 'Laguna',
                postalCode: '4000',
                countryCode: new \IPCV\WesternUnion\CountryCode(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP'), country_name: 'Philippines'))
            )
                ->setCity('Ciy of San Pedro')
                ->setAddressLine2('Sun Subdivision, Barangay FooBar')
        )
        ->setPreferredCustomer(new \IPCV\WesternUnion\PreferredCustomer(\IPCV\WesternUnion\PermanentChange::None, myWuNumber: '123-123-123'))
        ->setComplianceDetails(
            (new \IPCV\WesternUnion\ComplianceDetails())
                ->setComplianceDataBuffer('0108UNI_01_S0201A0317123-32111-223-1230611Philippines0708180119960824IT and Tech Professional0908010120181008010120282401N2011Philippines2910Foo Street8606LAGUNA3012Calamba City310440219901X3311Philippines3411Philippines3501M4406Salary2130Family Support/Living Expenses7006FamilyJ6194000000000218190315J701YM711Entry LevelO606PH_1.1')
        )
        ->setEmail('foobar@email.com')
        ->setPhoneCountryCode('63')
        ->setContactPhone('639123456789')
        ->setMobilePhone(new \IPCV\WesternUnion\MobilePhone(new \IPCV\WesternUnion\PhoneNumber(countryCode: '63', nationalNumber: '639123456789')))
    )
    ->setReceiver(
        (new \IPCV\WesternUnion\Receiver())
            ->setName(\IPCV\WesternUnion\Name::createTypeD(firstName: 'Jane', middleName: 'Doe', lastName: 'Doe'))
            ->setAddress(
                (new \IPCV\WesternUnion\Address(addressLine1: 'Foo Bar Street', state: 'Laguna', postalCode: '4000', countryCode: new \IPCV\WesternUnion\CountryCode(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP'), country_name: 'Philippines')))
            )
            ->setPhoneCountryCode('63')
            ->setMobilePhone(new \IPCV\WesternUnion\MobilePhone(new \IPCV\WesternUnion\PhoneNumber(countryCode: '63', nationalNumber: '639123456789')))
    )
    ->setPromotions(
        (new \IPCV\WesternUnion\Promotions())
            ->setCouponsPromotions('')
            ->setSenderPromoCode('')
    )
    ->setPaymentDetails(
        (new \IPCV\WesternUnion\PaymentDetails())
            ->setTransactionType(\IPCV\WesternUnion\TransactionType::WMF)
            ->setPaymentType(\IPCV\WesternUnion\PaymentType::CASH)
            ->setExpectedPayoutLocation(
                (new \IPCV\WesternUnion\ExpectedPayoutLocation())
                    ->setStateCode('Laguna')
                    ->setCity('City of San Pedro')
            )
            ->setOriginatingCountryCurrency(new \IPCV\WesternUnion\OriginatingCountryCurrency(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP')))
            ->setDestinationCountryCurrency(new \IPCV\WesternUnion\DestinationCountryCurrency(new \IPCV\WesternUnion\IsoCode(countryCode: 'PH', currencyCode: 'PHP')))
            ->setPayWoIdIndicator(\IPCV\WesternUnion\Option::N)
            ->setDuplicateDetectionFlag('D')
            ->setExchangeRate(1.0)
    )
    ->setFinancials(
        (new \IPCV\WesternUnion\Financials())
            ->setOriginatorsPrinicpalAmount(50_000)
            ->setDestinationPrinicipalAmount(50_000)
            ->setGrossTotalAmount(50_000)
            ->setPlusChargesAmount(0)
            ->setCharges(100)
            ->setMessageCharge(0)
    )
    ->setDeliveryServices(
        (new \IPCV\WesternUnion\DeliveryServices())
            ->setCode(\IPCV\WesternUnion\ServiceType::WILL_OR_CALL)
            ->setMessage(
                (new \IPCV\WesternUnion\Message())
                    ->add('Message 1 Maximum of 69 (nice) characters each.')
                    ->add('Message 2 Maximum of 4 messages only.')
                    ->add('Message 3')
                    ->add('Message 4')
            )
    )
    ->setForeignRemoteSystem(new \IPCV\WesternUnion\ForeignRemoteSystem(identifier: 'WGHHPH9940P', referenceNumber: '16char-refNo', counterId: 'ABC123'))
;

$response = $client->send($request);
$responseBodyAsString = (string)$response->getBody();
```
### Sample Western Union Send Money Store Response
```xml
<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <soapenv:Body>
        <xrsi:send-money-store-reply xmlns:xrsi="http://www.westernunion.com/schema/xrsi">
            <instant_notification>
                <addl_service_charges>010300002010030100103MSG02010030101103FEE12031001303100962101045000020210030350099200101C0211PIL00009698</addl_service_charges>
            </instant_notification>
            <advisory_text>02/28/23 00:07</advisory_text>
            <sender>
                <name name_type="D">
                    <first_name>Test</first_name>
                    <middle_name>T</middle_name>
                    <last_name>Test</last_name>
                </name>
                <address>
                    <addr_line1>Foo St.</addr_line1>
                    <city>Calamba</city>
                    <state>LAGUNA</state>
                    <postal_code>4000</postal_code>
                    <country_code>
                        <iso_code>
                            <country_code>PH</country_code>
                            <currency_code>PHP</currency_code>
                        </iso_code>
                        <country_name>Philippines</country_name>
                    </country_code>
                </address>
                <preferred_customer>
                    <mywu_number>015E38927</mywu_number>
                </preferred_customer>
                <compliance_details>
                    <compliance_data_buffer>0108UNI_01_S0201A0318123-321-2221-233340611Philippines0708200719950819Laborer-Agriculture0908200620181008200620282401N2011Philippines2907Foo St.8606LAGUNA3007Calamba310440009901X3311Philippines3411Philippines3501M4409Cash Tips2130Family Support/Living Expenses7006FamilyJ6194000000000212312074J701YO606PH_1.1</compliance_data_buffer>
                </compliance_details>
                <phone_country_code>63</phone_country_code>
                <contact_phone>99999912177</contact_phone>
                <mobile_phone>
                    <phone_number>
                        <country_code>63</country_code>
                        <national_number>99999912177</national_number>
                    </phone_number>
                </mobile_phone>
            </sender>
            <receiver>
                <name name_type="D">
                    <first_name>Tester</first_name>
                    <middle_name>T</middle_name>
                    <last_name>Tester</last_name>
                </name>
                <address>
                    <country_code>
                        <iso_code>
                            <country_code>PH</country_code>
                            <currency_code>PHP</currency_code>
                        </iso_code>
                        <country_name>Philippines</country_name>
                    </country_code>
                </address>
                <mobile_phone>
                    <phone_number/>
                </mobile_phone>
            </receiver>
            <payment_details>
                <expected_payout_location/>
                <recording_country_currency>
                    <iso_code>
                        <country_code>PH</country_code>
                        <currency_code>PHP</currency_code>
                    </iso_code>
                </recording_country_currency>
                <destination_country_currency>
                    <iso_code>
                        <country_code>PH</country_code>
                        <currency_code>PHP</currency_code>
                    </iso_code>
                </destination_country_currency>
                <originating_country_currency>
                    <iso_code>
                        <country_code>PH</country_code>
                        <currency_code>PHP</currency_code>
                    </iso_code>
                </originating_country_currency>
                <originating_city>MAKATI</originating_city>
                <originating_state>ME</originating_state>
                <transaction_type>WMN</transaction_type>
                <exchange_rate>1.0000000</exchange_rate>
                <fix_on_send>Y</fix_on_send>
                <pay_wo_id_indicator>N</pay_wo_id_indicator>
                <credit_debit_card_details>
                    <authorization_code/>
                </credit_debit_card_details>
            </payment_details>
            <financials>
                <taxes/>
                <originators_principal_amount>100</originators_principal_amount>
                <destination_principal_amount>100</destination_principal_amount>
                <gross_total_amount>200</gross_total_amount>
                <charges>100</charges>
            </financials>
            <promotions>
                <promo_code_description/>
                <promo_message/>
                <sender_promo_code/>
            </promotions>
            <mtcn>7373998006</mtcn>
            <new_mtcn>2305987373998006</new_mtcn>
            <filing_date>02-28</filing_date>
            <filing_time>1207A EST </filing_time>
            <pin_text_message_set_2/>
            <pin_text_message_set_2/>
            <pin_text_message_set_2/>
            <promo_text_message/>
            <promo_text_message/>
            <promo_text_message/>
            <promo_text_message/>
            <promo_text_message/>
            <promo_text_message/>
            <new_points_earned>0</new_points_earned>
            <phone_pin/>
            <phone_pin_text/>
            <auto_enroll_text/>
            <auto_enroll_text/>
            <auto_enroll_text/>
            <foreign_remote_system>
                <identifier>WGHHPH5130P</identifier>
                <reference_no>115210-000000003</reference_no>
                <counter_id>PH513ARP001A</counter_id>
            </foreign_remote_system>
            <host_message_set3/>
            <host_message_set3/>
            <host_message_set3/>
            <Is_convenience_search_flag>Y</Is_convenience_search_flag>
            <Is_convenience_suppress_Flag>Y</Is_convenience_suppress_Flag>
        </xrsi:send-money-store-reply>
    </soapenv:Body>
</soapenv:Envelope>
```
