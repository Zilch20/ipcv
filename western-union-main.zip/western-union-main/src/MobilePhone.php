<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

final class MobilePhone implements XmlSerializable
{
    use XmlHelper;

    public function __construct(public readonly PhoneNumber $phone_number)
    {
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<mobile_phone></mobile_phone>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
