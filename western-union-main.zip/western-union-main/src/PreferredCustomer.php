<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

class PreferredCustomer implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly PermanentChange $permanent_change;

    public readonly string $mywu_number;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(PermanentChange $permanentChange, string $myWuNumber)
    {
        $this->permanent_change = $permanentChange;
        $this->mywu_number = self::throwIfExceedsMaxLength($myWuNumber, 11);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<preferred_customer></preferred_customer>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
