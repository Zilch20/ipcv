<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Filters implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    /**
     * @var string[]
     */
    private array $filters = [];

    /**
     * @throws InvalidArgumentException
     */
    public function addFilter(string $filter): self
    {
        $this->filters[] = self::throwIfExceedsMaxLength($filter, 360);

        return $this;
    }

    /**
     * @return string[]
     */
    public function filters(): array
    {
        return $this->filters;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<filters></filters>');

        foreach ($this->filters() as $index => $filter) {
            $index++;
            $xml->addChild('queryfilter' . $index, $filter);
        }

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
