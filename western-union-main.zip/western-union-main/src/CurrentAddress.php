<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class CurrentAddress implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $addr_line1;

    public readonly string $addr_line2;

    public readonly string $city;

    public readonly string $state_name;

    public readonly string $postal_code;

    public readonly string $country;

    public function __construct()
    {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAddrLine1(string $addrLine1): self
    {
        $this->addr_line1 = self::throwIfExceedsMaxLength($addrLine1, 40);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAddrLine2(string $addrLine2): self
    {
        $this->addr_line2 = self::throwIfExceedsMaxLength($addrLine2, 40);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setCity(string $city): self
    {
        $this->city = self::throwIfExceedsMaxLength($city, 24);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setStateName(string $stateName): self
    {
        $this->state_name = self::throwIfExceedsMaxLength($stateName, 40);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setPostalCode(string $postalCode): self
    {
        $this->postal_code = self::throwIfExceedsMaxLength($postalCode, 9);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setCountry(string $country): self
    {
        $this->country = self::throwIfExceedsMaxLength($country, 44);

        return $this;
    }

    /**
     * @return array{
     *     addr_line1?: string,
     *     addr_line2?: string,
     *     city?: string,
     *     state_name?: string,
     *     postal_code?: string,
     *     country?: string,
     * }
     */
    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<Current_address></Current_address>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
