<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;

trait ValidatesInputLength
{
    /**
     * @throws InvalidArgumentException;
     */
    public static function throwIfExceedsMaxLength(string $input, int $maxLength): string
    {
        if (\strlen($input) > $maxLength) {
            throw new InvalidArgumentException("$input exceeds the max length of $maxLength characters.");
        }

        return $input;
    }
}
