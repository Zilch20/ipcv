<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

final class OriginalDestinationCountryCurrency implements XmlSerializable
{
    use XmlHelper;

    public function __construct(
        public readonly IsoCode $iso_code,
    ) {
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $originatingCountryAsSimpleXml = new SimpleXMLElement(
            '<original_destination_country_currency></original_destination_country_currency>'
        );
        $this->insertPropertiesAsChildToElement($originatingCountryAsSimpleXml, $this->toArray());

        if ($parent === null) {
            return $originatingCountryAsSimpleXml;
        }

        $this->appendChildToParent($parent, $originatingCountryAsSimpleXml);

        return $parent;
    }
}
