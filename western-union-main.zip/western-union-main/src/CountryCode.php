<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class CountryCode implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly IsoCode $iso_code;

    public readonly string $country_name;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(IsoCode $isoCode, string $country_name)
    {
        $this->iso_code = $isoCode;
        $this->country_name = self::throwIfExceedsMaxLength($country_name, 40);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new \SimpleXMLElement('<country_code></country_code>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
