<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class PaymentDetails implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly ExpectedPayoutLocation $expected_payout_location;

    public readonly RecordingCountryCurrency $recording_country_currency;

    public readonly DestinationCountryCurrency $destination_country_currency;

    public readonly OriginatingCountryCurrency $originating_country_currency;

    public readonly TransactionType $transaction_type;

    public readonly PaymentType $payment_type;

    public readonly string $exchange_rate;

    public readonly Option $pay_wo_id_indicator;

    public readonly string $duplicate_detection_flag;

    public readonly OriginalDestinationCountryCurrency $original_destination_country_currency;

    public function setTransactionType(TransactionType $transactionType): self
    {
        $this->transaction_type = $transactionType;

        return $this;
    }

    public function setPaymentType(PaymentType $paymentType): self
    {
        $this->payment_type = $paymentType;

        return $this;
    }

    public function setExchangeRate(float $exchangeRate): self
    {
        $this->exchange_rate = (string)$exchangeRate;

        return $this;
    }

    public function setExpectedPayoutLocation(ExpectedPayoutLocation $expectedPayoutLocation): self
    {
        $this->expected_payout_location = $expectedPayoutLocation;

        return $this;
    }

    public function setRecordingCountryCurrency(RecordingCountryCurrency $recordingCountryCurrency): self
    {
        $this->recording_country_currency = $recordingCountryCurrency;

        return $this;
    }

    public function setOriginatingCountryCurrency(OriginatingCountryCurrency $originatingCountryCurrency): self
    {
        $this->originating_country_currency = $originatingCountryCurrency;

        return $this;
    }

    public function setDestinationCountryCurrency(DestinationCountryCurrency $destinationCountryCurrency): self
    {
        $this->destination_country_currency = $destinationCountryCurrency;

        return $this;
    }

    public function setPayWoIdIndicator(Option $option): self
    {
        $this->pay_wo_id_indicator = $option;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setDuplicateDetectionFlag(string $duplicateDetectionFlag): self
    {
        $this->duplicate_detection_flag = self::throwIfExceedsMaxLength($duplicateDetectionFlag, 1);

        return $this;
    }

    public function setOriginalDestinationCountryCurrency(
        OriginalDestinationCountryCurrency $originalDestinationCountryCurrency
    ): self {
        $this->original_destination_country_currency = $originalDestinationCountryCurrency;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $paymentDetailsAsXml = new \SimpleXMLElement('<payment_details></payment_details>');

        $this->insertPropertiesAsChildToElement($paymentDetailsAsXml, $this->toArray());

        if ($parent === null) {
            return $paymentDetailsAsXml;
        }

        $this->appendChildToParent($parent, $paymentDetailsAsXml);

        return $parent;
    }
}
