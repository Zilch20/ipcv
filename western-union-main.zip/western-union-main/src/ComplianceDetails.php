<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use DateTimeImmutable;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class ComplianceDetails implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $template_id;

    public readonly string $version;

    public readonly IdDetails $id_details;

    public readonly ThirdPartyDetails $third_party_details;

    public readonly string $id_issue_date;

    public readonly string $id_expiration_date;

    public readonly string $date_of_birth;

    public readonly string $occupation;

    public readonly string $transaction_reason;

    public readonly CurrentAddress $Current_address;

    public readonly string $contact_phone;

    public readonly string $Country_of_Birth;

    public readonly string $nationality;

    public readonly Gender $Gender;

    public readonly string $Source_of_Funds;

    public readonly string $Relationship_to_Receiver_Sender;

    public readonly Option $Does_the_ID_have_an_expiration_date;

    public readonly string $ack_flag;

    public readonly string $Country_Code;

    public readonly string $galactic_id;

    public readonly Option $multi_error_supported;

    public readonly string $employment_position_level;

    public readonly string $compliance_data_buffer;

    /**
     * @throws InvalidArgumentException
     */
    public function setTemplateId(string $templateId): self
    {
        $this->template_id = self::throwIfExceedsMaxLength($templateId, 84);

        return $this;
    }

    public function setVersion(string $version): self
    {
        $this->version = $version;

        return $this;
    }

    public function setIdDetails(IdDetails $idDetails): self
    {
        $this->id_details = $idDetails;

        return $this;
    }

    public function setThirdPartyDetails(ThirdPartyDetails $thirdPartyDetails): self
    {
        $this->third_party_details = $thirdPartyDetails;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setIdIssueDate(DateTimeImmutable $idIssueDate): self
    {
        $this->id_issue_date = $idIssueDate->format('dmY');

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setIdExpirationDate(DateTimeImmutable $idExpirationDate): self
    {
        $this->id_expiration_date = $idExpirationDate->format('dmY');

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setDateOfBirth(DateTimeImmutable $dateOfBirth): self
    {
        $this->date_of_birth = $dateOfBirth->format('dmY');

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setOccupation(string $occupation): self
    {
        $this->occupation = self::throwIfExceedsMaxLength($occupation, 30);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setTransactionReason(string $transactionReason): self
    {
        $this->transaction_reason = self::throwIfExceedsMaxLength($transactionReason, 50);

        return $this;
    }

    public function setCurrentAddress(CurrentAddress $currentAddress): self
    {
        $this->Current_address = $currentAddress;

        return $this;
    }

    public function setContactPhone(string $contactPhone): self
    {
        $this->contact_phone = self::throwIfExceedsMaxLength($contactPhone, 20);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setCountryOfBirth(string $countryOfBirth): self
    {
        $this->Country_of_Birth = self::throwIfExceedsMaxLength($countryOfBirth, 44);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setNationality(string $nationality): self
    {
        $this->nationality = self::throwIfExceedsMaxLength($nationality, 44);

        return $this;
    }

    public function setGender(Gender $gender): self
    {
        $this->Gender = $gender;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setSourceOfFunds(string $sourceOfFunds): self
    {
        $this->Source_of_Funds = self::throwIfExceedsMaxLength($sourceOfFunds, 30);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setRelationshipToReceiverSender(string $relationshipToReceiverSender): self
    {
        $this->Relationship_to_Receiver_Sender = self::throwIfExceedsMaxLength($relationshipToReceiverSender, 20);

        return $this;
    }

    public function setDoesTheIdHaveAnExpirationDate(Option $doesTheIdHaveAnExpirationDate): self
    {
        $this->Does_the_ID_have_an_expiration_date = $doesTheIdHaveAnExpirationDate;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAckFlag(string $ackFlag): self
    {
        $this->ack_flag = self::throwIfExceedsMaxLength($ackFlag, 1);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setCountryCode(string $countryCode): self
    {
        $this->Country_Code = self::throwIfExceedsMaxLength($countryCode, 3);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setGalacticId(string $galacticId): self
    {
        $this->galactic_id = self::throwIfExceedsMaxLength($galacticId, 19);

        return $this;
    }

    public function setMultiErrorSupported(Option $multiErrorSupported): self
    {
        $this->multi_error_supported = $multiErrorSupported;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setEmploymentPositionLevel(string $employmentPositionLevel): self
    {
        $this->employment_position_level = self::throwIfExceedsMaxLength($employmentPositionLevel, 20);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setComplianceDataBuffer(string $complianceDataBuffer): self
    {
        $this->compliance_data_buffer = self::throwIfExceedsMaxLength($complianceDataBuffer, 1024);

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<compliance_details></compliance_details>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
