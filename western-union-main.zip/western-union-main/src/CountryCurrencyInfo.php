<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

final class CountryCurrencyInfo implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public function __construct(
        public readonly CountryUnisysCode $country_unisys_code,
        public readonly IsoCode $iso_code,
        public readonly CountryName $country_name,
    ) {
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new \SimpleXMLElement('<country_currency_info></country_currency_info>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
