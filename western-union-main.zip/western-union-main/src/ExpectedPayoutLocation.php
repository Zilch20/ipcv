<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class ExpectedPayoutLocation implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $state_code;

    public readonly string $city;

    public function setStateCode(string $stateCode): self
    {
        $this->state_code = $stateCode;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setCity(string $city): self
    {
        $this->city = self::throwIfExceedsMaxLength($city, 30);

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<expected_payout_location></expected_payout_location>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
