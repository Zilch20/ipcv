<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

enum PaymentType: string
{
    case CASH = 'Cash';

    case ACH = 'ACH';

    case CREDIT_CARD = 'CreditCard';

    case DEBIT_CARD = 'DebitCard';

    public static function fromString(string $paymentType): ?PaymentType
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($paymentType) ? $rc->getConstant($paymentType) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(PaymentType $paymentType) => $paymentType->value, self::cases());
    }
}
