<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

class ReceiveMoneyReceiver implements XmlSerializable
{
    use XmlHelper;
    use ValidatesInputLength;

    public Name $name;

    public Address $address;

    public ComplianceDetails $complianceDetails;

    public string $email;

    public string $phone_country_code;

    public string $contact_phone;

    public MobilePhone $mobile_phone;

    public BankDetails $bank_details;

    public function setName(Name $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function setAddress(Address $address): self
    {
        $this->address = $address;

        return $this;
    }

    public function setComplianceDetails(ComplianceDetails $complianceDetails): self
    {
        $this->complianceDetails = $complianceDetails;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setEmail(string $email): self
    {
        $this->email = self::throwIfExceedsMaxLength($email, 80);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setPhoneCountryCode(string $phone_country_code): self
    {
        $this->phone_country_code = self::throwIfExceedsMaxLength($phone_country_code, 3);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setContactPhone(string $contact_phone): self
    {
        $this->contact_phone = self::throwIfExceedsMaxLength($contact_phone, 31);

        return $this;
    }

    public function setMobilePhone(MobilePhone $mobile_phone): self
    {
        $this->mobile_phone = $mobile_phone;

        return $this;
    }

    public function setBankDetails(BankDetails $bank_details): self
    {
        $this->bank_details = $bank_details;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<receiver></receiver>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
