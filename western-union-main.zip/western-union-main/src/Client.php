<?php

namespace IPCV\WesternUnion;

use Psr\Http\Message\ResponseInterface;

interface Client
{
    public function send(Request $request): ResponseInterface;
}
