<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class BankDetails implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $name;

    public readonly string $account_number;

    public readonly string $account_type;

    public readonly string $routing_number;

    public readonly string $branch_number;

    public readonly string $bank_location;

    public readonly string $bic;

    public readonly string $bank_code;

    public readonly string $sort_code;

    public readonly string $account_prefix;

    public readonly string $account_suffix;

    public readonly string $bank_account_holder;

    public function __construct()
    {
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setName(string $name): self
    {
        $this->name = self::throwIfExceedsMaxLength($name, 50);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAccountNumber(string $accountNumber): self
    {
        $this->account_number = self::throwIfExceedsMaxLength($accountNumber, 35);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAccountType(string $accountType): self
    {
        $this->account_type = self::throwIfExceedsMaxLength($accountType, 10);

        return $this;
    }


    /**
     * @throws InvalidArgumentException
     */
    public function setRoutingNumber(string $routingNumber): self
    {
        $this->routing_number = self::throwIfExceedsMaxLength($routingNumber, 20);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setBranchNumber(string $branchNumber): self
    {
        $this->branch_number = self::throwIfExceedsMaxLength($branchNumber, 4);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setBankLocation(string $bankLocation): self
    {
        $this->bank_location = self::throwIfExceedsMaxLength($bankLocation, 18);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setBic(string $bic): self
    {
        $this->bic = self::throwIfExceedsMaxLength($bic, 11);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setBankCode(string $bankCode): self
    {
        $this->bank_code = self::throwIfExceedsMaxLength($bankCode, 11);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setSortCode(string $sortCode): self
    {
        $this->sort_code = self::throwIfExceedsMaxLength($sortCode, 11);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAccountPrefix(string $accountPrefix): self
    {
        $this->account_prefix = self::throwIfExceedsMaxLength($accountPrefix, 14);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAccountSuffix(string $accountSuffix): self
    {
        $this->account_suffix = self::throwIfExceedsMaxLength($accountSuffix, 14);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setBankAccountHolder(string $bankAccountHolder): self
    {
        $this->bank_account_holder = self::throwIfExceedsMaxLength($bankAccountHolder, 20);

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<bank_details></bank_details>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
