<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class InstantNotification implements XmlSerializable
{
    use XmlHelper;
    use ValidatesInputLength;

    public readonly string $addl_service_charges;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $addl_service_charges)
    {
        $this->addl_service_charges = self::throwIfExceedsMaxLength($addl_service_charges, 300);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<instant_notification></instant_notification>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
