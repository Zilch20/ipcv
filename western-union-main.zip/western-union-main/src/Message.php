<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Message implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public const MAX_NUMBER_OF_MESSAGES = 4;

    /**
     * @var string[]
     */
    private array $messages = [];

    /**
     * @throws InvalidArgumentException
     */
    public function add(string $message): self
    {
        if (count($this->messages()) === self::MAX_NUMBER_OF_MESSAGES) {
            throw new InvalidArgumentException('Maximum number of messages reached.');
        }

        $this->messages[] = self::throwIfExceedsMaxLength($message, 69);

        return $this;
    }

    /**
     * @return string[]
     */
    public function messages(): array
    {
        return $this->messages;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<message><message_details context="4"></message_details></message>');

        foreach ($this->messages() as $message) {
            $xml->message_details->addChild('text', $message);
        }

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
