<?php

declare(strict_types=1);

namespace IPCV\WesternUnion\SendMoneyValidation;

use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DeliveryServices;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\Promotions;
use IPCV\WesternUnion\Receiver;
use IPCV\WesternUnion\Request as BaseRequest;
use IPCV\WesternUnion\Sender;
use IPCV\WesternUnion\ValidatesInputLength;
use IPCV\WesternUnion\XmlHelper;
use SimpleXMLElement;

final class Request implements BaseRequest
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly Device $device;

    public readonly Channel $channel;

    public readonly Sender $sender;

    public readonly Receiver $receiver;

    public readonly PaymentDetails $payment_details;

    public readonly Financials $financials;

    public readonly DeliveryServices $delivery_services;

    public readonly Promotions $promotions;

    public readonly ForeignRemoteSystem $foreign_remote_system;

    public function setDevice(Device $device): self
    {
        $this->device = $device;

        return $this;
    }

    public function setChannel(Channel $channel): self
    {
        $this->channel = $channel;

        return $this;
    }

    public function setSender(Sender $sender): self
    {
        $this->sender = $sender;

        return $this;
    }

    public function setReciver(Receiver $receiver): self
    {
        $this->receiver = $receiver;

        return $this;
    }

    public function setPaymentDetails(PaymentDetails $paymentDetails): self
    {
        $this->payment_details = $paymentDetails;

        return $this;
    }

    public function setFinancials(Financials $financials): self
    {
        $this->financials = $financials;

        return $this;
    }

    public function setDeliveryServices(DeliveryServices $deliveryServices): self
    {
        $this->delivery_services = $deliveryServices;

        return $this;
    }

    public function setPromotions(Promotions $promotions): self
    {
        $this->promotions = $promotions;

        return $this;
    }

    public function setForeignRemoteSystem(ForeignRemoteSystem $foreignRemoteSystem): self
    {
        $this->foreign_remote_system = $foreignRemoteSystem;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    /**
     * @throws \Exception
     */
    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $baseXml =
            '<soapenv:Envelope'
                . ' xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
                . ' xmlns:xrsi="http://www.westernunion.com/schema/xrsi">'
            . '<soapenv:Header/>'
            . '<soapenv:Body>'
                . '<xrsi:send-money-validation-request>'
                . '</xrsi:send-money-validation-request>'
            . '</soapenv:Body>'
            . '</soapenv:Envelope>'
        ;

        $xml = new SimpleXMLElement($baseXml);

        $this->insertPropertiesAsChildToElement(
            $xml
                ->children('soapenv', true)
                ->Body
                ->children('xrsi', true),
            $this->toArray()
        );

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
