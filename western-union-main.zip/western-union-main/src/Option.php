<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

enum Option: string
{
    case Y = 'Y';
    case N = 'N';

    public static function fromString(string $optionAsString): ?Option
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($optionAsString) ? $rc->getConstant($optionAsString) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(Option $option) => $option->value, self::cases());
    }
}
