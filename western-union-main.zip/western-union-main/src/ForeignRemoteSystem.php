<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class ForeignRemoteSystem implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $identifier;

    public readonly string $reference_no;

    public readonly string $counter_id;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $identifier, string $referenceNumber, string $counterId)
    {
        $this->identifier = self::throwIfExceedsMaxLength($identifier, 12);
        $this->reference_no = self::throwIfExceedsMaxLength($referenceNumber, 16);
        $this->counter_id = self::throwIfExceedsMaxLength($counterId, 12);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<foreign_remote_system></foreign_remote_system>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
