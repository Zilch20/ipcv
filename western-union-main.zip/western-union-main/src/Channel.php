<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use Exception;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Channel implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $type;

    public readonly string $name;

    public readonly string $version;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $type, string $name, string $version)
    {
        $this->type = self::throwIfExceedsMaxLength($type, maxLength: 3);
        $this->name = self::throwIfExceedsMaxLength($name, maxLength: 20);
        $this->version = self::throwIfExceedsMaxLength($version, maxLength: 20);
    }

    /**
     * @throws Exception
     */
    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new \SimpleXMLElement('<channel></channel>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }
}
