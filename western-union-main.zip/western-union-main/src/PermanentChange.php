<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

enum PermanentChange: string
{
    case Store = 'Store';

    case None = 'None';

    case LookUp = 'LookUp';

    case EnrollWuCard = 'EnrollWuCard';

    case DeleteWuCard = 'DeleteWuCard';

    case UpdateWuCard = 'UpdateWuCard';

    case AddAssociate = 'AddAssociate';

    case UpdateAssociate = 'UpdateAssociate';

    case UpdateSenderAssociate = 'UpdateSenderAssociate';

    public static function fromString(string $permanentChange): ?PermanentChange
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($permanentChange) ? $rc->getConstant($permanentChange) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(PermanentChange $permanentChange) => $permanentChange->value, self::cases());
    }
}
