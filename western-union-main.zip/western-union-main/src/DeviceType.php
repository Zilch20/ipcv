<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

enum DeviceType: string
{
    case ATM = 'ATM';

    case WEB = 'WEB';

    case AGENT = 'AGENT';

    case CSR = 'CSR';

    case IVR = 'IVR';

    case MOBILE = 'MOBILE';

    case SYSTEM = 'SYSTEM';

    case WALLET = 'WALLET';

    case OTHER = 'OTHER';

    public static function fromString(string $deviceType): ?DeviceType
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($deviceType) ? $rc->getConstant($deviceType) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(DeviceType $deviceType) => $deviceType->value, self::cases());
    }
}
