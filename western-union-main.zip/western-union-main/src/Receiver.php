<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Receiver implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly Name $name;

    public readonly Address $address;

    public readonly string $phone_country_code;

    public readonly string $contact_phone;

    public readonly MobilePhone $mobile_phone;

    public readonly string $reason_for_sending;

    public function setName(Name $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function setAddress(Address $address): self
    {
        $this->address = $address;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setPhoneCountryCode(string $phoneCountryCode): self
    {
        $this->phone_country_code = self::throwIfExceedsMaxLength($phoneCountryCode, 6);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setContactPhone(string $contactPhone): self
    {
        $this->contact_phone = self::throwIfExceedsMaxLength($contactPhone, 31);

        return $this;
    }

    public function setMobilePhone(MobilePhone $mobilePhone): self
    {
        $this->mobile_phone = $mobilePhone;

        return $this;
    }

    public function setReasonForSending(string $reasonForSending): self
    {
        $this->reason_for_sending = $reasonForSending;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<receiver></receiver>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
