<?php

namespace IPCV\WesternUnion;

interface Request extends XmlSerializable
{
}
