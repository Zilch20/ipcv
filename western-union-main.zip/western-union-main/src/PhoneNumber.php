<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class PhoneNumber implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $country_code;

    public readonly string $national_number;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $countryCode, string $nationalNumber)
    {
        $this->country_code = self::throwIfExceedsMaxLength($countryCode, 3);
        $this->national_number = self::throwIfExceedsMaxLength($nationalNumber, 14);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<phone_number></phone_number>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
