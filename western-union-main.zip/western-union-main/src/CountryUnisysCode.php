<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class CountryUnisysCode implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    private string $country_unisys_code;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $countryUnisysCode)
    {
        $this->country_unisys_code = self::throwIfExceedsMaxLength($countryUnisysCode, 3);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new \SimpleXMLElement('<country_unisys_code></country_unisys_code>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
