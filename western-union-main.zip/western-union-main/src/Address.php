<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Address implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $addr_line1;

    public readonly string $addr_line2;

    public readonly string $city;

    public readonly string $state;

    public readonly string $postal_code;

    public readonly CountryCode $country_code;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $addressLine1, string $state, string $postalCode, CountryCode $countryCode)
    {
        $this->addr_line1 = self::throwIfExceedsMaxLength($addressLine1, 84);
        $this->state = self::throwIfExceedsMaxLength($state, 40);
        $this->postal_code = self::throwIfExceedsMaxLength($postalCode, 40);
        $this->country_code = $countryCode;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAddressLine2(string $addressLine2): self
    {
        $this->addr_line2 = self::throwIfExceedsMaxLength($addressLine2, 84);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setCity(string $city): self
    {
        $this->city = self::throwIfExceedsMaxLength($city, 30);

        return $this;
    }

    public function __toString(): string
    {
        return \sprintf(
            <<<XML
            <address>%s%s%s%s%s%s</address>
            XML,
            <<<ADDR_LINE_1
            <addr_line1>{$this->addressLine1}</addr_line1>
            ADDR_LINE_1,
            $this->buildAddressLine2(),
            $this->buildCity(),
            <<<STATE
            <state>{$this->state}</state>
            STATE,
            <<<POSTAL_CODE
            <postal_code>{$this->postalCode}</postal_code>
            POSTAL_CODE,
            $this->countryCode
        );
    }

    private function buildAddressLine2(): string
    {
        return ($this->addressLine2 ?? false)
            ? <<<XML
            <addr_line2>{$this->addressLine2}</addr_line2>
            XML
            : '';
    }

    private function buildCity(): string
    {
        return ($this->city ?? false)
            ? <<<XML
            <city>{$this->city}</city>
            XML
            : '';
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<address></address>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
