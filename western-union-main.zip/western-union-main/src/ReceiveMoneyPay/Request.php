<?php

declare(strict_types=1);

namespace IPCV\WesternUnion\ReceiveMoneyPay;

use DOMDocument;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\ReceiveMoneyReceiver;
use IPCV\WesternUnion\Request as BaseRequest;
use IPCV\WesternUnion\ValidatesInputLength;
use IPCV\WesternUnion\XmlHelper;
use IPCV\WesternUnion\XmlSerializable;
use SimpleXMLElement;

final class Request implements BaseRequest
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly Device $device;

    public readonly Channel $channel;

    public readonly ReceiveMoneyReceiver $receiver;

    public readonly PaymentDetails $payment_details;

    public readonly Financials $financials;

    public readonly string $money_transfer_key;

    public readonly string $new_mtcn;

    public readonly string $mtcn;

    public readonly string $pay_or_do_not_pay_indicator;

    public readonly ForeignRemoteSystem $foreign_remote_system;

    public function setDevice(Device $device): self
    {
        $this->device = $device;

        return $this;
    }

    public function setChannel(Channel $channel): self
    {
        $this->channel = $channel;

        return $this;
    }

    public function setReceiver(ReceiveMoneyReceiver $receiver): self
    {
        $this->receiver = $receiver;

        return $this;
    }

    public function setPaymentDetails(PaymentDetails $paymentDetails): self
    {
        $this->payment_details = $paymentDetails;

        return $this;
    }

    public function setFinancials(Financials $financials): self
    {
        $this->financials = $financials;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setMoneyTransferKey(string $moneyTransferKey): self
    {
        $this->money_transfer_key = self::throwIfExceedsMaxLength($moneyTransferKey, 10);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setNewMtcn(string $newMtcn): self
    {
        $this->new_mtcn = self::throwIfExceedsMaxLength($newMtcn, 16);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setMtcn(string $mtcn): self
    {
        $this->mtcn = self::throwIfExceedsMaxLength($mtcn, 16);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setPayOrDoNotPayIndicator(string $payOrDoNotPayIndicator): self
    {
        $this->pay_or_do_not_pay_indicator = self::throwIfExceedsMaxLength($payOrDoNotPayIndicator, 11);

        return $this;
    }

    public function setForeignRemoteSystem(ForeignRemoteSystem $foreignRemoteSystem): self
    {
        $this->foreign_remote_system = $foreignRemoteSystem;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $doc = self::createDOMDocument();
        $root = $doc->documentElement->ownerDocument;
        $this->buildDOMDocument($root);

        $xml = new \SimpleXMLElement($doc->saveXML());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }

    private static function createDOMDocument(): DOMDocument
    {
        $xml =  <<<XML
<soapenv:Envelope 
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
    xmlns:xrsi="http://www.westernunion.com/schema/xrsi"
    >
    <soapenv:Header/>
    <soapenv:Body>
        <xrsi:receive-money-pay-request>
            <device/>
            <channel/>
            <receiver/>
            <payment_details/>
            <financials/>
            <money_transfer_key/>
            <new_mtcn/>
            <mtcn/>
            <pay_or_do_not_pay_indicator/>
            <foreign_remote_system/>
        </xrsi:receive-money-pay-request>
    </soapenv:Body>
</soapenv:Envelope>
XML;
        $doc = new DOMDocument();
        $doc->loadXML($xml);

        return $doc;
    }

    private function buildDOMDocument(DOMDocument $root): void
    {
        foreach ($this->toArray() as $key => $prop) {
            if ($prop instanceof XmlSerializable) {
                $d = new DOMDocument();
                $d->loadXML($prop->toSimpleXML()->asXML());

                $xrsi = $root
                    ->documentElement
                    ->getElementsByTagName('Body')
                    ->item(0)
                    ->childNodes
                    ->item(1)
                ;

                $xrsi->replaceChild(
                    $root->importNode($d->documentElement, true),
                    $root->getElementsByTagName($key)->item(0)
                );
                continue;
            }

            $root->getElementsByTagName($key)->item(0)->nodeValue = $prop;
        }
    }
}
