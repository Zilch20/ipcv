<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

final class Financials implements XmlSerializable
{
    use XmlHelper;

    public readonly string $originators_principal_amount;

    public readonly string $destination_principal_amount;

    public readonly string $gross_total_amount;

    public readonly string $pay_amount;

    public readonly string $principal_amount;

    public readonly string $plus_charges_amount;

    public readonly string $charges;

    public readonly string $tolls;

    public readonly string $message_charge;

    public function setOriginatorsPrinicpalAmount(int $originatorAmount): self
    {
        $this->originators_principal_amount = (string)$originatorAmount;

        return $this;
    }

    public function setDestinationPrinicipalAmount(int $destinationAmount): self
    {
        $this->destination_principal_amount = (string)$destinationAmount;

        return $this;
    }

    public function setGrossTotalAmount(int $grossTotalAmount): self
    {
        $this->gross_total_amount = (string)$grossTotalAmount;

        return $this;
    }

    public function setPayAmount(int $payAmount): self
    {
        $this->pay_amount = (string)$payAmount;

        return $this;
    }

    public function setPrincipalAmount(int $principalAmount): self
    {
        $this->principal_amount = (string)$principalAmount;

        return $this;
    }

    public function setPlusChargesAmount(int $plusChargesAmount): self
    {
        $this->plus_charges_amount = (string)$plusChargesAmount;

        return $this;
    }

    public function setCharges(int $charges): self
    {
        $this->charges = (string)$charges;

        return $this;
    }

    public function setTolls(int $tolls): self
    {
        $this->tolls = (string)$tolls;

        return $this;
    }

    public function setMessageCharge(int $messageCharge): self
    {
        $this->message_charge = (string)$messageCharge;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $financialsAsSimpleXml = new \SimpleXMLElement('<financials></financials>');

        $this->insertPropertiesAsChildToElement($financialsAsSimpleXml, $this->toArray());

        if ($parent === null) {
            return $financialsAsSimpleXml;
        }

        $this->appendChildToParent($parent, $financialsAsSimpleXml);

        return $parent;
    }
}
