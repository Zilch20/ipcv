<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

enum Gender: string
{
    case M = 'M';

    case F = 'F';

    public static function fromString(string $gender): ?Gender
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($gender) ? $rc->getConstant($gender) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(Gender $gender) => $gender->value, self::cases());
    }
}
