<?php

declare(strict_types=1);

namespace IPCV\WesternUnion\SendMoneyStore;

use DOMDocument;
use IPCV\WesternUnion\BankDetails;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DeliveryServices;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\InstantNotification;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\Promotions;
use IPCV\WesternUnion\Receiver;
use IPCV\WesternUnion\Request as BaseRequest;
use IPCV\WesternUnion\Sender;
use IPCV\WesternUnion\ValidatesInputLength;
use IPCV\WesternUnion\XmlHelper;
use IPCV\WesternUnion\XmlSerializable;
use SimpleXMLElement;

final class Request implements BaseRequest
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly Device $device;

    public readonly Channel $channel;

    public readonly InstantNotification $instant_notification;

    public readonly Sender $sender;

    public readonly Receiver $receiver;

    public readonly BankDetails $bank_details;

    public readonly Promotions $promotions;

    public readonly PaymentDetails $payment_details;

    public readonly Financials $financials;

    public readonly DeliveryServices $delivery_services;

    public readonly string $mtcn;

    public readonly string $new_mtcn;

    public readonly ForeignRemoteSystem $foreign_remote_system;

    public function setDevice(Device $device): self
    {
        $this->device = $device;

        return $this;
    }

    public function setChannel(Channel $channel): self
    {
        $this->channel = $channel;

        return $this;
    }

    public function setInstantNotification(InstantNotification $instantNotification): self
    {
        $this->instant_notification = $instantNotification;

        return $this;
    }

    public function setSender(Sender $sender): self
    {
        $this->sender = $sender;

        return $this;
    }

    public function setReceiver(Receiver $receiver): self
    {
        $this->receiver = $receiver;

        return $this;
    }

    public function setBankDetails(BankDetails $bankDetails): self
    {
        $this->bank_details = $bankDetails;

        return $this;
    }

    public function setPromotions(Promotions $promotions): self
    {
        $this->promotions = $promotions;

        return $this;
    }

    public function setPaymentDetails(PaymentDetails $paymentDetails): self
    {
        $this->payment_details = $paymentDetails;

        return $this;
    }

    public function setFinancials(Financials $financials): self
    {
        $this->financials = $financials;

        return $this;
    }

    public function setDeliveryServices(DeliveryServices $deliveryServices): self
    {
        $this->delivery_services = $deliveryServices;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setMtcn(string $mtcn): self
    {
        $this->mtcn = self::throwIfExceedsMaxLength($mtcn, 16);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setNewMtcn(string $newMtcn): self
    {
        $this->new_mtcn = self::throwIfExceedsMaxLength($newMtcn, 16);

        return $this;
    }

    public function setForeignRemoteSystem(ForeignRemoteSystem $foreignRemoteSystem): self
    {
        $this->foreign_remote_system = $foreignRemoteSystem;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $doc = self::createDOMDocument();
        $root = $doc->documentElement->ownerDocument;
        $this->buildDOMDocument($root);

        $xml = new \SimpleXMLElement($doc->saveXML());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }

    private static function createDOMDocument(): DOMDocument
    {
        $xml = <<<XML
<soapenv:Envelope 
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
    xmlns:xrsi="http://www.westernunion.com/schema/xrsi"
    >
    <soapenv:Header/>
    <soapenv:Body>
        <xrsi:send-money-store-request>
            <device/>
            <channel/>
            <instant_notification/>
            <sender/>
            <receiver/>
            <bank_details/>
            <promotions/>
            <payment_details/>
            <financials/>
            <delivery_services/>
            <mtcn/>
            <new_mtcn/>
            <foreign_remote_system/>
        </xrsi:send-money-store-request>
    </soapenv:Body>
</soapenv:Envelope>
XML;
        $doc = new DOMDocument();
        $doc->loadXML($xml);

        return $doc;
    }

    private function buildDOMDocument(DOMDocument $root): void
    {
        foreach ($this->toArray() as $key => $prop) {
            if ($prop instanceof XmlSerializable) {
                $d = new DOMDocument();
                $d->loadXML($prop->toSimpleXML()->asXML());

                $xrsi = $root
                    ->documentElement
                    ->getElementsByTagName('Body')
                    ->item(0)
                    ->childNodes
                    ->item(1)
                ;

                $xrsi->replaceChild(
                    $root->importNode($d->documentElement, true),
                    $root->getElementsByTagName($key)->item(0)
                );
                continue;
            }

            $root->getElementsByTagName($key)->item(0)->nodeValue = $prop;
        }
    }
}
