<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use BackedEnum;
use SimpleXMLElement;

trait XmlHelper
{
    public function insertPropertiesAsChildToElement(SimpleXMLElement $element, array $properties): void
    {
        foreach ($properties as $key => $value) {
            if ($value instanceof XmlSerializable) {
                $this->appendChildToParent($element, $value->toSimpleXML());
                continue;
            }

            if ($value instanceof BackedEnum) {
                $element->addChild($key, $value->value);
                continue;
            }

            $element->addChild($key, \htmlspecialchars($value));
        }
    }

    public function appendChildToParent(SimpleXMLElement $parent, SimpleXMLElement $child): void
    {
        $parentDom = \dom_import_simplexml($parent);
        $childDom = \dom_import_simplexml($child);

        $parentDom->appendChild($parentDom->ownerDocument->importNode($childDom, true));
    }
}
