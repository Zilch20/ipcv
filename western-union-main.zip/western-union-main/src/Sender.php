<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Sender implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly Name $name;

    public readonly Address $address;

    public readonly PreferredCustomer $preferred_customer;

    public readonly ComplianceDetails $compliance_details;

    public readonly string $email;

    public readonly string $phone_country_code;

    public readonly string $contact_phone;

    public readonly MobilePhone $mobile_phone;

    public readonly BankDetails $bank_details;

    public function __construct()
    {
    }

    public function setName(Name $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function setAddress(Address $address): self
    {
        $this->address = $address;

        return $this;
    }

    public function setPreferredCustomer(PreferredCustomer $preferredCustomer): self
    {
        $this->preferred_customer = $preferredCustomer;

        return $this;
    }

    public function setComplianceDetails(ComplianceDetails $complianceDetails): self
    {
        $this->compliance_details = $complianceDetails;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setEmail(string $email): self
    {
        $this->email = self::throwIfExceedsMaxLength($email, 80);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setPhoneCountryCode(string $phoneCountryCode): self
    {
        $this->phone_country_code = self::throwIfExceedsMaxLength($phoneCountryCode, 6);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setContactPhone(string $contactPhone): self
    {
        $this->contact_phone = self::throwIfExceedsMaxLength($contactPhone, 31);

        return $this;
    }

    public function setMobilePhone(MobilePhone $mobilePhone): self
    {
        $this->mobile_phone = $mobilePhone;

        return $this;
    }

    public function setBankDetails(BankDetails $bankDetails): self
    {
        $this->bank_details = $bankDetails;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<sender></sender>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
