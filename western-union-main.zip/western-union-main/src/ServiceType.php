<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

enum ServiceType: string
{
    case WILL_OR_CALL = '000';

    case DIRECT_TO_BANK = '500';

    public static function fromString(string $serviceType): ?ServiceType
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($serviceType) ? $rc->getConstant($serviceType) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(ServiceType $serviceType) => $serviceType->value, self::cases());
    }
}
