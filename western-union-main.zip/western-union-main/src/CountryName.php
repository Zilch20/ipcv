<?php

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class CountryName implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    private readonly string $country_name;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $country_name)
    {
        $this->country_name = self::throwIfExceedsMaxLength($country_name, 40);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new \SimpleXMLElement('<country_name></country_name>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
