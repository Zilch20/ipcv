<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class DeliveryServices implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly ServiceType $code;

    public readonly string $routing_code;

    public readonly Message $message;

    public function setCode(ServiceType $code): self
    {
        $this->code = $code;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setRoutingCode(string $routingCode): self
    {
        $this->routing_code = self::throwIfExceedsMaxLength($routingCode, 41);

        return $this;
    }

    public function setMessage(Message $message): self
    {
        $this->message = $message;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<delivery_services></delivery_services>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
