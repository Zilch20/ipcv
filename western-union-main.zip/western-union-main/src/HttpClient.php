<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Http\Message\ResponseInterface;

final class HttpClient implements Client
{
    public function __construct(public readonly ClientInterface $client)
    {
    }

    /**
     * @throws GuzzleException
     */
    public function send(Request $request): ResponseInterface
    {
        return $this->client->request(method: 'POST', uri: '', options: ['body' => $request->toSimpleXML()->asXML()]);
    }
}
