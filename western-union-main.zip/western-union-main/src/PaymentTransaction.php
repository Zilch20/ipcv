<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class PaymentTransaction implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly Receiver $receiver;

    public readonly PaymentDetails $payment_details;

    public readonly string $mtcn;

    public function setReceiver(Receiver $receiver): self
    {
        $this->receiver = $receiver;

        return $this;
    }

    public function setPaymentDetails(PaymentDetails $paymentDetails): self
    {
        $this->payment_details = $paymentDetails;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setMtcn(string $mtcn): self
    {
        $this->mtcn = self::throwIfExceedsMaxLength($mtcn, 16);

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new \SimpleXMLElement('<payment_transaction></payment_transaction>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
