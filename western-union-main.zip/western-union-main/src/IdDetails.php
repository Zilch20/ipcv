<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

final class IdDetails implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly IdType $id_type;

    public readonly string $id_country_of_issue;

    public readonly string $id_number;

    public function __construct(IdType $idType, string $idCountryOfIssue, string $idNumber)
    {
        $this->id_type = $idType;
        $this->id_country_of_issue = $idCountryOfIssue;
        $this->id_number = $idNumber;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<id_details></id_details>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
