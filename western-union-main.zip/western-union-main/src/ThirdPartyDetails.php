<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

class ThirdPartyDetails implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public function __construct(public readonly Option $flag_pay)
    {
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<third_party_details></third_party_details>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
