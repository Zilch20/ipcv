<?php

declare(strict_types=1);

namespace IPCV\WesternUnion\DataAccessServer;

use GuzzleHttp\ClientInterface;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Http\Message\ResponseInterface;

class HttpClient implements Client
{
    public function __construct(
        private readonly ClientInterface $client
    ) {
    }

    /**
     * @throws GuzzleException
     */
    public function send(DASRequest $request): ResponseInterface
    {
        return $this->client->request(method: 'POST', uri: '', options: ['body' => $request->toSimpleXML()->asXML()]);
    }
}
