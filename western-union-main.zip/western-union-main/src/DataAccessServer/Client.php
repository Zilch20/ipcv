<?php

namespace IPCV\WesternUnion\DataAccessServer;

use Psr\Http\Message\ResponseInterface;

interface Client
{
    public function send(DASRequest $request): ResponseInterface;
}
