<?php

namespace IPCV\WesternUnion\DataAccessServer;

use IPCV\WesternUnion\XmlSerializable;

interface DASRequest extends XmlSerializable
{
}
