<?php

declare(strict_types=1);

namespace IPCV\WesternUnion\DataAccessServer;

use DOMDocument;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Filters;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\ValidatesInputLength;
use IPCV\WesternUnion\XmlHelper;
use IPCV\WesternUnion\XmlSerializable;
use SimpleXMLElement;

final class Request implements DASRequest
{
    use ValidatesInputLength;
    use XmlHelper;

    public Channel $channel;

    public ForeignRemoteSystem $foreign_remote_system;

    public string $client_id;

    public string $name;

    public string $account_num;

    public Filters $filters;

    public function setChannel(Channel $channel): self
    {
        $this->channel = $channel;

        return $this;
    }

    public function setForeignRemoteSystem(ForeignRemoteSystem $foreignRemoteSystem): self
    {
        $this->foreign_remote_system = $foreignRemoteSystem;

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setClientId(string $clientId): self
    {
        $this->client_id = self::throwIfExceedsMaxLength($clientId, 3);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setName(string $name): self
    {
        $this->name = self::throwIfExceedsMaxLength($name, 31);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setAccountNum(string $accountNum): self
    {
        $this->account_num = self::throwIfExceedsMaxLength($accountNum, 34);

        return $this;
    }

    public function setFilters(Filters $filters): self
    {
        $this->filters = $filters;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $doc = self::createDOMDocument();
        $root = $doc->documentElement->ownerDocument;
        $this->buildDOMDocument($root);

        $xml = new \SimpleXMLElement($doc->saveXML());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }

    private static function createDOMDocument(): DOMDocument
    {
        $xml = <<<XML
<soapenv:Envelope 
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
    xmlns:xrsi="http://www.westernunion.com/schema/xrsi"
    >
    <soapenv:Header/>
    <soapenv:Body>
        <xrsi:h2h-das-request>
            <channel/>
            <foreign_remote_system/>
            <client_id/>
            <name/>
            <account_num/>
            <filters/>
        </xrsi:h2h-das-request>
    </soapenv:Body>
</soapenv:Envelope>
XML;

        $doc = new DOMDocument();
        $doc->loadXML($xml);

        return $doc;
    }

    private function buildDOMDocument(DOMDocument $root): void
    {
        foreach ($this->toArray() as $key => $prop) {
            if ($prop instanceof XmlSerializable) {
                $d = new DOMDocument();
                $d->loadXML($prop->toSimpleXML()->asXML());

                $xrsi = $root
                    ->documentElement
                    ->getElementsByTagName('Body')
                    ->item(0)
                    ->childNodes
                    ->item(1)
                ;

                $xrsi->replaceChild(
                    $root->importNode($d->documentElement, true),
                    $root->getElementsByTagName($key)->item(0)
                );
                continue;
            }

            if ($key === "name" && ($root->getElementsByTagName($key)->count() > 1)) {
                $root->getElementsByTagName($key)->item(1)->nodeValue = $prop;
                continue;
            }

            $root->getElementsByTagName($key)->item(0)->nodeValue = $prop;
        }
    }
}
