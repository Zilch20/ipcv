<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

final class OriginatingCountryCurrency implements XmlSerializable
{
    use XmlHelper;

    public function __construct(
        public readonly IsoCode $iso_code,
    ) {
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $originatingCountryAsSimpleXml = new SimpleXMLElement(
            '<originating_country_currency></originating_country_currency>'
        );
        $this->insertPropertiesAsChildToElement($originatingCountryAsSimpleXml, $this->toArray());

        if ($parent === null) {
            return $originatingCountryAsSimpleXml;
        }

        $this->appendChildToParent($parent, $originatingCountryAsSimpleXml);

        return $parent;
    }
}
