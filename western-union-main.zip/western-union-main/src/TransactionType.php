<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

enum TransactionType: string
{
    /**
     * Payout FX rate will be determined on pay
     */
    case WMN = 'WMN';

    /**
     * Payout FX rate will be fixed on send
     */
    case WMF = 'WMF';

    public static function fromString(string $transactionType): ?TransactionType
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($transactionType) ? $rc->getConstant($transactionType) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return \array_map(static fn(TransactionType $transactionType) => $transactionType->value, self::cases());
    }
}
