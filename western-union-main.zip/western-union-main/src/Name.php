<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Name implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public const NAME_TYPE_D = 'D';

    public const NAME_TYPE_M = 'M';

    public readonly string $type;

    public readonly string $first_name;

    public readonly string $middle_name;

    public readonly string $last_name;

    public readonly string $given_name;

    public readonly string $paternal_name;

    public readonly string $maternal_name;

    private function __construct()
    {
    }

    /**
     * @throws InvalidArgumentException
     */
    public static function createTypeM(string $givenName, string $paternalName, string $materalName): Name
    {
        $instance = new self();
        $instance->type = self::NAME_TYPE_M;
        $instance->given_name = self::throwIfExceedsMaxLength($givenName, 80);
        $instance->paternal_name = self::throwIfExceedsMaxLength($paternalName, 80);
        $instance->maternal_name = self::throwIfExceedsMaxLength($materalName, 80);

        return $instance;
    }

    /**
     * @throws InvalidArgumentException
     */
    public static function createTypeD(string $firstName, string $middleName, string $lastName): Name
    {
        $instance = new self();
        $instance->type = self::NAME_TYPE_D;
        $instance->first_name = self::throwIfExceedsMaxLength($firstName, 80);
        $instance->middle_name = self::throwIfExceedsMaxLength($middleName, 80);
        $instance->last_name = self::throwIfExceedsMaxLength($lastName, 80);

        return $instance;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement("<name name_type=\"{$this->type}\"></name>");

        $nameAsArray = $this->toArray();
        unset($nameAsArray['type']);

        $this->insertPropertiesAsChildToElement($xml, $nameAsArray);

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
