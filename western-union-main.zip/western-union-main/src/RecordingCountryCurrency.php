<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use SimpleXMLElement;

final class RecordingCountryCurrency implements XmlSerializable
{
    use XmlHelper;

    public function __construct(
        public readonly IsoCode $iso_code,
    ) {
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $recordingCountryAsSimpleXml = new SimpleXMLElement(
            '<recording_country_currency></recording_country_currency>'
        );
        $this->insertPropertiesAsChildToElement($recordingCountryAsSimpleXml, $this->toArray());

        if ($parent === null) {
            return $recordingCountryAsSimpleXml;
        }

        $this->appendChildToParent($parent, $recordingCountryAsSimpleXml);

        return $parent;
    }
}
