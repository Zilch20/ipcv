<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Promotions implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $coupons_promotions;

    public readonly string $sender_promo_code;

    /**
     * @throws InvalidArgumentException
     */
    public function setCouponsPromotions(string $couponsPromotions): self
    {
        $this->coupons_promotions = self::throwIfExceedsMaxLength($couponsPromotions, 20);

        return $this;
    }

    /**
     * @throws InvalidArgumentException
     */
    public function setSenderPromoCode(string $senderPromoCode): self
    {
        $this->sender_promo_code = self::throwIfExceedsMaxLength($senderPromoCode, 20);

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $promotionsAsXml = new \SimpleXMLElement('<promotions></promotions>');

        $this->insertPropertiesAsChildToElement($promotionsAsXml, $this->toArray());

        if ($parent === null) {
            return $promotionsAsXml;
        }

        $this->appendChildToParent($parent, $promotionsAsXml);

        return $parent;
    }
}
