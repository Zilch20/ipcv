<?php

declare(strict_types=1);

namespace IPCV\WesternUnion\PayStatusInquiry;

use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\Request as BaseRequest;
use IPCV\WesternUnion\ValidatesInputLength;
use IPCV\WesternUnion\XmlHelper;
use SimpleXMLElement;

final class Request implements BaseRequest
{
    use ValidatesInputLength;
    use XmlHelper;

    public Device $device;

    public Channel $channel;

    public PaymentDetails $payment_details;

    public string $mtcn;

    public ForeignRemoteSystem $foreign_remote_system;

    public function setDevice(Device $device): self
    {
        $this->device = $device;

        return $this;
    }

    public function setChannel(Channel $channel): self
    {
        $this->channel = $channel;

        return $this;
    }

    public function setPaymentDetails(PaymentDetails $paymentDetails): self
    {
        $this->payment_details = $paymentDetails;

        return $this;
    }

    public function setMtcn(string $mtcn): self
    {
        $this->mtcn = $mtcn;

        return $this;
    }

    public function setForeignRemoteSystem(ForeignRemoteSystem $foreignRemoteSystem): self
    {
        $this->foreign_remote_system = $foreignRemoteSystem;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $baseXml =
            '<soapenv:Envelope'
            . ' xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
            . ' xmlns:xrsi="http://www.westernunion.com/schema/xrsi">'
            . '<soapenv:Header/>'
            . '<soapenv:Body>'
            . '<xrsi:pay-status-inquiry-request-data>'
            . '</xrsi:pay-status-inquiry-request-data>'
            . '</soapenv:Body>'
            . '</soapenv:Envelope>'
        ;

        $xml = new \SimpleXMLElement($baseXml);

        $this->insertPropertiesAsChildToElement(
            $xml
                ->children('soapenv', true)
                ->Body
                ->children('xrsi', true),
            $this->toArray()
        );

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
