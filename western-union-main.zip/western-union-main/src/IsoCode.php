<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class IsoCode implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $country_code;

    public readonly string $currency_code;

    /**
     * @throws InvalidArgumentException
     */
    public function __construct(string $countryCode, string $currencyCode)
    {
        $this->country_code = self::throwIfExceedsMaxLength($countryCode, 3);
        $this->currency_code = self::throwIfExceedsMaxLength($currencyCode, 3);
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(?SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $this->insertPropertiesAsChildToElement(
            $isoCodeSimpleXml = new \SimpleXMLElement('<iso_code></iso_code>'),
            $this->toArray()
        );

        if ($parent === null) {
            return $isoCodeSimpleXml;
        }

        $this->appendChildToParent($parent, $isoCodeSimpleXml);

        return $parent;
    }
}
