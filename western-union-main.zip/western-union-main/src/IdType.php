<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use ReflectionEnum;

use function array_map;

enum IdType: string
{
    case PASSPORT = 'A';

    case DRIVERS_LICENSE = 'C';

    case PRC_ID = '5';

    case NBI_CLEARANCE = '7';

    case POLICE_CLEARANCE = 'D';

    case POSTAL_ID = '1';

    case VOTERS_ID = 'M';

    case BARANGAY_CERTIFICATION = '3';

    case GSIS_ECARD = 'E';

    case SSS_ID = 'N';

    case NATIONAL_ID = 'B';

    case SENIOR_CITIZEN_ID = 'W';

    case OWWA_ID = 'V';

    case OFW_ID = '6';

    case SEAMANS_BOOK = 'R';

    case IMMIGRANT_CERTIFICATE_OF_REGISTRATION = '8';

    case PWD_ID = 'H';

    case DSWD_CERTIFICATE = '9';

    case IBP_ID = 'U';

    case STUDENT_ID = 'X';

    case UMID = '2';

    case TAXPAYERS_ID = '4';

    case OTHER = 'I';

    public static function fromString(string $idType): ?PermanentChange
    {
        $rc = new ReflectionEnum(self::class);

        return $rc->hasCase($idType) ? $rc->getConstant($idType) : null;
    }

    /**
     * @return string[]
     */
    public static function values(): array
    {
        return array_map(static fn(IdType $idType) => $idType->value, self::cases());
    }
}
