<?php

declare(strict_types=1);

namespace IPCV\WesternUnion\Exception;

class InvalidArgumentException extends \Exception
{
}
