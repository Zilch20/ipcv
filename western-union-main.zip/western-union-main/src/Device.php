<?php

declare(strict_types=1);

namespace IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use SimpleXMLElement;

final class Device implements XmlSerializable
{
    use ValidatesInputLength;
    use XmlHelper;

    public readonly string $id;

    public readonly DeviceType $type;

    /**
     * @throws InvalidArgumentException
     */
    public function setId(string $id): self
    {
        $this->id = self::throwIfExceedsMaxLength($id, 32);

        return $this;
    }

    public function setType(DeviceType $deviceType): self
    {
        $this->type = $deviceType;

        return $this;
    }

    public function toArray(): array
    {
        return \get_object_vars($this);
    }

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement
    {
        $xml = new SimpleXMLElement('<device></device>');

        $this->insertPropertiesAsChildToElement($xml, $this->toArray());

        if ($parent === null) {
            return $xml;
        }

        $this->appendChildToParent($parent, $xml);

        return $parent;
    }
}
