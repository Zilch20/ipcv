<?php

namespace IPCV\WesternUnion;

use SimpleXMLElement;

interface XmlSerializable
{
    public function toArray(): array;

    public function toSimpleXML(SimpleXMLElement $parent = null): SimpleXMLElement;
}
