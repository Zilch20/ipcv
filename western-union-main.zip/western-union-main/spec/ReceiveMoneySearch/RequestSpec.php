<?php

namespace spec\IPCV\WesternUnion\ReceiveMoneySearch;

use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\DeviceType;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\PaymentTransaction;
use IPCV\WesternUnion\ReceiveMoneySearch\Request;
use IPCV\WesternUnion\XmlSerializable;
use spec\IPCV\WesternUnion\BaseObjectBehavior;

/**
 * @mixin Request
 */
class RequestSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_device()
    {
        $this->setDevice($expected = new Device($this->randomString(32), DeviceType::AGENT));

        $this->device->shouldBe($expected);
    }

    function it_should_set_channel()
    {
        $this->setChannel($expected = new Channel('FOO', 'BAR', 'BAZ'));

        $this->channel->shouldBe($expected);
    }

    function it_should_set_foreign_remote_system()
    {
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'));

        $this->foreign_remote_system->shouldBe($expected);
    }

    function it_should_set_payment_transaction()
    {
        $this->setPaymentTransaction($expected = new PaymentTransaction());

        $this->payment_transaction->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this->setDevice($expected = new Device($this->randomString(32), DeviceType::AGENT));
        $this->setChannel($expected = new Channel('FOO', 'BAR', 'BAZ'));
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'));
        $this->setPaymentTransaction($expected = new PaymentTransaction());

        $baseXml =
            '<soapenv:Envelope'
            . ' xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
            . ' xmlns:xrsi="http://www.westernunion.com/schema/xrsi">'
            . '<soapenv:Header/>'
            . '<soapenv:Body>'
            . '<xrsi:receive-money-search-request>'
            . '</xrsi:receive-money-search-request>'
            . '</soapenv:Body>'
            . '</soapenv:Envelope>'
        ;

        $expected = new \SimpleXMLElement($baseXml);

        $this->insertPropertiesAsChildToElement(
            $expected
                ->children('soapenv', true)
                ->Body
                ->children('xrsi', true),
            $this->toArray()->getWrappedObject()
        );

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this->setDevice($expected = new Device($this->randomString(32), DeviceType::AGENT));
        $this->setChannel($expected = new Channel('FOO', 'BAR', 'BAZ'));
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'));
        $this->setPaymentTransaction($expected = new PaymentTransaction());

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
