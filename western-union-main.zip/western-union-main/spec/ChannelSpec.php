<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\XmlHelper;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Channel
 */
class ChannelSpec extends BaseObjectBehavior
{
    use XmlHelper;

    function let()
    {
        $this->beConstructedWith("H2H", "qwe", "9500");
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_type()
    {
        $this->type->shouldBe("H2H");
    }

    function it_should_return_name()
    {
        $this->name->shouldBe("qwe");
    }

    function it_should_return_version()
    {
        $this->version->shouldBe("9500");
    }

    function it_should_not_allow_type_to_exceed_max_length_of_3_characters()
    {
        $longType = $this->faker()->words(5, true);

        $this->beConstructedWith($longType, 'qwe', '9500');

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_allow_name_to_exceed_max_length_of_20_characters()
    {
        $longName = $this->faker()->words(10, true);

        $this->beConstructedWith('H2H', $longName, '9500');

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_allow_version_to_exceed_max_length_of_20_characters()
    {
        $longVersion = $this->faker()->words(10, true);

        $this->beConstructedWith('H2H', 'Foo', $longVersion);

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<channel></channel>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
