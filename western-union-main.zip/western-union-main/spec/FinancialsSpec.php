<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\XmlHelper;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Financials
 */
class FinancialsSpec extends BaseObjectBehavior
{
    use XmlHelper;

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_originator_amount()
    {
        $this->setOriginatorsPrinicpalAmount(100025);

        $this->originators_principal_amount->shouldBe('100025');
    }

    function it_should_set_destination_amount()
    {
        $this->setDestinationPrinicipalAmount(100025);

        $this->destination_principal_amount->shouldBe('100025');
    }

    public function it_should_set_gross_total_amount()
    {
        $this->setGrossTotalAmount(200025);

        $this->gross_total_amount->shouldBe('200025');
    }

    public function it_should_set_pay_amount()
    {
        $this->setPayAmount(50000);

        $this->pay_amount->shouldBe('50000');
    }

    public function it_should_set_principal_amount()
    {
        $this->setPrincipalAmount(50000);

        $this->principal_amount->shouldBe('50000');
    }

    public function it_should_set_plus_charges_amount()
    {
        $this->setPlusChargesAmount(0);

        $this->plus_charges_amount->shouldBe('0');
    }

    function it_should_set_charges()
    {
        $this->setCharges(2000);

        $this->charges->shouldBe('2000');
    }

    function it_should_set_tolls()
    {
        $this->setTolls(5000);

        $this->tolls->shouldBe('5000');
    }

    function it_should_set_message_charge()
    {
        $this->setMessageCharge(0);

        $this->message_charge->shouldBe('0');
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $element = new \SimpleXMLElement('<financials></financials>');

        $this->insertPropertiesAsChildToElement($element, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($element->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
