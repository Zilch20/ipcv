<?php

namespace spec\IPCV\WesternUnion\DataAccessServer;

use DOMDocument;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DataAccessServer\DASRequest;
use IPCV\WesternUnion\Filters;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\XmlSerializable;
use spec\IPCV\WesternUnion\BaseObjectBehavior;

/**
 * @mixin DASRequest
 */
class RequestSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_channel()
    {
        $this->setChannel($expected = new Channel('FOO', 'BAR', 'BAZ'));

        $this->channel->shouldBe($expected);
    }

    function it_should_set_foreign_remote_system()
    {
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'));

        $this->foreign_remote_system->shouldBe($expected);
    }

    function it_should_set_client_id()
    {
        $this->setClientId($expected = $this->randomString(3));

        $this->client_id->shouldBe($expected);
    }

    function it_should_set_name()
    {
        $this->setName($expected = $this->randomString(31));

        $this->name->shouldBe($expected);
    }

    function it_should_set_account_num()
    {
        $this->setAccountNum($expected = $this->randomString(34));

        $this->account_num->shouldBe($expected);
    }

    function it_should_set_filters()
    {
        $this->setFilters($expected = new Filters());

        $this->filters->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this
            ->setChannel(new Channel('FOO', 'BAR', 'BAZ'))
            ->setForeignRemoteSystem(new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'))
            ->setClientId($this->randomString(3))
            ->setName($this->randomString(31))
            ->setAccountNum($this->randomString(34))
            ->setFilters(new Filters())
        ;

        $xml = <<<XML
<soapenv:Envelope 
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
    xmlns:xrsi="http://www.westernunion.com/schema/xrsi"
    >
    <soapenv:Header/>
    <soapenv:Body>
        <xrsi:h2h-das-request>
            <channel/>
            <foreign_remote_system/>
            <client_id/>
            <name/>
            <account_num/>
            <filters/>
        </xrsi:h2h-das-request>
    </soapenv:Body>
</soapenv:Envelope>
XML;
        $doc = new DOMDocument();
        $doc->loadXML($xml);

        $root = $doc->documentElement->ownerDocument;

        foreach ($this->toArray()->getWrappedObject() as $key => $prop) {
            if ($prop instanceof XmlSerializable) {
                $d = new DOMDocument();
                $d->loadXML($prop->toSimpleXML()->asXML());

                $xrsi = $root
                    ->documentElement
                    ->getElementsByTagName('Body')
                    ->item(0)
                    ->childNodes
                    ->item(1);

                $xrsi->replaceChild(
                    $root->importNode($d->documentElement, true),
                    $root->getElementsByTagName($key)->item(0)
                );
                continue;
            }

            if ($key === "name" && ($root->getElementsByTagName($key)->count() > 1)) {
                $root->getElementsByTagName($key)->item(1)->nodeValue = $prop;
                continue;
            }

            $root->getElementsByTagName($key)->item(0)->nodeValue = $prop;
        }

        $expected = new \SimpleXMLElement($doc->saveXML());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML())
        ;
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this
            ->setChannel($expected = new Channel('FOO', 'BAR', 'BAZ'))
            ->setForeignRemoteSystem($expected = new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'))
            ->setClientId($expected = $this->randomString(3))
            ->setName($expected = $this->randomString(31))
            ->setAccountNum($expected = $this->randomString(34))
            ->setFilters($expected = new Filters())
        ;

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
