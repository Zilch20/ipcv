<?php

namespace spec\IPCV\WesternUnion\DataAccessServer;

use GuzzleHttp\ClientInterface;
use IPCV\WesternUnion\DataAccessServer\Client;
use IPCV\WesternUnion\DataAccessServer\DASRequest;
use IPCV\WesternUnion\DataAccessServer\HttpClient;
use PhpSpec\ObjectBehavior;

/**
 * @mixin HttpClient
 */
class HttpClientSpec extends ObjectBehavior
{
    function let(ClientInterface $client)
    {
        $this->beConstructedWith($client);
    }

    function it_should_be_a_data_access_server_client()
    {
        $this->shouldHaveType(Client::class);
    }

    function it_should_send_request(DASRequest $request, ClientInterface $client)
    {
        $request->toSimpleXML()->shouldBeCalledOnce()->willReturn($xml = new \SimpleXMLElement('<foo></foo>'));
        $client->request(
            method: 'POST',
            uri: '',
            options: ['body' => $xml->asXML()],
        )
            ->shouldBeCalledOnce();

        $this->send($request);
    }
}
