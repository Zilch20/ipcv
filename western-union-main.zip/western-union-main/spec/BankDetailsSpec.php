<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\BankDetails;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin BankDetails
 */
class BankDetailsSpec extends BaseObjectBehavior
{
    function let()
    {
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_name()
    {
        $this->setName($expected = $this->randomString(50));

        $this->name->shouldBe($expected);
    }

    function it_should_set_account_number()
    {
        $this->setAccountNumber($expected = $this->randomString(35));

        $this->account_number->shouldBe($expected);
    }

    function it_should_set_account_type()
    {
        $this->setAccountType($expected = $this->randomString(10));

        $this->account_type->shouldBe($expected);
    }

    function it_should_set_routing_number()
    {
        $this->setRoutingNumber($expected = $this->randomString(20));

        $this->routing_number->shouldBe($expected);
    }

    function it_should_set_branch_number()
    {
        $this->setBranchNumber($expected = $this->randomString(4));

        $this->branch_number->shouldBe($expected);
    }

    function it_should_set_bank_location()
    {
        $this->setBankLocation($expected = $this->randomString(18));

        $this->bank_location->shouldBe($expected);
    }

    function it_should_set_bic()
    {
        $this->setBic($expected = $this->randomString(11));

        $this->bic->shouldBe($expected);
    }

    function it_should_set_bank_code()
    {
        $this->setBankCode($expected = $this->randomString(11));

        $this->bank_code->shouldBe($expected);
    }

    function it_should_set_sort_code()
    {
        $this->setSortCode($expected = $this->randomString(8));

        $this->sort_code->shouldBe($expected);
    }

    function it_should_set_account_prefix()
    {
        $this->setAccountPrefix($expected = $this->randomString(14));

        $this->account_prefix->shouldBe($expected);
    }

    function it_should_set_account_suffix()
    {
        $this->setAccountSuffix($expected = $this->randomString(14));

        $this->account_suffix->shouldBe($expected);
    }

    function it_should_set_bank_account_holder()
    {
        $this->setBankAccountHolder($expected = $this->randomString(20));

        $this->bank_account_holder->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this->setName($expected = $this->randomString(50));
        $this->setAccountNumber($expected = $this->randomString(35));
        $this->setAccountType($expected = $this->randomString(10));
        $this->setRoutingNumber($expected = $this->randomString(20));
        $this->setBranchNumber($expected = $this->randomString(4));
        $this->setBankLocation($expected = $this->randomString(18));
        $this->setBic($expected = $this->randomString(11));
        $this->setBankCode($expected = $this->randomString(11));
        $this->setSortCode($expected = $this->randomString(8));
        $this->setAccountPrefix($expected = $this->randomString(14));
        $this->setAccountSuffix($expected = $this->randomString(14));
        $this->setBankAccountHolder($expected = $this->randomString(20));

        $expected = new \SimpleXMLElement('<bank_details></bank_details>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this->setName($expected = $this->randomString(50));
        $this->setAccountNumber($expected = $this->randomString(35));
        $this->setAccountType($expected = $this->randomString(10));
        $this->setRoutingNumber($expected = $this->randomString(20));
        $this->setBranchNumber($expected = $this->randomString(4));
        $this->setBankLocation($expected = $this->randomString(18));
        $this->setBic($expected = $this->randomString(11));
        $this->setBankCode($expected = $this->randomString(11));
        $this->setSortCode($expected = $this->randomString(8));
        $this->setAccountPrefix($expected = $this->randomString(14));
        $this->setAccountSuffix($expected = $this->randomString(14));
        $this->setBankAccountHolder($expected = $this->randomString(20));

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
