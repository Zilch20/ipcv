<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\DeliveryServices;
use IPCV\WesternUnion\Message;
use IPCV\WesternUnion\ServiceType;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin DeliveryServices
 */
class DeliveryServicesSpec extends BaseObjectBehavior
{
    function it_should_set_code()
    {
        $this->setCode($expected = ServiceType::WILL_OR_CALL);

        $this->code->shouldBe($expected);
    }

    function it_should_set_routing_code()
    {
        $this->setRoutingCode($expected = $this->randomString(41));

        $this->routing_code->shouldBe($expected);
    }

    function it_should_set_message()
    {
        $expected = (new Message())
            ->add('foo')
            ->add('bar')
            ->add('baz')
            ->add('qux')
        ;

        $this->setMessage($expected);

        $this->message->shouldBe($expected);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<delivery_services></delivery_services>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
