<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Message;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Message
 */
class MessageSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_add_message()
    {
        $this->add($message = 'Ang mahiwagang mensahe');

        $this->messages()->shouldBe([$message]);
    }

    function it_should_not_add_message_with_more_than_69_characters()
    {
        $messageWith70Chars = 'Ang mahiwagang mensaheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee';

        $this->shouldThrow(InvalidArgumentException::class)->during('add', [$messageWith70Chars]);
    }

    function it_should_not_allow_more_than_4_messages()
    {
        $this->add('foo');
        $this->add('bar');
        $this->add('baz');
        $this->add('qux');

        $this->shouldThrow(InvalidArgumentException::class)->during('add', ['quux']);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this->add('foo');
        $this->add('bar');
        $this->add('baz');
        $this->add('qux');

        $expected = new \SimpleXMLElement('<message><message_details context="4"></message_details></message>');

        foreach ($this->messages()->getWrappedObject() as $message) {
            $expected->message_details->addChild('text', $message);
        }

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
