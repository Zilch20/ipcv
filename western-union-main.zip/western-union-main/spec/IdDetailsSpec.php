<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\IdDetails;
use IPCV\WesternUnion\IdType;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin IdDetails
 */
class IdDetailsSpec extends BaseObjectBehavior
{
    function let()
    {
        $idType = IdType::from($this->faker()->randomElement(IdType::values()));
        $idCountryOfIssue = $this->faker()->country();
        $idNumber = $this->faker()->uuid();

        $this->beConstructedWith($idType, $idCountryOfIssue, $idNumber);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form()
    {
        $expected = new \SimpleXMLElement('<id_details></id_details>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
