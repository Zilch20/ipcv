<?php

namespace spec\IPCV\WesternUnion\SendMoneyValidation;

use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DeliveryServices;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\Promotions;
use IPCV\WesternUnion\Receiver;
use IPCV\WesternUnion\Sender;
use IPCV\WesternUnion\SendMoneyValidation\Request;
use IPCV\WesternUnion\XmlSerializable;
use spec\IPCV\WesternUnion\BaseObjectBehavior;

/**
 * @mixin Request
 */
class RequestSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_device()
    {
        $this->setDevice($expected = new Device());

        $this->device->shouldBe($expected);
    }

    public function it_should_set_channel()
    {
        $this->setChannel($expected = new Channel('H2H', 'AGENT', '9500'));

        $this->channel->shouldBe($expected);
    }

    function it_should_set_sender()
    {
        $this->setSender($expected = new Sender());

        $this->sender->shouldBe($expected);
    }

    function it_should_set_receiver()
    {
        $this->setReciver($expected = new Receiver());

        $this->receiver->shouldBe($expected);
    }

    function it_should_set_payment_details()
    {
        $this->setPaymentDetails($paymentDetails = new PaymentDetails());
        $this->payment_details->shouldBe($paymentDetails);
    }

    function it_should_set_financials()
    {
        $this->setFinancials($expected = new Financials());

        $this->financials->shouldBe($expected);
    }

    function it_should_set_delivery_services()
    {
        $expected = new DeliveryServices();

        $this->setDeliveryServices($expected);
        $this->delivery_services->shouldBe($expected);
    }

    function it_should_set_promotions()
    {
        $this->setPromotions($expected = new Promotions());

        $this->promotions->shouldBe($expected);
    }

    function it_should_set_foreign_remote_system()
    {
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('ASDF-1234', '123123123', 'QWERQWE'));

        $this->foreign_remote_system->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this->setDevice(new Device());
        $this->setChannel(new Channel('H2H', 'AGENT', '9500'));
        $this->setSender(new Sender());
        $this->setReciver(new Receiver());
        $this->setPaymentDetails(new PaymentDetails());
        $this->setFinancials(new Financials());
        $this->setDeliveryServices(new DeliveryServices());
        $this->setPromotions(new Promotions());
        $this->setForeignRemoteSystem(new ForeignRemoteSystem('ASDF-1234', '123123123', 'QWERQWE'));

        $baseXml =
            '<soapenv:Envelope'
            . ' xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
            . ' xmlns:xrsi="http://www.westernunion.com/schema/xrsi">'
            . '<soapenv:Header/>'
            . '<soapenv:Body>'
            . '<xrsi:send-money-validation-request>'
            . '</xrsi:send-money-validation-request>'
            . '</soapenv:Body>'
            . '</soapenv:Envelope>'
        ;

        $expected = new \SimpleXMLElement($baseXml);

        $this->insertPropertiesAsChildToElement(
            $expected
                ->children('soapenv', true)
                ->Body
                ->children('xrsi', true),
            $this->toArray()->getWrappedObject()
        );

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this->setDevice(new Device());
        $this->setChannel(new Channel('H2H', 'AGENT', '9500'));
        $this->setSender(new Sender());
        $this->setReciver(new Receiver());
        $this->setPaymentDetails(new PaymentDetails());
        $this->setFinancials(new Financials());
        $this->setDeliveryServices(new DeliveryServices());
        $this->setPromotions(new Promotions());
        $this->setForeignRemoteSystem(new ForeignRemoteSystem('ASDF-1234', '123123123', 'QWERQWE'));

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
