<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\CurrentAddress;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin CurrentAddress
 */
class CurrentAddressSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_addr_line1()
    {
        $this->setAddrLine1($expected = $this->faker()->sentence(2));
        $this->addr_line1->shouldBe($expected);
    }

    function it_should_set_addr_line2()
    {
        $this->setAddrLine2($expected = $this->faker()->sentence(2));
        $this->addr_line2->shouldBe($expected);
    }

    function it_should_set_city()
    {
        $this->setCity($expected = $this->faker()->city());
        $this->city->shouldBe($expected);
    }

    function it_should_set_state_name()
    {
        $this->setStateName($expected = $this->faker()->sentence(2));
        $this->state_name->shouldBe($expected);
    }

    function it_should_set_postal_code()
    {
        $this->setPostalCode($expected = (string)\random_int(1000, 99999));
        $this->postal_code->shouldBe($expected);
    }

    function it_should_set_country()
    {
        $this->setCountry($expected = $this->faker()->country());
        $this->country->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this->setAddrLine1($this->randomString(40));
        $this->setAddrLine2($this->randomString(40));
        $this->setCity($this->randomString(24));
        $this->setStateName($this->randomString(40));
        $this->setPostalCode((string)\random_int(1000, 99999));
        $this->setCountry($this->randomString(44));

        $expected = new \SimpleXMLElement('<Current_address></Current_address>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_when_passed_with_a_simplexml_element()
    {
        $this->setAddrLine1($expected = $this->faker()->sentence(2));
        $this->setAddrLine2($expected = $this->faker()->sentence(2));
        $this->setCity($expected = $this->faker()->city());
        $this->setStateName($expected = $this->faker()->sentence(2));
        $this->setPostalCode($expected = (string)\random_int(1000, 99999));
        $this->setCountry($expected = $this->faker()->country());

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
