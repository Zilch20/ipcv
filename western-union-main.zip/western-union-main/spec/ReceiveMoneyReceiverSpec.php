<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Address;
use IPCV\WesternUnion\BankDetails;
use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\MobilePhone;
use IPCV\WesternUnion\Name;
use IPCV\WesternUnion\PhoneNumber;
use IPCV\WesternUnion\ReceiveMoneyReceiver;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin ReceiveMoneyReceiver
 */
class ReceiveMoneyReceiverSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_name()
    {
        $this->setName($name = Name::createTypeD('Foo', 'Bar', 'Baz'));

        $this->name->shouldBe($name);
    }

    function it_should_set_address()
    {
        $expected = new Address(
            'Foo Bar Street',
            'MANILA',
            '1000',
            new CountryCode(new IsoCode('PH', 'PHP'), 'Philippines')
        );
        $expected->setCity('MANILA CITY');

        $this->setAddress($expected);
        $this->address->shouldBe($expected);
    }

    function it_should_set_email()
    {
        $this->setEmail($email = 'foo@email.com');

        $this->email->shouldBe($email);
    }

    function it_should_set_phone_country_code()
    {
        $this->setPhoneCountryCode($code = '880');

        $this->phone_country_code->shouldBe($code);
    }

    function it_should_set_contact_phone()
    {
        $this->setContactPhone($contactPhone = '1234567890');

        $this->contact_phone->shouldBe($contactPhone);
    }

    function it_should_set_mobile_phone()
    {
        $this->setMobilePhone($mobilePhone = new MobilePhone(new PhoneNumber('63', '639123456789')));

        $this->mobile_phone->shouldBe($mobilePhone);
    }

    function it_should_set_bank_details()
    {
        $this->setBankDetails($bankDetails = new BankDetails());

        $this->bank_details->shouldBe($bankDetails);
    }

    function it_should_return_its_xml_form()
    {
        $address = new Address(
            'Foo Bar Street',
            'MANILA',
            '1000',
            new CountryCode(new IsoCode('PH', 'PHP'), 'Philippines')
        );
        $address->setCity('MANILA CITY');

        $this
            ->setName(Name::createTypeD('Juan', 'Dela Cruz', 'Chua'))
            ->setAddress($address)
            ->setComplianceDetails(new ComplianceDetails())
            ->setEmail($this->faker()->email())
            ->setPhoneCountryCode((string)\random_int(111, 999))
            ->setContactPhone($this->faker()->phoneNumber())
            ->setMobilePhone(new MobilePhone(new PhoneNumber('639', '123456789')))
            ->setBankDetails(new BankDetails())
        ;

        $expected = new \SimpleXMLElement('<receiver></receiver>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $address = new Address(
            'Foo Bar Street',
            'MANILA',
            '1000',
            new CountryCode(new IsoCode('PH', 'PHP'), 'Philippines')
        );
        $address->setCity('MANILA CITY');

        $this
            ->setName(Name::createTypeD('Juan', 'Dela Cruz', 'Chua'))
            ->setAddress($address)
            ->setComplianceDetails(new ComplianceDetails())
            ->setEmail($this->faker()->email())
            ->setPhoneCountryCode((string)\random_int(111, 999))
            ->setContactPhone($this->faker()->phoneNumber())
            ->setMobilePhone(new MobilePhone(new PhoneNumber('639', '123456789')))
            ->setBankDetails(new BankDetails())
        ;

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
