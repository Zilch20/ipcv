<?php

namespace spec\IPCV\WesternUnion;

use GuzzleHttp\ClientInterface;
use IPCV\WesternUnion\Client;
use IPCV\WesternUnion\HttpClient;
use IPCV\WesternUnion\Request;
use PhpSpec\ObjectBehavior;

/**
 * @mixin HttpClient
 */
class HttpClientSpec extends ObjectBehavior
{
    function let(ClientInterface $client)
    {
        $this->beConstructedWith($client);
    }

    function it_should_be_a_client()
    {
        $this->shouldHaveType(Client::class);
    }

    function it_should_send_request(Request $request, ClientInterface $client)
    {
        $request->toSimpleXML()->shouldBeCalledOnce()->willReturn($xml = new \SimpleXMLElement('<foo></foo>'));
        $client->request(
            method: 'POST',
            uri: '',
            options: ['body' => $xml->asXML()],
        )
        ->shouldBeCalledOnce();

        $this->send($request);
    }
}
