<?php

namespace spec\IPCV\WesternUnion\FeeInquiry;

use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DeliveryServices;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\FeeInquiry\Request;
use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\Promotions;
use IPCV\WesternUnion\XmlSerializable;
use spec\IPCV\WesternUnion\BaseObjectBehavior;

/**
 * @mixin Request
 */
class RequestSpec extends BaseObjectBehavior
{
    function it_should_set_device()
    {
        $this->setDevice($expected = new Device());

        $this->device->shouldBe($expected);
    }

    function it_should_set_channel()
    {
        $this->setChannel($expected = new Channel('H2H', 'IPCV', '9500'));

        $this->channel->shouldBe($expected);
    }

    function it_should_set_financials()
    {
        $this->setFinancials($expected = new Financials());

        $this->financials->shouldBe($expected);
    }

    function it_should_set_payment_details()
    {
        $this->setPaymentDetails($expected = new PaymentDetails());

        $this->payment_details->shouldBe($expected);
    }

    function it_should_set_foreign_remote_system()
    {
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('123', '123', '123'));

        $this->foreign_remote_system->shouldBe($expected);
    }

    function it_should_set_promotions()
    {
        $this->setPromotions($expected = new Promotions());

        $this->promotions->shouldBe($expected);
    }

    function it_should_set_delivery_services()
    {
        $this->setDeliveryServices($expected = new DeliveryServices());

        $this->delivery_services->shouldBe($expected);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $baseXml =
            '<soapenv:Envelope'
                . ' xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"'
                . ' xmlns:xrsi="http://www.westernunion.com/schema/xrsi">'
            . '<soapenv:Header/>'
            . '<soapenv:Body>'
                . '<xrsi:fee-inquiry-request>'
                . '</xrsi:fee-inquiry-request>'
            . '</soapenv:Body>'
            . '</soapenv:Envelope>'
        ;

        $expected = new \SimpleXMLElement($baseXml);

        $this->insertPropertiesAsChildToElement(
            $expected
                ->children('soapenv', true)
                ->Body
                ->children('xrsi', true),
            $this->toArray()->getWrappedObject()
        );

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
