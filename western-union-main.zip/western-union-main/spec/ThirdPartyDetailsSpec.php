<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Option;
use IPCV\WesternUnion\ThirdPartyDetails;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin ThirdPartyDetails
 */
class ThirdPartyDetailsSpec extends BaseObjectBehavior
{
    function let()
    {
        $this->beConstructedWith(Option::Y);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<third_party_details></third_party_details>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
