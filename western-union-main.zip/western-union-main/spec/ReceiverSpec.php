<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Address;
use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\MobilePhone;
use IPCV\WesternUnion\Name;
use IPCV\WesternUnion\PhoneNumber;
use IPCV\WesternUnion\Receiver;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Receiver
 */
class ReceiverSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_name()
    {
        $this->setName($expected = Name::createTypeD(
            'Juan',
            'Dela Cruz',
            'Chua'
        ));

        $this->name->shouldBe($expected);
    }

    function it_should_set_address()
    {
        $expected = new Address(
            '69/F Foo Building, 13th Avenue',
            'MANILA',
            '1000',
            new CountryCode(new IsoCode('PH', 'PHP'), 'PHILIPPINES')
        );
        $expected->setCity('MANILA CITY');

        $this->setAddress($expected);
        $this->address->shouldBe($expected);
    }

    function it_should_set_phone_country_code()
    {
        $this->setPhoneCountryCode($expected = (string)\random_int(111111, 999999));

        $this->phone_country_code->shouldBe($expected);
    }

    function it_should_set_contact_phone()
    {
        $this->setContactPhone($expected = $this->faker()->phoneNumber());

        $this->contact_phone->shouldBe($expected);
    }

    function it_should_set_mobile_phone()
    {
        $expected = new MobilePhone(new PhoneNumber('639', '999999999'));

        $this->setMobilePhone($expected);
        $this->mobile_phone->shouldBe($expected);
    }

    function it_should_set_reason_for_sending()
    {
        $this->setReasonForSending($expected = 'code_01');

        $this->reason_for_sending->shouldBe($expected);
    }

    function it_should_return_its_xml_form()
    {
        $this->setName(Name::createTypeD('Juan', 'Dela Cruz', 'Chua'));
        $this->setAddress(
            (new Address(
                '69/F Foo Building, 13th Avenue',
                'MANILA',
                '1000',
                new CountryCode(new IsoCode('PH', 'PHP'), 'PHILIPPINES')
            ))->setCity('MANILA CITY')
        );
        $this->setPhoneCountryCode((string)\random_int(111111, 999999));
        $this->setContactPhone($this->faker()->phoneNumber());
        $this->setMobilePhone(new MobilePhone(new PhoneNumber('639', '999999999')));
        $this->setReasonForSending('code_01');

        $expected = new \SimpleXMLElement('<receiver></receiver>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this->setName(Name::createTypeD('Juan', 'Dela Cruz', 'Chua'));
        $this->setAddress(
            (new Address(
                '69/F Foo Building, 13th Avenue',
                'MANILA',
                '1000',
                new CountryCode(new IsoCode('PH', 'PHP'), 'PHILIPPINES')
            ))->setCity('MANILA CITY')
        );
        $this->setPhoneCountryCode((string)\random_int(111111, 999999));
        $this->setContactPhone($this->faker()->phoneNumber());
        $this->setMobilePhone(new MobilePhone(new PhoneNumber('639', '999999999')));
        $this->setReasonForSending('code_01');

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
