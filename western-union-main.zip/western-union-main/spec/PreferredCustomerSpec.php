<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\PermanentChange;
use IPCV\WesternUnion\PreferredCustomer;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin PreferredCustomer
 */
class PreferredCustomerSpec extends BaseObjectBehavior
{
    function let()
    {
        $this->beConstructedWith(
            PermanentChange::from($this->faker()->randomElement(PermanentChange::values())),
            (string)\random_int(11_111_111_111, 99_999_999_999)
        );
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<preferred_customer></preferred_customer>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
