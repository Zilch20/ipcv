<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\CurrentAddress;
use IPCV\WesternUnion\Gender;
use IPCV\WesternUnion\IdDetails;
use IPCV\WesternUnion\IdType;
use IPCV\WesternUnion\Option;
use IPCV\WesternUnion\ThirdPartyDetails;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin ComplianceDetails
 */
class ComplianceDetailsSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_template_id()
    {
        $this->setTemplateId($expected = $this->faker()->uuid());

        $this->template_id->shouldBe($expected);
    }

    function it_should_set_version()
    {
        $this->setVersion($expected = $this->faker()->sentence());

        $this->version->shouldBe($expected);
    }

    function it_should_set_id_details()
    {
        $idType = IdType::from($this->faker()->randomElement(IdType::values()));

        $this->setIdDetails(
            $expected = new IdDetails($idType, $this->faker()->country(), $this->faker()->uuid())
        );

        $this->id_details->shouldBe($expected);
    }

    function it_should_set_third_party_details()
    {
        $this->setThirdPartyDetails($expected = new ThirdPartyDetails(Option::Y));

        $this->third_party_details->shouldBe($expected);
    }

    function it_should_set_id_issue_date()
    {
        $this->setIdIssueDate($expected = new \DateTimeImmutable());

        $this->id_issue_date->shouldBe($expected->format('dmY'));
    }

    function it_should_set_id_expiration_date()
    {
        $this->setIdExpirationDate($expected = new \DateTimeImmutable());

        $this->id_expiration_date->shouldBe($expected->format('dmY'));
    }

    function it_should_set_date_of_birth()
    {
        $this->setIdExpirationDate($expected = new \DateTimeImmutable());

        $this->id_expiration_date->shouldBe($expected->format('dmY'));
    }

    function it_should_set_occupation()
    {
        $this->setOccupation($expected = 'Employee');

        $this->occupation->shouldBe($expected);
    }

    function it_should_set_transaction_reason()
    {
        $this->setTransactionReason($expected = $this->faker()->sentence(3));

        $this->transaction_reason->shouldBe($expected);
    }

    function it_should_set_current_address()
    {
        $expected = (new CurrentAddress())
            ->setAddrLine1($this->faker()->sentence(1))
            ->setAddrLine2($this->faker()->sentence(1))
            ->setCity('MAKATI')
            ->setStateName($this->faker()->word())
            ->setPostalCode((string)random_int(1000, 99999))
            ->setCountry($this->faker()->country());

        $this->setCurrentAddress($expected);

        $this->Current_address->shouldBe($expected);
    }

    public function it_should_set_contact_phone()
    {
        $this->setContactPhone($expected = '639123456789');

        $this->contact_phone->shouldBe($expected);
    }

    function it_should_set_country_of_birth()
    {
        $this->setCountryOfBirth($expected = 'PHILIPPINES');

        $this->Country_of_Birth->shouldBe($expected);
    }

    function it_should_set_nationality()
    {
        $this->setNationality($expected = 'FILIPINO');

        $this->nationality->shouldBe($expected);
    }

    function it_should_set_gender()
    {
        $this->setGender($expected = Gender::M);

        $this->Gender->shouldBe($expected);
    }

    function it_should_set_source_of_funds()
    {
        $this->setSourceOfFunds($expected = 'Salary');

        $this->Source_of_Funds->shouldBe($expected);
    }

    function it_should_set_relationship_to_receiver_sender()
    {
        $this->setRelationshipToReceiverSender($expected = 'Friend');

        $this->Relationship_to_Receiver_Sender->shouldBe($expected);
    }

    function it_should_set_does_the_id_have_an_expiration_date()
    {
        $this->setDoesTheIdHaveAnExpirationDate($expected = Option::Y);

        $this->Does_the_ID_have_an_expiration_date->shouldBe($expected);
    }

    function it_should_set_ack_flag()
    {
        $this->setAckFlag($expected = 'X');

        $this->ack_flag->shouldBe($expected);
    }

    function it_should_set_Country_Code()
    {
        $this->setCountryCode($expected = '63');

        $this->Country_Code->shouldBe($expected);
    }

    function it_should_set_galactic_id()
    {
        $this->setGalacticId($expected = $this->faker()->word());

        $this->galactic_id->shouldBe($expected);
    }

    function it_should_set_multi_error_supported()
    {
        $this->setMultiErrorSupported($expected = Option::Y);

        $this->multi_error_supported->shouldBe($expected);
    }

    function it_should_set_employment_position_level()
    {
        $this->setEmploymentPositionLevel($expected = 'Entry Level');

        $this->employment_position_level->shouldBe($expected);
    }

    function it_should_set_compliance_data_buffer()
    {
        $this->setComplianceDataBuffer($expected = $this->faker()->sentence(5));

        $this->compliance_data_buffer->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $idType = IdType::from($this->faker()->randomElement(IdType::values()));

        $this->setTemplateId($this->faker()->uuid());
        $this->setVersion($this->faker()->sentence());
        $this->setIdDetails(new IdDetails($idType, $this->faker()->country(), $this->faker()->uuid()));
        $this->setThirdPartyDetails(new ThirdPartyDetails(Option::Y));
        $this->setIdIssueDate(new \DateTimeImmutable());
        $this->setIdExpirationDate(new \DateTimeImmutable());
        $this->setOccupation($this->randomString(30));
        $this->setTransactionReason($this->randomString(50));
        $this->setCurrentAddress(
            (new CurrentAddress())
            ->setAddrLine1('FOO')
            ->setAddrLine2('FOOBAR')
            ->setCity($this->faker()->city())
            ->setStateName($this->randomString(40))
            ->setPostalCode((string)random_int(1000, 99999))
            ->setCountry($this->randomString(44))
        );
        $this->setCountryOfBirth('PHILIPPINES');
        $this->setNationality('FILIPINO');
        $this->setGender(Gender::M);
        $this->setSourceOfFunds('Salary');
        $this->setRelationshipToReceiverSender('Friend');
        $this->setDoesTheIdHaveAnExpirationDate(Option::Y);
        $this->setAckFlag('X');
        $this->setGalacticId($this->faker()->word());
        $this->setMultiErrorSupported(Option::Y);
        $this->setEmploymentPositionLevel('Entry Level');
        $this->setComplianceDataBuffer($this->faker()->sentence(5));

        $expected = new \SimpleXMLElement('<compliance_details></compliance_details>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $idType = IdType::from($this->faker()->randomElement(IdType::values()));

        $this->setTemplateId($this->faker()->uuid());
        $this->setVersion($this->faker()->sentence());
        $this->setIdDetails(new IdDetails($idType, $this->faker()->country(), $this->faker()->uuid()));
        $this->setThirdPartyDetails(new ThirdPartyDetails(Option::Y));
        $this->setIdIssueDate(new \DateTimeImmutable());
        $this->setIdExpirationDate(new \DateTimeImmutable());
        $this->setOccupation('Employee');
        $this->setTransactionReason('PERSONAL');
        $this->setCurrentAddress(
            (new CurrentAddress())
                ->setAddrLine1('FOO')
                ->setAddrLine2('FOOBAR')
                ->setCity($this->faker()->city())
                ->setStateName($this->randomString(40))
                ->setPostalCode((string)random_int(1000, 99999))
                ->setCountry($this->randomString(44))
        );
        $this->setCountryOfBirth('PHILIPPINES');
        $this->setNationality('FILIPINO');
        $this->setGender(Gender::M);
        $this->setSourceOfFunds('Salary');
        $this->setRelationshipToReceiverSender('Friend');
        $this->setDoesTheIdHaveAnExpirationDate(Option::Y);
        $this->setAckFlag('X');
        $this->setGalacticId($this->faker()->word());
        $this->setMultiErrorSupported(Option::Y);
        $this->setEmploymentPositionLevel('Entry Level');
        $this->setComplianceDataBuffer($this->faker()->sentence(5));


        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
