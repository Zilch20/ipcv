<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\ExpectedPayoutLocation;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin ExpectedPayoutLocation
 */
class ExpectedPayoutLocationSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_state_code()
    {
        $this->setStateCode($expected = $this->randomString(10));

        $this->state_code->shouldBe($expected);
    }

    function it_should_set_city()
    {
        $this->setCity($expected = $this->randomString(30));

        $this->city->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<expected_payout_location></expected_payout_location>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
