<?php

declare(strict_types=1);

namespace spec\IPCV\WesternUnion;

use Faker\Factory;
use Faker\Generator;
use IPCV\WesternUnion\XmlHelper;
use SimpleXMLElement;

class BaseObjectBehavior extends \PhpSpec\ObjectBehavior
{
    use XmlHelper;

    private ?Generator $faker = null;

    protected function faker(): Generator
    {
        if (! $this->faker) {
            $this->faker = Factory::create();
        }

        return $this->faker;
    }

    protected function randomString(int $length): string
    {
        return $this->faker()->regexify('[A-Za-z0-9]{' . $length . '}');
    }

    public static function createPseudoParentElement(): SimpleXMLElement
    {
        return new SimpleXMLElement('<pseudo-parent></pseudo-parent>');
    }
}
