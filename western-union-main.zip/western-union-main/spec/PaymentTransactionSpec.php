<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\PaymentTransaction;
use IPCV\WesternUnion\Receiver;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin PaymentTransaction
 */
class PaymentTransactionSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_receiver()
    {
        $this->setReceiver($expected = new Receiver());

        $this->receiver->shouldBe($expected);
    }

    function it_should_set_payment_details()
    {
        $this->setPaymentDetails($expected = new PaymentDetails());

        $this->payment_details->shouldBe($expected);
    }

    function it_should_set_mtcn()
    {
        $this->setMtcn($expected = $this->randomString(16));

        $this->mtcn->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this->setReceiver($expected = new Receiver());
        $this->setPaymentDetails($expected = new PaymentDetails());
        $this->setMtcn($expected = $this->randomString(16));

        $expected = new \SimpleXMLElement('<payment_transaction></payment_transaction>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
