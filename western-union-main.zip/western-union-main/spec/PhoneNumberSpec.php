<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\PhoneNumber;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin PhoneNumber
 */
class PhoneNumberSpec extends BaseObjectBehavior
{
    function let()
    {
        $this->beConstructedWith((string)\random_int(111, 999), $foo = (string)\random_int(111111111, 999999999));
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<phone_number></phone_number>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
