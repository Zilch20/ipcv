<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Promotions;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Promotions
 */
class PromotionsSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_coupons_promotions()
    {
        $this->setCouponsPromotions($expected = $this->randomString(20));

        $this->coupons_promotions->shouldBe($expected);
    }

    function it_should_set_sender_promo_code()
    {
        $this->setSenderPromoCode($expected = $this->randomString(20));

        $this->sender_promo_code->shouldBe($expected);
    }

    function it_should_not_be_created_when_promotion_code_exceeds_20_characters()
    {
        $this
            ->shouldThrow(InvalidArgumentException::class)
            ->during('setCouponsPromotions', [$this->randomString(50)]);
    }

    function it_should_not_be_created_when_sender_promo_code_exceeds_20_characters()
    {
        $this
            ->shouldThrow(InvalidArgumentException::class)
            ->during('setSenderPromoCode', [$this->randomString(50)]);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<promotions></promotions>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
