<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Address;
use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Address
 */
class AddressSpec extends BaseObjectBehavior
{
    function let()
    {
        $addressLine1 = 'Block 50 Lot 100 Phase 50 Silent Hill Village';
        $state = 'Laguna';
        $postalCode = '4000';
        $countryCode = new CountryCode(new IsoCode('PH', 'PHP'), 'Philippines');

        $this->beConstructedWith($addressLine1, $state, $postalCode, $countryCode);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }


    function it_should_set_address_line_2()
    {
        $this->setAddressLine2($expected = 'Grove Street');

        $this->addr_line2->shouldBe($expected);
    }

    function it_should_set_city()
    {
        $this->setCity($expected = 'Los Santos City');

        $this->city->shouldBe($expected);
    }

    function it_should_not_set_address_line_2_when_it_exceeds_84_characters()
    {
        $longAddress = $this->faker()->sentence(50);
        $this
            ->shouldThrow(InvalidArgumentException::class)
            ->during('setAddressLine2', [$longAddress])
        ;
    }

    function it_should_not_set_city_when_it_exceeds_30_characters()
    {
        $longAddress = $this->faker()->sentence(50);
        $this
            ->shouldThrow(InvalidArgumentException::class)
            ->during('setCity', [$longAddress])
        ;
    }

    function it_should_not_be_created_when_address_line_1_exceeds_84_characters()
    {
        $addressLine1 = $this->faker()->sentence(50);
        $addressLine2 = 'Foo';
        $city = 'Sin City';
        $state = 'Laguna';
        $postalCode = '4000';
        $countryCode = new CountryCode(new IsoCode('PH', 'PHP'), 'Philippines');

        $this->beConstructedWith(
            $addressLine1,
            $state,
            $postalCode,
            $countryCode,
        );

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_state_exceeds_40_characters()
    {
        $addressLine1 = 'Block 50 Lot 100 Phase 50 Silent Hill Village';
        $addressLine2 = 'Foo';
        $city = 'Sin City';
        $state = $this->faker()->sentence(50);
        $postalCode = '4000';
        $countryCode = new CountryCode(new IsoCode('PH', 'PHP'), 'Philippines');

        $this->beConstructedWith(
            $addressLine1,
            $state,
            $postalCode,
            $countryCode,
        );

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_postal_code_exceeds_40_characters()
    {
        $addressLine1 = 'Block 50 Lot 100 Phase 50 Silent Hill Village';
        $addressLine2 = 'Foo';
        $city = 'Sin City';
        $state = 'Laguna';
        $postalCode = $this->faker()->sentence(50);
        $countryCode = new CountryCode(new IsoCode('PH', 'PHP'), 'Philippines');

        $this->beConstructedWith(
            $addressLine1,
            $state,
            $postalCode,
            $countryCode,
        );

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_return_its_xml_form()
    {
        $this->setAddressLine2($addressLine2 = 'Foo');
        $this->setCity($city = 'Sin City');

        $expected = new \SimpleXMLElement('<address></address>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this->setAddressLine2($addressLine2 = 'Foo');
        $this->setCity($city = 'Sin City');

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
