<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\CountryCurrencyInfo;
use IPCV\WesternUnion\CountryName;
use IPCV\WesternUnion\CountryUnisysCode;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin CountryCurrencyInfo
 */
class CountryCurrencyInfoSpec extends BaseObjectBehavior
{
    function let()
    {
        $cpcCode = new CountryUnisysCode('AAA');
        $isoCode = new IsoCode('PH', 'PHP');
        $country = new CountryName('Philippines');

        $this->beConstructedWith($cpcCode, $isoCode, $country);
    }


    function it_is_initializable()
    {
        $this->shouldHaveType(XmlSerializable::class);
    }

    function it_should_return_its_xml_form()
    {
        $expected = new \SimpleXMLElement('<country_currency_info></country_currency_info>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
