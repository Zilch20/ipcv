<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin ForeignRemoteSystem
 */
class ForeignRemoteSystemSpec extends BaseObjectBehavior
{
    private string $testIdentifier;

    private string $testReferenceNumber;

    private string $testCounterId;

    function let()
    {
        $this->beConstructedWith(
            $this->testIdentifier = '123-567-9876',
            $this->testReferenceNumber = 'ABCD-EFGH-IJ-123',
            $this->testCounterId = 'CDEFG-123456',
        );
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_not_be_created_when_identifier_exceeds_12_characters()
    {
        $identifier = $this->faker()->sentence(25);

        $this->beConstructedWith($identifier, '123', '123');
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_reference_number_exceeds_16_characters()
    {
        $referenceNumber = $this->faker()->sentence(25);

        $this->beConstructedWith('123', $referenceNumber, '123');
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_counter_id_exceeds_12_characters()
    {
        $counterId = $this->faker()->sentence(25);

        $this->beConstructedWith('123', $counterId, '123');
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<foreign_remote_system></foreign_remote_system>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
