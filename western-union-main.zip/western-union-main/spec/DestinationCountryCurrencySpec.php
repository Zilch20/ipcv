<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\DestinationCountryCurrency;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin DestinationCountryCurrency
 */
class DestinationCountryCurrencySpec extends BaseObjectBehavior
{
    function let()
    {
        $isoCode = new IsoCode('PH', 'PHP');

        $this->beConstructedWith($isoCode);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<destination_country_currency></destination_country_currency>');

        $this->appendChildToParent(
            $expected,
            $this->iso_code->getWrappedObject()->toSimpleXML()
        );

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
