<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\IsoCode;

/**
 * @mixin CountryCode
 */
class CountryCodeSpec extends BaseObjectBehavior
{
    private IsoCode $testIsoCode;

    private string $testCountryName;

    function let()
    {
        $this->testIsoCode = new IsoCode('PH', 'PHP');
        $this->testCountryName = 'Philippines';

        $this->beConstructedWith($this->testIsoCode, $this->testCountryName);
    }

    function it_should_not_be_created_when_country_name_exceeds_40_characters()
    {
        $this->beConstructedWith($this->testIsoCode, $this->faker()->sentence(50));
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_return_its_xml_form()
    {
        $expected = new \SimpleXMLElement('<country_code></country_code>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
