<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\DeviceType;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Device
 */
class DeviceSpec extends BaseObjectBehavior
{
    public function it_should_set_id()
    {
        $this->setId($expected = $this->randomString(32));

        $this->id->shouldBe($expected);
    }

    public function it_should_set_type()
    {
        $this->setType($expected = DeviceType::WALLET);

        $this->type->shouldBe($expected);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this
            ->setId($this->randomString(32))
            ->setType(DeviceType::IVR)
        ;

        $expected = new \SimpleXMLElement('<device></device>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this
            ->setId($this->randomString(32))
            ->setType(DeviceType::IVR)
        ;

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
