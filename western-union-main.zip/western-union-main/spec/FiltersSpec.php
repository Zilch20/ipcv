<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Filters;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Filters
 */
class FiltersSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_add_filters()
    {
        $this
            ->addFilter($filter1 = $this->randomString(360))
            ->addFilter($filter2 = $this->randomString(360))
            ->addFilter($filter3 = $this->randomString(360))
        ;

        $this->filters()->shouldBe([$filter1, $filter2, $filter3]);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
        ;

        $expected = new \SimpleXMLElement('<filters></filters>');

        foreach ($this->filters()->getWrappedObject() as $index => $filter) {
            $index++;
            $expected->addChild('queryfilter' . $index++, $filter);
        }

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
            ->addFilter($this->randomString(5))
        ;

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
