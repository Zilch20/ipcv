<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\Name;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Name
 */
class NameSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_create_name_type_D()
    {
        $firstName = $this->faker()->firstName();
        $middleName = $this->faker()->lastName();
        $lastName = $this->faker()->lastName();

        $this->beConstructedThrough('createTypeD', [$firstName, $middleName, $lastName]);
        $this->first_name->shouldBe($firstName);
        $this->middle_name->shouldBe($middleName);
        $this->last_name->shouldBe($lastName);

        $expected = new \SimpleXMLElement('<name name_type="D"></name>');

        $nameAsArray = $this->toArray()->getWrappedObject();
        unset($nameAsArray['type']);

        $this->insertPropertiesAsChildToElement($expected, $nameAsArray);

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_not_be_created_when_first_name_exceeds_80_characters()
    {
        $firstName = $this->faker()->sentence(50);
        $middleName = $this->faker()->lastName();
        $lastName = $this->faker()->lastName();

        $this->beConstructedThrough('createTypeD', [$firstName, $lastName, $middleName]);
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_middle_name_exceeds_80_characters()
    {
        $firstName = $this->faker()->firstName();
        $middleName = $this->faker()->sentence(50);
        $lastName = $this->faker()->lastName();

        $this->beConstructedThrough('createTypeD', [$firstName, $lastName, $middleName]);
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_last_name_exceeds_80_characters()
    {
        $firstName = $this->faker()->firstName();
        $middleName = $this->faker()->lastName();
        $lastName = $this->faker()->sentence(50);

        $this->beConstructedThrough('createTypeD', [$firstName, $lastName, $middleName]);
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_create_name_type_M()
    {
        $givenName = $this->faker()->firstName();
        $paternalName = $this->faker()->lastName();
        $maternalName = $this->faker()->lastName();

        $this->beConstructedThrough('createTypeM', [$givenName, $paternalName, $maternalName]);
        $this->given_name->shouldBe($givenName);
        $this->paternal_name->shouldBe($paternalName);
        $this->maternal_name->shouldBe($maternalName);

        $expected = new \SimpleXMLElement('<name name_type="M"></name>');

        $nameAsArray = $this->toArray()->getWrappedObject();
        unset($nameAsArray['type']);

        $this->insertPropertiesAsChildToElement($expected, $nameAsArray);

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_not_be_created_when_given_name_exceeds_80_characters()
    {
        $givenName = $this->faker()->sentence(50);
        $paternalName = $this->faker()->lastName();
        $maternalName = $this->faker()->lastName();

        $this->beConstructedThrough('createTypeM', [$givenName, $paternalName, $maternalName]);
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_paternal_name_exceeds_80_characters()
    {
        $givenName = $this->faker()->firstName();
        $paternalName = $this->faker()->sentence(50);
        $maternalName = $this->faker()->lastName();

        $this->beConstructedThrough('createTypeM', [$givenName, $paternalName, $maternalName]);
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_not_be_created_when_maternal_name_exceeds_80_characters()
    {
        $givenName = $this->faker()->firstName();
        $paternalName = $this->faker()->lastName();
        $maternalName = $this->faker()->sentence(50);

        $this->beConstructedThrough('createTypeM', [$givenName, $paternalName, $maternalName]);
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $givenName = $this->faker()->firstName();
        $paternalName = $this->faker()->lastName();
        $maternalName = $this->faker()->lastName();

        $this->beConstructedThrough('createTypeD', [$givenName, $paternalName, $maternalName]);

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
