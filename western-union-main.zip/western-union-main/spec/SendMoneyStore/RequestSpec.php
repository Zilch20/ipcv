<?php

namespace spec\IPCV\WesternUnion\SendMoneyStore;

use DOMDocument;
use IPCV\WesternUnion\BankDetails;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\DeliveryServices;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\DeviceType;
use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\InstantNotification;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\Promotions;
use IPCV\WesternUnion\Receiver;
use IPCV\WesternUnion\Sender;
use IPCV\WesternUnion\SendMoneyStore\Request;
use IPCV\WesternUnion\XmlSerializable;
use spec\IPCV\WesternUnion\BaseObjectBehavior;

/**
 * @mixin Request
 */
class RequestSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_device()
    {
        $this->setDevice($expected = new Device($this->randomString(32), DeviceType::AGENT));

        $this->device->shouldBe($expected);
    }

    function it_should_set_channel()
    {
        $this->setChannel($expected = new Channel('FOO', 'BAR', 'BAZ'));

        $this->channel->shouldBe($expected);
    }

    function it_should_set_instant_notification()
    {
        $this->setInstantNotification($expected = new InstantNotification('foo'));

        $this->instant_notification->shouldBe($expected);
    }

    function it_should_set_sender()
    {
        $this->setSender($expected = new Sender());

        $this->sender->shouldBe($expected);
    }

    function it_should_set_receiver()
    {
        $this->setReceiver($expected = new Receiver());

        $this->receiver->shouldBe($expected);
    }

    function it_should_set_bank_details()
    {
        $this->setBankDetails($expected = new BankDetails());

        $this->bank_details->shouldBe($expected);
    }

    function it_should_set_promotions()
    {
        $this->setPromotions($expected = new Promotions());

        $this->promotions->shouldBe($expected);
    }

    function it_should_set_payment_details()
    {
        $this->setPaymentDetails($expected = new PaymentDetails());

        $this->payment_details->shouldBe($expected);
    }

    function it_should_set_financials()
    {
        $this->setFinancials($expected = new Financials());

        $this->financials->shouldBe($expected);
    }

    function it_should_set_delivery_services()
    {
        $this->setDeliveryServices($expected = new DeliveryServices());

        $this->delivery_services->shouldBe($expected);
    }

    function it_should_set_mtcn()
    {
        $this->setMtcn($expected = $this->randomString(16));

        $this->mtcn->shouldBe($expected);
    }

    function it_should_set_new_mtcn()
    {
        $this->setNewMtcn($expected = $this->randomString(16));

        $this->new_mtcn->shouldBe($expected);
    }

    function it_should_set_foreign_remote_system()
    {
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'));

        $this->foreign_remote_system->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this
            ->setDevice(new Device())
            ->setChannel(new Channel('FOO', 'BAR', 'BAZ'))
            ->setInstantNotification(new InstantNotification('foo'))
            ->setSender(new Sender())
            ->setReceiver(new Receiver())
            ->setBankDetails(new BankDetails())
            ->setPromotions(new Promotions())
            ->setPaymentDetails(new PaymentDetails())
            ->setFinancials(new Financials())
            ->setDeliveryServices(new DeliveryServices())
            ->setMtcn($this->randomString(16))
            ->setNewMtcn($this->randomString(16))
            ->setForeignRemoteSystem(new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'))
        ;

        $xml =  <<<XML
<soapenv:Envelope 
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
    xmlns:xrsi="http://www.westernunion.com/schema/xrsi"
    >
    <soapenv:Header/>
    <soapenv:Body>
        <xrsi:send-money-store-request>
            <device/>
            <channel/>
            <instant_notification/>
            <sender/>
            <receiver/>
            <bank_details/>
            <promotions/>
            <payment_details/>
            <financials/>
            <delivery_services/>
            <mtcn/>
            <new_mtcn/>
            <foreign_remote_system/>
        </xrsi:send-money-store-request>
    </soapenv:Body>
</soapenv:Envelope>
XML;
        $doc = new DOMDocument();
        $doc->loadXML($xml);

        $root = $doc->documentElement->ownerDocument;

        foreach ($this->toArray()->getWrappedObject() as $key => $prop) {
            if ($prop instanceof XmlSerializable) {
                $d = new DOMDocument();
                $d->loadXML($prop->toSimpleXML()->asXML());

                $xrsi = $root
                    ->documentElement
                    ->getElementsByTagName('Body')
                    ->item(0)
                    ->childNodes
                    ->item(1);

                $xrsi->replaceChild(
                    $root->importNode($d->documentElement, true),
                    $root->getElementsByTagName($key)->item(0)
                );
                continue;
            }
            $root->getElementsByTagName($key)->item(0)->nodeValue = $prop;
        }

        $expected = new \SimpleXMLElement($doc->saveXML());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML())
        ;
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this
            ->setDevice(new Device())
            ->setChannel(new Channel('FOO', 'BAR', 'BAZ'))
            ->setInstantNotification(new InstantNotification('foo'))
            ->setSender(new Sender())
            ->setReceiver(new Receiver())
            ->setBankDetails(new BankDetails())
            ->setPromotions(new Promotions())
            ->setPaymentDetails(new PaymentDetails())
            ->setFinancials(new Financials())
            ->setDeliveryServices(new DeliveryServices())
            ->setMtcn($this->randomString(16))
            ->setNewMtcn($this->randomString(16))
            ->setForeignRemoteSystem(new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'))
        ;

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
