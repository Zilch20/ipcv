<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Address;
use IPCV\WesternUnion\BankDetails;
use IPCV\WesternUnion\ComplianceDetails;
use IPCV\WesternUnion\CountryCode;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\MobilePhone;
use IPCV\WesternUnion\Name;
use IPCV\WesternUnion\PermanentChange;
use IPCV\WesternUnion\PhoneNumber;
use IPCV\WesternUnion\PreferredCustomer;
use IPCV\WesternUnion\Sender;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin Sender
 */
class SenderSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_name()
    {
        $expected = Name::createTypeD(
            $this->faker()->firstName(),
            $this->faker()->lastName(),
            $this->faker()->lastName(),
        );

        $this->setName($expected);
        $this->name->shouldBe($expected);
    }

    function it_should_set_address()
    {
        $expected = new Address(
            $this->faker()->sentence(3),
            'MANILA',
            '1000',
            new CountryCode(new IsoCode('PH', 'PHP'), 'PHILIPPINES')
        );
        $expected->setCity('MANILA CITY');

        $this->setAddress($expected);
        $this->address->shouldBe($expected);
    }

    function it_should_set_preferred_customer()
    {
        $expected = new PreferredCustomer(
            PermanentChange::from($this->faker()->randomElement(PermanentChange::values())),
            (string)\random_int(11_111_111_111, 99_999_999_999)
        );

        $this->setPreferredCustomer($expected);
        $this->preferred_customer->shouldBe($expected);
    }

    function it_should_set_compliance_details()
    {
        $this->setComplianceDetails($expected = new ComplianceDetails());

        $this->compliance_details->shouldBe($expected);
    }

    function it_should_set_email()
    {
        $this->setEmail($expected = $this->faker()->email());

        $this->email->shouldBe($expected);
    }

    function it_should_set_phone_country_code()
    {
        $this->setPhoneCountryCode($expected = (string)\random_int(111111, 999999));

        $this->phone_country_code->shouldBe($expected);
    }

    function it_should_set_contact_phone()
    {
        $this->setContactPhone($expected = $this->faker()->phoneNumber());

        $this->contact_phone->shouldBe($expected);
    }

    function it_should_set_mobile_phone()
    {
        $expected = new MobilePhone(new PhoneNumber('639', '999999999'));

        $this->setMobilePhone($expected);
        $this->mobile_phone->shouldBe($expected);
    }

    function it_should_set_bank_details()
    {
        $this->setBankDetails($expected = new BankDetails());

        $this->bank_details->shouldBe($expected);
    }

    function it_should_return_its_xml_form()
    {
        $this->setName(
            Name::createTypeD(
                $this->faker()->firstName(),
                $this->faker()->lastName(),
                $this->faker()->lastName()
            )
        );
        $this->setAddress(
            new Address(
                $this->faker()->sentence(1),
                'MANILA',
                '1000',
                new CountryCode(new IsoCode('PH', 'PHP'), 'PHILIPPINES')
            )
        );
        $this->setPreferredCustomer(
            new PreferredCustomer(
                PermanentChange::from($this->faker()->randomElement(PermanentChange::values())),
                (string)\random_int(11_111_111_111, 99_999_999_999)
            )
        );

        $this->setComplianceDetails(new ComplianceDetails());

        $this->setEmail($this->faker()->email());
        $this->setPhoneCountryCode((string)\random_int(111111, 999999));
        $this->setContactPhone($this->faker()->phoneNumber());
        $this->setMobilePhone(new MobilePhone(new PhoneNumber('639', '999999999')));
        $this->setBankDetails(new BankDetails());

        $expected = new \SimpleXMLElement('<sender></sender>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this->setName(
            Name::createTypeD(
                $this->faker()->firstName(),
                $this->faker()->lastName(),
                $this->faker()->lastName()
            )
        );
        $this->setAddress(
            new Address(
                $this->faker()->sentence(3),
                'MANILA',
                '1000',
                new CountryCode(new IsoCode('PH', 'PHP'), 'PHILIPPINES')
            )
        );
        $this->setPreferredCustomer(
            new PreferredCustomer(
                PermanentChange::from($this->faker()->randomElement(PermanentChange::values())),
                (string)\random_int(11_111_111_111, 99_999_999_999)
            )
        );

        $this->setComplianceDetails(new ComplianceDetails());

        $this->setEmail($this->faker()->email());
        $this->setPhoneCountryCode((string)\random_int(111111, 999999));
        $this->setContactPhone($this->faker()->phoneNumber());
        $this->setMobilePhone(new MobilePhone(new PhoneNumber('639', '999999999')));
        $this->setBankDetails(new BankDetails());

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
