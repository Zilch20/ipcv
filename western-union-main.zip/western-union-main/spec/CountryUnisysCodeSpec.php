<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\CountryUnisysCode;
use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin CountryUnisysCode
 */
class CountryUnisysCodeSpec extends BaseObjectBehavior
{
    private string $code = 'AAA';

    function let()
    {
        $this->beConstructedWith($this->code);
    }

    function it_is_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_not_be_created_when_country_name_exceeds_3_characters()
    {
        $this->beConstructedWith('ASDF');
        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_return_its_xml_form()
    {
        $expected = new \SimpleXMLElement('<country_unisys_code></country_unisys_code>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
