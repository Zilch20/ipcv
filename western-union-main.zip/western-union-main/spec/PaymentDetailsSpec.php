<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\DestinationCountryCurrency;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\Option;
use IPCV\WesternUnion\OriginalDestinationCountryCurrency;
use IPCV\WesternUnion\OriginatingCountryCurrency;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\PaymentType;
use IPCV\WesternUnion\RecordingCountryCurrency;
use IPCV\WesternUnion\TransactionType;
use IPCV\WesternUnion\XmlHelper;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin PaymentDetails
 */
class PaymentDetailsSpec extends BaseObjectBehavior
{
    use XmlHelper;

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_transaction_type()
    {
        $this->setTransactionType($expected = $this->faker()->randomElement([TransactionType::WMF, TransactionType::WMN]));

        $this->transaction_type->shouldBe($expected);
    }

    function it_should_set_payment_type()
    {
        $this->setPaymentType($expected = PaymentType::CASH);

        $this->payment_type->shouldBe($expected);
    }

    function it_should_set_exchange_rate()
    {
        $this->setExchangeRate($expected = 1.000000501);

        $this->exchange_rate->shouldBe((string)$expected);
    }

    function it_should_set_recording_country_currency()
    {
        $this->setRecordingCountryCurrency($expected = new RecordingCountryCurrency(new IsoCode('PH', 'PHP')));

        $this->recording_country_currency->shouldBe($expected);
    }

    function it_should_set_originating_country_currency()
    {
        $this->setOriginatingCountryCurrency($expected = new OriginatingCountryCurrency(new IsoCode('PH', 'PHP')));

        $this->originating_country_currency->shouldBe($expected);
    }

    function it_should_set_destination_country_currency()
    {
        $this->setDestinationCountryCurrency($expected = new DestinationCountryCurrency(new IsoCode('PH', 'PHP')));

        $this->destination_country_currency->shouldBe($expected);
    }

    function it_should_set_pay_wo_id_indicator()
    {
        $this->setPayWoIdIndicator($expected = Option::Y);

        $this->pay_wo_id_indicator->shouldBe($expected);
    }

    function it_should_set_duplicate_detection_flag()
    {
        $this->setDuplicateDetectionFlag($expected = 'D');

        $this->duplicate_detection_flag->shouldBe($expected);
    }

    function it_should_set_original_destination_country_currency()
    {
        $expected = new OriginalDestinationCountryCurrency(new IsoCode('PH', 'PHP'));
        $this->setOriginalDestinationCountryCurrency($expected);

        $this->original_destination_country_currency->shouldBe($expected);
    }

    function it_should_return_its_xml_form()
    {
        $this
            ->setTransactionType($this->faker()->randomElement([TransactionType::WMF, TransactionType::WMN]))
            ->setPaymentType(PaymentType::CASH)
            ->setExchangeRate(1.0)
            ->setRecordingCountryCurrency(new RecordingCountryCurrency(new IsoCode('PH', 'PHP')))
            ->setOriginatingCountryCurrency(new OriginatingCountryCurrency(new IsoCode('PH', 'PHP')))
            ->setDestinationCountryCurrency(new DestinationCountryCurrency(new IsoCode('PH', 'PHP')))
            ->setPayWoIdIndicator(Option::Y)
            ->setDuplicateDetectionFlag('D')
            ->setOriginalDestinationCountryCurrency(new OriginalDestinationCountryCurrency(new IsoCode('PH', 'PHP')))
        ;

        $expected = new \SimpleXMLElement('<payment_details></payment_details>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this
            ->setTransactionType($this->faker()->randomElement([TransactionType::WMF, TransactionType::WMN]))
            ->setPaymentType(PaymentType::CASH)
            ->setExchangeRate(1.0)
            ->setRecordingCountryCurrency(new RecordingCountryCurrency(new IsoCode('PH', 'PHP')))
            ->setOriginatingCountryCurrency(new OriginatingCountryCurrency(new IsoCode('PH', 'PHP')))
            ->setDestinationCountryCurrency(new DestinationCountryCurrency(new IsoCode('PH', 'PHP')))
            ->setPayWoIdIndicator(Option::Y)
            ->setDuplicateDetectionFlag('D')
        ;

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
