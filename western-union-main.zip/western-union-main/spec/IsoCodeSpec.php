<?php

namespace spec\IPCV\WesternUnion;

use IPCV\WesternUnion\Exception\InvalidArgumentException;
use IPCV\WesternUnion\IsoCode;
use IPCV\WesternUnion\XmlSerializable;

/**
 * @mixin IsoCode
 */
class IsoCodeSpec extends BaseObjectBehavior
{
    function let()
    {
        $countryCode = 'PH';
        $currencyCode = 'PHP';

        $this->beConstructedWith($countryCode, $currencyCode);
    }

    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_return_country_code()
    {
        $this->country_code->shouldBe('PH');
    }

    function it_should_return_currency_code()
    {
        $this->currency_code->shouldBe('PHP');
    }

    function it_should_prevent_country_code_with_more_than_3_characters()
    {
        $this->beConstructedWith('PHILIPPINES', 'PHP');

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_prevent_currency_code_with_more_than_3_characters()
    {
        $this->beConstructedWith('PH', 'PHILIPPINE PESO');

        $this->shouldThrow(InvalidArgumentException::class)->duringInstantiation();
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $expected = new \SimpleXMLElement('<iso_code></iso_code>');

        $this->insertPropertiesAsChildToElement($expected, $this->toArray()->getWrappedObject());


        $this
            ->toSimpleXML()
            ->children()
            ->country_code
            ->asXML()
            ->shouldBe($expected->children()->country_code->asXML());

        $this
            ->toSimpleXML()
            ->children()
            ->currency_code
            ->asXML()
            ->shouldBe($expected->children()->currency_code->asXML());
    }

    function it_should_append_itself_when_passed_with_a_simplexml_element()
    {
        $this->insertPropertiesAsChildToElement(
            $expected = new \SimpleXMLElement('<iso_code></iso_code>'),
            $this->toArray()->getWrappedObject()
        );

        $this
            ->toSimpleXML(new \SimpleXMLElement('<pseudo-parent></pseudo-parent>'))
            ->iso_code
            ->children()
            ->country_code
            ->asXML()
            ->shouldBe($expected->children()->country_code->asXML());

        $this
            ->toSimpleXML(new \SimpleXMLElement('<pseudo-parent></pseudo-parent>'))
            ->iso_code
            ->children()
            ->currency_code
            ->asXML()
            ->shouldBe($expected->children()->currency_code->asXML());
    }
}
