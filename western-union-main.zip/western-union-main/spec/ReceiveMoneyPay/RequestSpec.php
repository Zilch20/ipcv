<?php

namespace spec\IPCV\WesternUnion\ReceiveMoneyPay;

use DOMDocument;
use IPCV\WesternUnion\Channel;
use IPCV\WesternUnion\Device;
use IPCV\WesternUnion\Financials;
use IPCV\WesternUnion\ForeignRemoteSystem;
use IPCV\WesternUnion\PaymentDetails;
use IPCV\WesternUnion\ReceiveMoneyPay\Request;
use IPCV\WesternUnion\ReceiveMoneyReceiver;
use IPCV\WesternUnion\XmlSerializable;
use spec\IPCV\WesternUnion\BaseObjectBehavior;

/**
 * @mixin Request
 */
class RequestSpec extends BaseObjectBehavior
{
    function it_should_be_xml_serializable()
    {
        $this->shouldImplement(XmlSerializable::class);
    }

    function it_should_set_device()
    {
        $this->setDevice($expected = new Device());

        $this->device->shouldBe($expected);
    }

    function it_should_set_channel()
    {
        $this->setChannel($expected = new Channel('FOO', 'BAR', 'BAZ'));

        $this->channel->shouldBe($expected);
    }

    function it_should_set_receiver()
    {
        $this->setReceiver($expected = new ReceiveMoneyReceiver());

        $this->receiver->shouldBe($expected);
    }

    function it_should_set_payment_details()
    {
        $this->setPaymentDetails($expected = new PaymentDetails());

        $this->payment_details->shouldBe($expected);
    }

    function it_should_set_financials()
    {
        $this->setFinancials($expected = new Financials());

        $this->financials->shouldBe($expected);
    }

    function it_should_set_money_transfer_key()
    {
        $this->setMoneyTransferKey($expected = $this->randomString(10));

        $this->money_transfer_key->shouldBe($expected);
    }

    function it_should_set_new_mtcn()
    {
        $this->setNewMtcn($expected = $this->randomString(16));

        $this->new_mtcn->shouldBe($expected);
    }

    function it_should_set_mtcn()
    {
        $this->setMtcn($expected = $this->randomString(16));

        $this->mtcn->shouldBe($expected);
    }

    function it_should_set_pay_or_do_not_pay_indicator()
    {
        $this->setPayOrDoNotPayIndicator($expected = 'P');

        $this->pay_or_do_not_pay_indicator->shouldBe($expected);
    }

    function it_should_set_foreign_remote_system()
    {
        $this->setForeignRemoteSystem($expected = new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'));

        $this->foreign_remote_system->shouldBe($expected);
    }

    function it_should_return_its_xml_form_without_parent()
    {
        $this
            ->setDevice(new Device())
            ->setChannel(new Channel('FOO', 'BAR', 'BAZ'))
            ->setReceiver(new ReceiveMoneyReceiver())
            ->setPaymentDetails(new PaymentDetails())
            ->setFinancials(new Financials())
            ->setMoneyTransferKey($this->randomString(10))
            ->setNewMtcn($this->randomString(16))
            ->setMtcn($this->randomString(16))
            ->setPayOrDoNotPayIndicator('P')
            ->setForeignRemoteSystem(new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'))
        ;

        $xml =  <<<XML
<soapenv:Envelope 
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
    xmlns:xrsi="http://www.westernunion.com/schema/xrsi"
    >
    <soapenv:Header/>
    <soapenv:Body>
        <xrsi:receive-money-pay-request>
            <device/>
            <channel/>
            <receiver/>
            <payment_details/>
            <financials/>
            <money_transfer_key/>
            <new_mtcn/>
            <mtcn/>
            <pay_or_do_not_pay_indicator/>
            <foreign_remote_system/>
        </xrsi:receive-money-pay-request>
    </soapenv:Body>
</soapenv:Envelope>
XML;

        $doc = new DOMDocument();
        $doc->loadXML($xml);

        $root = $doc->documentElement->ownerDocument;

        foreach ($this->toArray()->getWrappedObject() as $key => $prop) {
            if ($prop instanceof XmlSerializable) {
                $d = new DOMDocument();
                $d->loadXML($prop->toSimpleXML()->asXML());

                $xrsi = $root
                    ->documentElement
                    ->getElementsByTagName('Body')
                    ->item(0)
                    ->childNodes
                    ->item(1);

                $xrsi->replaceChild(
                    $root->importNode($d->documentElement, true),
                    $root->getElementsByTagName($key)->item(0)
                );
                continue;
            }
            $root->getElementsByTagName($key)->item(0)->nodeValue = $prop;
        }

        $expected = new \SimpleXMLElement($doc->saveXML());

        $this
            ->toSimpleXML()
            ->asXML()
            ->shouldBe($expected->asXML());
    }

    function it_should_append_itself_to_parent_when_a_parent_is_passed()
    {
        $this
            ->setDevice(new Device())
            ->setChannel(new Channel('FOO', 'BAR', 'BAZ'))
            ->setReceiver(new ReceiveMoneyReceiver())
            ->setPaymentDetails(new PaymentDetails())
            ->setFinancials(new Financials())
            ->setMoneyTransferKey($this->randomString(10))
            ->setNewMtcn($this->randomString(16))
            ->setMtcn($this->randomString(16))
            ->setPayOrDoNotPayIndicator('P')
            ->setForeignRemoteSystem(new ForeignRemoteSystem('FOO', 'BAR', 'BAZ'))
        ;

        $expected = self::createPseudoParentElement();

        $this->appendChildToParent($expected, $this->toSimpleXML()->getWrappedObject());

        $this
            ->toSimpleXML(self::createPseudoParentElement())
            ->asXML()
            ->shouldBe($expected->asXML());
    }
}
